# 技术支持 · Support

## 简介 · Introduction

社区可以帮助解决开发问题；需要私密、个性化协助时，可以提交技术支持工单。付费支持可以在保护项目知识产权的条件下分享算法，并调查实时策略问题。提交工单需要组织分配支持席位。

支持席位有 Bronze、Silver、Gold 三档。工单不能替代自行阅读文档和研究；若需要更深入的开发服务，可以考虑 Integration Partner。

## 功能 · Features

### 错误报告

怀疑 LEAN 存在问题时，可通过邮件、Discord 或论坛提供最小可复现回测。官方确认后会创建 GitHub Issue，可订阅它跟踪修复。历史数据问题建议在数据门户的 Data Issues 页面报告。

### 邮件与 API 支持

付费席位可通过工单私密交流。通常按提交顺序处理，较高档位优先。REST API 同样支持创建、列出、读取、回复和关闭工单。

### 知识产权保护

通过私密工单附加回测或实时部署时，仅获授权的支持人员能访问。原文说明此类人员经过筛选、背景检查，并已在公司工作至少两年。公开发到论坛则不是私密支持。

### 实时调试与设计建议

付费支持可调查实时部署问题、协助修复并准备重新部署。论坛和 Discord 不提供这类实时问题支持。Silver 和 Gold 还可提供算法设计建议，例如采用通用设计模式、减少代码量和提高回测效率。

### Gold 服务

Gold 可提供 Discord 私密聊天室、每月最多一小时电话咨询，以及 Local Platform、LEAN CLI、REST API 等本地开发相关支持。电话咨询前建议整理问题。

### 功能对照

| 功能 | 社区 | Bronze | Silver | Gold |
| --- | --- | --- | --- | --- |
| 错误报告 | 支持 | 支持 | 支持 | 支持 |
| 邮件支持 | 不支持 | 支持 | 支持 | 支持 |
| API 支持 | 不支持 | 支持 | 支持 | 支持 |
| 私密工单知识产权保护 | 不支持 | 支持 | 支持 | 支持 |
| 实时交易调试 | 不支持 | 支持 | 支持 | 支持 |
| 算法设计建议 | 不支持 | 不支持 | 支持 | 支持 |
| 私密聊天室 | 不支持 | 不支持 | 不支持 | 支持 |
| 电话咨询 | 不支持 | 不支持 | 不支持 | 支持 |
| 本地开发支持 | 不支持 | 不支持 | 不支持 | 支持 |

## 查看所有席位 · View All Seats

登录 Algorithm Lab，打开 **Organization > Members**。Team Management 页面展示组织中支持席位的分配。

## 添加席位 · Add Seats

1. 打开 Team Management，滚动到 **Organization Support（组织技术支持）**。
2. 点击 **Add Seat（添加席位）**。
3. 在支持页面选择档位，点击 **Select**。
4. 在 **Assign … Seat（分配席位）** 中选择成员。
5. 点击带价格的 **Add Seat +$…** 确认购买。

## 查看所有工单 · View All Tickets

打开 **Support > Organization Tickets**，即可查看组织支持历史。点击 **Closed（已关闭）** 查看已关闭工单，点击具体工单查看对话。

## 创建新工单 · Open New Tickets

1. 在左侧导航点击 **Support**，填写主题和消息。
2. 如需附项目，点击 **Add Project**，选择项目后点 **OK**。
3. 可继续点击 **Add Live Deployment** 或 **Add Backtest**，选择相应运行记录。
4. 勾选允许 QuantConnect Support Staff 查看项目的授权选项。
5. 点击 **Send（发送）**。

## 评论工单 · Comment on Tickets

在 Support History 打开工单；如已关闭，先点击 Closed。填写回复，点击 **Send**。

## 关闭工单 · Close Tickets

打开工单，可填写关闭原因，再点击 **Send and Close Ticket（发送并关闭工单）**。

## 重新打开工单 · Open Closed Tickets

在 Support History 点击 **Closed**，打开目标工单，可填写重新打开的原因，点击 **Open Ticket and Send**。

## 工单配额 · Ticket Quotas

下表为所读原文的数量与响应时间，不代表本次核验过的服务承诺。

| 档位 | 工单额度 | 响应时间（小时） |
| --- | --- | --- |
| Gold | 16 | 24 |
| Silver | 8 | 48 |
| Bronze | 4 | 72 或尽力响应 |

额度按滚动一个月恢复，不是在月初或账单日重置。需要即时帮助可与 Mia 对话。

## 服务时间 · Hours of Operation

人工支持团队周一至周五工作；AI 支持助手 Mia 全天候运行。原文未在本节提供具体工作时区或每日小时范围。
