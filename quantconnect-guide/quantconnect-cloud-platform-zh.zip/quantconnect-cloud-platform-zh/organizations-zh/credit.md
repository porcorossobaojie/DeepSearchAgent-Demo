# 平台点数 · Credit

## 简介 · Introduction

QuantConnect Credit（QCC）用于平台的小额付费，例如参数优化、下载数据、论坛赠奖，以及短信和超过免费额度的通知。

所读原文换算为 **1 QCC = 0.01 美元**，实际购买价格以结算页为准。点数属于组织，不属于个人，因此组织成员都可能使用该余额。

## 参数优化 · Optimizing Parameters

组织需有 QCC 才能使用参数优化。优化节点按时间租用，全部回测执行越久，消耗越多。任务开始前有费用估算，但实际时长无法预先精确知道，最终消耗可能不同。

## 下载数据集 · Downloading Datasets

可用 QCC 从 Dataset Market 将许可范围内的数据下载到本机，按文件或按天计费，具体取决于数据集。它与 Object Store 下载权限是不同机制，应分别阅读 Licensing 和存储许可说明。

## 赠送他人 · Giving to Others

可在论坛以 QCC 奖励他人的贡献。下面保留原文奖项及费用，并提供中文名称；这不是当前价格保证。

| 奖项（保留原名） | 中文说明 | QCC |
| --- | --- | --- |
| 银奖 · Silver Award | 量化研究者之间的认可，鼓励继续努力。 | 80 |
| 金奖 · Gold Award | 认可出色工作，送上一颗金星。 | 600 |
| 铂金奖 · Platinum Award | 表彰经得起时间考验、坚实而实用的贡献。 | 1,200 |
| 卓越勋章 · Medal for Excellence | 由平台工作人员授予对社区有卓越贡献的成员。 | 3,000 |
| 钚元素奖 · Plutonium Award | 认可令人惊叹的帖子，表达对作者的感谢。 | 2,000 |
| 文档莎士比亚奖 · Docs Shakespeare | 表彰文档贡献，其修改与示例可帮助后来者。 | 500 |
| 诺贝尔学者奖 · Nobel Laureate | 表彰量化研究方面的进展。 | 80 |
| 意大利面代码奖 · Spaghetti Code Award | 幽默地认可流程盘根错节却能编译运行的代码。 | 300 |
| 绝地量化师 · Jedi Quant | 认可展现量化潜力与编程能力的贡献。 | 200 |
| 实时交易者 · Live Trader | 认可看起来颇为惊险的交易经历。 | 50 |
| 今天学到了 · Today I Learned | 感谢分享新知识。 | 50 |
| 机器反学习 · Machine Unlearning | 幽默地表达希望让计算机承担全部工作的想法。 | 150 |
| 完全过拟合 · Totally Overfit | 幽默地评价到处堆满参数的过拟合现象。 | 80 |
| 脑洞大开奖 · Mind Blown Award | 表彰令人震撼、超出想象的内容。 | 80 |
| 研究伦勃朗奖 · Research Rembrandt | 认可将图表与分析组织得如艺术品的 Jupyter 笔记本。 | 100 |
| 开曼群岛奖 · Cayman Island Award | 幽默地表达一起坐船创办基金的愿望。 | 800 |
| 印钞机奖 · Printing Money Award | 奖励盈利算法。 | 100 |
| 团结力量奖 · Stronger Together Award | 表达携手合作的支持。 | 120 |
| 感谢支持奖 · Appreciate the Support Award | 量化交易路途艰难，感谢伸出援手。 | 250 |
| 匠心大师 · Master Craftsman | 表彰将原材料打磨成有益成果的精湛技艺。 | 600 |


奖项用于表达对研究、代码、文档、支持和社区贡献的认可。Medal for Excellence 由 QuantConnect 工作人员授予特别贡献者。

## 购买 QCC · Purchase QCC

1. 打开 Billing，滚动到 **Organization Credit (QCC)**。
2. 点击 **Purchase Credit**，选择组合，再点 **Continue**。
3. 如果首选组织已有信用卡并希望使用它，点击 **Purchase**；否则填写卡信息后购买。

**购买 QCC 只能向首选组织收费。** 如要向另一个已加入的组织收费，应先将其设置为首选组织。
