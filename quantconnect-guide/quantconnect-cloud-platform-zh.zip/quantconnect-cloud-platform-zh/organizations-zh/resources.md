# 计算与存储资源 · Resources

> 规格、额度和价格为所读源码版本中的信息，实际可用资源与限制以当前平台为准。下文会保留发现的原文不一致之处。

## 简介 · Introduction

组织可订阅硬件，运行回测、研究笔记本和托管实时策略，也可通过 Object Store 在不同运行之间存储数据。资源由组织成员共享，减少闲置；团队成员可以共同使用一组节点。

## 回测节点 · Backtesting Nodes

回测节点越多，可同时运行的回测越多。更强 CPU 可以加快运算，更多内存适合机器学习训练、期权数据和大股票池。

<table class="qc-table table">
    <thead>
        <tr>
            <th>名称</th>
            <th>CPU 核心数</th>
            <th>处理速度（GHz）</th>
            <th>内存（GB）</th>
            <th>GPU</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>B-MICRO</td>
            <td>2</td>
            <td>3.3</td>
            <td>8</td>
            <td>0</td>
        </tr>
        <tr>
            <td>B2-8</td>
            <td>2</td>
            <td>4.9</td>
            <td>8</td>
            <td>0</td>
        </tr>
        <tr>
            <td>B4-12</td>
            <td>4</td>
            <td>4.9</td>
            <td>12</td>
            <td>0</td>
        </tr>
        <tr>
            <td>B4-16-GPU</td>
            <td>4</td>
            <td>3</td>
            <td>16</td>
            <td>1/3</td>
        </tr>
        <tr>
            <td>B8-16</td>
            <td>8</td>
            <td>4.9</td>
            <td>16</td>
            <td>0</td>
        </tr>
    </tbody>
</table>

第一个组织包含免费 B-MICRO 节点。原文说明启动有 20 秒延迟，每天最多 200 次回测；升级付费套餐并添加新回测节点后会替换该节点并解除这些限制。

IDE 的 Resources 面板展示节点状态。默认选择性能最佳的可用节点，也可手动指定。CPU 采用公平使用原则，GPU 最多三名成员共享；GPU 更适合可并行的重复计算。不训练模型时，数据传输开销可能使 GPU 反而更慢。

**不能将普通回测节点用于参数优化**；优化使用单独的优化资源。价格参见官方 Pricing 页面。

## 研究节点 · Research Nodes

研究节点用于交互式 Jupyter 研究环境。更多计算能力和内存可以处理更多数据、加速笔记本计算。

<table class="qc-table table">
    <thead>
        <tr>
            <th>名称</th>
            <th>CPU 核心数</th>
            <th>处理速度（GHz）</th>
            <th>内存（GB）</th>
            <th>GPU</h4>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>R1-4</td>
            <td>1</td>
            <td>2.4</td>
            <td>4</td>
            <td>0</td>
        </tr>
        <tr>
            <td>R2-8</td>
            <td>2</td>
            <td>2.4</td>
            <td>8</td>
            <td>0</td>
        </tr>
        <tr>
            <td>R4-12</td>
            <td>4</td>
            <td>2.4</td>
            <td>12</td>
            <td>0</td>
        </tr>
        <tr>
            <td>R4-16-GPU</td>
            <td>4</td>
            <td>3</td>
            <td>16</td>
            <td>1/3</td>
        </tr>
        <tr>
            <td>R8-16</td>
            <td>8</td>
            <td>2.4</td>
            <td>16</td>
            <td>0</td>
        </tr>
    </tbody>
</table>

第一个组织提供免费 R1-4；订阅付费研究节点后会替换免费节点。启动研究环境时默认选择最佳可用节点，也可指定。CPU 采用公平使用原则，GPU 最多三名成员共享。价格参见官方 Pricing。

## 实时交易节点 · Live Trading Nodes

每个托管运行的实时算法需要一个实时节点。服务器位置取决于部署区域。更强节点支持更大标的集合，并提供更多模型训练时间。

<table class="qc-table table">
   <thead>
      <tr>
         <th>名称</th>
         <th>CPU 核心数</th>
         <th>处理速度（GHz）</th>
         <th>内存（GB）</th>
         <th>GPU</th>
      </tr>
   </thead>
   <tbody>
      <tr>
         <td>L-MICRO</td>
         <td>1</td>
         <td>2.6</td>
         <td>0.5</td>
         <td>0</td>
      </tr>
      <tr>
         <td>L1-1</td>
         <td>1</td>
         <td>2.6</td>
         <td>1</td>
         <td>0</td>
      </tr>
      <tr>
         <td>L1-2</td>
         <td>1</td>
         <td>2.6</td>
         <td>2</td>
         <td>0</td>
      </tr>
      <tr>
         <td>L2-4</td>
         <td>2</td>
         <td>2.6</td>
         <td>4</td>
         <td>0</td>
      </tr>
      <tr>
         <td>L8-16-GPU</td>
         <td>8</td>
         <td>3.1</td>
         <td>16</td>
         <td>1/2</td>
      </tr>
   </tbody>
</table>

原文估算每个行情订阅约需 5 MB 内存，512 MB 的 L-MICRO 约百个订阅就可能仅因行情占用而耗尽。建议平均使用量低于内存上限的 80%，L-MICRO 约为 410 MB。

LEAN 检查平滑后的 10 分钟均值，同时允许单次原始采样短暂达到两倍上限。因此短时尖峰与持续超限的影响不同。相关指标及优化方法见本节原文链接。

默认选择最佳可用节点，也可指定。CPU 采用公平使用原则，GPU 最多两名成员共享。GPU 不一定使所有算法更快。价格参见 Pricing。

## 智能体节点 · Agent Nodes

智能体节点为 AI 模型提供量化金融任务所需的工具、数据和上下文，用于部署智能体任务及连接远程 MCP 服务。节点越多，可并发的任务越多；更多 CPU 与内存适合较复杂任务。

<table class="qc-table table">
    <thead>
        <tr>
            <th>名称</th>
            <th>CPU 核心数</th>
            <th>内存（GB）</th>
            <th>智能体数</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>A-MICRO</td>
            <td>1</td>
            <td>1</td>
            <td>1</td>
        </tr>
        <tr>
            <td>A1-1</td>
            <td>1</td>
            <td>1</td>
            <td>1</td>
        </tr>
        <tr>
            <td>A4-8</td>
            <td>4</td>
            <td>8</td>
            <td>4</td>
        </tr>
        <tr>
            <td>A16-32</td>
            <td>16</td>
            <td>32</td>
            <td>16</td>
        </tr>
    </tbody>
</table>

首个组织提供免费 A-MICRO，原文额度为每月 100,000 tokens。升级付费套餐并添加智能体节点后，会替换免费节点并解除该月度上限。付费节点仍有按滚动一周计算的公平使用额度；超出后可升级型号或使用自己的模型密钥。免费 A-MICRO 不能连接远程 MCP 服务，需要付费智能体节点。任务默认使用最佳可用节点，也可在资源面板指定。

## 共享资源 · Sharing Resources

组织节点在全部成员间共享，以减少闲置。Algorithm Lab 可查看组织中哪些节点可用。

## 节点配额 · Node Quotas

<table class="qc-table table">
   <thead>
      <tr>
         <th>套餐</th>
         <th>回测</th>
         <th>研究</th>
         <th>实时交易</th>
      </tr>
   </thead>
   <tbody>
      <tr>
         <td>Free</td>
         <td>1</td>
         <td>1</td>
         <td>0</td>
      </tr>
      <tr>
         <td>Quant Researcher</td>
         <td>2</td>
         <td>1</td>
         <td>2</td>
      </tr>
      <tr>
         <td>Team</td>
         <td>10</td>
         <td>10</td>
         <td>10</td>
      </tr>
      <tr>
         <td>Trading Firm</td>
         <td>不限</td>
         <td>不限</td>
         <td>不限</td>
      </tr>
      <tr>
         <td>Institution</td>
         <td>不限</td>
         <td>不限</td>
         <td>不限</td>
      </tr>
   </tbody>
</table>

表中“不限”表示该套餐未设置相应数量上限，不表示计算资源免费。

## 模型训练配额 · Training Quotas

通常 `on_data` 必须在 10 分钟内返回；`train` 可以使用额外训练时间。平台采用“漏桶”机制：训练时间储备有容量上限，并随现实时间逐渐补充，超过常规 10 分钟训练时间后才消耗额外储备。

<table class="qc-table table">
   <thead>
      <tr>
         <th>型号</th>
         <th>额外容量（分钟）</th>
         <th>补充速率（分钟/天）</th>
      </tr>
   </thead>
   <tbody>
      <tr>
         <td>B-MICRO</td>
         <td>20</td>
         <td>1</td>
      </tr>
      <tr>
         <td>B2-8</td>
         <td>30</td>
         <td>5</td>
      </tr>
      <tr>
         <td>B4-12</td>
         <td>60</td>
         <td>10</td>
      </tr>
      <tr>
         <td>B8-16</td>
         <td>90</td>
         <td>15</td>
      </tr>
      <tr>
         <td>L-MICRO</td>
         <td>30</td>
         <td>5</td>
      </tr>
      <tr>
         <td>L1-1</td>
         <td>60</td>
         <td>10</td>
      </tr>
      <tr>
         <td>L1-2</td>
         <td>90</td>
         <td>15</td>
      </tr>
      <tr>
         <td>L1-4</td>
         <td>120</td>
         <td>20</td>
      </tr>
   </tbody>
</table>

补充速率按现实时间计算，不是回测时间。回测中 `train` 同步阻塞算法；实时环境中异步运行，需要确认模型准备好后再使用，并通过信号量等方式协调线程。

原文训练配额表使用 `L1-4`，而节点规格表列出 `L2-4`；本文保留原文差异，不擅自合并型号。

## 日志配额 · Log Quotas

服务条款不允许通过日志导出数据集信息。

<table class="qc-table table">
   <thead>
      <tr>
         <th>套餐</th>
         <th>每次回测日志</th>
         <th>每天日志</th>
      </tr>
   </thead>
   <tbody>
      <tr>
         <td>Free</td>
         <td>10KB</td>
         <td>3MB</td>
      </tr>
      <tr>
         <td>Quant Researcher</td>
         <td>100KB</td>
         <td>3MB</td>
      </tr>
      <tr>
         <td>Team</td>
         <td>1MB</td>
         <td>10MB</td>
      </tr>
      <tr>
         <td>Trading Firm</td>
         <td>5MB</td>
         <td>50MB</td>
      </tr>
      <tr>
         <td>Institution</td>
         <td>不限</td>
         <td>不限</td>
      </tr>
   </tbody>
</table>

删除产生过日志的项目或回测不会返还日志额度。每日额度按滚动 24 小时恢复，而不是午夜重置。

本节原文称实时项目日志最多保存 1,000,000 行、两年；Projects 的公共日志片段却写 100,000 行、一年。**源码存在不一致，尚未核验哪项为当前有效值。**

建议只记录关键状态变化，避免每个时间步都写日志，并用调试器检查运行时对象。剩余额度可在 **Organization > Resources** 查看。

## 代码会话配额 · Coding Session Quotas

打开项目会占用一个代码会话。免费用户同一时间只有一个活动会话，跨其全部免费组织计算。

<table class="qc-table table">
    <thead>
        <tr>
            <th>套餐</th>
            <th>初始代码会话数</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Quant Researcher</td>
            <td>2</td>
        </tr>
        <tr>
            <td>Team</td>
            <td>4</td>
        </tr>
        <tr>
            <td>Trading Firm</td>
            <td>8</td>
        </tr>
        <tr>
            <td>Institution</td>
            <td>16</td>
        </tr>
    </tbody>
</table>

付费额度按用户在各组织中分别计算；不是组织所有成员共用一份。若组织实时节点数更多，会话额度会相应增加，以便查看全部实时策略。

## 文件配额 · File Quotas

<table class="qc-table table">
   <thead>
      <tr>
         <th>套餐</th>
         <th>每项目最多文件数</th>
         <th>单文件大小上限（KB）</th>
      </tr>
   </thead>
   <tbody>
      <tr>
         <td>Free</td>
         <td>25</td>
         <td>32</td>
      </tr>
      <tr>
         <td>Quant Researcher</td>
         <td>50</td>
         <td>64</td>
      </tr>
      <tr>
         <td>Team</td>
         <td>75</td>
         <td>128</td>
      </tr>
      <tr>
         <td>Trading Firm</td>
         <td>100</td>
         <td>256</td>
      </tr>
      <tr>
         <td>Institution</td>
         <td>250</td>
         <td>256</td>
      </tr>
   </tbody>
</table>

共享代码库也属于项目，拥有独立配额。可将稳定且多项目复用的代码移入共享库；修改共享库会影响所有引用它的项目。

## 项目工作空间配额 · Project Workspace Quotas

工作空间包含项目文件、回测、优化和实时部署结果。表格是每位组织用户用于全部项目工作空间的总额度。

<table class="qc-table table">
   <thead>
      <tr>
         <th>套餐</th>
         <th>总额度（GB）</th>
      </tr>
   </thead>
   <tbody>
      <tr>
         <td>Free</td>
         <td>1</td>
      </tr>
      <tr>
         <td>Quant Researcher</td>
         <td>10</td>
      </tr>
      <tr>
         <td>Team</td>
         <td>25</td>
      </tr>
      <tr>
         <td>Trading Firm</td>
         <td>50</td>
      </tr>
      <tr>
         <td>Institution</td>
         <td>100</td>
      </tr>
   </tbody>
</table>

减少无用日志、删除旧项目和旧回测结果，可以控制空间使用量。

## 实时通知配额 · Live Trading Notification Quotas

每个实时算法的邮件、Telegram 和 Webhook 免费通知额度按小时计算。

<table class="qc-table table">
    <thead>
        <tr>
            <th>套餐</th>
            <th>每小时通知数</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Free</td>
            <td>不适用</td>
        </tr>
        <tr>
            <td>Quant Researcher</td>
            <td>20</td>
        </tr>
        <tr>
            <td>Team</td>
            <td>60</td>
        </tr>
        <tr>
            <td>Trading Firm</td>
            <td>240</td>
        </tr>
        <tr>
            <td>Institution</td>
            <td>3,600</td>
        </tr>
    </tbody>
</table>

超过免费额度，每条原文计费 1 QCC；发往美国或加拿大号码的短信每条 1 QCC，国际号码每条 10 QCC。费用以当前平台为准。

## 查看所有节点 · View All Nodes

登录 Algorithm Lab，打开 **Organization > Resources**。右上角按钮可切换显示方式。表格视图包含：

| 字段 | 中文说明 |
| --- | --- |
| Name | 节点名称 |
| Machine Type | 节点型号与规格 |
| In Use By | 使用节点的成员 |
| Host | 实时交易服务器名称 |
| Assets | 避免内存错误的建议最大标的数 |
| Actions | 可执行的操作 |

## 添加节点 · Add Nodes

需要账单权限。原文说明添加节点会重新计算整个订阅周期，收取当前与新订阅的差价，包含节点与订阅延期部分。

1. 打开 **Resources**。
2. 点击对应类型的 **Add … Node（添加节点）**。
3. 选择规格。
4. 点击 **Add Node**，资源页面会出现新节点。

## 移除节点 · Remove Nodes

需要账单权限。移除节点会重新计算订阅周期；周期中移除产生的按比例余额记入组织账户，用于未来账单。

1. 打开 **Organization > Home**，点击 **Edit Plan（编辑方案）**。
2. 进入 **Customize Plan > Build Your Own Pack > Compute Nodes**。
3. 点击目标型号旁的减号。
4. 点击 **Proceed to Checkout（前往结算）**。

## 重命名节点 · Rename Nodes

1. 打开 Resources，在目标节点点击 **Set Name（设置名称）**。
2. 输入名称，点击 **Save Changes**。

## 停止节点 · Stop Nodes

停止其他成员使用的节点需要相应权限。停止会终止节点上正在运行的回测、研究或实时会话。**停止实时节点不会改变持仓，只会停止算法执行。**

1. 打开 Resources，点击右上三横线切换为表格。
2. 在目标节点所在行点击 **Stop（停止）**。
