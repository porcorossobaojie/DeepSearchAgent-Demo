# 组织管理 · Administration

## 简介 · Introduction

可以在 Algorithm Lab 查看和管理组织。平台说明其不主张用户算法的知识产权，具体项目归属取决于组织类型及相关协议。

## 知识产权 · Intellectual Property

代码默认私有，可由项目共享对象，以及提交私密工单时获准的支持工程师访问。公开发布到论坛会改变其公开状态，不应把公开链接用于私密协作。

Free、Quant Researcher 是个人组织，项目归用户；Team 的项目归创建者；Trading Firm、Institution 组织中的员工项目归公司，需在对应组织内创建。原文用这一机制对应公司聘用开发人员时的代码归属需求。

以上是说明性翻译，正式归属仍以适用协议和条款为准。

## 企业品牌 · Corporate Branding

可自定义组织图片、名称和描述。Trading Firm 或 Institution 还可将 Algorithm Lab 集成到企业网站，让导航标志和配色与企业品牌相符。

## 迁移项目 · Migrating Projects

组织管理员可将项目迁移到自己加入的另一个组织。项目文件会复制，**Object Store 内容不会随迁移保留**。具体操作见 Projects 的“迁移项目”。

## 查看组织首页 · View the Organization Homepage

打开 **Organization > Home**。页面顶部展示品牌和统计，其余区域如下：

| 区域 | 功能 |
| --- | --- |
| Actions | 添加节点 |
| Resources | 查看和管理节点 |
| Billing | 查看和管理账单 |
| Team | 管理成员 |
| Support History | 查看工单 |
| Encryption Keys | 查看和管理加密密钥 |
| Backtesting Out of Sample Period | 调整样本外保留期 |
| Plan | 查看和更换套餐 |
| Credit Balance | 查看和购买 QCC |

## 编辑组织品牌 · Edit the Organization Branding

### 图片

1. 打开组织首页，点击组织图片。
2. 点击 **Choose file**，选择文件后点 **Open**。
3. 图片须为 `.gif`、`.jpg` 或 `.png`，小于 1 MB。
4. 点击 **Save**；出现 Photo Uploaded 表示完成。

### 名称

鼠标移到组织名称上，点击铅笔图标，输入新名称，再点 **Save Changes**。

## 查看所有组织 · View All Organizations

登录后点击顶部 **Connected as: 组织名**，即可查看自己加入的全部组织。

## 添加组织 · Add Organizations

点击 **Connected as**，在 Switch Organization 面板点 **Create Organization**，输入唯一名称并点 **Add**。

## 切换组织 · Switch Organizations

点击 **Connected as**，选择目标组织。顶部会显示新的当前组织。

## 设置首选组织 · Set a Preferred Organization

1. 点击顶部 **Connected as**。
2. 在 Switch Organization 的 **Preferred（首选）** 列，勾选目标组织的单选项。
3. 出现 Preferred organization selected 后，刷新页面以连接首选组织。

## 获取组织 ID · Get Organization Id

打开 Organization > Home，网址 `/organization/` 后面的字符串是组织 ID。

## 样本外保留期 · Out of Sample Period

组织管理者可保留最近若干个月数据，不供开发阶段的回测使用。例如保留一年，回测便不能使用最近一年数据。

在组织首页找到 **Backtesting Out of Sample Period**，调整时长；选择 **No Holdout Period** 表示不设保留期。
