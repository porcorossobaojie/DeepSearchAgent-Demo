# 账单与订阅 · Billing

## 简介 · Introduction

组织所有者负责账单，Trading Firm 和 Institution 可委派相关权限。原文说明支付资料交给 Stripe 处理，而不是由 QuantConnect 保存。

取消订阅会导致实时节点停止，因此订阅默认按月自动续费。

## 查看账单信息 · View Billing Information

登录并进入 **Organization > Billing**。顶部展示费用、日期和周期。

| 区域 | 内容 |
| --- | --- |
| Details | 账单姓名和地址 |
| Credit Card | 付款信用卡 |
| Products | 组织订阅明细 |
| Invoices | 发票 |
| Organization Credit (QCC) | 平台点数购买和支出 |

## 编辑账单资料 · Edit Billing Details

在 Billing 页的 **Details** 区域点击 **Edit**，填写新资料，再点 **Save**。

## 编辑信用卡 · Edit the Credit Card

### 添加

打开 Billing，点击 **Add Card**，输入卡信息并点 **Save**。Credit Card 区域会显示卡号后四位。

### 更换

在 Credit Card 区域点 **Edit**，填写新卡并保存。

### 移除

点击 **Remove**，再点 **OK**。页面显示 No entries found 表示已无卡记录。

## 下载发票与收据 · Download Invoices and Receipts

1. 在 Billing 页滚动到 **Invoices**。
2. 点击对应记录旁的 **Download as PDF**。
3. 选择 **Download invoice** 或 **Download receipt**，保存到本机。

## 更改组织套餐 · Change Organization Tiers

### 更换付费套餐

1. 打开 Organization > Home，点击 **Edit Plan**。
2. 在 **Choose a Plan** 中，点击目标套餐下的 **CHOOSE TIER**。
3. 选择预设组合，或 **Build Your Own Pack（自定义组合）**。预设包含团队席位、支持席位和节点；自定义可选择席位、附加功能与行情订阅。
4. 选择月付或年付；如有优惠码，点击 **+ Add Coupon**。
5. 未添加信用卡时，点击 **Proceed to Checkout** 并填写。
6. 点击 **Update Subscriptions** 或 **Subscribe Now**。

### 降级到 Free

原文明确指出：**降级到 Free 会删除数据，且删除是永久的**。如果只是降低费用，可考虑仅保留 Quant Researcher 席位；如果短期不用，可查看暂停订阅选项。

1. 打开 Downgrade 页面，点击 **Cancel My Plan**。
2. 阅读并确认后果：失去节点扩展；无法协作；回测结果和日志删除；超过免费限制的项目删除；Object Store 数据删除；实时算法停止且日志删除。
3. 如需保留项目，可先使用 LEAN CLI 的 `lean cloud pull`。结果可通过 Read Backtest、Read Live Algorithm API 保存。Object Store 仍受下载许可限制，普通组织不能假定可以导出后备份。
4. 勾选理解订阅将在当前周期结束时终止的确认项，点击 **Cancel My Subscription**。

本节只是翻译操作，不会替你执行订阅或删除动作。

## 暂停与恢复订阅 · Pause and Resume Subscriptions

暂时一两个月不用时，可暂停订阅。暂停期间访问受限，但云端配置、项目文件和设置会保留，恢复后回到原状态。

暂停：在 Downgrade 页选择 **Pause for 1 month** 或 **Pause for 2 months**，再点 **Pause My Subscription**。

恢复：打开 Billing，点击 **Resume**。提前恢复时，按实际暂停时长计算相应余额。

## 付款失败 · Payment Failures

原文说明 Stripe 会在付款失败后的 6–12 小时自动重试。实际付款状态以账单系统为准。
