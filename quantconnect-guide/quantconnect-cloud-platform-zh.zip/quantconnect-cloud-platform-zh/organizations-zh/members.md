# 成员管理 · Members

## 简介 · Introduction

用户可加入多个组织；组织成员数量取决于套餐。成员共享组织资源，但不会自动获得其他成员项目的访问权；需向项目添加协作者。

Trading Firm 和 Institution 的管理者可以给成员分配额外权限。

## 查看所有席位 · View All Seats

组织每名成员需要一个团队席位。打开 **Billing（账单）**，滚动到 **Products（产品）** 查看已有席位数量。

## 添加席位 · Add Seats

需要组织账单权限。

1. 在组织首页点击 **Edit Plan**。
2. 进入 **Customize Plan > Build Your Own Pack > Organization Seats**。
3. 在对应套餐的 Seats 区域点击加号。
4. 点击 **Proceed to Checkout**。

## 查看所有成员 · View All Members

打开 **Organization > Members**，Team Management 页面展示组织成员。右上角按钮可切换表格和卡片视图。

## 成员数量配额 · Membership Quotas

下表按所读源码转述，实际以当前平台为准。

| 套餐 | 最少成员数 | 最多成员数 |
| --- | --- | --- |
| Free | 1 | 1 |
| Quant Researcher | 1 | 1 |
| Team | 2 | 10 |
| Trading Firm | 2 | 不限 |
| Institution | 2 | 不限 |

## 添加成员 · Add Members

需要空余团队席位，以及添加成员权限。

1. 打开 Team Management，点击 **Add Member（添加成员）**。
2. 输入新成员登录 QuantConnect 使用的邮箱，点击 **Add Member**。
3. 若有权限编辑成员权限，选择权限并点 **Save Changes**；否则点击 **Cancel** 退出权限编辑。

新成员会出现在列表中。添加成员窗口也可生成邀请链接，持有该链接的人可以加入组织。新成员加入后，需要切换到此组织才能使用资源和参与协作。

## 添加技术支持 · Add Support

1. 在 Team Management 的 **Organization Support** 区域点击 **Add Seat**。
2. 选择 Bronze、Silver 或 Gold 档位。
3. 选择需要分配席位的成员。
4. 点击显示价格的添加按钮。

这是支持席位，与团队成员席位不同。

## 移除成员 · Remove Members

需要移除成员权限。先停止成员正在使用的全部节点。移除不可逆，成员将失去组织项目访问权。

- Team：成员创建的项目仍归该成员。
- Trading Firm、Institution：成员在组织创建的项目转给组织管理者。

卡片视图中，点击成员右上角三点菜单，选 **Remove** 再确认；表格视图中，点击成员旁的 Remove 再确认。

## 权限 · Permissions

组织成员默认可使用组织资源。Trading Firm 和 Institution 管理者可分配额外权限：

| 类别 | 权限 | 含义 |
| --- | --- | --- |
| Billing | Update | 修改订阅与账单信息 |
| Stop Node | Backtest | 停止回测节点 |
| Stop Node | Research | 停止研究节点 |
| Stop Node | Live | 停止实时节点 |
| Team | Add | 添加成员 |
| Team | Remove | 移除成员 |
| Team | Edit | 修改成员权限 |
| Storage | Create | 写入对象存储 |
| Storage | Delete | 删除对象存储内容 |
| Storage | Billing | 增购对象存储空间 |

## 编辑权限 · Edit Permissions

需要 Team / Edit 权限。

卡片视图：点击成员右上角三点菜单，选择 **Edit Permissions（编辑权限）**。表格视图：点击成员旁的 Edit Permissions。

勾选或取消对应权限，点击 **Save Changes**。
