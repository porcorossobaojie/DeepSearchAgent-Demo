# 入门 · Getting Started

## 简介 · Introduction

组织是一组共享硬件资源、数据访问和开发协作能力的成员。计算资源用于回测、研究笔记本和实时策略，存储资源用于保存项目数据。你可以创建组织、加入已有组织，也可以同时加入多个组织。

平台提供不同组织套餐，可按团队发展调整订阅。需要工程师帮助时，可为成员分配不同级别的技术支持席位。

## 添加组织 · Add Organizations

1. 登录 Algorithm Lab。
2. 点击顶部 **Connected as: 组织名（当前连接组织）**。
3. 在 **Switch Organization（切换组织）** 面板点击 **Create Organization（创建组织）**。
4. 输入唯一的组织名称，点击 **Add（添加）**。

出现 **Created Successfully（创建成功）** 表示完成。

## 切换组织 · Switch Organizations

1. 登录 Algorithm Lab，点击顶部 **Connected as: 组织名**。
2. 在 Switch Organization 面板点击目标组织。

顶部导航会显示新组织名称。切换组织意味着接下来使用对应组织的项目、资源和权限。

## 重命名组织 · Rename Organizations

1. 打开 **Organization > Home（组织 > 首页）**。
2. 将鼠标移到组织名上，点击铅笔图标。
3. 输入新名称，点击 **Save Changes（保存更改）**。

出现 **Organization Name Updated Successfully（组织名称更新成功）** 表示完成。

## 获取组织 ID · Get Organization Id

打开 **Organization > Home**，查看网址。例如 `https://www.quantconnect.com/organization/5cad178b20a1d52567b534553413b691` 中最后一段就是组织 ID。

## 样本外保留期 · Out of Sample Period

组织管理者可以要求回测截止在距离当前日期若干个月之前，保留最近一段数据，等策略开发完成后再用于检验。这有助于降低过拟合风险。

例如保留一年，团队研究人员便不能在开发阶段的回测中使用最近一年的数据。

1. 打开组织首页。
2. 滚动到 **Backtesting Out of Sample Period（回测样本外保留期）**。
3. 调整时长，或选择 **No Holdout Period（不设置保留期）**。
