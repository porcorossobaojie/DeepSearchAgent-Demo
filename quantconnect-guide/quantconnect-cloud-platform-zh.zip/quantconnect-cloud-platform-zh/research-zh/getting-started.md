# 入门 · Getting Started

## 简介 · Introduction

研究环境是基于 Jupyter 笔记本的交互式环境，通过 `QuantBook` 访问研究功能，支持 Python 和 C#。Python 可以导入项目代码文件中的逻辑。

回测前适合先在这里检验假设、分析数据和绘图。Python 研究环境支持调试；机器学习模型可以在研究中训练，保存到 Object Store，再供回测和实时策略加载。也可通过平台 API 导入回测结果继续分析。

本章说明云端入口；完整 API 与分析方法另见 Research Environment 文档。

## 示例 · Example

官方 Python 片段展示如何请求 SPY 的日线历史，计算 30 期、两倍标准差的布林带并绘图。它假设平台笔记本已完成必要初始化。

```python
# 中文注释版：仅补充解释，保留原示例的执行语句。
# 创建研究对象，用于订阅标的、请求历史和计算指标。
qb = QuantBook()

# 订阅 SPY（标普 500 ETF），取得平台使用的 Symbol 标识。
symbol = qb.add_equity("SPY").symbol

# 请求最近 360 根日线；这里的 360 是数据条数，不是自然日天数。
history = qb.history(symbol, 360, Resolution.DAILY)

# 计算 30 期、2 倍标准差的布林带，并取得指标历史表。
bbdf = qb.indicator_history(BollingerBands(30, 2), symbol, 360, Resolution.DAILY).data_frame

# 将价格以及布林带下轨、中轨、上轨画在同一张图中。
bbdf[['price', 'lowerband', 'middleband', 'upperband']].plot();
```

![研究环境中的布林带图](https://cdn.quantconnect.com/i/tu/research-env-python-demo.png)

C# 原文另有在独立单元格加载 `Initialize.csx`、`QuantConnect.csx`，创建 `QuantBook` 并打印历史价格的示例；代码保留在下方。

```csharp
// 中文注释版：仅补充解释，保留原示例的执行语句。
// 在独立笔记本单元格加载平台初始化脚本及所需程序集。
#load "../Initialize.csx"
```

```csharp
// 中文注释版：仅补充解释，保留原示例的执行语句。
// 加载平台提供的研究 API 脚本；这是笔记本指令，不是普通 C# 语句。
#load "../QuantConnect.csx"
```

```csharp
// 中文注释版：仅补充解释，保留原示例的执行语句。
using QuantConnect;
using QuantConnect.Data;
using QuantConnect.Algorithm;
using QuantConnect.Research;

// 创建研究对象，用于访问订阅和历史数据。
var qb = new QuantBook();

// 订阅 SPY，并取得唯一的 Symbol 标识。
var symbol = qb.AddEquity("SPY").Symbol;

// 请求最近 70 根日线数据；条数不等于自然日天数。
var history = qb.History(symbol, 70, Resolution.Daily);

// 逐条遍历请求到的日线数据。
foreach (var tradeBar in history)
{
    // 输出每根行情的结束时间及数据内容。
    Console.WriteLine($"{tradeBar.EndTime} :: {tradeBar.ToString()}");
}
```

## 打开笔记本 · Open Notebooks

1. 打开项目，在右侧选择 **Explorer**。
2. 展开 **Workspace (Workspace)**。
3. 点击 `research.ipynb`（Python）或 `Research.ipynb`（C#）。

打开后会自动连接 Jupyter 服务器并选择内核，最多可能等待一分钟。如果右上仍显示 `base (Python x.x.x)`，先等其切换为 **Foundation-Py-Default** 或 **Foundation-C#-Default**。

过早执行可能出现 `NameError: name 'QuantBook' is not defined`。

## 运行单元格 · Run Notebook Cells

笔记本单元格可以编写代码或 Markdown。按 **Shift+Enter** 执行当前单元格。

| 快捷键 | 功能 |
| --- | --- |
| Shift+Enter | 运行选中单元格 |
| a | 在上方插入 |
| b | 在下方插入 |
| x | 剪切 |
| v | 粘贴 |
| z | 撤销单元格操作 |

原文说明有 15 分钟超时机制；若单元格无响应，重启笔记本后再执行。

## 停止节点 · Stop Nodes

停止云端研究节点需要对应权限。打开项目，点击右侧 **Resources**，再点击目标研究节点旁的停止按钮。

## 添加笔记本 · Add Notebooks

1. 打开项目，在右侧 Explorer 展开工作空间。
2. 点击 **New File**。
3. 输入 `文件名.ipynb`，按 Enter。

## 重命名笔记本 · Rename Notebooks

在右侧 Explorer 右键点击笔记本，选择 **Rename**，输入新名称并按 Enter。

原文还列出以下保留目录名，不应作为普通自建目录使用：`.ipynb_checkpoints`、`.idea`、`.vscode`、`__pycache__`、`bin`、`obj`、`backtests`、`live`、`optimizations`、`storage`、`report`。

## 删除笔记本 · Delete Notebooks

在 Explorer 右键选择笔记本，点击 **Delete Permanently**，再点击 **Delete** 确认。

## 学习 Jupyter · Learn Jupyter

原文推荐 tutorialspoint 的 Jupyter Tutorial、DataCamp 的 Jupyter Notebook Tutorial，以及 Microsoft Developer Blogs 的 An Introduction to DataFrame。对应地址见本节相关链接。
