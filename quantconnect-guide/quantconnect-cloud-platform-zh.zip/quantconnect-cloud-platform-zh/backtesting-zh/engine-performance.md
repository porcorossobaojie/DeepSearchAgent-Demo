# 引擎性能 · Engine Performance

## 简介 · Introduction

官方定期运行一组基准算法，检查 LEAN master 分支的状态和速度。Lean Performance Benchmark 页面顶部图表展示各算法每秒处理的数据点，底部表格列出参与测试的算法。

这反映计算性能，不是策略收益排行。对应基准页面链接见下方原文相关链接。
