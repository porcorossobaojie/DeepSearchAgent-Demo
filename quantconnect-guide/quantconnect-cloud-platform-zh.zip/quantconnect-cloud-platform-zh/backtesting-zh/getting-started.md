# 入门 · Getting Started

## 简介 · Introduction

回测是在历史数据上模拟执行交易算法，用于衡量策略过去可能的表现。历史表现不保证未来，但能帮助确认规则在不同市场中的行为。

平台提供数据、开源 LEAN 引擎和托管云资源；本章聚焦云端回测。

## 运行回测 · Run Backtests

打开项目，点击 **Backtest**。构建成功后会显示收到回测请求；启动成功后自动打开结果标签，代码错误则显示在该标签中。

云端任务执行期间可刷新或关闭 IDE，不会因此停止回测。运行范围受到组织样本外保留期限制。

## 查看所有回测 · View All Backtests

1. 打开项目，点击 IDE 右上 **Backtest Results**。
2. 列表中的播放图标表示普通回测，快进图标表示优化结果。
3. 可用 **Show** 过滤类型、**Hide Error** 隐藏运行错误记录，并分页或点击列名排序。
4. 点击记录打开结果。

## 重命名回测 · Rename Backtests

回测默认采用自动名称。在项目回测历史中，将鼠标移到记录上，点击铅笔图标，输入新名称并点 **OK**。

也可在代码中设置：

```python
# 中文注释版：仅补充解释，保留原示例的执行语句。
# 给本次回测设置便于识别的名称。
self.set_name("Backtest Name")
```

## 样本外保留期 · Out of Sample Period

组织管理者可以保留最近若干个月数据，防止开发阶段反复调参使用它。打开组织首页，在 **Backtesting Out of Sample Period** 调整时长，或选择 **No Holdout Period**。

## 本地部署回测 · On-Premise Backtests

原文在此链接到 Local Platform 的入门文档。本篇保留原引用，不将本地安装流程写成云端步骤。

## 获取回测 ID · Get Backtest Id

在回测日志的第一行查看 ID，例如 `8b16cec0c44f75188d82f9eadb310e17`。

## 分享回测 · Share Backtests

结果页 **Share Results** 区域点击 **Make Public**。之后可点击 **Backtest URL** 复制链接，或 **Embed Code** 复制 iframe 嵌入代码。

持有链接者可访问公开结果。该公共片段提供 **Make Private** 按钮恢复私密。Projects 的共享说明同时提醒公开结果可能暴露项目文件；请勿将公开链接视为私密协作通道。
