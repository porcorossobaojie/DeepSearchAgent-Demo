# 表现报告 · Report

## 简介 · Introduction

回测完成后可生成 PDF 报告，汇总关键统计、收益及历史危机期间的表现。

## 关键统计 · Key Statistics

报告顶部包含：运行天数、年换手率、CAGR（复合年增长率）、交易资产类别、日均交易数、回撤、概率夏普、夏普、信息比率和策略容量。

日均交易数是总交易数除以回测天数，是频率近似；换手率描述一年中被替换的组合比例。其余定义可追溯下方原文的术语链接。

## 收益 · Returns

- 每笔收益：直方图展示交易收益分布。
- 每日收益：蓝色为盈利日，灰色为亏损日。
- 每月收益：绿正红负，颜色越深绝对值越大；黄为变化较小，白色表示不在回测区间，单元格数值是百分比。
- 年收益：蓝条为各年总收益，红虚线为年度收益均值。
- 累计收益：蓝线为策略，灰线为基准。

## 资产配置 · Asset Allocation

饼图使用各资产持仓绝对价值的时间加权平均。占比太小的资产并入 Others；不是仅展示期末持仓。

## 回撤 · Drawdown

每日回撤是相对截至当时的权益历史高点下降的百分比，按日数据计算。图中用不同颜色标记五个主要回撤区间。

## 滚动统计 · Rolling Statistics

展示过去 6 个月和 12 个月的组合 Beta 及夏普比率，浅蓝代表 6 个月，深蓝代表 12 个月。

## 敞口 · Exposure

图表展示整体杠杆随时间变化，以及按资产类别划分的多空敞口。

## 危机事件 · Crisis Events

对比策略与基准在指定历史阶段的累计收益，蓝线为策略、灰线为基准。只纳入发生在回测区间中的事件。

下面保留原文选定的观察区间。这些是报告分段，不等同于历史事件本身的唯一日期定义。

<table class="table qc-table">
   <thead>
      <tr>
         <th>阶段名称</th>
         <th>开始日期</th>
         <th>结束日期</th>
      </tr>
   </thead>
   <tbody>
      <tr>
         <td>2000 年互联网泡沫</td>
         <td>2/26/2000</td>
         <td>9/10/2000</td>
      </tr>
      <tr>
         <td>2001 年 9·11</td>
         <td>9/5/2001</td>
         <td>10/10/2001</td>
      </tr>
      <tr>
         <td>2003 年美国房地产泡沫</td>
         <td>1/1/2003</td>
         <td>2/20/2003</td>
      </tr>
      <tr>
         <td>2007 年全球金融危机</td>
         <td>10/1/2007</td>
         <td>12/1/2011</td>
      </tr>
      <tr>
         <td>2010 年闪电崩盘</td>
         <td>5/1/2010</td>
         <td>5/22/2010</td>
      </tr>
      <tr>
         <td>2011 年福岛事故</td>
         <td>3/1/2011</td>
         <td>4/22/2011</td>
      </tr>
      <tr>
         <td>2011 年美国信用降级</td>
         <td>8/5/2011</td>
         <td>9/1/2011</td>
      </tr>
      <tr>
         <td>2012 年欧洲央行利率事件</td>
         <td>9/5/2012</td>
         <td>10/12/2012</td>
      </tr>
      <tr>
         <td>2014 年欧洲债务危机</td>
         <td>10/1/2014</td>
         <td>10/29/2014</td>
      </tr>
      <tr>
         <td>2015 年市场抛售</td>
         <td>8/10/2015</td>
         <td>10/10/2015</td>
      </tr>
      <tr>
         <td>2010–2012 年复苏</td>
         <td>1/1/2010</td>
         <td>10/1/2012</td>
      </tr>
      <tr>
         <td>2014–2019 年新常态</td>
         <td>1/1/2014</td>
         <td>1/1/2019</td>
      </tr>
      <tr>
         <td>2020 年新冠疫情</td>
         <td>2/10/2020</td>
         <td>9/20/2020</td>
      </tr>
      <tr>
         <td>2020–2021 年疫情后上涨</td>
         <td>4/1/2020</td>
         <td>1/1/2022</td>
      </tr>
      <tr>
         <td>2021 年迷因股行情</td>
         <td>1/1/2021</td>
         <td>5/15/2021</td>
      </tr>
      <tr>
         <td>2022–2023 年俄乌战争</td>
         <td>2/1/2022</td>
         <td>1/1/2024</td>
      </tr>
      <tr>
         <td>2022 年至今 AI 热潮</td>
         <td>11/30/2022</td>
         <td>至今</td>
      </tr>
   </tbody>
</table>

## 参数 · Parameters

报告列出项目全部参数的名称和值，方便解释和复现当次回测配置。

## 自定义报告 · Customize Reports

云端可在项目添加 **`report.html`** 和 **`report.css`**，覆盖默认报告结构与样式。模板原文位于 LEAN 仓库 `Report/template.html` 和 `Report/css/report.css`；可用占位键见 `Report/ReportKey.cs`。

例如 `{{$KPI-SHARPE}}` 插入夏普值。危机图使用 `{{$HTML-CRISIS-PLOTS}}`，并在 `<!--crisis` 与 `crisis-->` 包围的模板片段中使用 `{{$TEXT-CRISIS-TITLE}}`、`{{$PLOT-CRISIS-CONTENT}}`。

参数使用 `{{$PARAMETERS}}`，在 `<!--parameters` 和 `parameters-->` 中使用 `{{$KEY0}}`、`{{$VALUE0}}` 等占位符。

下面保留原文 HTML 示例，作为代码显示，不会当成本页模板执行：

```html
<!-- 中文注释版：这是报告生成器的危机图模板。保留 crisis 标记；TEXT-CRISIS-TITLE 填入事件标题，PLOT-CRISIS-CONTENT 填入图片内容。不要在原有模板注释内部再嵌套 HTML 注释。 -->
<!--crisis
<div class="col-xs-4">
    <table class="crisis-chart table compact">
        <thead>
        <tr>
            <th style="display: block; height: 75px;">{{$TEXT-CRISIS-TITLE}}</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td style="padding:0;">
                <img src="{{$PLOT-CRISIS-CONTENT}}">
            </td>
        </tr>
        </tbody>
    </table>
</div>
crisis-->
```

```html
<!-- 中文注释版：这是报告参数行模板。保留 parameters 标记；KEY0/VALUE0 是第一个参数名及值，KEY1/VALUE1 是第二个。占位键不能翻译或改名。 -->
<!--parameters
<tr>
    <td class = "title"> {{$KEY0}} </td><td> {{$VALUE0}} </td>
    <td class = "title"> {{$KEY1}} </td><td> {{$VALUE1}} </td>
</tr>
parameters-->
```

原文还有可克隆的自定义报告示例，生成后顶部有红色横幅，链接保留在下方。共享资源中的 `lean report --html/--css` 是 CLI 操作，本文不把它当作云端网页操作。
