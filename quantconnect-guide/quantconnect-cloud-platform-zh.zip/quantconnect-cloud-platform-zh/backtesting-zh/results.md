# 结果分析 · Results

## 简介 · Introduction

回测结果页展示策略表现，帮助理解历史行为，并在实时交易前调查潜在改进。

## 查看回测结果 · View Backtest Results

部署后自动打开结果页，包含权益曲线、订单、日志和统计，任务执行中持续更新。云端计算不会因关闭或刷新页面而中断；可从项目回测历史重新打开。

默认结果私密，主动公开后才向其他人开放。原文说明删除结果或连续 12 个月不活跃时会归档结果。下载原始数据参见“下载结果”。

<!-- MARGIN_SUBCHAPTER -->

## 运行统计 · Runtime Statistics

顶部横幅展示运行统计：

| 名称 | 中文含义 |
| --- | --- |
| Equity | 账户权益 |
| Fees | 费用 |
| Holdings | 持仓价值 |
| Net Profit | 净收益 |
| PSR | 概率夏普比率 |
| Return | 收益率 |
| Unrealized | 未实现盈亏 |
| Volume | 交易量／金额口径见官方定义 |

也可添加自定义统计并下载。原文上限为 50 项，名称和值截到 200 字符；Base64 或十六进制等编码值会被忽略，并发送一条调试消息。节点资源另见 Server Statistics。

## 内置图表 · Built-in Charts

| 图表 | 内容 |
| --- | --- |
| Strategy Equity | 权益及分期收益 |
| Capacity | 策略容量估计 |
| Drawdown | 从权益高点到低点的回撤 |
| Benchmark | 基准收盘价，默认 SPY |
| Exposure | 多空敞口比例 |
| Assets Sales Volume | 各交易标的占总交易量的比例 |
| Portfolio Turnover | 组合换手率 |
| Portfolio Margin | 保证金使用堆叠图 |
| Performance | 程序计算性能 |
| Asset Plot | 带订单事件的资产价格图，原文面向付费组织 |

图表数据可通过 Download Results 下载。

## 性能图 · Performance Chart

用于优化程序计算性能，不是展示盈利能力。

| 序列 | 原文说明的统计内容 |
| --- | --- |
| CPU | CPU 使用百分比 |
| ManagedRAM | 机器使用的内存，标识与具体口径以引擎定义为准 |
| TotalRAM | 当前进程私有内存，含托管与非托管部分 |
| ActiveSecurities | 股票池选中、存在持仓或未结订单的活跃标的数 |
| DataPoints | 每秒处理的数据点 |
| HistoryDataPoints | 历史数据提供器的数据点数 |
| Subscriptions | 读取订阅耗时 |
| Selection | 选股及增删标的耗时 |
| Slice | 构造时间片耗时 |
| Schedule | 定时事件耗时 |
| Consolidators | 数据合并和指标更新耗时 |
| Securities | 标的更新及变更事件耗时 |
| Transactions | 订单成交、取消、更新及处理器耗时 |
| SplitsDividendsDelisting | 公司行为事件耗时 |
| OnData | `on_data` 及 `alpha.update` 耗时 |
| WallTime | 实际经过时间 |

耗时按上次采样以来的秒数记录。默认关闭；可设置采样周期，例如：

```python
# 中文注释版：仅补充解释，保留原示例的执行语句。
# 设置计算性能图的采样间隔为七天；不是每七天执行一次策略。
self.settings.performance_sample_period = timedelta(7)
```

这是策略配置片段，需要相应导入与算法上下文。

## 资产图 · Asset Plots

展示资产价格和订单事件：提交为灰圆，更新为蓝圆，取消为灰方块；成交和部分成交为绿色买入箭头或红色卖出箭头。提交图标默认隐藏。

在结果页 **Orders** 标签，点击标的旁 **Asset Plot** 图标打开。悬停订单事件会突出对应事件、价格和标签；标签可记录下单或取消原因。

可点击 1m、3m、1y、All 或横向拖拽缩放。显示整个区间时通常采用日收盘价，放大后可能使用更细数据；并不总与策略订阅频率相同。日线视图会合并同一天的多个事件标记。

成交标记用真实模拟成交价，可能与显示行情价不同，原因包括滑点、买卖报价成交或成交模型按最高／最低价填单。

## 自定义图表 · Custom Charts

结果页会展示算法创建的自定义图表。`SeriesType.Candle` 可将足够多的采样点聚合为蜡烛图，但 `plot` 每个时间步仅接收一个值，不能直接提交每根行情的 OHLC，也不能控制蜡烛周期。

更复杂图表可将数据存入 Object Store，再在研究环境用第三方库绘制，需遵守组织存储权限。

图表类型和散点标记清单在官网通过 API 类型树动态生成，源码只含 `QuantConnect.SeriesType` 与 `QuantConnect.ScatterMarkerSymbol` 的占位。本地稿未伪造完整枚举，请结合对应 API 原文。

<table class="qc-table table">
   <thead>
      <tr>
         <th>套餐</th>
         <th>最多序列数</th>
         <th>每序列最多数据点</th>
      </tr>
   </thead>
   <tbody>
      <tr>
         <td>Free</td>
         <td>10</td>
         <td>4,000</td>
      </tr>
      <tr>
         <td>Quant Researcher</td>
         <td>10</td>
         <td>8,000</td>
      </tr>
      <tr>
         <td>Team</td>
         <td>25</td>
         <td>16,000</td>
      </tr>
      <tr>
         <td>Trading Firm</td>
         <td>25</td>
         <td>32,000</td>
      </tr>
      <tr>
         <td>Institution</td>
         <td>100</td>
         <td>96,000</td>
      </tr>
   </tbody>
</table>

超过序列数量会提示 `Exceeded maximum chart series count`；超过数据点会跳过数据。超过云端绘图需要时，建议改在研究环境分析。这里保留按套餐的表格；Projects 的公共调试片段另写固定 4,000 点，源码存在不同描述，以当前平台为准。

## 调整图表 · Adjust Charts

- Select Chart 区域点击图表名，显示或隐藏图表。
- 点击图上方序列名，显示或隐藏序列。
- 使用时间范围按钮或横向拖动缩放；缩放会影响全部图表。
- 放大后可拖动底部水平条改变可见区间。
- 拖动图表右下角调整大小，拖动标题改变位置。
- Select Chart 的重置按钮重置缩放；若运行中刷新，可能只显示刷新后引擎处理到的数据。

## 关键统计 · Key Statistics

Overview 的 Overall Statistics 展示整体结果；Rolling Statistics 展示部分指标随时间滚动变化。

| 原文指标 | 中文 |
| --- | --- |
| Probabilistic Sharpe Ratio | 概率夏普比率 |
| Total Trades | 总交易次数 |
| Average Loss / Average Win | 平均亏损／盈利 |
| Drawdown | 回撤 |
| Net Profit | 净收益 |
| Loss Rate / Win Rate | 亏损率／胜率 |
| Profit-Loss Ratio | 盈亏比 |
| Beta / Alpha | 贝塔／阿尔法 |
| Annual Variance | 年化方差 |
| Tracking Error | 跟踪误差 |
| Total Fees | 总费用 |
| Lowest Capacity Asset | 容量最低的标的 |
| Sharpe Ratio | 夏普比率 |
| Compounding Annual Return | 复合年化收益率 |
| Expectancy | 期望收益指标 |
| Annual Standard Deviation | 年化标准差 |
| Information Ratio | 信息比率 |
| Treynor Ratio | 特雷诺比率 |
| Estimated Strategy Capacity | 估计策略容量 |

统计口径以官方术语表为准。可通过 Download Results 下载；研究方法提示见 Research Guide。

## 报告 · Reports

1. 在结果页点击 **Report**。
2. 若无项目描述，先填写并 **Save**。
3. 点击 **Download Report**。

生成可能需要一分钟。若 IDE 提示仍在生成，可稍后再次点击下载。

## 订单 · Orders

Orders 展示算法创建的订单。超过十条可分页，展开订单可查看提交、成交、部分成交、更新、取消，以及期权行权和到期事件。

表格时间为 **ET（美国东部时间）**。点击 **Download Orders** 可下载折叠汇总形式的 CSV，时间改为 **UTC**。

API 导出端点为 `/backtests/export/orders`。完整订单信息可通过 Download Results 获取；在研究笔记本中可用 `read_backtest_orders` 或 `/backtests/orders/read` 分析云端订单。

## 交易 · Trades

Trades 展示已完成交易，订单如何组合成交易取决于 Trade Statistics 设置。展开记录可查看组成该交易的成交。

页面时间为 ET，Download Trades 下载的 CSV 时间为 UTC。API 为 `/backtests/export/trades`。完整 JSON 中相关键为 `closedTrades`。

订单是交易指令，交易记录是按规则组合后的完整交易，两者数量不能直接等同。

## 投资见解 · Insights

Insights 展示算法发出的投资见解，超过十条可分页。页面时间按 ET。点击 **Download Insights** 下载 JSON。

原文标题为 JSON，正文却称“CSV 中时间为 UTC”，存在格式用词不一致，本文不据此改称 CSV；使用时应检查实际下载文件与时间字段。

## 日志 · Logs

打开 **Logs** 查看日志，可在 **Filter logs** 搜索，点击 **Download Logs** 下载。日志时间按**算法时区**，与订单表的 ET 和下载文件 UTC 不一定相同。

## 项目文件 · Project Files

**Code** 标签展示本次运行使用的项目文件，默认打开 `main.py` 或 `Main.cs`。通过文件名下拉切换。点击 **Clone Algorithm** 可用本次运行的文件创建新项目。

## 分享结果 · Share Results

在 Share Results 点击 **Make Public**，然后复制 Backtest URL 或 Embed Code。公共片段提供 Make Private 按钮。公开内容涉及结果及项目访问，应同时阅读 Projects 的公开分享说明。

## 下载结果 · Download Results

在 **Overview** 点击 **Download Results**，下载运行统计、图表、Overview 和 Orders 数据，格式为 JSON，时间按 UTC。

原文提供将 JSON 展平并保存 CSV 的 Python 示例：

```python
# 中文注释版：仅补充解释，保留原示例的执行语句。
# 导入标准库，用于解析下载的 JSON 结果。
import json
# 导入 pandas，用于整理表格并导出 CSV。
import pandas as pd

# 将占位路径换成下载的结果文件，按 UTF-8 读取并解析 JSON。
data = json.loads(open("<YOUR_JSON_FILE>.json", "r", encoding="utf-8").read())

# 递归展平嵌套字典，用路径表示原有层级；列表不会在此继续递归展开。
def flatten_json(obj, parent_key='', sep='_'):
    items = []
    # 逐一处理字典成员，保留字段路径。
    for k, v in obj.items():
        # 将父路径和当前键拼接，形成展平后的字段名。
        new_key = f"{parent_key}{sep}{k}" if parent_key else k
        # 字典继续递归，其他类型保留为叶子值。
        if isinstance(v, dict):
            # 合并子字典展平得到的键值对。
            items.extend(flatten_json(v, new_key, sep=sep).items())
        else:
            # 保存当前叶子节点；列表也会作为值保留。
            items.append((new_key, v))
    return dict(items)

# 把嵌套结果转换成“路径 → 值”的字典。
flat_data = flatten_json(data)

# 按下划线拆分路径，生成 pandas 多级索引；原键含下划线时也会被拆分。
multi_index_tuples = [tuple(k.split('_')) for k in flat_data.keys()]
# 按字段顺序取值，与上面构造的索引顺序对应。
values = list(flat_data.values())

# 以路径作为多级行索引，创建只有 Value 一列的数据表。
multi_index = pd.MultiIndex.from_tuples(multi_index_tuples)
df = pd.DataFrame(values, index=multi_index, columns=['Value'])

# 将数据表保存到当前工作目录中的 results.csv。
df.to_csv('results.csv')
```

需将占位路径改为实际文件，并具备 pandas。以下代码仅保留原文用途，未在本次真实回测结果上执行。

## 查看全部回测 · View All Backtests

在项目右上打开 Backtest Results，可筛选、分页和排序。鼠标移到记录上，铅笔图标重命名，克隆图标用当次代码新建项目，垃圾桶删除结果。

## 样本外保留期 · Out of Sample Period

组织首页的 Backtesting Out of Sample Period 可保留最近若干个月数据，不供开发回测使用；No Holdout Period 表示不设保留期。

## 错误 · Errors

原文说明回测输出数据超过 700 MB 时，LEAN 可能无法上传结果，使结果页空白。实际限制以平台为准；出现空白也需检查任务错误，不能直接认定唯一原因。
