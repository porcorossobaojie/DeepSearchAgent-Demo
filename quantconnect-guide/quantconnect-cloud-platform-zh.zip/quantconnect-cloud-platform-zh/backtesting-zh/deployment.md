# 部署 · Deployment

## 简介 · Introduction

将回测任务部署到云端服务器，用 LEAN 模拟算法。回测和实时交易使用同一引擎，便于工作流衔接，但历史成交假设与真实执行条件仍需分别验证。

## 节点 · Nodes

更多节点支持更多并发回测，更强 CPU 和内存支持更复杂计算。

<table class="qc-table table">
    <thead>
        <tr>
            <th>名称</th>
            <th>CPU 核心数</th>
            <th>处理速度（GHz）</th>
            <th>内存（GB）</th>
            <th>GPU</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>B-MICRO</td>
            <td>2</td>
            <td>3.3</td>
            <td>8</td>
            <td>0</td>
        </tr>
        <tr>
            <td>B2-8</td>
            <td>2</td>
            <td>4.9</td>
            <td>8</td>
            <td>0</td>
        </tr>
        <tr>
            <td>B4-12</td>
            <td>4</td>
            <td>4.9</td>
            <td>12</td>
            <td>0</td>
        </tr>
        <tr>
            <td>B4-16-GPU</td>
            <td>4</td>
            <td>3</td>
            <td>16</td>
            <td>1/3</td>
        </tr>
        <tr>
            <td>B8-16</td>
            <td>8</td>
            <td>4.9</td>
            <td>16</td>
            <td>0</td>
        </tr>
    </tbody>
</table>

首个组织的免费 B-MICRO 原文有启动延迟 20 秒、每日 200 次限制；升级付费套餐并添加新节点后会替换。默认选择最佳可用节点，也可在 Resources 指定。

CPU 采用公平使用原则，GPU 最多三名成员共享。GPU 适合模型训练等并行计算，普通算法可能因传输开销而没有加速。

## 并发回测 · Concurrent Backtesting

组织有多个回测节点时可以同时跑多个任务，减少等待。参数优化另租优化节点，不要求先拥有相同数量的普通回测节点。

<table class="qc-table table">
   <thead>
      <tr>
         <th>套餐</th>
         <th>节点额度</th>
      </tr>
   </thead>
   <tbody>
      <tr>
         <td>Free</td>
         <td>1</td>
      </tr>
      <tr>
         <td>Quant Researcher</td>
         <td>2</td>
      </tr>
      <tr>
         <td>Team</td>
         <td>10</td>
      </tr>
      <tr>
         <td>Trading Firm</td>
         <td>不限</td>
      </tr>
      <tr>
         <td>Institution</td>
         <td>不限</td>
      </tr>
   </tbody>
</table>

## 日志 · Logs

日志按每次回测和每天分别限额。剩余额度在 **Organization > Resources** 查看。

<table class="qc-table table">
   <thead>
      <tr>
         <th>套餐</th>
         <th>每次回测日志</th>
         <th>每天日志</th>
      </tr>
   </thead>
   <tbody>
      <tr>
         <td>Free</td>
         <td>10KB</td>
         <td>3MB</td>
      </tr>
      <tr>
         <td>Quant Researcher</td>
         <td>100KB</td>
         <td>3MB</td>
      </tr>
      <tr>
         <td>Team</td>
         <td>1MB</td>
         <td>10MB</td>
      </tr>
      <tr>
         <td>Trading Firm</td>
         <td>5MB</td>
         <td>50MB</td>
      </tr>
      <tr>
         <td>Institution</td>
         <td>不限</td>
         <td>不限</td>
      </tr>
   </tbody>
</table>

## 订单 · Orders

单次回测订单数量上限取决于套餐：

<table class="qc-table table">
   <thead>
      <tr>
         <th>套餐</th>
         <th>订单额度</th>
      </tr>
   </thead>
   <tbody>
      <tr>
         <td>Free</td>
         <td>10K</td>
      </tr>
      <tr>
         <td>Quant Researcher</td>
         <td>10M</td>
      </tr>
      <tr>
         <td>Team</td>
         <td>不限</td>
      </tr>
      <tr>
         <td>Trading Firm</td>
         <td>不限</td>
      </tr>
      <tr>
         <td>Institution</td>
         <td>不限</td>
      </tr>
   </tbody>
</table>

## 安全 · Security

原文说明项目代码存于隔离数据库，部署时编译和混淆，以降低云端代码直接被读取的风险；平台采用软件更新、SSH 密钥及数据库访问限制等措施。它也承认线上服务不能保证绝对安全。

更多内容见 Security and IP。此处是原文安全措施说明，未对基础设施进行独立审计。

## 构建项目 · Build Projects

IDE 会在输入后自动构建；手动构建可点击 **Build**。错误行会以红色突出显示。构建无响应时先刷新重试，仍无响应则查看平台 Status 页面或联系支持。

## 运行回测 · Run Backtests

打开项目并点击 **Backtest**。构建成功后显示请求确认，随后打开结果页。代码错误会显示在该页。任务在云端执行，刷新或关闭 IDE 不会使其停止。

## 停止回测 · Stop Backtests

打开 **Resources**，点击目标回测节点旁的停止按钮。停止其他成员使用的节点需要相应权限。

## 运行时限 · Runtime Quota

所读原文规定单次回测最多执行 12 小时。运行时长取决于数据量、算法计算和节点型号；实际限制以当前平台为准。
