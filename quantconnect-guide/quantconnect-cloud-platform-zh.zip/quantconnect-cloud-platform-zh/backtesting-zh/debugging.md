# 调试 · Debugging

## 简介 · Introduction

内置回测调试器可以逐行执行代码、暂停和检查变量，帮助理解程序内部状态。

## 断点 · Breakpoints

断点是执行到某行时暂停的位置。启动调试器前，至少要设置一个断点。

- **添加**：点击行号左侧。
- **条件**：右键断点，选 Edit Breakpoint；Expression 输入条件表达式，仅在为真时暂停；Hit Count 输入次数，达到该次数才暂停。
- **启用／禁用**：右键选 Enable Breakpoint 或 Disable Breakpoint。
- **全部切换**：Run and Debug 面板的 Breakpoints 区域，点击 Toggle Active Breakpoints。
- **删除**：右键选 Remove Breakpoint；移除全部可点击 Remove All Breakpoints。

## 启动调试器 · Launch Debugger

打开项目，在代码中加至少一个断点，然后点击 **Debug**。第一次命中断点时会打开 Run and Debug 面板。

## 控制调试器 · Control Debugger

下表保留原文默认快捷键；实际可在 IDE 快捷键设置中确认。

| 按钮 | 默认快捷键 | 功能 |
| --- | --- | --- |
| Continue | 原表未列出 | 继续到下一断点 |
| Step Over | Alt+F10 | 执行到当前或上层作用域下一行 |
| Step Into | Alt+F11 | 进入当前调用的函数定义 |
| Restart | Shift+F11 | 重启调试器 |
| Disconnect | Shift+F5 | 退出调试器 |

## 检查变量 · Inspect Variables

Variables 区域展示当前断点的局部变量；展开对象可查看成员，执行时会更新。右键变量选择 **Set Value**，输入新值并按 Enter，可修改其当前值。

Watch 区域可添加自定义表达式，例如当前回测时间。鼠标移到 Watch 上点击加号，输入表达式并按 Enter。IDE 会对 DataFrame 等对象做可读格式化。
