# 组合保证金图 · Portfolio Margin Plots

## 简介 · Introduction

这是堆叠面积图，各颜色表示某标的占用可用保证金的比例。为便于观察，只显示每个时点最大的约 5–10 项持仓，其余归入 Others。

## 采样频率 · Sample Frequency

回测按每天一次采样，因此不能用该图判断日内保证金峰值。

## 现金与保证金 · Cash vs Margin

保证金账户先使用现金，再借入保证金，以减少借款利息。

原文比较两个等权买入持有策略：100% 资产敞口可能使图线接近 50%，因为剩余购买能力来自杠杆；50% 敞口留下更多现金，资产上涨时现金占比缩小，保证金占比图可能上升。

这些数字基于示例的账户与杠杆条件，不适用于所有券商模型。两份原始 Python 示例如下：

```python
# 中文注释版：仅补充解释，保留原示例的执行语句。
# region imports
# 导入 LEAN 的常用算法类、数据类型及枚举。
from AlgorithmImports import *
# endregion

# 等权买入并持有：目标持仓市值合计为账户权益的 100%。
# 定义继承 QCAlgorithm 的策略类，由 LEAN 管理其生命周期。
class EqualWeightedFullExposureAlgorithm(QCAlgorithm):
    # 初始化只在算法开始时运行一次，设置回测条件和数据订阅。
    def initialize(self):
        # 设置历史回测的开始日期。
        self.set_start_date(2014, 1, 1)
        # 设置历史回测的结束日期。
        self.set_end_date(2016, 1, 1)
        # 设置回测初始资金为 100,000 单位账户货币。
        self.set_cash(100000)
        # 订阅 SPY、QQQ、AAPL 日线，并保存它们的 Symbol。
        self.symbols = [self.add_equity(t, Resolution.DAILY).symbol for t in ["SPY", "QQQ", "AAPL"]]

    # 行情到达时执行；data 包含该时间片可用的数据。
    def on_data(self, data: Slice):
        # 只有组合没有任何持仓时才建仓，避免每次行情都重复买入。
        if not self.portfolio.invested:
            # 将 100% 的目标敞口平均分给所有标的；三个标的各约 33.3%。
            weight = 1.0 / len(self.symbols)
            for symbol in self.symbols:
                # 将该标的调整到目标组合权重；weight 表示比例，不是股数。
                self.set_holdings(symbol, weight)
```

```python
# 中文注释版：仅补充解释，保留原示例的执行语句。
# region imports
# 导入 LEAN 的常用算法类、数据类型及枚举。
from AlgorithmImports import *
# endregion

# 等权买入并持有：仅投入账户权益的 50%，其余留作现金。
# 定义继承 QCAlgorithm 的策略类，由 LEAN 管理其生命周期。
class EqualWeightedHalfExposureAlgorithm(QCAlgorithm):
    # 初始化只在算法开始时运行一次，设置回测条件和数据订阅。
    def initialize(self):
        # 设置历史回测的开始日期。
        self.set_start_date(2014, 1, 1)
        # 设置历史回测的结束日期。
        self.set_end_date(2016, 1, 1)
        # 设置回测初始资金为 100,000 单位账户货币。
        self.set_cash(100000)
        # 订阅 SPY、QQQ、AAPL 日线，并保存它们的 Symbol。
        self.symbols = [self.add_equity(t, Resolution.DAILY).symbol for t in ["SPY", "QQQ", "AAPL"]]

    # 行情到达时执行；data 包含该时间片可用的数据。
    def on_data(self, data: Slice):
        # 只有组合没有任何持仓时才建仓，避免每次行情都重复买入。
        if not self.portfolio.invested:
            # 将 50% 的目标敞口平均分配；三个标的各约 16.7%。
            weight = 0.5 / len(self.symbols)
            for symbol in self.symbols:
                # 将该标的调整到目标组合权重；weight 表示比例，不是股数。
                self.set_holdings(symbol, weight)
```

## 示例 · Examples

### 买入保护性看跌期权

持有标的同时买入看跌期权，可降低对应标的保证金。示例先买 SPY，数月后买入保护性 put，图中分别标记标的和期权。

### 期权价差

同时持有多空期权腿可组合降低保证金。原文示例逐步建立熊市看涨价差：先卖实值 call，之后买同到期的虚值 call。

### 期货

期货示例的保证金按固定美元金额计算。组合价值下降时，固定金额占可用保证金的比例会上升，即使合约占用的美元值未变。

### 外汇

原文以 50 倍杠杆和 500% EURUSD 敞口示意，初始保证金占比为 `500% / 50 = 10%`。这是图表解释示例，并非建议使用该杠杆。

四份官方 Python 示例按上述顺序保留：

```python
# 中文注释版：仅补充解释，保留原示例的执行语句。
# region imports
# 导入 LEAN 的常用算法类、数据类型及枚举。
from AlgorithmImports import *
# endregion

# 先持有 SPY，再买保护性看跌期权，观察保证金占用变化。
# 定义继承 QCAlgorithm 的策略类，由 LEAN 管理其生命周期。
class BuyingPutOptionsMarginAlgorithm(QCAlgorithm):
    # 初始化只在算法开始时运行一次，设置回测条件和数据订阅。
    def initialize(self):
        # 设置历史回测的开始日期。
        self.set_start_date(2013, 10, 7)
        # 设置历史回测的结束日期。
        self.set_end_date(2014, 7, 1)
        # 设置回测初始资金为 100,000 单位账户货币。
        self.set_cash(100000)
        # 订阅 SPY 分钟行情，作为保护性期权对应的标的。
        equity = self.add_equity("SPY", Resolution.MINUTE)
        # 保存正股 Symbol，后续据此查询持仓并下单。
        self._equity_symbol = equity.symbol
        # 订阅期权链；实际可交易合约由下面的筛选器决定。
        option = self.add_option("SPY", Resolution.MINUTE)
        # 筛选平值附近各五档行权价、距到期 150–200 天的合约。
        option.set_filter(lambda u: u.strikes(-5, 5).expiration(150, 200))
        # 用 None 表示尚未选择该期权腿，后续据此控制建仓。
        self._put_contract = None

    # 行情到达时执行；data 包含该时间片可用的数据。
    def on_data(self, data: Slice):
        # 尚未持有 SPY 时建立目标仓位；这是行情事件中的条件判断。
        if not self.portfolio[self._equity_symbol].invested:
            # 把 SPY 调整至 100% 目标权重，随后退出本次行情处理。
            self.set_holdings(self._equity_symbol, 1)
            return

        # 时间超过指定日期、且尚未记录期权合约时，寻找保护性看跌期权。
        if self._put_contract is None and self.time > datetime(2014, 1, 1):
            for chain in data.option_chains.values():
                # 只保留看跌期权；若列表为空，继续检查其他期权链。
                puts = [c for c in chain if c.right == OptionRight.PUT]
                if not puts:
                    continue
                # 选择行权价最接近标的当前价的看跌期权，即最接近平值的合约。
                contract = sorted(puts, key=lambda c: abs(c.strike - c.underlying_last_price))[0]
                # 按市价买入一张合约；数量 1 是合约张数，不是标的股数。
                self.market_order(contract.symbol, 1)
                # 记录选中的合约，避免再次触发同一首次买入条件。
                self._put_contract = contract.symbol
```

```python
# 中文注释版：仅补充解释，保留原示例的执行语句。
# region imports
# 导入 LEAN 的常用算法类、数据类型及枚举。
from AlgorithmImports import *
# endregion

# 定义继承 QCAlgorithm 的策略类，由 LEAN 管理其生命周期。
class HyperActiveOrangeHippopotamus(QCAlgorithm):

    # 初始化只在算法开始时运行一次，设置回测条件和数据订阅。
    def initialize(self):
        # 设置历史回测的开始日期。
        self.set_start_date(2023, 2, 3)
        # 设置历史回测的结束日期。
        self.set_end_date(2023, 3, 3)
        # 设置回测初始资金为 100,000 单位账户货币。
        self.set_cash(100000)
        # 订阅期权链；实际可交易合约由下面的筛选器决定。
        option = self.add_option("GOOG", Resolution.MINUTE)
        # 保存期权链的 Symbol，用于从行情时间片读取对应链。
        self.symbol = option.symbol
        # 筛选平值附近各十档行权价、距到期 30–45 天的合约。
        option.set_filter(lambda universe: universe.strikes(-10, 10).expiration(30, 45))

        # 用 None 表示尚未选择该期权腿，后续据此控制建仓。
        self.itm_call = None
        # 用 None 表示尚未选择该期权腿，后续据此控制建仓。
        self.otm_call = None

    # 行情到达时执行；data 包含该时间片可用的数据。
    def on_data(self, data: Slice):
        # 获取当前时间片中的期权链；没有数据就退出本次处理。
        chain = data.option_chains.get(self.symbol, None)
        if not chain: return

        if self.itm_call is None:
            # 选取当前期权链中最远的到期日。
            expiry = sorted(chain, key = lambda x: x.expiry, reverse=True)[0].expiry
            # 筛选该到期日的实值看涨期权，再选择最低行权价。
            itm_calls = [c for c in chain if c.expiry == expiry and c.right == OptionRight.CALL and c.strike < chain.underlying.price]
            if len(itm_calls) == 0: return
            self.itm_call = sorted(itm_calls, key=lambda x: x.strike)[0]
            # 卖出一张实值看涨期权，建立价差的空头腿。
            self.market_order(self.itm_call.symbol, -1)

        if self.otm_call is None and self.time.day > 13:
            # 筛选同到期、行权价高于空头腿的虚值看涨期权，再取最高行权价。
            otm_calls = [c for c in chain if c.expiry == self.itm_call.expiry and c.right == OptionRight.CALL and c.strike > chain.underlying.price and c.strike > self.itm_call.strike]
            if len(otm_calls) == 0: return
            self.otm_call = sorted(otm_calls, key=lambda x: x.strike)[-1]
            # 买入一张虚值看涨期权，补上价差的多头腿。
            self.market_order(self.otm_call.symbol, 1)
```

```python
# 中文注释版：仅补充解释，保留原示例的执行语句。
# region imports
# 导入 LEAN 的常用算法类、数据类型及枚举。
from AlgorithmImports import *
# endregion

# 定义继承 QCAlgorithm 的策略类，由 LEAN 管理其生命周期。
class SleepyTanAlligator(QCAlgorithm):

    # 初始化只在算法开始时运行一次，设置回测条件和数据订阅。
    def initialize(self):
        # 设置历史回测的开始日期。
        self.set_start_date(2023, 10, 1)
        # 设置历史回测的结束日期。
        self.set_end_date(2023, 11, 1)
        # 设置回测初始资金为 100,000 单位账户货币。
        self.set_cash(100000)
        # 订阅标普 500 E-mini 期货，后续从期货链选择实际合约。
        self.future = self.add_future(Futures.Indices.SP_500_E_MINI)
        # 保存期货链的标识，区别于实际下单的具体到期合约。
        self.symbol = self.future.symbol
        # 保留距离到期 0–182 天的期货合约。
        self.future.set_filter(0, 182)

    # 行情到达时执行；data 包含该时间片可用的数据。
    def on_data(self, data: Slice):
        # 只有组合没有任何持仓时才建仓，避免每次行情都重复买入。
        if not self.portfolio.invested:
            for continuous_contract_symbol, chain in data.futures_chains.items():
                # 按未平仓量从大到小选第一个合约；原文示例假设链不为空。
                contract = sorted(chain, key=lambda contract: contract.open_interest, reverse=True)[0]
                # 按市价买入一张合约；数量 1 是合约张数，不是标的股数。
                self.market_order(contract.symbol, 1)

    # 在日终回调中记录保证金数据，便于比较使用量与剩余额度。
    def on_end_of_day(self, symbol) -> None:
        # 把剩余保证金画入 Margin 图表的 MarginRemaining 序列。
        self.plot("Margin", "MarginRemaining", self.portfolio.margin_remaining)
        # 把已使用保证金画入同一图表，便于对比。
        self.plot("Margin", "TotalMarginUsed", self.portfolio.total_margin_used)
```

```python
# 中文注释版：仅补充解释，保留原示例的执行语句。
# region imports
# 导入 LEAN 的常用算法类、数据类型及枚举。
from AlgorithmImports import *
# endregion

# 原文杠杆示例：EURUSD 目标敞口为权益的 500%，用于说明保证金比例。
# 定义继承 QCAlgorithm 的策略类，由 LEAN 管理其生命周期。
class ForexMarginAlgorithm(QCAlgorithm):
    # 初始化只在算法开始时运行一次，设置回测条件和数据订阅。
    def initialize(self):
        # 设置历史回测的开始日期。
        self.set_start_date(2018, 1, 1)
        # 设置历史回测的结束日期。
        self.set_end_date(2018, 10, 1)
        # 设置回测初始资金为 100,000 单位账户货币。
        self.set_cash(100000)
        # 订阅 OANDA 的 EURUSD 日线，使用该市场对应的模型。
        self._symbol = self.add_forex("EURUSD", Resolution.DAILY, Market.OANDA).symbol

    # 行情到达时执行；data 包含该时间片可用的数据。
    def on_data(self, data: Slice):
        # 只有组合没有任何持仓时才建仓，避免每次行情都重复买入。
        if not self.portfolio.invested:
            # 5 表示目标市值为账户权益的五倍；需要对应杠杆与购买力支持。
            self.set_holdings(self._symbol, 5)
```

## 序列颜色变化 · Series Color Changes

图随回测逐日更新，但某标的颜色到结束时才最终确定，因此执行中与结束后的颜色可能不同。

## 序列名称 · Series Names

序列名采用标的最后已知代码。如果不同历史资产具有相同的最后代码，例如不同年份的 FB，可能显示同一个序列名称；不能仅凭标签断定是同一资产。
