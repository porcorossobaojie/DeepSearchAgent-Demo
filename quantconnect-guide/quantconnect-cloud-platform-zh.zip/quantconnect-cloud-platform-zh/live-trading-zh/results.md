# 结果分析 · Results

## 简介 · Introduction

实时结果页用于监控运行表现、持仓和订单，调查策略是否按预期执行。

## 查看实时结果 · View Live Results

部署后自动打开，包含权益曲线、持仓、交易、日志和服务器信息，随执行更新。关闭或刷新网页不会中断云端运行。重新打开项目并点击 Deploy Live，可返回结果页。

## 运行统计 · Runtime Statistics

顶部横幅展示权益、费用、持仓、净收益、PSR、收益率、未实现盈亏和交易量等。可增加自定义统计；停止后再部署会重置运行统计。

## 内置图表 · Built-in Charts

Strategy Equity 中 Equity 是实时权益，Out of Sample Backtest 是同一期间的样本外回测权益，Meta 标记部署、停止与运行错误。

其他图包括回撤、基准（默认 SPY）、多空敞口、标的交易量占比、换手率、保证金占用和资产交易图。比较实时和回测时还需阅读 Reconciliation，不能只看两条曲线是否接近。

## 资产图 · Asset Plots

在 Orders 点击标的旁 Asset Plot。提交为灰圆、更新蓝圆、取消灰方块，成交／部分成交为绿色买入或红色卖出箭头，提交标记默认隐藏。

悬停显示价格、事件和标签。用范围按钮或拖动缩放，缩小后可能把同日事件合并显示。成交价与图表价格可能因滑点、买卖报价和成交模型不同。

## 自定义图表 · Custom Charts

算法创建的自定义图会显示在结果页。Candle 会聚合提供的数据点，plot 每时点一个数值，并不能直接传入 OHLC 或指定每根蜡烛的周期。

类型与标记清单在官网通过 API 类型树生成，本地未伪造完整枚举。实时图按一分钟或十分钟采样；一分粒度积累足够多样本后，IDE 可能降为十分粒度。

## 调整图表 · Adjust Charts

Select Chart 可显示／隐藏图表，点击序列名可显示／隐藏序列。范围按钮或横向拖动缩放，底部水平条平移。右下角拖动调整尺寸，拖标题移动。

重置按钮恢复缩放；运行中刷新图表可能仅显示刷新后引擎见到的数据。

## 持仓 · Holdings

| 字段 | 含义 |
| --- | --- |
| Symbol | 标的代码 |
| Average Price | 平均持仓成本 |
| Quantity | 持仓数量 |
| Market Value | 按市价计算的价值 |
| Unrealized | 未实现利润，原文含费用与价差成本 |

随行情更新。现金区域来自 CashBook。勾选 Show All Portfolio 查看全部持仓和活跃订阅；可在此添加订阅及手动下单。

## 订单 · Orders

Orders 展示订单及提交、成交、部分成交、更新、取消和期权事件。展开查看细节，超过十条可分页。

页面订单时间为 ET，Download Orders 的 CSV 为 UTC。API 导出 `/live/export/orders` 原文保留最近 750 天；更早记录使用 `read_live_orders` 或 `/live/orders/read`。研究环境也可用该读取端点分析云端订单。

## 交易 · Trades

Trades 展示按 Trade Statistics 规则组合的已结束交易，展开可查看组成它的成交。页面按 ET，Download Trades 的 CSV 按 UTC，API 导出为 `/live/export/trades`。

交易不是单条订单，同一交易可能由多个订单成交组成。

## 投资见解 · Insights

Insights 展示算法发出的见解，可分页并通过 Download Insights 下载。共享原文标题为 JSON，但正文提到 CSV 时间，存在格式描述不一致；需检查实际文件而非猜测格式。

## 日志 · Logs

Logs 显示日志和部署、错误、发单、退出等状态。**本实时章节规定时间为 UTC**，不要套用回测“算法时区”的说明。

停止后再部署会保留日志。Filter logs 搜索，Download Logs 下载。建议对关键行为保留适量日志，便于调查。

## 项目文件 · Project Files

Code 标签展示此次运行使用的项目文件，默认主策略文件，可用下拉切换。Clone Algorithm 以这些文件创建新项目。

## 查看全部实时项目 · View All Live Projects

左侧闪电图标打开 Live Dashboard，展示组织中的实时算法状态。点击行打开项目，再点击 Deploy Live 查看结果。

## 错误 · Errors

运行错误会停止算法并发送邮件。启用自动重启时会尝试恢复，但连续失败五次后不再重试，且须满足部署章节描述的运行时长等条件。

## 分享结果 · Share Results

Share Results 点击 Make Public 后，可复制 Live Stream 链接或 Embed Code 的 iframe。无需 QuantConnect 账号也可能访问公开结果。

URL 的 theme 参数可选 darkly（深色）、chrome（浅色）。停止分享使用 Make Private。
