# 策略运行控制 · Algorithm Control

## 简介 · Introduction

实时结果页允许在运行中添加订阅、手动交易和控制算法。它与修改源码后重新部署不同，会直接影响正在运行的实例。

## 添加行情订阅 · Add Security Subscriptions

1. 在实时结果页 Holdings 点击 **Add Security**。
2. 填代码、资产类型、数据频率、杠杆和市场。
3. 按需勾选 Fill Forward（填充前值）和 Extended Market Hours（延长交易时段）。
4. 点击 Add Security。

添加后可以通过 IDE 手动交易，不必仅为新增标的重部署。原文说明不能从 IDE 手动删除订阅。

## 手动下单 · Place Manual Trades

可以使用部署券商支持的订单类型。适用场景包括处理已有持仓、修正买错标的、增加对冲或提前再平衡。

1. 打开实时结果页的 Holdings，必要时勾选 Show All Portfolio。
2. 若标的仍未列出，先添加订阅。
3. 点击标的，选择 **Create Order** 或 **Liquidate**。
4. 创建订单时填写数量，选择 Type，点击 **Submit Order**。

原文说明当前无法取消这类手动订单，实际能力须核对当前界面。与直接在券商账户下单不同，本文描述的是平台 IDE 的操作；账户外部操作前应先停止算法。

## 平仓 · Liquidate Positions

结果页点击 Liquidate 并确认。开市时提交市价平仓单，未开市提交开盘市价单，提交后停止算法。可能仍有尚未成交的订单，需核对券商状态。

## 停止算法 · Stop the Algorithm

点击 Stop 并确认，算法停止但持仓保留。修改代码、节点、向导配置或到券商端手动操作前，先停止；之后根据状态重新部署。

## 更新算法 · Update the Algorithm

停止后修改源码或 Project 参数，再重新部署。新实例不保留所有内存状态；同项目的实时历史会保留，若需新历史则克隆。

如需运行中读取业务配置，原文提出定时下载远程文件的方法，不是修改部署时注入的项目参数：

```python
# 中文注释版：仅补充解释，保留原示例的执行语句。
# 片段演示每分钟读取远程配置；需放入完整算法并补齐解析与错误处理。
# 初始化只在算法开始时运行一次，设置回测条件和数据订阅。
def initialize(self):
    # 这个字典用于算法自己的配置状态，不是 Project 参数面板。
    self.parameters = {}
    if self.live_mode:
        def download_parameters():
            # url_to_remote_file 由开发者定义；远程内容需验证后再应用。
            content = self.download(url_to_remote_file)
            # 原文省略：将 content 解析并更新 self.parameters。

        # 注册每天有效、每分钟触发的定时事件。
        self.schedule.on(
            self.date_rules.every_day(),
            self.time_rules.every(timedelta(minutes=1)),
            download_parameters
        )
```

## 接收命令 · Receive Commands

Commands 允许向运行中的算法发送信息并调用预先实现的方法，可更新状态或触发其他逻辑。Notifications 是“向外发送”，Commands 是“向内接收”。具体处理 API 见 Writing Algorithms 的 Commands 章节。
