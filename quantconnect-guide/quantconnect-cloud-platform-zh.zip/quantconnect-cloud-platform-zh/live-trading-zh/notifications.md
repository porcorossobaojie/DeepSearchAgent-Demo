# 通知 · Notifications

## 简介 · Introduction

通知支持邮件、短信、Telegram 和 Webhook。部署向导可对订单事件或投资见解通知；其他时机可由代码的 NotificationManager 发出。**回测会忽略通知**。

## 邮件 · Email

邮件正文原文上限 10 KB，经过邮件服务商可能较慢；没收到时检查垃圾箱。

在 Deploy Live 启用 **Order Events** 或 **Insights**，点击 **Email**，输入地址和主题，点击 Add。更多接收配置可点 Add Notification。

## 短信 · SMS

短信正文原文上限 1,600 字符，不要求收件人连接互联网，但仍依赖运营商服务。

启用事件类型，点击 **SMS**，输入号码，再点击 Add。短信收费见配额。

## Telegram · Telegram

创建群组并加入机器人；自建可联系 @BotFather，或使用 @quantconnect_notifications_bot。部署向导启用通知类型，点击 Telegram，填用户或群组 ID。使用自建机器人时还需其 token，再点 Add。

原文举例 `web.telegram.org/z/#-503016366` 的群组 ID 为 `-503016366`。Telegram 界面版本可能变化，应核对实际 ID。

## Webhook · Webhooks

Webhook 向指定网址发 HTTP POST，原文请求超时 300 秒。可在自己的服务写入数据库或继续处理。

部署页启用事件类型，点击 Webhook，填写 URL；如需请求头，用 **Add Header** 填键和值，再点击 Add。

### 顶层字段

| 字段 | 类型及含义 |
| --- | --- |
| ProjectName | 项目名字符串 |
| ProjectId | 项目整数 ID |
| Insights | 自上次通知以来的投资见解数组 |
| OrderEvents | 自上次通知以来的订单事件数组 |
| Portfolio | 当前持仓及现金数组 |

### 订单事件字段

| 字段 | 含义 |
| --- | --- |
| OrderId / Id | 订单 ID／订单事件 ID |
| Symbol | value（代码）、id（标的 ID）、permtick（永久代码）对象 |
| UtcTime | ISO 8601 UTC 时间 |
| Status | 1 已提交、2 部分成交、3 成交、5 取消、6 无效、7 待取消、8 更新已提交 |
| OrderFee | Value 内含 Amount 数值和 Currency 币种 |
| FillPrice / FillPriceCurrency | 成交价／计价币种 |
| FillQuantity | 本次事件成交量 |
| Direction | 0 买、1 卖、2 持有 |
| IsAssignment | 是否为期权指派 |
| Quantity | 订单总数量 |

Webhook 的序列化格式与一般 API 响应不同，不能直接套用其他端点字段。

### 组合字段

Ticker 为代码，Quantity 为数量，AveragePrice 为均价，`UnreazliedProfit` 为未实现利润。**后者拼写按原文保留**，不要擅自改成另一个键。现金项不含均价和未实现利润。

下面是原始 JSON 示例。JSON 不允许注释，因此字段含义放在上方表格中，保留合法可解析格式：

```json
{
  "ProjectName": "My Algorithm",
  "ProjectId": 29064060,
  "Insights": [
    {
      "Id": "a0af97846797499dbd515753bdb73a0c",
      "GroupId": null,
      "SourceModel": "4a834e9d-f10f-4ebe-9fd9-df5fc509b0f8",
      "GeneratedTime": 1773767160.2239125,
      "CreatedTime": 1773767160.2239125,
      "CloseTime": 1777482360.2239125,
      "Symbol": "SPY R735QTJ8XC9X",
      "Ticker": "SPY",
      "Type": "price",
      "reference": 671.77,
      "ReferenceValueFinal": 0,
      "Direction": "up",
      "Period": 2592000,
      "Magnitude": null,
      "Confidence": null,
      "Weight": null,
      "ScoreIsFinal": false,
      "ScoreMagnitude": "0",
      "ScoreDirection": "0",
      "EstimatedValue": "0",
      "Tag": ""
    }
  ],
  "OrderEvents": [
    {
      "OrderId": 1,
      "Id": 1,
      "Symbol": {
        "value": "AAPL",
        "id": "AAPL R735QTJ8XC9X",
        "permtick": "AAPL"
      },
      "UtcTime": "2026-03-17T17:06:00.2239123Z",
      "Status": 3,
      "OrderFee": {
        "Value": {
          "Amount": 1,
          "Currency": "USD"
        }
      },
      "FillPrice": 254.05,
      "FillPriceCurrency": "USD",
      "FillQuantity": 130,
      "Direction": 0,
      "IsAssignment": false,
      "Quantity": 130
    }
  ],
  "Portfolio": [
    {
      "Ticker": "AAPL",
      "Quantity": 130,
      "AveragePrice": 254.05,
      "UnreazliedProfit": -4.9
    },
    {
      "Ticker": "USD",
      "Quantity": 34053.79
    }
  ]
}
```

Insights 对象中的 Id／GroupId 为识别和分组信息，SourceModel 为来源模型；GeneratedTime、CreatedTime、CloseTime 为时间字段，Period 为持续长度；Magnitude、Confidence、Weight 为幅度、置信度和权重，null 表示未提供。评分相关键用于见解评价，具体定义见原文的 Insight API，不应仅从本示例推断所有类型。

## 配额 · Quotas

邮件、Telegram 和 Webhook 按每个实时算法的小时额度计算：

<table class="qc-table table">
    <thead>
        <tr>
            <th>套餐</th>
            <th>每小时通知数</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Free</td>
            <td>不适用</td>
        </tr>
        <tr>
            <td>Quant Researcher</td>
            <td>20</td>
        </tr>
        <tr>
            <td>Team</td>
            <td>60</td>
        </tr>
        <tr>
            <td>Trading Firm</td>
            <td>240</td>
        </tr>
        <tr>
            <td>Institution</td>
            <td>3,600</td>
        </tr>
    </tbody>
</table>

超过后原文每条 1 QCC；发美国或加拿大短信每条 1 QCC，国际号码每条 10 QCC。费用和额度以当前平台为准。

## 使用条款 · Terms of Use

通知系统不能用于分发数据。
