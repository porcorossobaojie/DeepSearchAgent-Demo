# 入门 · Getting Started

## 简介 · Introduction

实时算法按当前市场数据运行，可采用模拟账户或真实券商账户。平台介绍其算法托管在 Equinix 等数据中心，由工程团队维护。原文关于稳定运行时长的描述是服务介绍，不是本文验证的可用性承诺。

## 部署实时算法 · Deploy Live Algorithms

每个同时运行的算法需要一个可用实时节点。

1. 打开项目，点击 **Deploy Live**。
2. 在 Brokerage 选择 **QuantConnect Paper Trading** 进行平台模拟；接入真实券商请按该券商专属文档填写认证信息。
3. 选择 Region 和对应 Node。
4. 如需修改行情来源，在 Data Provider 点击 Show。
5. 模拟账户可在 Algorithm Cash State 点击 Show、Add Currency，填写币种和数量。
6. 可在 Algorithm Holdings State 添加标的 ID、代码、数量和均价。
7. 按需设置通知和 **Automatically restart algorithm**。
8. 点击 **Deploy**，等待结果页，原文部署最长可能约五分钟。

部署后核对权益、现金和持仓。不同券商可恢复的内容不同，重启不会自动保留全部算法状态。

此为共享原文的云端模拟流程；IB 等券商还需要认证、行情授权及可能的每周重新认证。应使用对应券商文档，不能把模拟字段当成真实账户资金设置。

## 重启实时算法 · Restart Live Algorithms

停止后重新部署、更新和自动错误恢复都会启动新实例，并再次执行 `initialize`。

开启自动重启后会尽力恢复，失败五次后停止尝试；不能替代监控。通常从券商恢复现金、持仓，以及部分券商支持的未结订单，其余状态须自行重建，详见部署章节 State Persistence。

## 停止实时算法 · Stop Live Algorithms

在实时结果页点击 **Stop**，再次 Stop 确认。**持仓保留，不会自动平仓。**

修改代码、节点、部署设置，或需要直接在券商账户手动操作前，先停止算法。运行中绕过算法操作账户可能触发干扰检测，导致算法停止。反向并购等产生新持仓时也可能需要停止并重新部署。

## 平仓并停止 · Liquidate Live Algorithms

结果页点击 **Liquidate** 并再次确认。开市标的提交市价平仓单，未开市标的提交开盘市价单；提交后算法停止。**提交订单不代表已经全部成交。**

## 更新实时算法 · Update Live Algorithms

修改代码或 Project 参数需要停止、修改并重新部署。项目参数不是运行中热更新接口。

如果确实需要动态读取配置，原文展示定时下载远程文件的思路，以下保留示例并补注释：

```python
# 中文注释版：仅补充解释，保留原示例的执行语句。
# 此为配置热更新思路片段；不是可直接运行的完整策略。
# 初始化只在算法开始时运行一次，设置回测条件和数据订阅。
def initialize(self):
    # 保存由远程文件解析得到的业务配置；不是修改 Project 参数面板。
    self.parameters = {}
    if self.live_mode:
        def download_parameters():
            # url_to_remote_file 需事先定义；下载内容仍需校验和解析。
            content = self.download(url_to_remote_file)
            # 原文省略了将 content 转换为 self.parameters 的实现。

        # 实时模式下每分钟触发一次下载；自行处理失败和配置有效性。
        self.schedule.on(
            self.date_rules.every_day(),
            self.time_rules.every(timedelta(minutes=1)),
            download_parameters
        )
```

## 冗余部署 · Redundancy

部署区域包括 America / NY7（纽约）、Canada / TOR（多伦多）和 Europe / WAW（华沙），默认 NY7。选择区域后只列出该区可用节点。

跨区部署可降低单地区事故影响，但这不是自动无缝故障切换；需提前准备节点与状态恢复。原文提醒临时扩容可能要数天或数周。涉及 Binance、Bybit 的地区限制，原文要求选择 Europe，实际支持须核对当前券商及地区条款。

## 专用主机 · Dedicated Hosts

原文描述专供单个组织的主机为 80 核、160 GB 内存，通常配置为 20 个 L4-8 节点，可咨询其他组合；可在 NY7 和 TOR 申请。实际规格与供应以平台确认为准。

## 清除实时历史 · Clear Live Algorithms History

同一项目停止后再部署仍保留历史。要开始一份新的实时历史，克隆项目并部署副本。

## 本地实时算法 · On-Premise Live Algorithms

原文引用 Local Platform 入门，属于另一个部署流程，本篇不将其写成云端操作。

## 获取部署 ID · Get Deployment Id

在日志搜索 **Launching analysis for**。同一项目多次部署时使用最新一条 ID，例如 `L-6bf91128391608d0728ff90b81bfca41`。

## 获取部署详情 · Get Deployment Details

部署详情是券商提供的只读键值对，例如账户识别信息，不包含认证凭据。不同券商提供的键不同，有些不提供。

LEAN 在调用 initialize 前填好 `deployment_details`；外部也可通过 `/live/read` 的 deploymentDetails 字段获取。

```python
# 中文注释版：仅补充解释，保留原示例的执行语句。
# 将只读部署详情中的键值对整理成字符串，便于核对连接账户。
deployment_details = [f'{kvp.key}:{kvp.value}' for kvp in self.deployment_details]
# 原文说明这些详情不含凭据；日志仍应按账号信息的访问要求管理。
# 记录常规运行信息，消息写入日志并计入日志额度。
self.log(f'deployment_details: {deployment_details}')
```

## 自动化部署 · Automate Deployments

可在研究笔记本通过 API 编程部署、停止或平仓多个算法。具体 API 参数见本节原文链接；本次仅翻译说明，未执行这些操作。
