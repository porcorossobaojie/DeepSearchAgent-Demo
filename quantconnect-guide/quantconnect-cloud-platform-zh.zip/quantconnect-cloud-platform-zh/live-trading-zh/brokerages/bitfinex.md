# Bitfinex

非官方中文翻译，按原文小节排列；专有名词、按钮、错误消息和代码字段保留英文对照。费用、IP、权限及产品范围为所标源码版本的记录。各节保留官方链接，代码保留执行语句并添加中文注释。

## 简介 · 01 Introduction

<p>QuantConnect 支持使用实时行情运行实盘模式的算法。</p>
<p>Bitfinex 由 Giancarlo Devasini、Raphael Nicolle 于 2012 年创立，面向非禁止地区提供加密交易。原文记载法币 USD/EUR/GBP 入金最低 10,000，加密入金无最低额；另有质押、移动 App 和未实现收益排行，强调数字资产技术创新。</p>
<p>集成实现见 Lean.Brokerages.Bitfinex 仓库。</p>

## 账户类型 · 02 Account Types

<p>Bitfinex 支持现金和保证金账户；算法设置方式见对应券商模型文档。</p>
<p>AccountType.Cash/CASH 连接 Exchange 钱包，AccountType.Margin/MARGIN 连接 Margin 钱包；不支持 Funding 或 Capital Raise。向 set_brokerage_model 传错类型可能连接空钱包并产生警告。名称以 F0 结尾的币种不载入 CashBook。</p>
<h4>创建账户</h4>
<p>按 Bitfinex 官网开户向导开立账户。</p>
<p>开户后生成并妥善保存 API 凭据用于部署。</p>
<h4>模拟交易</h4>
<p>原生模拟只支持 TESTBTCTESTUSD 和 TESTBTCTESTUSDT，步骤如下：</p>
<ol>
<li>创建模拟子账户并补充虚拟余额，见 Paper Trading 文档。</li>
<li>为子账户创建 API key，见 API Key 创建/撤销文档。</li>
<li>算法使用 AccountType.Cash/CASH。</li>
</ol>
<p>若要模拟其他证券，按以下步骤使用 QuantConnect Paper Trading 模拟券商：</p>
<ol>
<li>在 Initialize/initialize 中设置 Bitfinex 券商模型和账户类型。</li>
<li>使用 QuantConnect Paper Trading 券商部署算法。</li>
</ol>


## 资产类别 · 04 Asset Classes

<p>本集成支持加密货币交易。</p>


## 数据源 · 05 Data Providers

<p>QuantConnect 数据源提供实时加密货币行情。</p>

## 订单 · 06 Orders

<p>平台对 Bitfinex API 的订单类型、属性和更新进行建模；实盘部署后也可通过 IDE 手动下单。</p>
<h4>订单类型</h4>
<p>下表列出本集成对各资产支持的订单类型：</p>
<table class="qc-table table">
<thead>
<tr>
<th style="width: 50%">订单类型</th>
<th>加密货币</th>
</tr>
</thead>
<tbody>
<tr>
<td>市价单（Market）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>限价单（Limit）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>止损市价单（Stop market）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>止损限价单（Stop limit）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
</tbody>
</table>

<h4>订单属性</h4>
<p>下表为 Bitfinex API 的自定义订单属性，可用 BitfinexOrderProperties 设置。</p>
<table class="table qc-table">
<thead>
<tr>
<th>属性</th>
<th>数据类型</th>
<th>说明</th>
<th>默认值</th>
</tr>
</thead>
<tbody>
<tr>
<td><code class="csharp">TimeInForce</code><code class="python">time_in_force</code></td>
<td><code>TimeInForce</code></td>
<td>
             A <a href="https://www.quantconnect.com/docs/v2/writing-algorithms/trading-and-orders/order-properties#03-Time-In-Force">TimeInForce</a>为订单设置有效期，支持以下取值：<ul>
<li>当日有效（Day / DAY）</li>
<li><code class="csharp">GoodTilCanceled</code><code class="python">GOOD_TIL_CANCELED</code></li>
<li>指定日期前有效（GoodTilDate / good_til_date）</li>
</ul>
</td>
<td><code class="csharp">TimeInForce.GoodTilCanceled</code><code class="python">TimeInForce.GOOD_TIL_CANCELED</code></td>
</tr>
<tr>
<td><code class="csharp">Hidden</code><code class="python">hidden</code></td>
<td><code>bool</code></td>
<td>隐藏订单不显示在订单簿中，不影响其他参与者的可见报价，但收 taker 手续费。</td>
<td></td>
</tr>
<tr>
<td><code class="csharp">PostOnly</code><code class="python">post_only</code></td>
<td><code>bool</code></td>
<td>订单只能提供流动性，不能吃单；任意部分会吃单则整单拒绝，不会部分成交。</td>
<td></td>
</tr>
</tbody>
</table>
<h4>更新订单</h4>
<p>本集成支持更新 Bitfinex 订单。</p>


## 手续费 · 07 Fees

<p>Bitfinex 收费见 Fees Schedule；平台模型见 Fees。</p>
<p>通过 Bitfinex 部署前，在官网 Account &gt; Fees 设置以下选项：</p>
<table class="table qc-table">
<thead>
<tr>
<th style="width: 50%">费用设置</th>
<th style="width: 50%">取值</th>
</tr>
</thead>
<tbody>
<tr>
<td>手续费默认币种</td>
<td>USD</td>
</tr>
<tr>
<td>Exchange 订单费用类型</td>
<td>币种兑换手续费</td>
</tr>
</tbody>
</table>


## 保证金 · 08 Margin

<p>平台模拟购买力和追加保证金，帮助算法遵守保证金要求。</p>


## 滑点 · 09 Slippage

<p>Bitfinex 回测不计滑点；Bitfinex 模拟与实盘订单可能产生滑点。</p>
<p>Bitfinex 滑点模型见 Slippage。</p>

## 成交 · 10 Fills

<p>回测中 QuantConnect 立即、全部成交市价单。Bitfinex 模拟和实盘中，若数量超过盘口最优档可用数量，会按订单簿实际流动性成交。</p>
<p>Bitfinex 成交模型见 Fills。</p>

## 结算 · 11 Settlements

<p>交易后立即结算。</p>
<p>Bitfinex 结算模型见 Settlement。</p>


## 安全与稳定性 · 12 Security and Stability

<p>本集成的安全与稳定性说明如下。</p>
<h4>账户凭据</h4>
<p>通过 Bitfinex 部署时，平台不保存登录凭据。</p>
<h4>API 服务中断</h4>
<p>实盘订单通过 Bitfinex API 提交，API 有时可能中断；可在其状态页查看服务情况。</p>


## 入金与出金 · 13 Deposits and Withdrawals

<p>算法运行时仍可给关联券商账户出入金；平台每天美东时间 7:45 同步账户现金余额。</p>


## 演示算法 · 14 Demo Algorithm

<p>以下算法演示 Bitfinex 的功能：</p>
<div class="section-example-container testable">
<pre><code class="language-csharp">// 中文注释版：仅补充解释，保留原示例的执行语句。&#10;// Demonstrate Bitfinex brokerage functionality with an EMA crossover strategy.&#10;public class BitfinexDemoAlgorithm : QCAlgorithm&#10;{&#10;    private Symbol _symbol;&#10;    private ExponentialMovingAverage _fast;&#10;    private ExponentialMovingAverage _slow;&#10;&#10;    public override void Initialize()&#10;    {&#10;        // 设置回测开始日期；实盘运行不以此恢复历史状态。&#10;        SetStartDate(2024, 9, 1);&#10;        // 设置回测结束日期。&#10;        SetEndDate(2024, 12, 31);&#10;        // 设置回测初始现金；实盘资金以券商账户和部署配置为准。&#10;        SetCash(100000);&#10;        // 设置券商模型和账户类型，决定资产、订单及现实约束。&#10;        SetBrokerageModel(BrokerageName.Bitfinex, AccountType.Cash);&#10;        // 订阅指定市场的加密货币对。&#10;        _symbol = AddCrypto("BTCUSD", Resolution.Daily, Market.Bitfinex).Symbol;&#10;        // 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        _fast = EMA(_symbol, 10, Resolution.Daily);&#10;        // 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        _slow = EMA(_symbol, 50, Resolution.Daily);&#10;    }&#10;&#10;    public override void OnData(Slice slice)&#10;    {&#10;        // 指标准备好后才使用信号，历史样本不足时退出。&#10;        if (!_slow.IsReady) return;&#10;        if (_fast &gt; _slow &amp;&amp; !Portfolio.Invested)&#10;            // 按目标权重调整仓位；1 表示账户权益的 100%，不是买入 1 股。&#10;            SetHoldings(_symbol, 1);&#10;        else if (_fast &lt; _slow &amp;&amp; Portfolio.Invested)&#10;            // 请求平仓；实际成交仍取决于市场和券商。&#10;            Liquidate();&#10;    }&#10;}</code></pre>
<pre><code class="language-python"># 中文注释版：仅补充解释，保留原示例的执行语句。&#10;# Demonstrate Bitfinex brokerage functionality with an EMA crossover strategy.&#10;# 定义继承 QCAlgorithm 的策略类，由 LEAN 管理其生命周期。&#10;class BitfinexDemoAlgorithm(QCAlgorithm):&#10;    # 初始化只在算法开始时运行一次，设置回测条件和数据订阅。&#10;    def initialize(self) -&gt; None:&#10;        # 设置历史回测的开始日期。&#10;        # 设置回测开始日期；实盘运行不以此恢复历史状态。&#10;        self.set_start_date(2024, 9, 1)&#10;        # 设置历史回测的结束日期。&#10;        # 设置回测结束日期。&#10;        self.set_end_date(2024, 12, 31)&#10;        # 设置回测初始资金为 100,000 单位账户货币。&#10;        # 设置回测初始现金；实盘资金以券商账户和部署配置为准。&#10;        self.set_cash(100000)&#10;        # 设置券商模型和账户类型，决定资产、订单及现实约束。&#10;        self.set_brokerage_model(BrokerageName.BITFINEX, AccountType.CASH)&#10;        # 订阅指定市场的加密货币对。&#10;        self._symbol = self.add_crypto("BTCUSD", Resolution.DAILY, Market.BITFINEX).symbol&#10;        # 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        self._fast = self.ema(self._symbol, 10, Resolution.DAILY)&#10;        # 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        self._slow = self.ema(self._symbol, 50, Resolution.DAILY)&#10;&#10;    # 行情到达时执行；data 包含该时间片可用的数据。&#10;    def on_data(self, slice: Slice) -&gt; None:&#10;        # 指标准备好后才使用信号，历史样本不足时退出。&#10;        if not self._slow.is_ready:&#10;            return&#10;        if self._fast.current.value &gt; self._slow.current.value and not self.portfolio.invested:&#10;            # 按目标权重调整仓位；1 表示账户权益的 100%，不是买入 1 股。&#10;            self.set_holdings(self._symbol, 1)&#10;        elif self._fast.current.value &lt; self._slow.current.value and self.portfolio.invested:&#10;            # 请求平仓；实际成交仍取决于市场和券商。&#10;            self.liquidate()</code></pre>
</div>

## 虚拟币对 · 15 Virtual Pairs

<p>每种法币和加密币都是独立资产。买入 BTCUSD 实际是用 USD 换 BTC，现金账簿减少 USD、增加 BTC；BTCUSD 持仓是表示交易的虚拟币对。部署时 LEAN 可载入各币种余额，却无法从余额反推每个虚拟币对的持仓。</p>


## 部署算法 · 16 Deploy Live Algorithms

<p>每个实盘算法必须有一个可用实盘节点。</p>
<p>按以下步骤部署实盘算法：</p>
<ol>
<li>打开要部署的项目。</li>
<p>若不使用 QuantConnect Paper Trading 券商而部署模拟算法，请在 Initialize/initialize 添加以下代码：</p>
<div class="section-example-container">
<pre><code class="language-python"># 中文注释版：仅补充解释，保留原示例的执行语句。&#10;self.set_account_currency('TESTUSD') # or 'TESTUSDT'&#10;# 设置券商模型和账户类型，决定资产、订单及现实约束。&#10;self.set_brokerage_model(BrokerageName.BITFINEX, AccountType.CASH)&#10;self.set_benchmark(lambda x: 0) # or the Symbol of the TESTBTCTESTUSD/TESTBTCTESTUSDT securities</code></pre>
<pre><code class="language-csharp">// 中文注释版：仅补充解释，保留原示例的执行语句。&#10;SetAccountCurrency("TESTUSD"); // or "TESTUSDT"&#10;// 设置券商模型和账户类型，决定资产、订单及现实约束。&#10;SetBrokerageModel(BrokerageName.Bitfinex, AccountType.Cash);&#10;SetBenchmark(x =&gt; 0); // or the Symbol of the TESTBTCTESTUSD/TESTBTCTESTUSDT securities</code></pre>
</div> <li>点击 Deploy Live（部署实盘）图标。<img alt="Lightning icon" class="inline-icon" src="https://cdn.quantconnect.com/i/tu/deploy-live-icon.png"/></li>
<li>在 Deploy Live 页面点击 Brokerage，选择 Bitfinex Exchange。</li>
<li>输入 API key 和 secret。</li><p>生成凭据见 Account Types；QuantConnect 不保存这些账户凭据。</p>
<li>在 Region 区域选择算法运行地区。</li>
<li>点击 Node 字段，选择要使用的实盘节点。</li>
<li>可选：在 Data Provider 区域点击 Show，修改数据源或添加其他数据源。</li>
<li>可选：配置通知。</li>
<li>配置 Automatically restart algorithm（自动重启算法）选项。</li>
<p>开启自动重启后，平台会尽力重启因运行错误而失败的算法，有助于应对券商 API 暂时断线等故障。</p>
<li>点击 Deploy（部署）。</li>
</ol>
<p>部署最多可能需要 5 分钟，完成后显示实盘结果页。可核对运行统计中的权益、现金账簿和持仓，确认券商原有持仓正确载入。</p>
<p>重启、自动重启和重新部署都不会保存算法全部内部状态。恢复哪些状态、其余状态如何持久化，见 State Persistence。</p>

