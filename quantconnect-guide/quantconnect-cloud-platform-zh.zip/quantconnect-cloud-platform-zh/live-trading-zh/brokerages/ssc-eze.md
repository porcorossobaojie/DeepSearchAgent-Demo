# SSC Eze

非官方中文翻译，按原文小节排列；专有名词、按钮、错误消息和代码字段保留英文对照。费用、IP、权限及产品范围为所标源码版本的记录。各节保留官方链接，代码保留执行语句并添加中文注释。

## 简介 · 01 Introduction

<p>QuantConnect 支持使用实时行情运行实盘模式的算法。</p>
<p>SS&amp;C Eze 原名 Eze Software，由 Sean McLaughlin 于 1995 年创立；其多资产、多经纪商执行管理系统（EMS）集中接入全球股票、债券、期货、期权和数字资产流动性。</p>

## 账户类型 · 02 Account Types

<p>SS&amp;C Eze 通过 EMS 路由订单，使用保证金账户；部署至专业主经纪商时在向导设置购买力。</p>
<h4>创建账户</h4>
<p>联系 SS&amp;C Eze 销售团队开户。</p>
<h4>模拟交易</h4>
<p>SS&amp;C Eze 不提供原生模拟，可通过 QuantConnect 按下列步骤模拟：</p>
<ol>
<li>在 Initialize/initialize 设置 SS&amp;C Eze 模型与账户类型。</li>
<li>使用 QuantConnect Paper Trading 券商部署算法。</li>
</ol>

## 资产类别 · 04 Asset Classes

<p>本集成支持以下资产：</p>
<ul>
<li>美国股票</li>
<li>股票期权</li>
<li>期货</li>
<li>期货期权</li>
<li>指数</li>
<li>指数期权</li>
</ul>
<p>SS&amp;C Eze 资产权限取决于所在地和账户，例如欧盟居民不能交易美国 ETF。核对当地规定，必要时调整账户权限。</p>

## 数据源 · 05 Data Providers

<p>推荐免费的 QuantConnect 数据源，覆盖美国股票、股票期权、指数期权、期货及 SPX/VIX 指数。期货期权需配合 SS&amp;C Eze 数据源，可能还需买行情订阅。详见 Datasets。</p>


## 订单 · 06 Orders

<p>本集成支持 Eze 的多种订单、TimeInForce 属性和订单更新；实盘也可在 IDE 手动下单。</p>
<h4>订单类型</h4>
<p>下表列出 SS&amp;C Eze 对各资产支持的订单类型：</p>
<table class="qc-table table">
<thead>
<tr>
<th style="width: 20%">订单类型</th>
<th style="width: 16%">股票</th>
<th style="width: 16%">股票期权</th>
<th style="width: 16%">期货</th>
<th style="width: 16%">期货期权</th>
<th style="width: 16%">指数期权</th>
</tr>
</thead>
<tbody>
<tr>
<td>市价单（Market）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>限价单（Limit）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>止损市价单（Stop market）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>止损限价单（Stop limit）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>开盘市价单</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>收盘市价单</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</tbody>
</table>

<h4>订单属性</h4>
<p>下表为 SS&amp;C Eze 自定义属性，通过 EzeOrderProperties 设置。</p>
<table class="table qc-table">
<thead>
<tr>
<th>属性</th>
<th>数据类型</th>
<th>说明</th>
<th>默认值</th>
</tr>
</thead>
<tbody>
<tr>
<td><code class="csharp">TimeInForce</code><code class="python">time_in_force</code></td>
<td><code>TimeInForce</code></td>
<td>A <a href="https://www.quantconnect.com/docs/v2/writing-algorithms/trading-and-orders/order-properties#03-Time-In-Force">TimeInForce</a>为订单设置有效期，支持以下取值：<ul>
<li>当日有效（Day / DAY）</li>
<li><code class="csharp">GoodTilCanceled</code><code class="python">GOOD_TIL_CANCELED</code></li>
<li>指定日期前有效（GoodTilDate / good_til_date）</li>
</ul>
</td>
<td><code class="csharp">TimeInForce.GoodTilCanceled</code><code class="python">TimeInForce.GOOD_TIL_CANCELED</code></td>
</tr>
<tr>
<td><code class="csharp">Account</code><code class="python">account</code></td>
<td><code class="csharp">string</code><code class="python">str</code></td>
<td>设置有权限的交易或中立账户，分号分隔，例如 TAL;TEST;USER1;TRADE 或 TAL;TEST;USER2;NEUTRAL。</td>
<td></td>
</tr>
<tr>
<td><code class="csharp">AccountType </code><code class="python">account_type</code></td>
<td><code class="csharp">string</code><code class="python">str</code></td>
<td>订单账户类型，例如 Eze EMS 的保证金单使用 119。</td>
<td></td>
</tr>
<tr>
<td><code class="csharp">Notes</code><code class="python">notes</code></td>
<td><code class="csharp">string</code><code class="python">str</code></td>
<td>用户消息或备注。</td>
<td></td>
</tr>
<tr>
<td><code class="csharp">Route</code><code class="python">route</code></td>
<td><code class="csharp">string</code><code class="python">str</code></td>
<td>SS&amp;C Eze EMS 显示的路由名称。</td>
<td></td>
</tr>
</tbody>
</table>
<h4>更新订单</h4>
<p>本集成支持 SS&amp;C Eze 订单更新。</p>
<h4>拆股处理</h4>
<p>使用原始价格（Raw）时，如果美国股票拆股，尚未成交订单中的以下属性会自动按拆股比例调整：</p>
<ul>
<li>数量</li>
<li>限价</li>
<li>止损价</li>
<li>触发价</li>
</ul>

## 手续费 · 07 Fees

<p>成交需支付 SS&amp;C Eze EMS 和目标主经纪商费用，平台模型见 Fees。</p>

## 保证金 · 08 Margin

<p>平台模拟购买力和追加保证金，帮助算法遵守保证金要求。</p>


## 滑点 · 09 Slippage

<p>SS&amp;C Eze 回测及 QuantConnect Paper Trading 不计滑点，实盘可能产生滑点。</p>
<p>SS&amp;C Eze 滑点模型见 Slippage。</p>


## 成交 · 10 Fills

<p>QuantConnect 回测和 QuantConnect Paper Trading 会立即、全部成交市价单；实盘数量超过盘口可用量时按订单簿流动性成交。</p>
<p>Eze 成交模型见 Fills。</p>


## 结算 · 11 Settlements

<p>保证金账户的交易即时结算。（原模板此处仅输出这一分支；现金账户规则应结合券商结算说明核对。）</p>
<p>SS&amp;C Eze 结算模型见 Settlement。</p>


## 安全与稳定性 · 12 Security and Stability


<p>通过 SS&amp;C Eze 部署时，平台不保存登录凭据。</p>


## 入金与出金 · 13 Deposits and Withdrawals

<p>算法运行时仍可给关联券商账户出入金；平台每天美东时间 7:45 同步账户现金余额。</p>


## 演示算法 · 14 Demo Algorithm

<p>以下算法演示 SS&amp;C Eze 集成：</p>
<div class="section-example-container testable">
<pre><code class="language-csharp">// 中文注释版：仅补充解释，保留原示例的执行语句。&#10;// Demonstrate SS&amp;C Eze brokerage functionality with an EMA crossover strategy on SPY.&#10;public class SSCEzeDemoAlgorithm : QCAlgorithm&#10;{&#10;    private ExponentialMovingAverage _fast;&#10;    private ExponentialMovingAverage _slow;&#10;&#10;    public override void Initialize()&#10;    {&#10;        // 设置回测开始日期；实盘运行不以此恢复历史状态。&#10;        SetStartDate(2024, 9, 1);&#10;        // 设置回测结束日期。&#10;        SetEndDate(2024, 12, 31);&#10;        // 设置回测初始现金；实盘资金以券商账户和部署配置为准。&#10;        SetCash(100000);&#10;        // 设置券商模型和账户类型，决定资产、订单及现实约束。&#10;        SetBrokerageModel(BrokerageName.Eze, AccountType.Margin);&#10;        // 订阅股票行情并取得对应证券。&#10;        var symbol = AddEquity("SPY", Resolution.Daily).Symbol;&#10;        // 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        _fast = EMA(symbol, 10, Resolution.Daily);&#10;        // 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        _slow = EMA(symbol, 50, Resolution.Daily);&#10;    }&#10;&#10;    public override void OnData(Slice slice)&#10;    {&#10;        // 指标准备好后才使用信号，历史样本不足时退出。&#10;        if (!_slow.IsReady) return;&#10;        if (_fast &gt; _slow &amp;&amp; !Portfolio.Invested)&#10;            // 按目标权重调整仓位；1 表示账户权益的 100%，不是买入 1 股。&#10;            SetHoldings("SPY", 1);&#10;        else if (_fast &lt; _slow &amp;&amp; Portfolio.Invested)&#10;            // 请求平仓；实际成交仍取决于市场和券商。&#10;            Liquidate();&#10;    }&#10;}</code></pre>
<pre><code class="language-python"># 中文注释版：仅补充解释，保留原示例的执行语句。&#10;# Demonstrate SS&amp;C Eze brokerage functionality with an EMA crossover strategy on SPY.&#10;# 定义继承 QCAlgorithm 的策略类，由 LEAN 管理其生命周期。&#10;class SSCEzeDemoAlgorithm(QCAlgorithm):&#10;    # 初始化只在算法开始时运行一次，设置回测条件和数据订阅。&#10;    def initialize(self) -&gt; None:&#10;        # 设置历史回测的开始日期。&#10;        # 设置回测开始日期；实盘运行不以此恢复历史状态。&#10;        self.set_start_date(2024, 9, 1)&#10;        # 设置历史回测的结束日期。&#10;        # 设置回测结束日期。&#10;        self.set_end_date(2024, 12, 31)&#10;        # 设置回测初始资金为 100,000 单位账户货币。&#10;        # 设置回测初始现金；实盘资金以券商账户和部署配置为准。&#10;        self.set_cash(100000)&#10;        # 设置券商模型和账户类型，决定资产、订单及现实约束。&#10;        self.set_brokerage_model(BrokerageName.EZE, AccountType.MARGIN)&#10;        # 订阅股票行情并取得对应证券。&#10;        symbol = self.add_equity("SPY", Resolution.DAILY).symbol&#10;        # 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        self._fast = self.ema(symbol, 10, Resolution.DAILY)&#10;        # 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        self._slow = self.ema(symbol, 50, Resolution.DAILY)&#10;&#10;    # 行情到达时执行；data 包含该时间片可用的数据。&#10;    def on_data(self, slice: Slice) -&gt; None:&#10;        # 指标准备好后才使用信号，历史样本不足时退出。&#10;        if not self._slow.is_ready:&#10;            return&#10;        if self._fast.current.value &gt; self._slow.current.value and not self.portfolio.invested:&#10;            # 按目标权重调整仓位；1 表示账户权益的 100%，不是买入 1 股。&#10;            self.set_holdings("SPY", 1)&#10;        elif self._fast.current.value &lt; self._slow.current.value and self.portfolio.invested:&#10;            # 请求平仓；实际成交仍取决于市场和券商。&#10;            self.liquidate()</code></pre>
</div>

## 部署算法 · 15 Deploy Live Algorithms

<p>每个实盘算法必须有一个可用实盘节点。</p>
<p>按以下步骤部署实盘算法：</p>
<ol>
<li>打开要部署的项目。</li>
<li>点击 Deploy Live（部署实盘）图标。<img alt="Lightning icon" class="inline-icon" src="https://cdn.quantconnect.com/i/tu/deploy-live-icon.png"/></li>
<li>在 Deploy Live 的 Brokerage 选择 SS&amp;C Eze。</li>
<li>输入 SS&amp;C Eze 用户名和密码。</li>
<li>按 BBCD（BANK;BRANCH;CUSTOMER;DEPOSIT）格式填写 Trading Account，填写 Domain，选择 Locale。</li>
<p>QuantConnect 不保存这些账户凭据。</p> <li>在 Region 区域选择算法运行地区。</li>
<li>点击 Node 字段，选择要使用的实盘节点。</li>
<li>可选：在 Data Provider 区域点击 Show，修改数据源或添加其他数据源。</li>
<p>通常使用 QuantConnect、Polygon 等第三方数据源或组合；向导中的排列顺序决定优先级。</p> <li>账户已有现金时，按以下步骤填写（有演示视频）：</li>
<ol>
<li>在 Algorithm Cash State 点击 Show。</li>
<li>点击 Add Currency。</li>
<li>填写币种代码（如 USD/CAD）及数量。</li>
</ol>
<li>可选：配置通知。</li>
<li>配置 Automatically restart algorithm（自动重启算法）选项。</li>
<p>开启自动重启后，平台会尽力重启因运行错误而失败的算法，有助于应对券商 API 暂时断线等故障。</p>
<li>点击 Deploy（部署）。</li>
</ol>
<p>部署最多可能需要 5 分钟，完成后显示实盘结果页。可核对运行统计中的权益、现金账簿和持仓，确认券商原有持仓正确载入。</p>
<p>重启、自动重启和重新部署都不会保存算法全部内部状态。恢复哪些状态、其余状态如何持久化，见 State Persistence。</p>


## 部署详情 · 16 Deployment Details

<p>SS&amp;C Eze 提供账户等部署详情，便于区分并行部署和核对账户，不包含凭据。</p>
<p>下表为 SS&amp;C Eze 部署详情：</p>
<table class="qc-table table">
<thead>
<tr>
<th>键名</th>
<th>说明</th>
</tr>
</thead>
<tbody>
<tr>
<td><code>eze-user-name</code></td>
<td>LEAN 用于登录 Eze 的用户名。</td>
</tr>
<tr>
<td><code>eze-domain</code></td>
<td>用户的 Eze 域。</td>
</tr>
<tr>
<td><code>eze-locale</code></td>
<td>用户的 Eze locale 地区设置。</td>
</tr>
<tr>
<td><code>eze-trading-account</code></td>
<td>接收订单的 Eze 交易账户。</td>
</tr>
</tbody>
</table>
<p>算法的 DeploymentDetails/deployment_details 是只读字典，LEAN 在调用 Initialize/initialize 之前填充，因此在算法任何位置都可读取。</p>
<div class="section-example-container">
<pre><code class="language-csharp">// 中文注释版：仅补充解释，保留原示例的执行语句。&#10;// 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;var deploymentDetails = DeploymentDetails.Select(kvp =&gt; $"{kvp.Key}:{kvp.Value}");&#10;Log($"deploymentDetails: {string.Join(", ", deploymentDetails)}");</code></pre>
<pre><code class="language-python"># 中文注释版：仅补充解释，保留原示例的执行语句。&#10;# 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;deployment_details = [f'{kvp.key}:{kvp.value}' for kvp in self.deployment_details]&#10;# 记录常规运行信息，消息写入日志并计入日志额度。&#10;# 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;self.log(f'deployment_details: {deployment_details}')</code></pre>
</div>
<p>也可在算法外通过 /live/read 响应的 deploymentDetails 读取详情。</p>

