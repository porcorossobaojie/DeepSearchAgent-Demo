# Interactive Brokers

非官方中文翻译，按原文小节排列；专有名词、按钮、错误消息和代码字段保留英文对照。费用、IP、权限及产品范围为所标源码版本的记录。各节保留官方链接，代码保留执行语句并添加中文注释。

## 简介 · 01 Introduction

<p>QuantConnect 支持使用实时行情运行实盘模式的算法。</p>
<p>Interactive Brokers（IB）由 Thomas Peterffy 于 1993 年创立，目标是以技术改善流动性，在价格、速度、规模、全球产品与交易工具方面竞争。服务覆盖 200 多个国家和地区，提供股票、ETF、期权、期货、期货期权、外汇、CFD、黄金、权证、债券、基金，以及模拟交易、交易平台和教育服务；原文称无最低入金要求。券商产品范围不等于本集成支持的范围。</p>
<p>集成实现见 Lean.Brokerages.InteractiveBrokers 仓库。</p>

## 账户类型 · 02 Account Types

<p>IB API 不支持 IBKR LITE，必须使用 IBKR PRO；可使用个人账户或财务顾问（FA）账户。</p>
<h4>个人账户</h4>
<p>IB 支持现金和保证金账户；算法设置方式见对应券商模型文档。</p>
<h4>财务顾问（FA）账户</h4>
<p>Trading Firm 和 Institution 组织可使用 IB FA 账户，让合资格专业人员通过一个算法管理多个客户账户。账户代码以 F、FA 或 I 开头即为 FA 账户，详见 Financial Advisors。</p>
<h4>创建账户</h4>
<p>要通过 IB 部署，必须开立 IBKR Pro；API 不支持 Lite。开户入口见其官网 Open an Account 页面。</p>
<p>实盘部署前需要启用 IBKR Mobile Authentication（IB Key）；开户后按官网安装与激活说明操作。</p>
<h4>模拟交易</h4>
<p>IB 支持模拟交易，配置步骤见其 Paper Trading Account 文档。</p>
<p>若要在模拟账户中使用 IB 行情，按以下步骤共享行情订阅：</p>
<ol>
<li>登录 IB Client Portal（客户门户）。</li>
<li>点击右上角人物图标，再点击 Settings。</li>
<li>在 Account Configuration 区域点击 Paper Trading Account。</li>
<li>点击 Yes。</li>
<li>点击 Save。</li>
</ol>
<p>模拟环境模拟了 Trader Workstation 正式账户的大多数行为，但不真正执行或清算，因此可能与实盘有差异。</p>
<h4>受保存款自动划转计划</h4>
<p>LEAN 不支持参加 Insured Bank Deposit Sweep Program 的 IB 账户：读取余额时会包含不可交易的 FDIC Sweep Account Cash。例如总现金 15 万美元，其中 5 万在划转账户，实际只有 10 万可交易。退出方式见该计划文档。</p>
<h4>股息领取方式</h4>
<p>股息选项决定股票和基金如何派息。应关闭自动再投资以现金收取股息；再投资可能产生零股，而 LEAN 不支持零股交易。例如 TLT 持仓变为 1270.8604 股后，无法正常全部平仓。</p>


## FIX 接入 · 03 FIX Integration

<p>FIX（金融信息交换协议）使现有 Interactive Brokers（IB）客户通过其账户接收 QuantConnect 的订单。可在 IB 客户门户订阅 QuantConnect 以启用 FIX 路由。</p>
<p>FIX 不支持以 DU 开头的 IB 模拟账户。可交易多个子账户，但必须关联同一个 QuantConnect 账户。</p>
<p>原文称 QC-IBKR FIX 连接可持续保持，避免 IB-Gateway 的每周重新登录；订单经专用 VPN 路由，提高连接与成交稳定性，且占用更少内存。这不应理解为没有任何断线可能。</p>
<p>开始前确认 IB 账户有效，并可访问客户门户。</p>
<p>登录的 IB 用户须有 Market Data 权限才能管理研究订阅。Research Subscriptions 缺失或为空时，在门户用户权限中启用 Market Data，立即生效；只有 Subscriber Status 权限不够。</p>
<img class="docs-image" src="https://cdn.quantconnect.com/i/tu/ib-fix-market-data.png"/>
<p>每个 IB 账户对应一个 IBKR QC UID，而主用户只能为其管理的所有账户保存一个 UID。需要不同 UID 时，分别用各子账户用户登录并注册。</p>
<p>第 5 步需要连接 IB 与 QuantConnect 的 IBKR QC UID。先打开实盘部署向导，用 IB 用户名认证，再选择交易账户，取得 QuantConnect 生成的 UID。</p>
<p>按以下步骤为 IB 账户启用 FIX：</p>
<ol>
<li>在客户门户依次打开 Settings、Research Subscriptions、News &amp; Research Subscriptions、Manage Subscriptions。</li>
<img class="docs-image" src="https://cdn.quantconnect.com/i/tu/ib-fix-01.png"/>
<li>在订阅列表选择 QuantConnect，创建 FIX 会话，再点击 Continue。</li>
<img class="docs-image" src="https://cdn.quantconnect.com/i/tu/ib-fix-02.png"/>
<li>在 Review Your Research Subscriptions 页面阅读行情协议和披露条款并确认。</li>
<img class="docs-image" src="https://cdn.quantconnect.com/i/tu/ib-fix-03.png"/>
<li>在 Service Account Configuration 页面点击 QuantConnect 旁的 Configure 齿轮。</li>
<img class="docs-image" src="https://cdn.quantconnect.com/i/tu/ib-fix-04.png"/>
<li>在 Service Account Configuration for QuantConnect 对话框选择要关联的 IB 账户，在 QuantConnect UID 输入 IBKR QC UID，再保存。</li>
<img class="docs-image" src="https://cdn.quantconnect.com/i/tu/ib-fix-05-uid.png"/>
<img class="docs-image" src="https://cdn.quantconnect.com/i/tu/ib-fix-06-uid1.png"/>
<p>此 IBKR QC UID 是 QuantConnect 服务的默认订阅者，可在此选择多个账户。</p>
<p>取得 IBKR QC UID 的方法见 Deploy Live Algorithms FIX。</p>
<li>返回 Service Account Configuration，点击 Continue。</li>
<img class="docs-image" src="https://cdn.quantconnect.com/i/tu/ib-fix-07.png"/>
<li>阅读并确认 OMS Riders and Addendum 附加协议。</li>
<img class="docs-image" src="https://cdn.quantconnect.com/i/tu/ib-fix-08.png"/>
<img class="docs-image" src="https://cdn.quantconnect.com/i/tu/ib-fix-09.png"/>
<p>确认后订阅完成，所选信息会加入 FIX 连接用于订单校验。</p>
<p>每个 IBKR QC UID 只需注册一次；交易未注册账户时需重复。保存后等待约 5 分钟，让 IB 应用变更，再部署。</p>
<p>订阅后通常不再显示 Service Account Configuration。要修改已保存 UID，点击 Manage Subscriptions，不改订阅并连续点击两次 Continue，再点击 QuantConnect 旁的 Configure。</p>
</ol>


## 资产类别 · 04 Asset Classes

<p>本集成支持以下资产类别：</p>
<ul>
<li>美国股票</li>
<li>股票期权</li>
<li>外汇</li>
<li>期货</li>
<li>期货期权</li>
<li>指数</li>
<li>指数期权</li>
<li>差价合约（CFD）</li>
</ul>
<p>并非所有客户都可交易 IB 的全部资产。例如欧盟居民不能交易美国 ETF，可考虑对应 CFD。以所在地规定和账户权限为准，部分资产需调整券商账户设置。</p>

## 数据源 · 05 Data Providers

<p>推荐免费的 QuantConnect 实时数据源，覆盖美国股票、股票期权、指数期权、期货、外汇和 CFD，并提供 SPX/VIX 期权所需的标的指数。它不提供期货期权数据，交易该资产需结合 IB 数据源，可能还要购买 IB 行情订阅。详见 Datasets。</p>
<p>使用 FIX 路由时建议单独使用 QuantConnect 数据源；IB 数据源仍通过普通 API 推送，会重新引入 FIX 原本避免的每周登录。若需期货期权数据，仍须使用 IB 并接受这一要求。</p>


## 订单 · 06 Orders

<p>平台对 IB API 的订单类型、属性和更新进行建模；实盘部署后也可通过 IDE 手动下单。</p>
<h4>订单类型</h4>
<p>下表列出本集成支持的订单，详情见券商文档。（原文重复词已合并。）</p>
<table class="qc-table table">
<thead>
<tr>
<th style="width: 50%">订单类型</th>
<th style="width: 50%">IB 文档页面</th>
</tr>
</thead>
<tbody>
<tr>
<td>市价单（Market）</td>
<td>市价单</td>
</tr>
<tr>
<td>限价单（Limit）</td>
<td>限价单</td>
</tr>
<tr>
<td>触价限价单（Limit if touched）</td>
<td>触价限价单</td>
</tr>
<tr>
<td>止损市价单（Stop market）</td>
<td>止损单</td>
</tr>
<tr>
<td>止损限价单（Stop limit）</td>
<td>止损限价单</td>
</tr>
<tr>
<td>移动止损</td>
<td>移动止损单</td>
</tr>
<tr>
<td>开盘市价单（Market on open）</td>
<td>开盘市价单（MOO）</td>
</tr>
<tr>
<td>收盘市价单（Market on close）</td>
<td>收盘市价单（MOC）</td>
</tr>
<tr>
<td>组合市价单（Combo market）</td>
<td>价差组合单</td>
</tr>
<tr>
<td>组合限价单（Combo limit）</td>
<td>价差组合单</td>
</tr>
<tr>
<td>分腿组合限价单（Combo leg limit）</td>
<td>价差组合单</td>
</tr>
<tr>
<td>期权行权</td>
<td>期权行权</td>
</tr>
</tbody>
</table>
<p>下表列出 IB 对各资产支持的订单类型：</p>
<table class="qc-table table">
<thead>
<tr>
<th>订单类型</th>
<th>美国股票</th>
<th>股票期权</th>
<th>外汇</th>
<th>期货</th>
<th>期货期权</th>
<th>指数期权</th>
<th>差价合约（CFD）</th>
</tr>
</thead>
<tbody>
<tr>
<td>市价单（Market）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>限价单（Limit）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>触价限价单（Limit if touched）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>止损市价单（Stop market）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>止损限价单（原表拼写为 Stopl imit）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>移动止损</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>开盘市价单（Market on open）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td></td>
<td></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>收盘市价单（Market on close）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td></td>
<td></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td></td>
<td></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>组合市价单（Combo market）</td>
<td></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td></td>
<td></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td></td>
</tr>
<tr>
<td>组合限价单（Combo limit）</td>
<td></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td></td>
<td></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td></td>
</tr>
<tr>
<td>分腿组合限价单（Combo leg limit）</td>
<td></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td></td>
<td></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td></td>
</tr>
<tr>
<td>期权行权</td>
<td></td>
<td>不支持现金结算期权<img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td></td>
<td></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td></td>
<td></td>
</tr>
<tr>
<td>括号订单（Bracket）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>一单成交取消另一单（OCO）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>一单触发另一单（OTO）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>一单更新另一单（OUO）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
</tbody>
</table>

<h4>订单属性</h4>
<p>可通过 InteractiveBrokersOrderProperties 对象设置 IB API 的自定义订单执行属性，见下表；表中不含 FA 账户方法。</p>
<table class="table qc-table">
<thead>
<tr>
<th>属性</th>
<th>数据类型</th>
<th>说明</th>
<th>默认值</th>
</tr>
</thead>
<tbody>
<tr>
<td><code class="csharp">TimeInForce</code><code class="python">time_in_force</code></td>
<td><code>TimeInForce</code></td>
<td>A <a href="https://www.quantconnect.com/docs/v2/writing-algorithms/trading-and-orders/order-properties#03-Time-In-Force">TimeInForce</a>为订单设置有效期，支持以下取值：<ul>
<li>当日有效（Day / DAY）</li>
<li><code class="csharp">GoodTilCanceled</code><code class="python">GOOD_TIL_CANCELED</code></li>
<li>指定日期前有效（GoodTilDate / good_til_date）</li>
</ul>
</td>
<td><code class="csharp">TimeInForce.GoodTilCanceled</code><code class="python">TimeInForce.GOOD_TIL_CANCELED</code></td>
</tr>
<tr>
<td><code class="csharp">OutsideRegularTradingHours</code><code class="python">outside_regular_trading_hours</code></td>
<td><code>bool</code></td>
<td>是否允许订单在常规交易时段外触发和成交。</td>
<td><code class="csharp">false</code><code class="python">False</code></td>
</tr>
</tbody>
</table>
<h4>关联条件订单</h4>
<p>IB 接受任意规模的条件订单组，包括不同证券、触发链和组合单。若其他订单触发移动止损单，父订单必须是限价或止损限价单。</p>
<h4>更新订单</h4>
<p>本集成支持更新 IB 订单。</p>
<h4>财务顾问组订单</h4>
<p>FA 组订单下单方式见 Financial Advisors。</p>
<h4>零股交易</h4>
<p>IB API 和 FIX/CTCI 均不支持零股交易。</p>
<h4>拆股处理</h4>
<p>使用原始价格（Raw）时，如果美国股票拆股，尚未成交订单中的以下属性会自动按拆股比例调整：</p>
<ul>
<li>数量</li>
<li>限价</li>
<li>止损价</li>
<li>触发价</li>
</ul>
<h4>成交时间</h4>
<p>原文记载 IB 实盘订单成交时间为 400 毫秒；实际成交取决于市场情况。</p>
<h4>券商强制平仓</h4>
<p>IB 强平部分持仓时，会发出含 Brokerage Liquidation 消息的订单事件。</p>


## 手续费 · 07 Fees

<p>IB 交易费用见官网 Commissions；平台费用模型见 Fees。</p>


## 保证金 · 08 Margin

<p>平台模拟购买力和追加保证金，帮助算法遵守保证金要求。</p>


## 滑点 · 09 Slippage

<p>IB 回测不计滑点；IB 模拟与实盘订单可能产生滑点。</p>
<p>IB 滑点模型见 Slippage。</p>

## 成交 · 10 Fills

<p>回测中 QuantConnect 立即、全部成交市价单。IB 模拟和实盘中，若数量超过盘口最优档可用数量，会按订单簿实际流动性成交。</p>
<p>IB 成交模型见 Fills。</p>


## 结算 · 11 Settlements

<p>保证金账户的交易即时结算。（原模板此处仅输出这一分支；现金账户规则应结合券商结算说明核对。）</p>
<p>IB 结算模型见 Settlement。</p>


## 安全与稳定性 · 12 Security and Stability

<p>本集成的安全与稳定性说明如下。</p>
<h4>账户凭据</h4>
<p>部署 IB 实盘算法时，平台不保存这些登录凭据。</p>
<h4>API 服务中断</h4>
<p>实盘订单通过 IB API 提交，API 有时可能中断；可在其状态页查看服务情况。</p>
<h4>连接</h4>
<p>IB 默认只允许一个账户连接；算法连接期间进行其他登录可能令算法停止。若要同时打开 TWS，请为账户创建第二用户并用其登录；并行运行更多算法时，为每个额外算法开立子账户。</p>
<p>若无法登录 TWS，请联系 IB；若可登录 TWS 但部署向导失败，请联系 QuantConnect 并提供算法 ID 与部署 ID。</p>
<h4>短信双重验证</h4>
<p>本集成不支持短信、Online Security Code Card 或 Microsoft/Google Authenticator 等第三方 2FA，应使用 IBKR Mobile 的 IB Key。</p>
<h4>IP 限制</h4>
<p>若 IB 账户启用 IP 限制，请将 207.182.16.137 加入白名单。</p>

## 系统重置与每周认证 · 13 System Resets

<p>每周日，IB Key 设备会收到重新认证算法连接的通知。部署时可选择周日通知时间，并确保届时设备有足够电量。</p>
<p>认证超时后，QuantConnect 会发邮件提供 Connect 和 Stop：Connect 重新发起认证并通知 IB Key；Stop 停止部署。不操作则算法在持仓资产开市前停止，例如美股为美东标准时间 9:30。</p>
<p>若未收到通知，参阅 IB 官网 I am not receiving IBKR Mobile notifications。</p>

## 入金与出金 · 14 Deposits and Withdrawals

<p>算法运行时仍可给关联券商账户出入金；平台每天美东时间 7:45 同步账户现金余额。</p>


## 演示算法 · 15 Demo Algorithm

<p>以下算法演示 IB 的功能：</p>
<div class="section-example-container testable">
<pre><code class="language-csharp">// 中文注释版：仅补充解释，保留原示例的执行语句。&#10;// Demonstrate IB brokerage functionality with an EMA crossover strategy on SPY.&#10;public class InteractiveBrokersDemoAlgorithm : QCAlgorithm&#10;{&#10;    private ExponentialMovingAverage _fast;&#10;    private ExponentialMovingAverage _slow;&#10;&#10;    public override void Initialize()&#10;    {&#10;        // 设置回测开始日期；实盘运行不以此恢复历史状态。&#10;        SetStartDate(2024, 9, 1);&#10;        // 设置回测结束日期。&#10;        SetEndDate(2024, 12, 31);&#10;        // 设置回测初始现金；实盘资金以券商账户和部署配置为准。&#10;        SetCash(100000);&#10;        // 设置券商模型和账户类型，决定资产、订单及现实约束。&#10;        SetBrokerageModel(BrokerageName.InteractiveBrokersBrokerage, AccountType.Margin);&#10;        // 订阅股票行情并取得对应证券。&#10;        var symbol = AddEquity("SPY", Resolution.Daily).Symbol;&#10;        // 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        _fast = EMA(symbol, 10, Resolution.Daily);&#10;        // 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        _slow = EMA(symbol, 50, Resolution.Daily);&#10;    }&#10;&#10;    public override void OnData(Slice slice)&#10;    {&#10;        // 指标准备好后才使用信号，历史样本不足时退出。&#10;        if (!_slow.IsReady) return;&#10;        if (_fast &gt; _slow &amp;&amp; !Portfolio.Invested)&#10;            // 按目标权重调整仓位；1 表示账户权益的 100%，不是买入 1 股。&#10;            SetHoldings("SPY", 1);&#10;        else if (_fast &lt; _slow &amp;&amp; Portfolio.Invested)&#10;            // 请求平仓；实际成交仍取决于市场和券商。&#10;            Liquidate();&#10;    }&#10;}</code></pre>
<pre><code class="language-python"># 中文注释版：仅补充解释，保留原示例的执行语句。&#10;# Demonstrate IB brokerage functionality with an EMA crossover strategy on SPY.&#10;# 定义继承 QCAlgorithm 的策略类，由 LEAN 管理其生命周期。&#10;class InteractiveBrokersDemoAlgorithm(QCAlgorithm):&#10;    # 初始化只在算法开始时运行一次，设置回测条件和数据订阅。&#10;    def initialize(self) -&gt; None:&#10;        # 设置历史回测的开始日期。&#10;        # 设置回测开始日期；实盘运行不以此恢复历史状态。&#10;        self.set_start_date(2024, 9, 1)&#10;        # 设置历史回测的结束日期。&#10;        # 设置回测结束日期。&#10;        self.set_end_date(2024, 12, 31)&#10;        # 设置回测初始资金为 100,000 单位账户货币。&#10;        # 设置回测初始现金；实盘资金以券商账户和部署配置为准。&#10;        self.set_cash(100000)&#10;        # 设置券商模型和账户类型，决定资产、订单及现实约束。&#10;        self.set_brokerage_model(BrokerageName.INTERACTIVE_BROKERS_BROKERAGE, AccountType.MARGIN)&#10;        # 订阅股票行情并取得对应证券。&#10;        symbol = self.add_equity("SPY", Resolution.DAILY).symbol&#10;        # 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        self._fast = self.ema(symbol, 10, Resolution.DAILY)&#10;        # 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        self._slow = self.ema(symbol, 50, Resolution.DAILY)&#10;&#10;    # 行情到达时执行；data 包含该时间片可用的数据。&#10;    def on_data(self, slice: Slice) -&gt; None:&#10;        # 指标准备好后才使用信号，历史样本不足时退出。&#10;        if not self._slow.is_ready:&#10;            return&#10;        if self._fast.current.value &gt; self._slow.current.value and not self.portfolio.invested:&#10;            # 按目标权重调整仓位；1 表示账户权益的 100%，不是买入 1 股。&#10;            self.set_holdings("SPY", 1)&#10;        elif self._fast.current.value &lt; self._slow.current.value and self.portfolio.invested:&#10;            # 请求平仓；实际成交仍取决于市场和券商。&#10;            self.liquidate()</code></pre>
</div>

## 部署算法 · 16 Deploy Live Algorithms

<p>每个实盘算法必须有一个可用实盘节点。</p>
<p>按以下步骤部署实盘算法：</p>
<ol>
<li>打开要部署的项目。</li>
<li>点击 Deploy Live（部署实盘）图标。<img alt="Lightning icon" class="inline-icon" src="https://cdn.quantconnect.com/i/tu/deploy-live-icon.png"/></li>
<li>在 Deploy Live 页面点击 Brokerage 字段，从列表选择 Interactive Brokers。</li>
<li>输入 IB 用户名、账户 ID 和密码。</li>
<p>QuantConnect 不保存这些账户凭据。</p>
<li>在 Weekly Restart UTC 字段填写每周日重新认证通知的 UTC 时间。</li>
<p>例如 UTC 16:00 对应美国东部标准时间 11:00、东部夏令时 12:00、太平洋标准时间 08:00、太平洋夏令时 09:00；其他时区可用 UTC Time Zone Converter 换算。</p>
<p>启用 2FA 时，每周日 IB Key 会收到重新认证通知；超时未认证，算法停止。</p>
<li>在 Region 区域选择算法运行地区。</li>
<li>点击 Node 字段，选择要使用的实盘节点。</li>
<li>可选：在 Data Provider 区域点击 Show，修改数据源或添加其他数据源。</li>
<p>大多数情况建议同时使用 QC 和 IB 数据源。</p><p>若模拟账户使用 IB 数据源，须与模拟账户共享行情订阅，步骤见 Account Types。</p>
<li>可选：配置通知。</li>
<li>配置 Automatically restart algorithm（自动重启算法）选项。</li>
<p>开启自动重启后，平台会尽力重启因运行错误而失败的算法，有助于应对券商 API 暂时断线等故障。</p>
<li>点击 Deploy（部署）。</li>
<li>若 IB 启用 2FA，请点开 IB Key 通知并输入 PIN。</li></ol>
<p>部署最多可能需要 5 分钟，完成后显示实盘结果页。可核对运行统计中的权益、现金账簿和持仓，确认券商原有持仓正确载入。</p>
<p>重启、自动重启和重新部署都不会保存算法全部内部状态。恢复哪些状态、其余状态如何持久化，见 State Persistence。</p>


## 通过 FIX 部署 · 17 Deploy Live Algorithms FIX

<p>每个实盘算法必须有一个可用实盘节点。</p>
<p>按以下步骤部署实盘算法：</p>
<ol>
<li>打开要部署的项目。</li>
<li>点击 Deploy Live（部署实盘）图标。<img alt="Lightning icon" class="inline-icon" src="https://cdn.quantconnect.com/i/tu/deploy-live-icon.png"/></li>
<li>在 Deploy Live 页面点击 Brokerage 字段，从列表选择 Interactive Brokers。</li>
<li>在 Interactive Brokers (FIX) Authentication 区域执行以下步骤：</li>
<ol>
<li>点击 Account，选择 IB 用户名。</li>
<p>如尚未关联该用户，点击 + Add Account，在 IBKR User Name 填写用户名。</p>
<li>点击 Authenticate，再登录 IB。</li>
<p>成功后 Authorization 显示 Authorization Complete，向导出现 Account ID 和 IBKR QC UID。</p>
<li>点击 Account ID，选择要交易的 IB 账户。</li>
<li>复制 IBKR QC UID，添加到 IB 账户。</li>
<p>QuantConnect 根据所选账户生成 IBKR QC UID，未选 Account ID 时为空。必须先注册此值，IB 才接受来自 QuantConnect 的订单。</p>
<p>按 FIX Integration 完成注册后返回。每个 UID 只需一次；交易新账户时需注册其 UID。保存后等约 5 分钟让 IB 应用，再部署。</p>
</ol> <li>在 Region 区域选择算法运行地区。</li>
<li>点击 Node 字段，选择要使用的实盘节点。</li>
<li>可选：在 Data Provider 区域点击 Show，修改数据源或添加其他数据源。</li>
<p>大多数情况建议同时使用 QC 和 IB 数据源。</p><p>若模拟账户使用 IB 数据源，须与模拟账户共享行情订阅，步骤见 Account Types。</p>
<li>可选：配置通知。</li>
<li>配置 Automatically restart algorithm（自动重启算法）选项。</li>
<p>开启自动重启后，平台会尽力重启因运行错误而失败的算法，有助于应对券商 API 暂时断线等故障。</p>
<li>点击 Deploy（部署）。</li>
<li>若 IB 启用 2FA，请点开 IB Key 通知并输入 PIN。</li></ol>
<p>部署最多可能需要 5 分钟，完成后显示实盘结果页。可核对运行统计中的权益、现金账簿和持仓，确认券商原有持仓正确载入。</p>
<p>重启、自动重启和重新部署都不会保存算法全部内部状态。恢复哪些状态、其余状态如何持久化，见 State Persistence。</p>


## 部署详情 · 18 Deployment Details

<p>部署 Interactive Brokers 算法时，券商提供交易账户等详情，可区分并行部署和核对目标账户；这些详情不包含凭据。</p>
<p>下表列出 Interactive Brokers 提供的部署详情：</p>
<table class="qc-table table">
<thead>
<tr>
<th>键名</th>
<th>说明</th>
</tr>
</thead>
<tbody>
<tr>
<td><code>ib-account</code></td>
<td>接收订单的 IB 账户。</td>
</tr>
<tr>
<td><code>ib-user-name</code></td>
<td>LEAN 用于登录 IB 的用户名。</td>
</tr>
<tr>
<td><code>ib-trading-mode</code></td>
<td>账户交易模式：live 或 paper。</td>
</tr>
<tr>
<td><code>ib-financial-advisors-group-filter</code></td>
<td>LEAN 交易的财务顾问组；交易整个账户时为空。</td>
</tr>
<tr>
<td><code>ib-fix-account</code></td>
<td>接收订单的 IB 账户；使用 FIX 时返回此项而非前述普通连接详情。</td>
</tr>
<tr>
<td><code>ib-fix-user-name</code></td>
<td>FIX 会话用户名。</td>
</tr>
</tbody>
</table>
<p>算法的 DeploymentDetails/deployment_details 是只读字典，LEAN 在调用 Initialize/initialize 之前填充，因此在算法任何位置都可读取。</p>
<div class="section-example-container">
<pre><code class="language-csharp">// 中文注释版：仅补充解释，保留原示例的执行语句。&#10;// 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;var deploymentDetails = DeploymentDetails.Select(kvp =&gt; $"{kvp.Key}:{kvp.Value}");&#10;Log($"deploymentDetails: {string.Join(", ", deploymentDetails)}");</code></pre>
<pre><code class="language-python"># 中文注释版：仅补充解释，保留原示例的执行语句。&#10;# 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;deployment_details = [f'{kvp.key}:{kvp.value}' for kvp in self.deployment_details]&#10;# 记录常规运行信息，消息写入日志并计入日志额度。&#10;# 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;self.log(f'deployment_details: {deployment_details}')</code></pre>
</div>
<p>也可在算法外通过 /live/read 响应的 deploymentDetails 读取详情。</p>


## 故障排查 · 19 Troubleshooting

<p>下表说明部署至 IB 时可能出现的错误及警告。</p>
<table class="table qc-table">
<thead>
<tr>
<th>错误消息（保留英文便于检索）</th>
<th>可能原因与解决方法</th>
</tr>
</thead>
<tbody>
<tr>
<td nowrap="">
<div class="error-messages">Login failed.</div>
</td>
<td>凭据可能不正确，常见原因是密码前后有空格。可在本地编辑器检查。若无法登录 TWS，请联系 IB；若 TWS 成功但部署失败，联系 QuantConnect 并提供算法 ID、部署 ID。</td>
</tr>
<tr>
<td nowrap="">
<div class="error-messages">Login to the IB Gateway failed because<br/>a user account-tasks is required.</div>
</td>
<td>下载并运行 IB Gateway，按提示完成账户任务。</td>
</tr>
<tr>
<td rowspan="2">
<div class="error-messages">An existing session was detected and will not be automatically disconnected.</div>
<br/>
<div class="error-messages">Historical Market Data Service error message: Trading TWS session is connected from a different IP address.</div>
</td>
</tr>
<tr>
<td>IB 仍认为此前部署部分连接，完全断开可能要一分钟。参阅 Security and Stability 的 Connections。</td>
</tr>
<tr>
<td rowspan="2">
<div class="error-messages">The two factor authentication request timed out.</div>
<br/>
<div class="error-messages">A security dialog was detected for Code Card Authentication.</div>
<br/>
<div class="error-messages">Unknown message window detected: Challenge: 123 456</div>
</td>
</tr>
<tr>
<td>未及时响应移动端 2FA 后会出现代码卡 Challenge。确保 IB Key 设备有电并及时确认；收不到通知时参阅官网对应排查文档。</td>
</tr>
<tr>
<td>
<div class="error-messages">API support is not available for accounts that support free trading.</div>
</td>
<td>将 IBKR Lite 升级为 IBKR Pro。</td>
</tr>
<tr>
<td>
<div class="error-messages">No security definition has been found for the request.</div>
</td>
<td>算法添加了无效或不支持的证券，例如退市股票、过期或不存在的合约、错误到期日/行权价，或不支持的权证。若本应有效，提交支持工单并附部署 ID。算法通常继续运行但不交易该资产；要遇到此情况就拒绝部署，可设 Settings.IgnoreUnknownAssets/self.settings.ignore_unknown_assets 为 false/False。</td>
</tr>
<tr>
<td rowspan="2">
<div class="error-messages">Requested market data is not subscribed.</div>
<br/>
<div class="error-messages">Historical Market Data Service error message: No market data permissions for ...</div>
</td>
</tr>
<tr>
<td>使用 Interactive Brokers 数据源却没有所需订阅。订阅所需数据包、联系 IB，或重新部署并选择其他源；云端可用 QuantConnect 或 QuantConnect+Interactive Brokers 混合数据源，也可选第三方源。</td>
</tr>
<tr>
<td>
<div class="error-messages">Timeout waiting for brokerage response for brokerage order id 37 lean id 31</div>
</td>
<td>IB 未响应订单请求。停止并重新部署后，LEAN 会重新读取该订单及其带来的持仓变化。</td>
</tr>
<tr>
<td>
<div class="error-messages">No market data during competing live session.</div>
</td>
<td>运行中从其他位置登录 IB，导致当前行情断线。关闭其他会话后数据会自动恢复，算法不会因此直接报错停止；参阅已有会话冲突说明。</td>
</tr>
</tbody>
</table>
<p>其他错误见 TWS API 的 Error Codes；仍需帮助时新建工单并附出错的实盘部署。</p>
