# Coinbase

非官方中文翻译，按原文小节排列；专有名词、按钮、错误消息和代码字段保留英文对照。费用、IP、权限及产品范围为所标源码版本的记录。各节保留官方链接，代码保留执行语句并添加中文注释。

## 简介 · 01 Introduction

<p>QuantConnect 支持使用实时行情运行实盘模式的算法。</p>
<p>Coinbase 由 Brian Armstrong、Fred Ehrsam 于 2012 年创立，以提高全球经济自由度为目标。向 100 多国客户提供加密交易，原文称无最低入金；另提供自托管钱包、Visa 奖励卡及比特币抵押信贷。</p>
<p>集成实现见 Lean.Brokerages.Coinbase 仓库。</p>


## 账户类型 · 02 Account Types

<p>Coinbase 支持现金账户，算法设置见券商模型文档。</p>
<h4>创建账户</h4>
<p>按官网 Create an Account 教程开户。</p>
<p>部署需 API 凭据。在官网 API Key Management 创建时，勾选 View（只读）和 Trade（代您交易）。下方 JSON 为凭据结构示例，不能直接作为真实凭据使用。</p>
<div class="section-example-container"><p class="code-explanation">格式说明：以下保留原文字段/凭据结构，不能直接当作真实可用凭据；JSON 不插入注释，以免破坏格式。API name 为名称，privateKey 为私钥；不同部署环境的私钥换行处理见上下文。</p><pre><code class="language-text">organizations/2c7dhs-a3a3-4acf-aa0c-f68584f34c37/apiKeys/41090ffa-asd2-8080-815f-afaf63747e35&#10;-----BEGIN EC PRIVATE KEY-----\nMHcCAQEEIPcJGfXYEdLQi0iFj1xvGfPwuRNoebbwuKS4xL2NrlGWpoAoGCCqGSM49\nAwEHoUQDQgAEclN+asd/EhJ3UjOWkHmP/iqGBv5NkNJ75bUq\nVgxS4aU3/djHiIuSf27QasdOFIDGJLmOn7YiQ==\n-----END EC PRIVATE KEY-----\n</code></pre></div>
<p>此例的 API name 为：</p>
<div class="section-example-container"><p class="code-explanation">格式说明：以下保留原文字段/凭据结构，不能直接当作真实可用凭据；JSON 不插入注释，以免破坏格式。API name 为名称，privateKey 为私钥；不同部署环境的私钥换行处理见上下文。</p><pre><code class="language-text">organizations/2c7dhs-a3a3-4acf-aa0c-f68584f34c37/apiKeys/41090ffa-asd2-8080-815f-afaf63747e35</code></pre></div>
<p>LEAN CLI 使用的 API private key 为：</p>
<div class="section-example-container"><p class="code-explanation">格式说明：以下保留原文字段/凭据结构，不能直接当作真实可用凭据；JSON 不插入注释，以免破坏格式。API name 为名称，privateKey 为私钥；不同部署环境的私钥换行处理见上下文。</p><pre><code class="language-text">-----BEGIN EC PRIVATE KEY-----\nMHcCAQEEIPcJGfXYEdLQi0iFj1xvGfPwuRNoebbwuKS4xL2NrlGWpoAoGCCqGSM49\nAwEHoUQDQgAEclN+asd/EhJ3UjOWkHmP/iqGBv5NkNJ75bUq\nVgxS4aU3/djHiIuSf27QasdOFIDGJLmOn7YiQ==\n-----END EC PRIVATE KEY-----\n</code></pre></div>
<p>Cloud Platform 和 Local Platform 使用的 API private key 为：</p>
<div class="section-example-container"><p class="code-explanation">格式说明：以下保留原文字段/凭据结构，不能直接当作真实可用凭据；JSON 不插入注释，以免破坏格式。API name 为名称，privateKey 为私钥；不同部署环境的私钥换行处理见上下文。</p><pre><code class="language-text">MHcCAQEEIPcJGfXYEdLQi0iFj1xvGfPwuRNoebbwuKS4xL2NrlGWpoAoGCCqGSM49AwEHoUQDQgAEclN+asd/EhJ3UjOWkHmP/iqGBv5NkNJ75bUqVgxS4aU3/djHiIuSf27QasdOFIDGJLmOn7YiQ==</code></pre></div>
<p>Cloud/Local Platform 的私钥须按以下方式调整格式：</p>
<ol>
<li>去掉 -----BEGIN EC PRIVATE KEY-----\n。</li>
<li>去掉 \n-----END EC PRIVATE KEY-----\n。</li>
<li>去掉其余 \n 字符。</li>
</ol>
<h4>模拟交易</h4>
<p>Coinbase 没有原生模拟交易，可按下列步骤用 QuantConnect 模拟：</p>
<ol>
<li>在 Initialize/initialize 中设置 Coinbase 券商模型和账户类型。</li>
<li>使用 QuantConnect Paper Trading 券商部署算法。</li>
</ol>


## 资产类别 · 04 Asset Classes

<p>本集成支持加密货币交易。</p>


## 数据源 · 05 Data Providers

<p>QuantConnect 数据源提供实时加密货币行情。</p>

## 订单 · 06 Orders

<p>支持多种订单和属性，不支持直接改单；实盘也可在 IDE 手动下单。</p>
<h4>订单类型</h4>
<p>下表列出本集成对各资产支持的订单类型：</p>
<table class="qc-table table">
<thead>
<tr>
<th style="width: 50%">订单类型</th>
<th>加密货币</th>
</tr>
</thead>
<tbody>
<tr>
<td>市价单（Market）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>限价单（Limit）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>止损市价单（Stop market）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>止损限价单（Stop limit）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
</tbody>
</table>

<h4>订单属性</h4>
<p>下表为 Coinbase API 的自定义订单属性，可用 CoinbaseOrderProperties 设置。</p>
<table class="table qc-table">
<thead>
<tr>
<th>属性</th>
<th>数据类型</th>
<th>说明</th>
<th>默认值</th>
</tr>
</thead>
<tbody>
<tr>
<td><code class="csharp">TimeInForce</code><code class="python">time_in_force</code></td>
<td><code>TimeInForce</code></td>
<td>订单有效期设置；支持 GoodTilCanceled/GOOD_TIL_CANCELED。</td>
<td><code class="csharp">TimeInForce.GoodTilCanceled</code><code class="python">TimeInForce.GOOD_TIL_CANCELED</code></td>
</tr>
<tr>
<td><code class="csharp">PostOnly</code><code class="python">post_only</code></td>
<td><code>bool</code></td>
<td>只允许提供流动性；若部分订单会吃单，则整单拒绝，不部分成交。</td>
<td></td>
</tr>
<tr>
<td><code class="csharp">SelfTradePreventionId</code><code class="python">self_trade_prevention_id</code></td>
<td><code>bool</code></td>
<td>启用自成交保护，避免同一用户的买卖单互相成交，降低账户内意外自成交风险。</td>
<td></td>
</tr>
</tbody>
</table>
<h4>更新订单</h4>
<p>不支持直接更新限价单，须先撤单再按新参数提交，见对应替代方案。</p>


## 手续费 · 07 Fees

<p>Coinbase 收费见官网 What are the fees 页面；平台模型见 Fees。</p>


## 保证金 · 08 Margin

<p>Coinbase 不支持保证金交易。</p>


## 滑点 · 09 Slippage

<p>Coinbase 回测不计滑点；Coinbase 模拟与实盘订单可能产生滑点。</p>
<p>Coinbase 滑点模型见 Slippage。</p>


## 成交 · 10 Fills

<p>回测中 QuantConnect 立即、全部成交市价单。Coinbase 模拟和实盘中，若数量超过盘口最优档可用数量，会按订单簿实际流动性成交。</p>
<p>Coinbase 成交模型见 Fills。</p>


## 结算 · 11 Settlements

<p>交易后立即结算。</p>
<p>Coinbase 结算模型见 Settlement。</p>


## 安全与稳定性 · 12 Security and Stability

<p>本集成的安全与稳定性说明如下。</p>
<h4>账户凭据</h4>
<p>通过 Coinbase 部署时，平台不保存登录凭据。</p>
<h4>API 服务中断</h4>
<p>实盘订单通过 Coinbase API 提交，API 有时可能中断；可在其状态页查看服务情况。</p>


## 入金与出金 · 13 Deposits and Withdrawals

<p>算法运行时仍可给关联券商账户出入金；平台每天美东时间 7:45 同步账户现金余额。</p>


## 演示算法 · 14 Demo Algorithm

<p>以下算法演示 Coinbase 的功能：</p>
<div class="section-example-container testable">
<pre><code class="language-csharp">// 中文注释版：仅补充解释，保留原示例的执行语句。&#10;// Demonstrate Coinbase brokerage functionality with an EMA crossover strategy.&#10;public class CoinbaseDemoAlgorithm : QCAlgorithm&#10;{&#10;    private Symbol _symbol;&#10;    private ExponentialMovingAverage _fast;&#10;    private ExponentialMovingAverage _slow;&#10;&#10;    public override void Initialize()&#10;    {&#10;        // 设置回测开始日期；实盘运行不以此恢复历史状态。&#10;        SetStartDate(2024, 9, 1);&#10;        // 设置回测结束日期。&#10;        SetEndDate(2024, 12, 31);&#10;        // 设置回测初始现金；实盘资金以券商账户和部署配置为准。&#10;        SetCash(100000);&#10;        // 设置券商模型和账户类型，决定资产、订单及现实约束。&#10;        SetBrokerageModel(BrokerageName.Coinbase, AccountType.Cash);&#10;        // 订阅指定市场的加密货币对。&#10;        _symbol = AddCrypto("BTCUSD", Resolution.Daily, Market.Coinbase).Symbol;&#10;        // 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        _fast = EMA(_symbol, 10, Resolution.Daily);&#10;        // 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        _slow = EMA(_symbol, 50, Resolution.Daily);&#10;    }&#10;&#10;    public override void OnData(Slice slice)&#10;    {&#10;        // 指标准备好后才使用信号，历史样本不足时退出。&#10;        if (!_slow.IsReady) return;&#10;        if (_fast &gt; _slow &amp;&amp; !Portfolio.Invested)&#10;            // 按目标权重调整仓位；1 表示账户权益的 100%，不是买入 1 股。&#10;            SetHoldings(_symbol, 1);&#10;        else if (_fast &lt; _slow &amp;&amp; Portfolio.Invested)&#10;            // 请求平仓；实际成交仍取决于市场和券商。&#10;            Liquidate();&#10;    }&#10;}</code></pre>
<pre><code class="language-python"># 中文注释版：仅补充解释，保留原示例的执行语句。&#10;# Demonstrate Coinbase brokerage functionality with an EMA crossover strategy.&#10;# 定义继承 QCAlgorithm 的策略类，由 LEAN 管理其生命周期。&#10;class CoinbaseDemoAlgorithm(QCAlgorithm):&#10;    # 初始化只在算法开始时运行一次，设置回测条件和数据订阅。&#10;    def initialize(self) -&gt; None:&#10;        # 设置历史回测的开始日期。&#10;        # 设置回测开始日期；实盘运行不以此恢复历史状态。&#10;        self.set_start_date(2024, 9, 1)&#10;        # 设置历史回测的结束日期。&#10;        # 设置回测结束日期。&#10;        self.set_end_date(2024, 12, 31)&#10;        # 设置回测初始资金为 100,000 单位账户货币。&#10;        # 设置回测初始现金；实盘资金以券商账户和部署配置为准。&#10;        self.set_cash(100000)&#10;        # 设置券商模型和账户类型，决定资产、订单及现实约束。&#10;        self.set_brokerage_model(BrokerageName.COINBASE, AccountType.CASH)&#10;        # 订阅指定市场的加密货币对。&#10;        self._symbol = self.add_crypto("BTCUSD", Resolution.DAILY, Market.COINBASE).symbol&#10;        # 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        self._fast = self.ema(self._symbol, 10, Resolution.DAILY)&#10;        # 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        self._slow = self.ema(self._symbol, 50, Resolution.DAILY)&#10;&#10;    # 行情到达时执行；data 包含该时间片可用的数据。&#10;    def on_data(self, slice: Slice) -&gt; None:&#10;        # 指标准备好后才使用信号，历史样本不足时退出。&#10;        if not self._slow.is_ready:&#10;            return&#10;        if self._fast.current.value &gt; self._slow.current.value and not self.portfolio.invested:&#10;            # 按目标权重调整仓位；1 表示账户权益的 100%，不是买入 1 股。&#10;            self.set_holdings(self._symbol, 1)&#10;        elif self._fast.current.value &lt; self._slow.current.value and self.portfolio.invested:&#10;            # 请求平仓；实际成交仍取决于市场和券商。&#10;            self.liquidate()</code></pre>
</div>

## 虚拟币对 · 15 Virtual Pairs

<p>每种法币和加密币都是独立资产。买入 BTCUSD 实际是用 USD 换 BTC，现金账簿减少 USD、增加 BTC；BTCUSD 持仓是表示交易的虚拟币对。部署时 LEAN 可载入各币种余额，却无法从余额反推每个虚拟币对的持仓。</p>


## 部署算法 · 16 Deploy Live Algorithms

<p>每个实盘算法必须有一个可用实盘节点。</p>
<p>按以下步骤部署实盘算法：</p>
<ol>
<li>打开要部署的项目。</li>
<li>点击 Deploy Live（部署实盘）图标。<img alt="Lightning icon" class="inline-icon" src="https://cdn.quantconnect.com/i/tu/deploy-live-icon.png"/></li>
<li>在 Deploy Live 页面点击 Brokerage 字段，从列表选择 Coinbase。</li>
<li>输入 Coinbase API Name 与 API Private Key。</li><p>凭据生成步骤见 Account Types 的 Create an Account；QuantConnect 不保存这些凭据。</p>
<li>在 Region 区域选择算法运行地区。</li>
<li>点击 Node 字段，选择要使用的实盘节点。</li>
<li>可选：在 Data Provider 区域点击 Show，修改数据源或添加其他数据源。</li>
<li>账户已有持仓时，按以下步骤填写（有演示视频）：</li>
<ol>
<li>在 Algorithm Holdings State 点击 Show。</li>
<li>点击 Add Holding。</li>
<li>填写 Symbol ID、代码、数量和平均价格。</li>
</ol>
<li>可选：配置通知。</li>
<li>配置 Automatically restart algorithm（自动重启算法）选项。</li>
<p>开启自动重启后，平台会尽力重启因运行错误而失败的算法，有助于应对券商 API 暂时断线等故障。</p>
<li>点击 Deploy（部署）。</li>
</ol>
<p>部署最多可能需要 5 分钟，完成后显示实盘结果页。可核对运行统计中的权益、现金账簿和持仓，确认券商原有持仓正确载入。</p>
<p>重启、自动重启和重新部署都不会保存算法全部内部状态。恢复哪些状态、其余状态如何持久化，见 State Persistence。</p>

