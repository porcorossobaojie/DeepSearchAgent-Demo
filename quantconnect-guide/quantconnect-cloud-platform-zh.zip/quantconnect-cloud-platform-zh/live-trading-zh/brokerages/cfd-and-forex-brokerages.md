# CFD 与外汇券商（OANDA）

非官方中文翻译，按原文小节排列；专有名词、按钮、错误消息和代码字段保留英文对照。费用、IP、权限及产品范围为所标源码版本的记录。各节保留官方链接，代码保留执行语句并添加中文注释。

## 简介 · 01 Introduction

<p>QuantConnect 支持使用实时行情运行实盘模式的算法。</p>
<p>QuantConnect 通过 OANDA 提供 CFD 和外汇交易。OANDA 由 Michael Stumm、Richard Olsen 于 1995 年创立，目标是改善货币交易和数据使用。原文称覆盖 240 多个国家和地区、无最低入金，并提供模拟账户、图表工具和教育内容。</p>
<p>集成实现见 Lean.Brokerages.OANDA 仓库。</p>

## 账户类型 · 02 Account Types

<p>OANDA 支持保证金账户，算法设置见券商模型文档。</p>
<h4>创建账户</h4>
<p>按 OANDA 官网 How to open an account 指引开户。</p>
<p>部署需账户号码与 access token。号码在 Account Statement，格式 ###-###-######-###；token 在 Manage API Access 获取。</p>
<div class="highlight">
<p>欧盟居民须注意：OANDA Europe Markets 于 2023-03-17 停业并将账户转至 OANDA TMS；原文随后写作 OANDA TWS，名称不一致。此实体不提供实盘 REST API。只有可在集团其他实体开户的欧盟居民（例如符合条件的美国公民）才可能使用本集成，须核对开户资格。</p>
</div>
<h4>模拟交易</h4>
<p>OANDA 支持模拟，配置步骤如下：</p>
<ol>
<li>创建 OANDA demo 账户。</li>
<li>登录模拟账户。</li>
<li>在 Account 的 My Services 点击 Manage API Access。</li>
<li>在 Your key to OANDA's API 页面点击 Generate。</li>
<p>妥善保存显示的 access token，模拟部署需要。</p>
<li>顶部导航点击 My Account。</li>
<li>Account 页的 Manage Funds 点击 View。</li>
<li>My Funds 页的 Account Summary 中记录 v20 Account Number。</li>
<p>模拟部署需要 v20 Account Number。</p>
</ol>


## 资产类别 · 04 Asset Classes

<p>本集成支持外汇和 CFD。</p>


## 数据源 · 05 Data Providers

<p>QuantConnect 数据源提供实时外汇和 CFD 行情。</p>

## 订单 · 06 Orders

<p>支持多种订单、TimeInForce 和改单；实盘可在 IDE 手动下单。</p>
<h4>订单类型</h4>
<p>下表列出本集成对各资产支持的订单类型：</p>
<table class="qc-table table">
<thead>
<tr>
<th style="width: 50%">订单类型</th>
<th style="width: 25%">外汇</th>
<th style="width: 25%">差价合约（CFD）</th>
</tr>
</thead>
<tbody>
<tr>
<td>市价单（Market）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>限价单（Limit）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>止损市价单（Stop market）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>止损限价单（Stop limit）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
</tbody>
</table>

<h4>订单有效期</h4>
<p>支持 GTC（GoodTilCanceled/GOOD_TIL_CANCELED）有效期。</p>
<h4>更新订单</h4>
<p>本集成支持更新 OANDA 订单。</p>


## 手续费 · 07 Fees

<p>OANDA 费用见 Our Charges and Fees；平台模型见 Fees。</p>


## 保证金 · 08 Margin

<p>平台模拟购买力和追加保证金，帮助算法遵守保证金要求。</p>


## 滑点 · 09 Slippage

<p>OANDA 回测不计滑点；OANDA 模拟与实盘订单可能产生滑点。</p>
<p>OANDA 滑点模型见 Slippage。</p>


## 成交 · 10 Fills

<p>OANDA 成交模型见 Fills。</p>


## 结算 · 11 Settlements

<p>交易后立即结算。</p>
<p>OANDA 结算模型见 Settlement。</p>


## 安全与稳定性 · 12 Security and Stability

<p>本集成的安全与稳定性说明如下。</p>
<h4>账户凭据</h4>
<p>通过 OANDA 部署时，平台不保存登录凭据。</p>
<h4>API 服务中断</h4>
<p>实盘订单通过 OANDA API 提交，API 有时可能中断；可在其状态页查看服务情况。</p>


## 入金与出金 · 13 Deposits and Withdrawals

<p>算法运行时仍可给关联券商账户出入金；平台每天美东时间 7:45 同步账户现金余额。</p>


## 演示算法 · 14 Demo Algorithm

<p>以下算法演示 OANDA 的功能：</p>
<div class="section-example-container testable">
<pre><code class="language-csharp">// 中文注释版：仅补充解释，保留原示例的执行语句。&#10;// Demonstrate OANDA brokerage functionality with an EMA crossover strategy on EURUSD.&#10;public class OandaDemoAlgorithm : QCAlgorithm&#10;{&#10;    private Symbol _symbol;&#10;    private ExponentialMovingAverage _fast;&#10;    private ExponentialMovingAverage _slow;&#10;&#10;    public override void Initialize()&#10;    {&#10;        // 设置回测开始日期；实盘运行不以此恢复历史状态。&#10;        SetStartDate(2024, 9, 1);&#10;        // 设置回测结束日期。&#10;        SetEndDate(2024, 12, 31);&#10;        // 设置回测初始现金；实盘资金以券商账户和部署配置为准。&#10;        SetCash(100000);&#10;        // 设置券商模型和账户类型，决定资产、订单及现实约束。&#10;        SetBrokerageModel(BrokerageName.OandaBrokerage, AccountType.Margin);&#10;        // 订阅指定市场的外汇币对。&#10;        _symbol = AddForex("EURUSD", Resolution.Daily, Market.Oanda).Symbol;&#10;        // 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        _fast = EMA(_symbol, 10, Resolution.Daily);&#10;        // 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        _slow = EMA(_symbol, 50, Resolution.Daily);&#10;    }&#10;&#10;    public override void OnData(Slice slice)&#10;    {&#10;        // 指标准备好后才使用信号，历史样本不足时退出。&#10;        if (!_slow.IsReady) return;&#10;        if (_fast &gt; _slow &amp;&amp; !Portfolio.Invested)&#10;            // 按目标权重调整仓位；1 表示账户权益的 100%，不是买入 1 股。&#10;            SetHoldings(_symbol, 1);&#10;        else if (_fast &lt; _slow &amp;&amp; Portfolio.Invested)&#10;            // 请求平仓；实际成交仍取决于市场和券商。&#10;            Liquidate();&#10;    }&#10;}</code></pre>
<pre><code class="language-python"># 中文注释版：仅补充解释，保留原示例的执行语句。&#10;# Demonstrate OANDA brokerage functionality with an EMA crossover strategy on EURUSD.&#10;# 定义继承 QCAlgorithm 的策略类，由 LEAN 管理其生命周期。&#10;class OandaDemoAlgorithm(QCAlgorithm):&#10;    # 初始化只在算法开始时运行一次，设置回测条件和数据订阅。&#10;    def initialize(self) -&gt; None:&#10;        # 设置历史回测的开始日期。&#10;        # 设置回测开始日期；实盘运行不以此恢复历史状态。&#10;        self.set_start_date(2024, 9, 1)&#10;        # 设置历史回测的结束日期。&#10;        # 设置回测结束日期。&#10;        self.set_end_date(2024, 12, 31)&#10;        # 设置回测初始资金为 100,000 单位账户货币。&#10;        # 设置回测初始现金；实盘资金以券商账户和部署配置为准。&#10;        self.set_cash(100000)&#10;        # 设置券商模型和账户类型，决定资产、订单及现实约束。&#10;        self.set_brokerage_model(BrokerageName.OANDA_BROKERAGE, AccountType.MARGIN)&#10;        # 订阅 OANDA 的 EURUSD 日线，使用该市场对应的模型。&#10;        # 订阅指定市场的外汇币对。&#10;        self._symbol = self.add_forex("EURUSD", Resolution.DAILY, Market.OANDA).symbol&#10;        # 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        self._fast = self.ema(self._symbol, 10, Resolution.DAILY)&#10;        # 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        self._slow = self.ema(self._symbol, 50, Resolution.DAILY)&#10;&#10;    # 行情到达时执行；data 包含该时间片可用的数据。&#10;    def on_data(self, slice: Slice) -&gt; None:&#10;        # 指标准备好后才使用信号，历史样本不足时退出。&#10;        if not self._slow.is_ready:&#10;            return&#10;        if self._fast.current.value &gt; self._slow.current.value and not self.portfolio.invested:&#10;            # 按目标权重调整仓位；1 表示账户权益的 100%，不是买入 1 股。&#10;            self.set_holdings(self._symbol, 1)&#10;        elif self._fast.current.value &lt; self._slow.current.value and self.portfolio.invested:&#10;            # 请求平仓；实际成交仍取决于市场和券商。&#10;            self.liquidate()</code></pre>
</div>

## 部署算法 · 15 Deploy Live Algorithms

<p>每个实盘算法必须有一个可用实盘节点。</p>
<p>按以下步骤部署实盘算法：</p>
<ol>
<li>打开要部署的项目。</li>
<li>点击 Deploy Live（部署实盘）图标。<img alt="Lightning icon" class="inline-icon" src="https://cdn.quantconnect.com/i/tu/deploy-live-icon.png"/></li>
<li>在 Deploy Live 页面点击 Brokerage 字段，从列表选择 OANDA。</li>
<li>输入 OANDA 账户 ID 和 access token。</li><p>获取方法见 Account Types 的 Create an Account；QuantConnect 不保存这些凭据。</p>
<li>点击 Environment，选择所需环境。</li>
<p>支持的环境如下：</p>
<table class="table qc-table">
<thead>
<tr>
<th>环境</th>
<th>说明</th>
</tr>
</thead>
<tbody>
<tr>
<td>真实（Real）</td>
<td>通过 fxTrade 交易真实资金</td>
</tr>
<tr>
<td>模拟（Demo）</td>
<td>通过 fxTrade Practice 交易虚拟资金</td>
</tr>
</tbody>
</table> <li>在 Region 区域选择算法运行地区。</li>
<li>点击 Node 字段，选择要使用的实盘节点。</li>
<li>可选：在 Data Provider 区域点击 Show，修改数据源或添加其他数据源。</li>
<li>可选：配置通知。</li>
<li>配置 Automatically restart algorithm（自动重启算法）选项。</li>
<p>开启自动重启后，平台会尽力重启因运行错误而失败的算法，有助于应对券商 API 暂时断线等故障。</p>
<li>点击 Deploy（部署）。</li>
</ol>
<p>部署最多可能需要 5 分钟，完成后显示实盘结果页。可核对运行统计中的权益、现金账簿和持仓，确认券商原有持仓正确载入。</p>
<p>重启、自动重启和重新部署都不会保存算法全部内部状态。恢复哪些状态、其余状态如何持久化，见 State Persistence。</p>


## 部署详情 · 16 Deployment Details

<p>部署 OANDA 算法时，券商提供交易账户等详情，可区分并行部署和核对目标账户；这些详情不包含凭据。</p>
<p>下表列出 OANDA 提供的部署详情：</p>
<table class="qc-table table">
<thead>
<tr>
<th>键名</th>
<th>说明</th>
</tr>
</thead>
<tbody>
<tr>
<td><code>oanda-account-id</code></td>
<td>接收订单的 OANDA 账户。</td>
</tr>
<tr>
<td><code>oanda-environment</code></td>
<td>账户环境：Trade 为真实账户，Practice 为模拟账户。</td>
</tr>
</tbody>
</table>
<p>算法的 DeploymentDetails/deployment_details 是只读字典，LEAN 在调用 Initialize/initialize 之前填充，因此在算法任何位置都可读取。</p>
<div class="section-example-container">
<pre><code class="language-csharp">// 中文注释版：仅补充解释，保留原示例的执行语句。&#10;// 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;var deploymentDetails = DeploymentDetails.Select(kvp =&gt; $"{kvp.Key}:{kvp.Value}");&#10;Log($"deploymentDetails: {string.Join(", ", deploymentDetails)}");</code></pre>
<pre><code class="language-python"># 中文注释版：仅补充解释，保留原示例的执行语句。&#10;# 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;deployment_details = [f'{kvp.key}:{kvp.value}' for kvp in self.deployment_details]&#10;# 记录常规运行信息，消息写入日志并计入日志额度。&#10;# 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;self.log(f'deployment_details: {deployment_details}')</code></pre>
</div>
<p>也可在算法外通过 /live/read 响应的 deploymentDetails 读取详情。</p>

