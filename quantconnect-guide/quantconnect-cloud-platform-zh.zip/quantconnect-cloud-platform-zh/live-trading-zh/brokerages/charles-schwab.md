# Charles Schwab

非官方中文翻译，按原文小节排列；专有名词、按钮、错误消息和代码字段保留英文对照。费用、IP、权限及产品范围为所标源码版本的记录。各节保留官方链接，代码保留执行语句并添加中文注释。

## 简介 · 01 Introduction

<p>QuantConnect 支持使用实时行情运行实盘模式的算法。</p>
<p>Charles Schwab 由 Charles R. Schwab 于 1971 年创立，提供股票、期权、指数期权等交易；原文称无账户或交易最低要求、无隐藏费用。</p>

## 账户类型 · 02 Account Types

<p>Charles Schwab 支持现金和保证金账户；算法设置方式见对应券商模型文档。</p>
<h4>创建账户</h4>
<p>按 Charles Schwab 官网开户向导开立账户。</p>

<h4>模拟交易</h4>
<p>Charles Schwab API 不支持模拟交易，但可用 QuantConnect 按以下方法模拟：</p>
<ol>
<li>在 Initialize/initialize 中设置 Charles Schwab 券商模型和账户类型。</li>
<li>使用 QuantConnect Paper Trading 券商部署算法。</li>
</ol>


## 身份认证 · 03 Authentication

<p>本集成可认证多个 Charles Schwab 用户，每个项目一个用户并关联一个交易账户。同一用户再部署第二个算法会停止第一个。例如 JohnDoe 的两个账户 XXXXX549/XXXXX725 只能部署其中一个；第二个算法须用 RichardRoe 等另一用户及其所属账户。</p>

## 资产类别 · 04 Asset Classes

<p>本集成支持以下资产类别：</p>
<ul>
<li>美国股票</li>
<li>股票期权</li>
<li>指数</li>
<li>指数期权</li>
</ul><p>Charles Schwab 资产权限因所在地及账户而异，例如欧盟居民不能交易美国 ETF。请核对当地规定，必要时调整券商账户权限。</p>

## 数据源 · 05 Data Providers

<p>推荐免费的 QuantConnect 数据源，覆盖美国股票、股票期权、指数期权以及 SPX/VIX 标的指数。用 Charles Schwab 报价可能需另购行情订阅，详见 Datasets。</p>


## 订单 · 06 Orders

<p>本集成支持 Charles Schwab 的多种订单、TimeInForce 属性和订单更新；实盘也可在 IDE 手动下单。</p>
<h4>订单类型</h4>
<p>下表列出本集成对各资产支持的订单类型：</p>
<table class="qc-table table">
<thead>
<tr>
<th style="width: 40%">订单类型</th>
<th style="width: 20%">股票</th>
<th style="width: 20%">股票期权</th>
<th style="width: 20%">指数期权</th>
</tr>
</thead>
<tbody>
<tr>
<td>市价单（Market）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>限价单（Limit）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>止损市价单（Stop market）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td></td>
</tr>
<tr>
<td>开盘市价单（Market on open）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td></td>
<td></td>
</tr>
<tr>
<td>收盘市价单（Market on close）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td></td>
<td></td>
</tr>
<tr>
<td>组合市价单（Combo market）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>组合限价单（Combo limit）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>括号订单（Bracket）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>一单成交取消另一单（OCO）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>一单触发另一单（OTO）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
</tbody>
</table>

<h4>订单属性</h4>
<p>下表为 Charles Schwab 自定义订单属性，可用 CharlesSchwabOrderProperties 对象设置。</p>
<table class="table qc-table">
<thead>
<tr>
<th>属性</th>
<th>数据类型</th>
<th>说明</th>
<th>默认值</th>
</tr>
</thead>
<tbody>
<tr>
<td><code class="csharp">TimeInForce</code><code class="python">time_in_force</code></td>
<td><code>TimeInForce</code></td>
<td>A <a href="https://www.quantconnect.com/docs/v2/writing-algorithms/trading-and-orders/order-properties#03-Time-In-Force">TimeInForce</a>为订单设置有效期，支持以下取值：<ul>
<li>当日有效（Day / DAY）</li>
<li><code class="csharp">GoodTilCanceled</code><code class="python">GOOD_TIL_CANCELED</code></li>
<li>指定日期前有效（GoodTilDate / good_til_date）</li>
</ul>
</td>
<td><code class="csharp">TimeInForce.GoodTilCanceled</code><code class="python">TimeInForce.GOOD_TIL_CANCELED</code></td>
</tr>
<tr>
<td><code class="csharp">ExtendedRegularTradingHours</code><code class="python">extended_regular_trading_hours</code></td>
<td><code>bool</code></td>
<td>设为 true，允许订单在常规时段外触发或成交。</td>
<td><code class="csharp">false</code><code class="python">False</code></td>
</tr>
</tbody>
</table>
<h4>关联条件订单</h4>
<p>Charles Schwab 支持条件组及触发链，但各单必须为单腿，不支持组合单或 OUO，也不支持更新组内订单；修改时须取消整组再重建。</p>
<h4>更新订单</h4>
<p>本集成支持更新 Charles Schwab 订单。</p>
<h4>拆股处理</h4>
<p>使用原始价格（Raw）时，如果美国股票拆股，尚未成交订单中的以下属性会自动按拆股比例调整：</p>
<ul>
<li>数量</li>
<li>限价</li>
<li>止损价</li>
<li>触发价</li>
</ul>

## 请求限流 · 07 Rate Limit

<p>Charles Schwab 下单、改单、撤单合计每分钟最多 120 次、每天 4,000 次，应控制请求频率。</p>


## 手续费 · 08 Fees

<p>Charles Schwab 股票交易免佣，其他费用见官网 Pricing；平台模型见 Fees。</p>

## 保证金 · 09 Margin

<p>平台模拟购买力和追加保证金，帮助算法遵守保证金要求。</p>


## 滑点 · 10 Slippage

<p>Charles Schwab 回测和 QuantConnect Paper Trading 不计滑点，实盘可能产生滑点。</p>
<p>Charles Schwab 滑点模型见 Slippage。</p>


## 成交 · 11 Fills

<p>QuantConnect 回测和 QuantConnect Paper Trading 会立即、全部成交市价单；实盘数量超过盘口可用量时按订单簿流动性成交。</p>
<p>Charles Schwab 成交模型见 Fills。</p>

## 结算 · 12 Settlements

<p>保证金账户的交易即时结算。（原模板此处仅输出这一分支；现金账户规则应结合券商结算说明核对。）</p>
<p>Charles Schwab 结算模型见 Settlement。</p>

## 安全与稳定性 · 13 Security and Stability


<p>通过 Charles Schwab 部署时，平台不保存登录凭据。</p>


## 入金与出金 · 14 Deposits and Withdrawals

<p>算法运行时仍可给关联券商账户出入金；平台每天美东时间 7:45 同步账户现金余额。</p>
<p>入金 24 小时后才可用于 API 交易。</p>


## 演示算法 · 15 Demo Algorithm

<p>以下算法演示 Charles Schwab 的功能：</p>
<div class="section-example-container testable">
<pre><code class="language-csharp">// 中文注释版：仅补充解释，保留原示例的执行语句。&#10;// Demonstrate Charles Schwab brokerage functionality with an EMA crossover strategy on SPY.&#10;public class CharlesSchwabDemoAlgorithm : QCAlgorithm&#10;{&#10;    private ExponentialMovingAverage _fast;&#10;    private ExponentialMovingAverage _slow;&#10;&#10;    public override void Initialize()&#10;    {&#10;        // 设置回测开始日期；实盘运行不以此恢复历史状态。&#10;        SetStartDate(2024, 9, 1);&#10;        // 设置回测结束日期。&#10;        SetEndDate(2024, 12, 31);&#10;        // 设置回测初始现金；实盘资金以券商账户和部署配置为准。&#10;        SetCash(100000);&#10;        // 设置券商模型和账户类型，决定资产、订单及现实约束。&#10;        SetBrokerageModel(BrokerageName.CharlesSchwab, AccountType.Margin);&#10;        // 订阅股票行情并取得对应证券。&#10;        var symbol = AddEquity("SPY", Resolution.Daily).Symbol;&#10;        // 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        _fast = EMA(symbol, 10, Resolution.Daily);&#10;        // 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        _slow = EMA(symbol, 50, Resolution.Daily);&#10;    }&#10;&#10;    public override void OnData(Slice slice)&#10;    {&#10;        // 指标准备好后才使用信号，历史样本不足时退出。&#10;        if (!_slow.IsReady) return;&#10;        if (_fast &gt; _slow &amp;&amp; !Portfolio.Invested)&#10;            // 按目标权重调整仓位；1 表示账户权益的 100%，不是买入 1 股。&#10;            SetHoldings("SPY", 1);&#10;        else if (_fast &lt; _slow &amp;&amp; Portfolio.Invested)&#10;            // 请求平仓；实际成交仍取决于市场和券商。&#10;            Liquidate();&#10;    }&#10;}</code></pre>
<pre><code class="language-python"># 中文注释版：仅补充解释，保留原示例的执行语句。&#10;# Demonstrate Charles Schwab brokerage functionality with an EMA crossover strategy on SPY.&#10;# 定义继承 QCAlgorithm 的策略类，由 LEAN 管理其生命周期。&#10;class CharlesSchwabDemoAlgorithm(QCAlgorithm):&#10;    # 初始化只在算法开始时运行一次，设置回测条件和数据订阅。&#10;    def initialize(self) -&gt; None:&#10;        # 设置历史回测的开始日期。&#10;        # 设置回测开始日期；实盘运行不以此恢复历史状态。&#10;        self.set_start_date(2024, 9, 1)&#10;        # 设置历史回测的结束日期。&#10;        # 设置回测结束日期。&#10;        self.set_end_date(2024, 12, 31)&#10;        # 设置回测初始资金为 100,000 单位账户货币。&#10;        # 设置回测初始现金；实盘资金以券商账户和部署配置为准。&#10;        self.set_cash(100000)&#10;        # 设置券商模型和账户类型，决定资产、订单及现实约束。&#10;        self.set_brokerage_model(BrokerageName.CHARLES_SCHWAB, AccountType.MARGIN)&#10;        # 订阅股票行情并取得对应证券。&#10;        symbol = self.add_equity("SPY", Resolution.DAILY).symbol&#10;        # 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        self._fast = self.ema(symbol, 10, Resolution.DAILY)&#10;        # 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        self._slow = self.ema(symbol, 50, Resolution.DAILY)&#10;&#10;    # 行情到达时执行；data 包含该时间片可用的数据。&#10;    def on_data(self, slice: Slice) -&gt; None:&#10;        # 指标准备好后才使用信号，历史样本不足时退出。&#10;        if not self._slow.is_ready:&#10;            return&#10;        if self._fast.current.value &gt; self._slow.current.value and not self.portfolio.invested:&#10;            # 按目标权重调整仓位；1 表示账户权益的 100%，不是买入 1 股。&#10;            self.set_holdings("SPY", 1)&#10;        elif self._fast.current.value &lt; self._slow.current.value and self.portfolio.invested:&#10;            # 请求平仓；实际成交仍取决于市场和券商。&#10;            self.liquidate()</code></pre>
</div>

## 部署算法 · 16 Deploy Live Algorithms

<p>每个实盘算法必须有一个可用实盘节点。</p>
<p>按以下步骤部署实盘算法：</p>
<ol>
<li>打开要部署的项目。</li>
<li>点击 Deploy Live（部署实盘）图标。<img alt="Lightning icon" class="inline-icon" src="https://cdn.quantconnect.com/i/tu/deploy-live-icon.png"/></li>
<li>在 Deploy Live 页面点击 Brokerage 字段，从列表选择 Charles Schwab。</li>
<li>输入 Charles Schwab Login ID 用户名并按 Enter。</li><li>勾选 Authorization，再点击 Authenticate。</li>
<li>在 Charles Schwab 官网用同一 ID 登录，选择要关联的 Schwab 账户，点击 Allow 授权 QuantConnect。</li>
<li>点击 Select Account Id，选择一个账户。</li> <li>在 Region 区域选择算法运行地区。</li>
<li>点击 Node 字段，选择要使用的实盘节点。</li>
<li>可选：在 Data Provider 区域点击 Show，修改数据源或添加其他数据源。</li>
<p>通常可使用 QuantConnect、Charles Schwab 数据源或两者组合；部署向导中的排列顺序决定 LEAN 的优先级。</p> <li>可选：配置通知。</li>
<li>配置 Automatically restart algorithm（自动重启算法）选项。</li>
<p>开启自动重启后，平台会尽力重启因运行错误而失败的算法，有助于应对券商 API 暂时断线等故障。</p>
<li>点击 Deploy（部署）。</li>
</ol>
<p>部署最多可能需要 5 分钟，完成后显示实盘结果页。可核对运行统计中的权益、现金账簿和持仓，确认券商原有持仓正确载入。</p>
<p>重启、自动重启和重新部署都不会保存算法全部内部状态。恢复哪些状态、其余状态如何持久化，见 State Persistence。</p>


## 部署详情 · 17 Deployment Details

<p>部署 Charles Schwab 算法时，券商提供交易账户等详情，可区分并行部署和核对目标账户；这些详情不包含凭据。</p>
<p>下表列出 Charles Schwab 提供的部署详情：</p>
<table class="qc-table table">
<thead>
<tr>
<th>键名</th>
<th>说明</th>
</tr>
</thead>
<tbody>
<tr>
<td><code>charles-schwab-account-number</code></td>
<td>接收订单的 Charles Schwab 账户。</td>
</tr>
</tbody>
</table>
<p>算法的 DeploymentDetails/deployment_details 是只读字典，LEAN 在调用 Initialize/initialize 之前填充，因此在算法任何位置都可读取。</p>
<div class="section-example-container">
<pre><code class="language-csharp">// 中文注释版：仅补充解释，保留原示例的执行语句。&#10;// 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;var deploymentDetails = DeploymentDetails.Select(kvp =&gt; $"{kvp.Key}:{kvp.Value}");&#10;Log($"deploymentDetails: {string.Join(", ", deploymentDetails)}");</code></pre>
<pre><code class="language-python"># 中文注释版：仅补充解释，保留原示例的执行语句。&#10;# 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;deployment_details = [f'{kvp.key}:{kvp.value}' for kvp in self.deployment_details]&#10;# 记录常规运行信息，消息写入日志并计入日志额度。&#10;# 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;self.log(f'deployment_details: {deployment_details}')</code></pre>
</div>
<p>也可在算法外通过 /live/read 响应的 deploymentDetails 读取详情。</p>


## 故障排查 · 18 Troubleshooting

<p>下表说明会导致 Charles Schwab 拒单的错误：</p>
<table class="table qc-table">
<thead>
<tr>
<th>错误消息（保留英文便于检索）</th>
<th>可能原因与解决方法</th>
</tr>
</thead>
<tbody>
<tr>
<td>
<div class="error-messages">Name = Account_Sys_0005,Description = No trades are currently allowed</div>
</td>
<td>账户可能缺少交易权限。登录 schwab.com，进入 Trade &gt; Trading Platforms，点击 Enable trading on thinkorswim。权限生效最多可能需 48 小时；仍失败请联系 Charles Schwab。</td>
</tr>
<tr>
<td>
<div class="error-messages">Name = Order_Sys_0002,Description = The stop price must be above the current ask for buy stop orders and below the bid for sell stop orders.</div>
</td>
<td>
                The stop price is on the wrong side of the market. A buy stop must sit above the current ask and a sell stop must sit below the current bid; Schwab rejects the order when the market has already crossed the stop price (for example, a sell stop set at or above the current bid). This often happens when a stop is submitted with a stale price or right at the market. Compute the stop price from the current quote — reference the ask for buy stops and the bid for sell stops — so it always sits on the correct side of the market:
                <div class="section-example-container">
<pre><code class="language-python"># 中文注释版：仅补充解释，保留原示例的执行语句。&#10;security = self.securities[symbol]&#10;# Buy stop above the ask, sell stop below the bid&#10;stop_price = security.ask_price * 1.001 if quantity &gt; 0 else security.bid_price * 0.999&#10;# 提交止损市价卖单，并用标签记录原因；stop_price 需事先定义。&#10;self.stop_market_order(symbol, quantity, stop_price)</code></pre>
<pre><code class="language-csharp">// 中文注释版：仅补充解释，保留原示例的执行语句。&#10;var security = Securities[symbol];&#10;// Buy stop above the ask, sell stop below the bid&#10;var stopPrice = quantity &gt; 0 ? security.AskPrice * 1.001m : security.BidPrice * 0.999m;&#10;StopMarketOrder(symbol, quantity, stopPrice);</code></pre>
</div>
</td>
</tr>
<tr>
<td>
<div class="error-messages">Name = Position_Sys_0001,Description = This order may result in an oversold/overbought position in your account. Please check your position quantity and/or open orders.</div>
</td>
<td>
                Schwab thinks the order quantity plus your existing open orders exceeds your current position (oversold) or buying power (overbought). It commonly appears when you call <code>Liquidate</code>/<code>liquidate</code>, which cancels your open orders and submits a market order to close the position at the same time. Because Schwab hasn't confirmed the cancellation yet, it still counts the resting order and sees the closing order as doubling your exposure. For example, on a short of 82 shares, <code>liquidate</code> cancels a resting buy-82 stop (still <span class="menu-name">CancelPending</span>) and submits a new market buy-82 to cover, so Schwab sees 164 shares of buying against an 82-share short and flags the order as overbought by 82. Cancel the open orders first, give Schwab about one minute to process the cancellations, and then liquidate:
                <div class="section-example-container">
<pre><code class="language-python"># 中文注释版：仅补充解释，保留原示例的执行语句。&#10;all_cancelled_orders = self.transactions.cancel_open_orders()&#10;# Wait ~1 minute for Schwab to process the cancellations, then:&#10;# 请求平仓；实际成交仍取决于市场和券商。&#10;self.liquidate()</code></pre>
<pre><code class="language-csharp">// 中文注释版：仅补充解释，保留原示例的执行语句。&#10;var allCancelledOrders = Transactions.CancelOpenOrders();&#10;// Wait ~1 minute for Schwab to process the cancellations, then:&#10;// 请求平仓；实际成交仍取决于市场和券商。&#10;Liquidate();</code></pre>
</div>
</td>
</tr>
</tbody>
</table>
<p>以下警告本身不会拒单，常伴随其他错误；应检查上文对应错误确定实际原因。</p>
<table class="table qc-table">
<thead>
<tr>
<th>警告消息（保留英文）</th>
<th>含义</th>
</tr>
</thead>
<tbody>
<tr>
<td>
<div class="error-messages">Name = Easy_To_Borrow_GTC,Description = This security is currently easy to borrow, good until canceled orders may be subjected to changes in status to hard to borrow resulting in your order being canceled.</div>
</td>
<td>当前易借的股票，日后若变成难借，其撤销前有效的卖空单可能被取消。</td>
</tr>
<tr>
<td>
<div class="error-messages">Name = ETB_WARNING,Description = Please note: although this security is considered easy to borrow at this time, conditions may change including share availability and possible fees associated with hard to borrow securities.</div>
</td>
<td>当前虽易借，但可借股数和借券费用可能变化。</td>
</tr>
<tr>
<td>
<div class="error-messages">Name = PRICES_CAN_CHANGE_QUICKLY,Description = With market orders, prices can change quickly in fast market conditions resulting in execution prices that can be different from the quotes displayed at order entry.</div>
</td>
<td>快速行情中，市价单成交价可能不同于下单时显示的报价。</td>
</tr>
<tr>
<td>
<div class="error-messages">Name = SCHW_DO0989,Description = Please note that when a Stop order triggers it becomes a Market order. Because of this and depending on market conditions, this order may execute at a price significantly different than the Stop price.</div>
</td>
<td>止损单触发后变为市价单，成交价可能显著偏离止损价。</td>
</tr>
<tr>
<td>
<div class="error-messages">Name = STOP_ORDERS_NO_GUARANTEE,Description = With stop orders, there is no guarantee that the execution price will be equal to or near the activation price.</div>
</td>
<td>不能保证止损单在触发价或其附近成交。</td>
</tr>
</tbody>
</table>
<p>仍需支持时新建工单并附出错部署。（原文 ticker 为 ticket 的笔误。）</p>

