# dYdX

非官方中文翻译，按原文小节排列；专有名词、按钮、错误消息和代码字段保留英文对照。费用、IP、权限及产品范围为所标源码版本的记录。各节保留官方链接，代码保留执行语句并添加中文注释。

## 简介 · 01 Introduction


<p>QuantConnect 支持使用实时行情运行实盘模式的算法。</p>
<p>dYdX 由加州创业者、曾任 Coinbase/Uber 工程师的 Antonio Juliano 于 2017 年 7 月创立，最初提供加密保证金、借贷服务。它是去中心化、无需许可的协议，未向政府注册为经纪商或交易商，不面向美国或其他受限用户；使用须遵守其 Software Terms of Use。</p>
<p>实现见 LEAN 对应仓库。原文提示：使用 DYDX 风险由用户自行承担，资产不获任何政府或其他方担保。</p>


## 账户类型 · 02 Account Types

<p>dYdX 支持保证金账户，算法设置见模型文档。</p>
<h4>创建账户</h4>
<p>在 dYdX 官网点击 Sign In。</p>
<p>开户后进入 More &gt; API Trading Keys，点击 Generated New API Key，妥善保存，再点击 Authorize API Key。</p>
<h4>模拟交易</h4>
<p>在 dYdX Testnet 官网点击 Sign In，按上述流程创建独立模拟密钥。</p>


## 资产类别 · 04 Asset Classes

<p>本集成支持加密期货。</p>


## 数据源 · 05 Data Providers

<p>QuantConnect 数据源提供实时加密期货行情。</p>

## 订单 · 06 Orders

<p>平台对 dYdX API 的订单类型、属性和更新进行建模；实盘部署后也可通过 IDE 手动下单。</p>
<h4>订单类型</h4>
<p>下表列出本集成对各资产支持的订单类型：</p>
<table class="qc-table table">
<thead>
<tr>
<th style="width: 50%">订单类型</th>
<th>加密期货</th>
</tr>
</thead>
<tbody>
<tr>
<td>市价单（Market）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>限价单（Limit）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>止损市价单（Stop market）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>止损限价单（Stop limit）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
</tbody>
</table>

<h4>订单属性</h4>
<p>下表为 dYdX API 的自定义订单属性，可用 dYdXOrderProperties 设置。</p>
<table class="table qc-table">
<thead>
<tr>
<th>属性</th>
<th>数据类型</th>
<th>说明</th>
<th>默认值</th>
</tr>
</thead>
<tbody>
<tr>
<td><code class="csharp">TimeInForce</code><code class="python">time_in_force</code></td>
<td><code>TimeInForce</code></td>
<td>
             A <a href="https://www.quantconnect.com/docs/v2/writing-algorithms/trading-and-orders/order-properties#03-Time-In-Force">TimeInForce</a>为订单设置有效期，支持以下取值：<ul>
<li>当日有效（Day / DAY）</li>
<li>GoodTilCanceled / GOOD_TIL_CANCELED（注 1）</li>
<li>指定日期前有效（GoodTilDate / good_til_date）</li>
</ul>
</td>
<td><code class="csharp">TimeInForce.GoodTilCanceled</code><code class="python">TimeInForce.GOOD_TIL_CANCELED</code></td>
</tr>
<tr>
<td><code class="csharp">GasLimit</code><code class="python">gas_limit</code></td>
<td><code class="csharp">ulong</code><code class="python">int</code></td>
<td>订单最多可使用的 gas 数量。</td>
<td>1_000_000</td>
</tr>
<tr>
<td><code class="csharp">GoodTilBlockOffset</code><code class="python">good_til_block_offset</code></td>
<td><code class="csharp">ulong</code><code class="python">int</code></td>
<td>订单失效时的区块高度。</td>
<td>20</td>
</tr>
<tr>
<td>立即成交否则取消（IOC，注 2）</td>
<td><code>bool</code></td>
<td>要求只以 maker 挂单；新 post-only 订单若会与已有 maker 成交，验证者会取消该单。</td>
<td><code class="csharp">false</code><code class="python">False</code></td>
</tr>
<tr>
<td>PostOnly / post_only（注 2）</td>
<td><code>bool</code></td>
<td>仅限限价单：只提供流动性；若任何部分会吃单，整单拒绝且不部分成交。</td>
<td><code class="csharp">false</code><code class="python">False</code></td>
</tr>
<tr>
<td><code class="csharp">ReduceOnly</code><code class="python">reduce_only</code></td>
<td><code>bool</code></td>
<td>只允许减少当前仓位的标志，详见券商 Reduce-Only Order。</td>
<td><code class="csharp">false</code><code class="python">False</code></td>
</tr>
</tbody>
</table>
<p>注 1：GTC 并非永久有效，这里的订单在 90 天后过期。</p>
<p>注 2：PostOnly 和 IOC 互斥，同一时刻只能启用一种执行方式。</p>
<h4>更新订单</h4>
<p>不支持直接改单，可先撤销再按新参数重下，见对应替代方案。</p>

## 手续费 · 07 Fees

<p>dYdX 费用见官网 Fees，平台模型也见 Fees。</p>

## 保证金 · 08 Margin

<p>平台模拟购买力和追加保证金，帮助算法遵守保证金要求。</p>


## 滑点 · 09 Slippage

<p>dYdX 回测不计滑点；dYdX 模拟与实盘订单可能产生滑点。</p>
<p>dYdX 滑点模型见 Slippage。</p>

## 成交 · 10 Fills

<p>订单加入链上区块后才会成交。</p>
<p>dYdX 成交模型见 Fills。</p>

## 结算 · 11 Settlements

<p>交易后立即结算。</p>
<p>dYdX 结算模型见 Settlement。</p>


## 安全与稳定性 · 12 Security and Stability

<p>本集成的安全与稳定性说明如下。</p>
<h4>账户凭据</h4>
<p>通过 dYdX 部署时，平台不保存登录凭据。</p>
<h4>API 服务中断</h4>
<p>实盘订单通过 dYdX API 提交，API 有时可能中断；可在其状态页查看服务情况。</p>


## 入金与出金 · 13 Deposits and Withdrawals

<p>运行期间可向关联的 dYdX 账户出入金；每天美东时间 7:45 同步现金余额。</p>


## 演示算法 · 14 Demo Algorithm

<p>以下算法演示本集成功能：</p>
<div class="section-example-container testable">
<pre><code class="language-csharp">// 中文注释版：仅补充解释，保留原示例的执行语句。&#10;// Demonstrate dYdX brokerage functionality with an EMA crossover strategy.&#10;public class DydxDemoAlgorithm : QCAlgorithm&#10;{&#10;    private Symbol _symbol;&#10;    private ExponentialMovingAverage _fast;&#10;    private ExponentialMovingAverage _slow;&#10;&#10;    public override void Initialize()&#10;    {&#10;        // 设置回测开始日期；实盘运行不以此恢复历史状态。&#10;        SetStartDate(2024, 9, 1);&#10;        // 设置回测结束日期。&#10;        SetEndDate(2024, 12, 31);&#10;        // 设置回测初始现金；实盘资金以券商账户和部署配置为准。&#10;        SetCash(100000);&#10;        // 设置券商模型和账户类型，决定资产、订单及现实约束。&#10;        SetBrokerageModel(BrokerageName.DYDX, AccountType.Margin);&#10;        // 订阅加密期货，注意保证金和资金费用。&#10;        _symbol = AddCryptoFuture("BTCUSD", Resolution.Daily, Market.DYDX).Symbol;&#10;        // 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        _fast = EMA(_symbol, 10, Resolution.Daily);&#10;        // 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        _slow = EMA(_symbol, 50, Resolution.Daily);&#10;    }&#10;&#10;    public override void OnData(Slice slice)&#10;    {&#10;        // 指标准备好后才使用信号，历史样本不足时退出。&#10;        if (!_slow.IsReady) return;&#10;        if (_fast &gt; _slow &amp;&amp; !Portfolio.Invested)&#10;            // 按目标权重调整仓位；1 表示账户权益的 100%，不是买入 1 股。&#10;            SetHoldings(_symbol, 1);&#10;        else if (_fast &lt; _slow &amp;&amp; Portfolio.Invested)&#10;            // 请求平仓；实际成交仍取决于市场和券商。&#10;            Liquidate();&#10;    }&#10;}</code></pre>
<pre><code class="language-python"># 中文注释版：仅补充解释，保留原示例的执行语句。&#10;# Demonstrate dYdX brokerage functionality with an EMA crossover strategy.&#10;# 定义继承 QCAlgorithm 的策略类，由 LEAN 管理其生命周期。&#10;class DydxDemoAlgorithm(QCAlgorithm):&#10;    # 初始化只在算法开始时运行一次，设置回测条件和数据订阅。&#10;    def initialize(self) -&gt; None:&#10;        # 设置历史回测的开始日期。&#10;        # 设置回测开始日期；实盘运行不以此恢复历史状态。&#10;        self.set_start_date(2024, 9, 1)&#10;        # 设置历史回测的结束日期。&#10;        # 设置回测结束日期。&#10;        self.set_end_date(2024, 12, 31)&#10;        # 设置回测初始资金为 100,000 单位账户货币。&#10;        # 设置回测初始现金；实盘资金以券商账户和部署配置为准。&#10;        self.set_cash(100000)&#10;        # 设置券商模型和账户类型，决定资产、订单及现实约束。&#10;        self.set_brokerage_model(BrokerageName.DYDX, AccountType.MARGIN)&#10;        # 订阅加密期货，注意保证金和资金费用。&#10;        self._symbol = self.add_crypto_future("BTCUSD", Resolution.DAILY, Market.DYDX).symbol&#10;        # 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        self._fast = self.ema(self._symbol, 10, Resolution.DAILY)&#10;        # 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        self._slow = self.ema(self._symbol, 50, Resolution.DAILY)&#10;&#10;    # 行情到达时执行；data 包含该时间片可用的数据。&#10;    def on_data(self, slice: Slice) -&gt; None:&#10;        # 指标准备好后才使用信号，历史样本不足时退出。&#10;        if not self._slow.is_ready:&#10;            return&#10;        if self._fast.current.value &gt; self._slow.current.value and not self.portfolio.invested:&#10;            # 按目标权重调整仓位；1 表示账户权益的 100%，不是买入 1 股。&#10;            self.set_holdings(self._symbol, 1)&#10;        elif self._fast.current.value &lt; self._slow.current.value and self.portfolio.invested:&#10;            # 请求平仓；实际成交仍取决于市场和券商。&#10;            self.liquidate()</code></pre>
</div>

## 部署算法 · 15 Deploy Live Algorithms

<p>dYdX 是去中心化、无需许可的协议，并非券商；QuantConnect 为简化界面将其列在券商选项中。</p>
<p>每个实盘算法必须有一个可用实盘节点。</p>
<p>按以下步骤部署实盘算法：</p>
<ol>
<li>打开要部署的项目。</li>
<li>点击 Deploy Live（部署实盘）图标。<img alt="Lightning icon" class="inline-icon" src="https://cdn.quantconnect.com/i/tu/deploy-live-icon.png"/></li>
<li>在 Deploy Live 页面点击 Brokerage，选择 dYdX Exchange。</li>
<li>输入 API private key、钱包地址与子账户号码。</li><p>凭据生成步骤见 Account Types 的 Create an Account；QuantConnect 不保存这些凭据。</p> <li>在 Region 区域选择算法运行地区。</li>
<li>点击 Node 字段，选择要使用的实盘节点。</li>
<li>可选：在 Data Provider 区域点击 Show，修改数据源或添加其他数据源。</li>
<li>可选：配置通知。</li>
<li>配置 Automatically restart algorithm（自动重启算法）选项。</li>
<p>开启自动重启后，平台会尽力重启因运行错误而失败的算法，有助于应对券商 API 暂时断线等故障。</p>
<li>点击 Deploy（部署）。</li>
</ol>
<p>部署最多可能需要 5 分钟，完成后显示实盘结果页。可核对运行统计中的权益、现金账簿和持仓，确认券商原有持仓正确载入。</p>
<p>重启、自动重启和重新部署都不会保存算法全部内部状态。恢复哪些状态、其余状态如何持久化，见 State Persistence。</p>


## 部署详情 · 16 Deployment Details

<p>部署 dYdX 算法时，券商提供交易账户等详情，可区分并行部署和核对目标账户；这些详情不包含凭据。</p>
<p>下表列出 dYdX 提供的部署详情：</p>
<table class="qc-table table">
<thead>
<tr>
<th>键名</th>
<th>说明</th>
</tr>
</thead>
<tbody>
<tr>
<td><code>dydx-address</code></td>
<td>接收订单的钱包地址。</td>
</tr>
<tr>
<td><code>dydx-chain-id</code></td>
<td>账户链：真实资金用 dydx-mainnet-1，测试网用 dydx-testnet-4。</td>
</tr>
<tr>
<td><code>dydx-subaccount-number</code></td>
<td>接收订单的钱包子账户。</td>
</tr>
</tbody>
</table>
<p>算法的 DeploymentDetails/deployment_details 是只读字典，LEAN 在调用 Initialize/initialize 之前填充，因此在算法任何位置都可读取。</p>
<div class="section-example-container">
<pre><code class="language-csharp">// 中文注释版：仅补充解释，保留原示例的执行语句。&#10;// 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;var deploymentDetails = DeploymentDetails.Select(kvp =&gt; $"{kvp.Key}:{kvp.Value}");&#10;Log($"deploymentDetails: {string.Join(", ", deploymentDetails)}");</code></pre>
<pre><code class="language-python"># 中文注释版：仅补充解释，保留原示例的执行语句。&#10;# 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;deployment_details = [f'{kvp.key}:{kvp.value}' for kvp in self.deployment_details]&#10;# 记录常规运行信息，消息写入日志并计入日志额度。&#10;# 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;self.log(f'deployment_details: {deployment_details}')</code></pre>
</div>
<p>也可在算法外通过 /live/read 响应的 deploymentDetails 读取详情。</p>

