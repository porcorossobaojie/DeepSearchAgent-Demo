# Bloomberg FIX

非官方中文翻译，按原文小节排列；专有名词、按钮、错误消息和代码字段保留英文对照。费用、IP、权限及产品范围为所标源码版本的记录。各节保留官方链接，代码保留执行语句并添加中文注释。

## 简介 · 01 Introduction

<p>QuantConnect 支持使用实时行情运行实盘模式的算法。</p>
<p>Bloomberg FIX 通过 FIX 协议直接把订单路由至 Bloomberg 网络，不提供行情；它是独立附加组件，不代表 Bloomberg 关联或背书。</p>
<p>此连接与使用 SAPI 接入 EMSX 的 Terminal Link 不同：它连接 FixNet HUB，不适用 SAPI 配置步骤。两者资产范围相同，但订单类型、改单支持及账户类型不同。</p>
<p>需加入 Institution 套餐组织才能使用 Bloomberg FIX。</p>
<p>该连接的建模方式见 Bloomberg FIX 券商模型文档。</p>


## 账户类型 · 02 Account Types

<p>Bloomberg FIX 支持保证金账户，路由至 FIX 会话配置的主经纪商；部署时在向导设置购买力。算法账户设置见 Bloomberg FIX 模型文档。</p>
<h4>创建账户</h4>
<p>需要 Bloomberg Terminal 和 FIX entitlement，配置步骤如下：</p>
<ol>
<li>安装 Bloomberg Terminal。</li>
<li>请 Bloomberg Support 为订单路由开通 FIX 会话。</li>
<li>向其索取会话 CompID。</li>
<p>妥善保存，实盘部署时需要。</p>
<li>联系目标主经纪商，确认必需 FIX tag。</li>
</ol>
<h4>模拟交易</h4>
<p>此 FIX 连接不提供原生模拟，可用 QuantConnect 按以下步骤模拟：</p>
<ol>
<li>在 Initialize/initialize 中设置 Bloomberg FIX 券商模型。</li>
<li>使用 QuantConnect Paper Trading 券商部署算法。</li>
</ol>


## 资产类别 · 04 Asset Classes

<p>Bloomberg FIX 集成支持以下资产：</p>
<ul>
<li>美国股票</li>
<li>股票期权</li>
<li>指数期权</li>
<li>期货</li>
</ul>


## 数据源 · 05 Data Providers

<p>Bloomberg FIX 只路由订单、不提供行情。推荐免费的 QuantConnect 数据源，覆盖美国股票、股票期权、指数期权、期货及 SPX/VIX 指数，详见 Datasets。</p>


## 订单 · 06 Orders

<p>Bloomberg FIX 支持对应订单类型及改单；实盘也可通过 IDE 手动下单。</p>
<h4>订单类型</h4>
<p>下表为本集成对各资产支持的订单类型：</p>
<table class="qc-table table">
<thead>
<tr>
<th>订单类型</th>
<th>股票</th>
<th>股票期权</th>
<th>指数期权</th>
<th>期货</th>
</tr>
</thead>
<tbody>
<tr>
<td>市价单（Market）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>开盘市价单（Market on open）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td></td>
</tr>
<tr>
<td>收盘市价单（Market on close）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>限价单（Limit）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>止损市价单（Stop market）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>止损限价单（Stop limit）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
</tbody>
</table>

<p>期货不支持开盘市价单，提交会被判为无效。</p>
<h4>更新订单</h4>
<p>FixNet HUB 接受 cancel/replace（FIX 35=G），可更新挂单的数量、限价、止损价、订单类型和有效期。</p>
<h4>订单属性</h4>
<p>BloombergFixOrderProperties 继承各 FIX 连接共用的 FixOrderProperties；下表列出自定义订单执行属性。</p>
<table class="table qc-table">
<thead>
<tr>
<th style="width: 18%">属性</th>
<th style="width: 17%">数据类型</th>
<th style="width: 45%">说明</th>
<th style="width: 20%">默认值</th>
</tr>
</thead>
<tbody>
<tr>
<td><code class="csharp">TimeInForce</code><code class="python">time_in_force</code></td>
<td><code>TimeInForce</code></td>
<td>应用于订单的 TimeInForce 有效期设置。</td>
<td><code class="csharp">TimeInForce.GoodTilCanceled</code><code class="python">TimeInForce.GOOD_TIL_CANCELED</code></td>
</tr>
<tr>
<td><code class="csharp">HandleInstruction</code><code class="python">handle_instruction</code></td>
<td><code class="csharp">char?</code><code class="python">str/NoneType</code></td>
<td>交易场内订单处理指令，支持以下取值：<ul>
<li>FixOrderProperties.AutomatedExecutionOrderPrivate / AUTOMATED_EXECUTION_ORDER_PRIVATE：私有自动执行，不允许经纪商干预。</li>
<li>FixOrderProperties.AutomatedExecutionOrderPublic / AUTOMATED_EXECUTION_ORDER_PUBLIC：公开自动执行，允许经纪商干预。</li>
<li>FixOrderProperties.ManualOrder / MANUAL_ORDER：暂存人工订单，需要经纪商介入。</li>
</ul>
</td>
<td></td>
</tr>
<tr>
<td><code class="csharp">Notes</code><code class="python">notes</code></td>
<td><code class="csharp">string</code><code class="python">str</code></td>
<td>可发送给经纪商的自由格式文字指令。</td>
<td></td>
</tr>
<tr>
<td><code class="csharp">LocateBroker</code><code class="python">locate_broker</code></td>
<td><code class="csharp">string</code><code class="python">str</code></td>
<td>卖空股票的借券经纪商，对应 LocateBroker，FIX tag 5700。</td>
<td></td>
</tr>
<tr>
<td><code class="csharp">LocateReqd</code><code class="python">locate_reqd</code></td>
<td><code class="csharp">string</code><code class="python">str</code></td>
<td>是否需要 locate，取 Y/N，对应 FIX tag 114。</td>
<td></td>
</tr>
<tr>
<td><code class="csharp">AutomaticPositionSides</code><code class="python">automatic_position_sides</code></td>
<td><code class="csharp">bool</code><code class="python">bool</code></td>
<td>是否根据当前持仓自动判断开平仓方向；禁用时只发送普通买卖，不发送 FIX tag 77。</td>
<td><code class="csharp">true</code><code class="python">True</code></td>
</tr>
<tr>
<td><code class="csharp">PositionSide</code><code class="python">position_side</code></td>
<td><code class="csharp">OrderPosition?</code><code class="python">OrderPosition/NoneType</code></td>
<td>显式指定开平仓方向的 OrderPosition，优先于根据持仓自动判断的 AutomaticPositionSides/automatic_position_sides。</td>
<td></td>
</tr>
<tr>
<td><code class="csharp">AdditionalProperties</code><code class="python">additional_properties</code></td>
<td><code class="csharp">BaseExtendedDictionary&lt;string, string&gt;</code><code class="python">BaseExtendedDictionary[str, str]</code></td>
<td>额外 FIX tag 字典，键为 tag 号码、值为内容。</td>
<td>空字典</td>
</tr>
</tbody>
</table>

<p>开平仓方向同时设置 FIX Side（54）和 OpenClose（77），对应关系如下：</p>
<table class="table qc-table">
<thead>
<tr>
<th>开平仓方向</th>
<th>Tag 54</th>
<th>Tag 77</th>
</tr>
</thead>
<tbody>
<tr>
<td><code class="csharp">OrderPosition.BuyToOpen</code><code class="python">OrderPosition.BUY_TO_OPEN</code></td>
<td>1（买入）</td>
<td>O（开仓）</td>
</tr>
<tr>
<td><code class="csharp">OrderPosition.BuyToClose</code><code class="python">OrderPosition.BUY_TO_CLOSE</code></td>
<td>1（买入）</td>
<td>C（平仓）</td>
</tr>
<tr>
<td><code class="csharp">OrderPosition.SellToOpen</code><code class="python">OrderPosition.SELL_TO_OPEN</code></td>
<td>5（卖空）</td>
<td>O（开仓）</td>
</tr>
<tr>
<td><code class="csharp">OrderPosition.SellToClose</code><code class="python">OrderPosition.SELL_TO_CLOSE</code></td>
<td>2（卖出）</td>
<td>C（平仓）</td>
</tr>
</tbody>
</table>
<p>买入平空与买入开多均为 54=1，靠 tag 77 区分。改单和撤单沿用原订单 tag 值；若不按当前持仓自动判断，可设置 PositionSide/position_side。</p>
<p>FIX 对手方可能要求额外 tag，可添加到 AdditionalProperties/additional_properties。例如代码用 9301 标记 DMA 直接市场接入。</p>
<p class="python">字典初始为空，不能用普通 Python dict 整体替换；批量添加用 update，全部删除用 clear。</p>
<h4>拆股处理</h4>
<p>使用原始价格（Raw）时，如果美国股票拆股，尚未成交订单中的以下属性会自动按拆股比例调整：</p>
<ul>
<li>数量</li>
<li>限价</li>
<li>止损价</li>
<li>触发价</li>
</ul>

## 手续费 · 07 Fees

<p>Bloomberg FIX 路由订单按目标主经纪商收费；平台费用模型见 Fees。</p>


## 保证金 · 08 Margin

<p>部署 Bloomberg FIX 时在向导填写现金和持仓，平台据此模拟购买力及追加保证金。</p>


## 成交 · 09 Fills

<p>LEAN 通过 FIX 会话路由至目标主经纪商，再接收成交结果。</p>
<p>Bloomberg FIX 成交模型见 Fills。</p>


## 使用许可与合规要求 · 10 Compliance

<p>Bloomberg 与 QuantConnect 无关联，也不背书此 FIX 连接。</p>
<p>以下规则适用：</p>
<ul>
<li>使用者须持有 Bloomberg Terminal 许可。</li>
<li>FIX 会话仅用于订单路由，不提供数据。</li>
<li>Bloomberg 开通 FIX 会话及接受的 CompID；只能路由至该会话覆盖的主经纪商。</li>
</ul>


## 部署算法 · 11 Deploy Live Algorithms

<p>每个实盘算法必须有一个可用实盘节点。</p>
<p>按以下步骤部署实盘算法：</p>
<ol>
<li>打开要部署的项目。</li>
<li>点击 Deploy Live（部署实盘）图标。<img alt="Lightning icon" class="inline-icon" src="https://cdn.quantconnect.com/i/tu/deploy-live-icon.png"/></li>
<li>在 Deploy Live 的 Brokerage 下拉选择 Bloomberg Fix。</li>
<li>Sender Sub ID 填 QuantConnect 用户 ID。</li>
<p>此值经 FIX tag 50 发送，让 Bloomberg 识别用户；申请 API token 后，QuantConnect 会用邮件发送用户 ID 和 token。</p>
<li>On Behalf Of Comp ID 填交易公司 CompID。</li>
<p>该值由 Bloomberg 在开通会话时分配，对应 FIX tag 115。</p>
<li>Deliver To Comp ID 填接收订单的主经纪商 CompID。</li>
<p>此值对应 FIX tag 128，不清楚时向主经纪商索取。</p>
<li>Environment 选择 Live。</li> <li>在 Region 区域选择算法运行地区。</li>
<li>点击 Node 字段，选择要使用的实盘节点。</li>
<li>可选：在 Data Provider 区域点击 Show，修改数据源或添加其他数据源。</li>
<li>账户已有现金时，按以下步骤填写（有演示视频）：</li>
<ol>
<li>在 Algorithm Cash State 点击 Show。</li>
<li>点击 Add Currency。</li>
<li>填写币种代码（如 USD/CAD）及数量。</li>
</ol>
<li>账户已有持仓时，按以下步骤填写（有演示视频）：</li>
<ol>
<li>在 Algorithm Holdings State 点击 Show。</li>
<li>点击 Add Holding。</li>
<li>填写 Symbol ID、代码、数量和平均价格。</li>
</ol>
<li>可选：配置通知。</li>
<li>配置 Automatically restart algorithm（自动重启算法）选项。</li>
<p>开启自动重启后，平台会尽力重启因运行错误而失败的算法，有助于应对券商 API 暂时断线等故障。</p>
<li>点击 Deploy（部署）。</li>
</ol>
<p>部署最多可能需要 5 分钟，完成后显示实盘结果页。可核对运行统计中的权益、现金账簿和持仓，确认券商原有持仓正确载入。</p>
<p>重启、自动重启和重新部署都不会保存算法全部内部状态。恢复哪些状态、其余状态如何持久化，见 State Persistence。</p>


## 部署详情 · 12 Deployment Details

<p>Bloomberg Fix 提供交易账户等部署详情，用于区分并行部署和核对账户，不包含凭据。</p>
<p>下表为 Bloomberg Fix 部署详情：</p>
<table class="qc-table table">
<thead>
<tr>
<th>键名</th>
<th>说明</th>
</tr>
</thead>
<tbody>
<tr>
<td><code>bloomberg-fix-sender-sub-id</code></td>
<td>会话内识别用户的 Sender Sub ID，对应 FIX tag 50。</td>
</tr>
<tr>
<td><code>bloomberg-fix-on-behalf-of-comp-id</code></td>
<td>识别交易公司的 On Behalf Of Comp ID，对应 FIX tag 115。</td>
</tr>
<tr>
<td><code>bloomberg-fix-deliver-to-comp-id</code></td>
<td>接收订单的主经纪商 Deliver To Comp ID，对应 FIX tag 128。</td>
</tr>
</tbody>
</table>
<p>算法的 DeploymentDetails/deployment_details 是只读字典，LEAN 在调用 Initialize/initialize 之前填充，因此在算法任何位置都可读取。</p>
<div class="section-example-container">
<pre><code class="language-csharp">// 中文注释版：仅补充解释，保留原示例的执行语句。&#10;// 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;var deploymentDetails = DeploymentDetails.Select(kvp =&gt; $"{kvp.Key}:{kvp.Value}");&#10;Log($"deploymentDetails: {string.Join(", ", deploymentDetails)}");</code></pre>
<pre><code class="language-python"># 中文注释版：仅补充解释，保留原示例的执行语句。&#10;# 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;deployment_details = [f'{kvp.key}:{kvp.value}' for kvp in self.deployment_details]&#10;# 记录常规运行信息，消息写入日志并计入日志额度。&#10;# 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;self.log(f'deployment_details: {deployment_details}')</code></pre>
</div>
<p>也可在算法外通过 /live/read 响应的 deploymentDetails 读取详情。</p>

