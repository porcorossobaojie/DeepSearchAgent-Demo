# FIX 连接

非官方中文翻译，按原文小节排列；专有名词、按钮、错误消息和代码字段保留英文对照。费用、IP、权限及产品范围为所标源码版本的记录。各节保留官方链接，代码保留执行语句并添加中文注释。

## 简介 · 01 Introduction

<p>FIX 是前台交易消息的标准电子通信协议，社区包括约 300 家机构及主要投行。</p>

## 支持的连接 · 02 Supported Connections

<p>QuantConnect 提供以下 FIX 连接：</p>
<table class="qc-table table">
<thead>
<tr>
<th>名称</th>
<th>集成实现</th>
<th>模型实现</th>
</tr>
</thead>
<tbody>
<tr>
<td><a href="https://www.quantconnect.com/docs/v2/cloud-platform/live-trading/brokerages/bloomberg-fix">Bloomberg</a></td>
<td>Lean.Brokerages.Fix.Bloomberg</td>
<td><a href="https://github.com/QuantConnect/Lean/blob/master/Common/Brokerages/BloombergFixBrokerageModel.cs" rel="nofollow" target="_blank">BloombergFixBrokerageModel.cs</a></td>
</tr>
<tr>
<td>Raiffeisen Bank International</td>
<td><a href="https://github.com/QuantConnect/Lean.Brokerages.RaiffeisenBankInternational" rel="nofollow" target="_blank">Lean.Brokerages.RaiffeisenBankInternational</a></td>
<td><a href="https://github.com/QuantConnect/Lean/blob/master/Common/Brokerages/RBIBrokerageModel.cs" rel="nofollow" target="_blank">RBIBrokerageModel.cs</a></td>
</tr>
<tr>
<td><a href="https://www.quantconnect.com/docs/v2/cloud-platform/live-trading/brokerages/wolverine">Wolverine</a></td>
<td><a href="https://github.com/QuantConnect/Lean.Brokerages.Wolverine" rel="nofollow" target="_blank">Lean.Brokerages.Wolverine</a></td>
<td><a href="https://github.com/QuantConnect/Lean/blob/master/Common/Brokerages/WolverineBrokerageModel.cs" rel="nofollow" target="_blank">WolverineBrokerageModel.cs</a></td>
</tr>
</tbody>
</table>


## 订单属性 · 03 Order Properties

<p>FIX 连接支持自定义订单属性，下表为 FixOrderProperties 可设置的字段。</p>
<table class="table qc-table">
<thead>
<tr>
<th style="width: 18%">属性</th>
<th style="width: 17%">数据类型</th>
<th style="width: 45%">说明</th>
<th style="width: 20%">默认值</th>
</tr>
</thead>
<tbody>
<tr>
<td><code class="csharp">TimeInForce</code><code class="python">time_in_force</code></td>
<td><code>TimeInForce</code></td>
<td>应用于订单的 TimeInForce 有效期设置。</td>
<td><code class="csharp">TimeInForce.GoodTilCanceled</code><code class="python">TimeInForce.GOOD_TIL_CANCELED</code></td>
</tr>
<tr>
<td><code class="csharp">HandleInstruction</code><code class="python">handle_instruction</code></td>
<td><code class="csharp">char?</code><code class="python">str/NoneType</code></td>
<td>交易场内订单处理指令，支持以下取值：<ul>
<li>FixOrderProperties.AutomatedExecutionOrderPrivate / AUTOMATED_EXECUTION_ORDER_PRIVATE：私有自动执行，不允许经纪商干预。</li>
<li>FixOrderProperties.AutomatedExecutionOrderPublic / AUTOMATED_EXECUTION_ORDER_PUBLIC：公开自动执行，允许经纪商干预。</li>
<li>FixOrderProperties.ManualOrder / MANUAL_ORDER：暂存人工订单，需要经纪商介入。</li>
</ul>
</td>
<td></td>
</tr>
<tr>
<td><code class="csharp">Notes</code><code class="python">notes</code></td>
<td><code class="csharp">string</code><code class="python">str</code></td>
<td>可发送给经纪商的自由格式文字指令。</td>
<td></td>
</tr>
<tr>
<td><code class="csharp">AdditionalProperties</code><code class="python">additional_properties</code></td>
<td><code class="csharp">BaseExtendedDictionary&lt;string, string&gt;</code><code class="python">BaseExtendedDictionary[str, str]</code></td>
<td>额外 FIX tag 字典，键为 tag 号码、值为内容。</td>
<td>空字典</td>
</tr>
</tbody>
</table>

<p>每个 FIX 连接都有继承自 FixOrderProperties 的属性类，例如 Bloomberg FIX 提供 BloombergFixOrderProperties。</p>
<p>某些对手方需要额外 FIX tag，例如连接背后经纪商要求 9301=1 表示 DMA。可通过 AdditionalProperties/additional_properties 添加。</p>
<div class="section-example-container">
<pre><code class="language-csharp">// 中文注释版：仅补充解释，保留原示例的执行语句。&#10;public override void Initialize()&#10;{&#10;    // Set the default order properties to mark orders as direct market access (DMA)&#10;    var orderProperties = new BloombergFixOrderProperties();&#10;    // 设置额外 EMSX/FIX 字段，键名和字段值不能翻译。&#10;    orderProperties.AdditionalProperties["9301"] = "1";&#10;    // 将该属性对象设为后续订单的默认属性。&#10;    DefaultOrderProperties = orderProperties;&#10;}</code></pre>
<pre><code class="language-python"># 中文注释版：仅补充解释，保留原示例的执行语句。&#10;# 初始化只在算法开始时运行一次，设置回测条件和数据订阅。&#10;def initialize(self) -&gt; None:&#10;    # Set the default order properties to mark orders as direct market access (DMA)&#10;    order_properties = BloombergFixOrderProperties()&#10;    # 设置额外 EMSX/FIX 字段，键名和字段值不能翻译。&#10;    order_properties.additional_properties["9301"] = "1"&#10;    # 将该属性对象设为后续订单的默认属性。&#10;    self.default_order_properties = order_properties</code></pre>
</div>
<p class="python">字典初始为空，不能用普通 Python dict 整体替换；批量添加用 update，全部删除用 clear。</p>


## 组合状态 · 04 Portfolio State

<p>FIX 连接不能自动读取组合状态，部署时必须填写现金与持仓。</p>
<p>账户已有现金时，按以下步骤填写（有演示视频）：</p>
<ol>
<li>在 Algorithm Cash State 点击 Show。</li>
<li>点击 Add Currency。</li>
<li>填写币种代码（如 USD/CAD）及数量。</li>
</ol>
<p>账户已有持仓时，按以下步骤填写（有演示视频）：</p>
<ol>
<li>在 Algorithm Holdings State 点击 Show。</li>
<li>点击 Add Holding。</li>
<li>填写 Symbol ID、代码、数量和平均价格。</li>
</ol>
