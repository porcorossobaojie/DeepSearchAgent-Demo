# Tradier

非官方中文翻译，按原文小节排列；专有名词、按钮、错误消息和代码字段保留英文对照。费用、IP、权限及产品范围为所标源码版本的记录。各节保留官方链接，代码保留执行语句并添加中文注释。

## 简介 · 01 Introduction

<p>QuantConnect 支持使用实时行情运行实盘模式的算法。</p>
<p>Tradier 由 Dan Raju、Peter Laptewicz、Jason Barry、Jeyashree Chidambaram 和 Steve Agalloco 于 2012 年创立，目标是提供低成本、高价值经纪服务。原文称覆盖 250 多个国家和地区，提供股票与期权，现金账户无最低入金；并为注册顾问提供托管、清算、执行与计费。</p>
<p>集成实现见 Lean.Brokerages.Tradier 仓库。</p>

## 账户类型 · 02 Account Types

<p>Tradier 支持现金和保证金账户；算法设置方式见对应券商模型文档。</p>
<h4>创建账户</h4>
<p>按 Tradier 官网开户向导开立账户。</p>
<p>部署需账户 ID 和 access token，在官网 Settings &gt; API Access 获取；账户 ID 是下拉字段中的字母数字代码。</p>
<h4>模拟交易</h4>
<p>Tradier 模拟交易有以下限制：</p>
<ul>
<li>不提供账户活动，因为该信息来自其清算公司。</li>
<li>因交易所对延迟行情的限制，不提供流式行情。</li>
</ul>
<p>模拟账户号码和 token 位于 API Access 页下方 Sandbox Account Access (Paper Trading)。</p>
<p>股票可用 QuantConnect 实时数据；期权须用 Tradier 延迟数据；两者都交易时组合使用。Demo 环境的 Tradier 无流式行情，应改用 QuantConnect 数据源。（此段为原文数据源规则，使用前仍应核对当前提供商支持范围。）</p>


## 资产类别 · 04 Asset Classes

<p>本集成支持美国股票和股票期权。</p><p>Tradier 资产权限因所在地及账户而异，例如欧盟居民不能交易美国 ETF。请核对当地规定，必要时调整券商账户权限。</p>

## 数据源 · 05 Data Providers

<p>推荐免费的 QuantConnect 数据源，覆盖美国股票和股票期权。若用 Tradier 自有报价，可能需购买其行情订阅，详见 Datasets。</p>


## 订单 · 06 Orders

<p>支持多种订单和 TimeInForce，部分支持改单，不支持盘外交易；实盘可通过 IDE 手动下单。</p>
<h4>订单类型</h4>
<p>下表列出本集成对各资产支持的订单类型：</p>
<table class="qc-table table">
<thead>
<tr>
<th style="width: 50%">订单类型</th>
<th style="width: 25%">股票</th>
<th style="width: 25%">股票期权</th>
</tr>
</thead>
<tbody>
<tr>
<td>市价单（Market）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>限价单（Limit）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>止损市价单（Stop market）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>止损限价单（Stop limit）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
</tbody>
</table>

<h4>订单属性</h4>
<p>可通过 TradierOrderProperties 对象自定义 Tradier 订单执行属性，见下表。</p>
<table class="table qc-table">
<thead>
<tr>
<th>属性</th>
<th>数据类型</th>
<th>说明</th>
<th>默认值</th>
</tr>
</thead>
<tbody>
<tr>
<td><code class="csharp">TimeInForce</code><code class="python">time_in_force</code></td>
<td><code>TimeInForce</code></td>
<td>A <a href="https://www.quantconnect.com/docs/v2/writing-algorithms/trading-and-orders/order-properties#03-Time-In-Force">TimeInForce</a>为订单设置有效期，支持以下取值：<ul>
<li>当日有效（Day / DAY）</li>
<li><code class="csharp">GoodTilCanceled</code><code class="python">GOOD_TIL_CANCELED</code></li>
<li>指定日期前有效（GoodTilDate / good_til_date）</li>
</ul>
</td>
<td><code class="csharp">TimeInForce.GoodTilCanceled</code><code class="python">TimeInForce.GOOD_TIL_CANCELED</code></td>
</tr>
<tr>
<td><code class="csharp">OutsideRegularTradingHours</code><code class="python">outside_regular_trading_hours</code></td>
<td><code>bool</code></td>
<td>是否允许订单在常规交易时段外触发和成交。</td>
<td><code class="csharp">false</code><code class="python">False</code></td>
</tr>
</tbody>
</table>
<h4>更新订单</h4>
<p>大多数订单字段可更新；修改数量需先撤单再重下，详见不支持更新的券商替代方案。</p>
<h4>延长交易时段</h4>
<p>Tradier 不支持盘外交易；常规交易时段外下单会等到开盘后处理。</p>
<h4>自动撤单</h4>
<p>证券反向拆股时，Tradier 会自动取消其挂单。</p>
<h4>错误处理</h4>
<p>订单错误码见 Tradier 的 Error Responses。</p>


## 手续费 · 07 Fees

<p>Tradier 费用见 Pricing，平台模型见 Fees。</p>


## 保证金 · 08 Margin

<p>平台模拟购买力和追加保证金，帮助算法遵守保证金要求。</p>


## 滑点 · 09 Slippage

<p>Tradier 回测和 QuantConnect Paper Trading 不计滑点，实盘可能产生滑点。</p>
<p>Tradier 滑点模型见 Slippage。</p>


## 成交 · 10 Fills

<p>QuantConnect 回测和 QuantConnect Paper Trading 会立即、全部成交市价单；实盘数量超过盘口可用量时按订单簿流动性成交。</p>
<p>Tradier 成交模型见 Fills。</p>


## 结算 · 11 Settlements

<p>保证金账户的交易即时结算。（原模板此处仅输出这一分支；现金账户规则应结合券商结算说明核对。）</p>
<p>Tradier 结算模型见 Settlement。</p>


## 安全与稳定性 · 12 Security and Stability

<p>本集成的安全与稳定性说明如下。</p>
<h4>账户凭据</h4>
<p>通过 Tradier 部署时，平台不保存登录凭据。</p>
<h4>API 服务中断</h4>
<p>实盘订单通过 Tradier API 提交，API 有时可能中断；可在其状态页查看服务情况。</p>


## 入金与出金 · 13 Deposits and Withdrawals

<p>算法运行时仍可给关联券商账户出入金；平台每天美东时间 7:45 同步账户现金余额。</p>


## 演示算法 · 14 Demo Algorithm

<p>以下算法演示 Tradier 的功能：</p>
<div class="section-example-container testable">
<pre><code class="language-csharp">// 中文注释版：仅补充解释，保留原示例的执行语句。&#10;// Demonstrate Tradier brokerage functionality with an EMA crossover strategy on SPY.&#10;public class TradierDemoAlgorithm : QCAlgorithm&#10;{&#10;    private ExponentialMovingAverage _fast;&#10;    private ExponentialMovingAverage _slow;&#10;&#10;    public override void Initialize()&#10;    {&#10;        // 设置回测开始日期；实盘运行不以此恢复历史状态。&#10;        SetStartDate(2024, 9, 1);&#10;        // 设置回测结束日期。&#10;        SetEndDate(2024, 12, 31);&#10;        // 设置回测初始现金；实盘资金以券商账户和部署配置为准。&#10;        SetCash(100000);&#10;        // 设置券商模型和账户类型，决定资产、订单及现实约束。&#10;        SetBrokerageModel(BrokerageName.TradierBrokerage, AccountType.Margin);&#10;        // 订阅股票行情并取得对应证券。&#10;        var symbol = AddEquity("SPY", Resolution.Daily).Symbol;&#10;        // 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        _fast = EMA(symbol, 10, Resolution.Daily);&#10;        // 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        _slow = EMA(symbol, 50, Resolution.Daily);&#10;    }&#10;&#10;    public override void OnData(Slice slice)&#10;    {&#10;        // 指标准备好后才使用信号，历史样本不足时退出。&#10;        if (!_slow.IsReady) return;&#10;        if (_fast &gt; _slow &amp;&amp; !Portfolio.Invested)&#10;            // 按目标权重调整仓位；1 表示账户权益的 100%，不是买入 1 股。&#10;            SetHoldings("SPY", 1);&#10;        else if (_fast &lt; _slow &amp;&amp; Portfolio.Invested)&#10;            // 请求平仓；实际成交仍取决于市场和券商。&#10;            Liquidate();&#10;    }&#10;}</code></pre>
<pre><code class="language-python"># 中文注释版：仅补充解释，保留原示例的执行语句。&#10;# Demonstrate Tradier brokerage functionality with an EMA crossover strategy on SPY.&#10;# 定义继承 QCAlgorithm 的策略类，由 LEAN 管理其生命周期。&#10;class TradierDemoAlgorithm(QCAlgorithm):&#10;    # 初始化只在算法开始时运行一次，设置回测条件和数据订阅。&#10;    def initialize(self) -&gt; None:&#10;        # 设置历史回测的开始日期。&#10;        # 设置回测开始日期；实盘运行不以此恢复历史状态。&#10;        self.set_start_date(2024, 9, 1)&#10;        # 设置历史回测的结束日期。&#10;        # 设置回测结束日期。&#10;        self.set_end_date(2024, 12, 31)&#10;        # 设置回测初始资金为 100,000 单位账户货币。&#10;        # 设置回测初始现金；实盘资金以券商账户和部署配置为准。&#10;        self.set_cash(100000)&#10;        # 设置券商模型和账户类型，决定资产、订单及现实约束。&#10;        self.set_brokerage_model(BrokerageName.TRADIER_BROKERAGE, AccountType.MARGIN)&#10;        # 订阅股票行情并取得对应证券。&#10;        symbol = self.add_equity("SPY", Resolution.DAILY).symbol&#10;        # 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        self._fast = self.ema(symbol, 10, Resolution.DAILY)&#10;        # 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        self._slow = self.ema(symbol, 50, Resolution.DAILY)&#10;&#10;    # 行情到达时执行；data 包含该时间片可用的数据。&#10;    def on_data(self, slice: Slice) -&gt; None:&#10;        # 指标准备好后才使用信号，历史样本不足时退出。&#10;        if not self._slow.is_ready:&#10;            return&#10;        if self._fast.current.value &gt; self._slow.current.value and not self.portfolio.invested:&#10;            # 按目标权重调整仓位；1 表示账户权益的 100%，不是买入 1 股。&#10;            self.set_holdings("SPY", 1)&#10;        elif self._fast.current.value &lt; self._slow.current.value and self.portfolio.invested:&#10;            # 请求平仓；实际成交仍取决于市场和券商。&#10;            self.liquidate()</code></pre>
</div>

## 部署算法 · 15 Deploy Live Algorithms

<p>每个实盘算法必须有一个可用实盘节点。</p>
<p>按以下步骤部署实盘算法：</p>
<ol>
<li>打开要部署的项目。</li>
<li>点击 Deploy Live（部署实盘）图标。<img alt="Lightning icon" class="inline-icon" src="https://cdn.quantconnect.com/i/tu/deploy-live-icon.png"/></li>
<li>在 Deploy Live 页面点击 Brokerage 字段，从列表选择 Tradier。</li>
<li>输入 Tradier 账户 ID 和 token。</li><p>账户 ID/token 获取方法见 Account Types 的 Create an Account；QuantConnect 不保存这些凭据。</p>
<li>点击 Environment，选择所需环境。</li>
<p>支持的环境如下：</p>
<table class="table qc-table">
<thead>
<tr>
<th style="width: 25%">环境</th>
<th>说明</th>
</tr>
</thead>
<tbody>
<tr>
<td>真实（Real）</td>
<td>使用真实资金交易</td>
</tr>
<tr>
<td>模拟（Demo）</td>
<td>使用虚拟资金交易</td>
</tr>
</tbody>
</table> <li>在 Region 区域选择算法运行地区。</li>
<li>点击 Node 字段，选择要使用的实盘节点。</li>
<li>可选：在 Data Provider 区域点击 Show，修改数据源或添加其他数据源。</li>
<p>通常使用 QuantConnect、Tradier 或两者，向导顺序决定优先级。Demo 环境中，Tradier 因交易所对延迟行情限制而不提供流式行情。</p> <li>可选：配置通知。</li>
<li>配置 Automatically restart algorithm（自动重启算法）选项。</li>
<p>开启自动重启后，平台会尽力重启因运行错误而失败的算法，有助于应对券商 API 暂时断线等故障。</p>
<li>点击 Deploy（部署）。</li>
</ol>
<p>部署最多可能需要 5 分钟，完成后显示实盘结果页。可核对运行统计中的权益、现金账簿和持仓，确认券商原有持仓正确载入。</p>
<p>重启、自动重启和重新部署都不会保存算法全部内部状态。恢复哪些状态、其余状态如何持久化，见 State Persistence。</p>


## 部署详情 · 16 Deployment Details

<p>部署 Tradier 算法时，券商提供交易账户等详情，可区分并行部署和核对目标账户；这些详情不包含凭据。</p>
<p>下表列出 Tradier 提供的部署详情：</p>
<table class="qc-table table">
<thead>
<tr>
<th>键名</th>
<th>说明</th>
</tr>
</thead>
<tbody>
<tr>
<td><code>tradier-account-id</code></td>
<td>接收订单的 Tradier 账户。</td>
</tr>
<tr>
<td><code>tradier-use-sandbox</code></td>
<td>true 为 Tradier sandbox 模拟环境，false 为真实环境。</td>
</tr>
</tbody>
</table>
<p>算法的 DeploymentDetails/deployment_details 是只读字典，LEAN 在调用 Initialize/initialize 之前填充，因此在算法任何位置都可读取。</p>
<div class="section-example-container">
<pre><code class="language-csharp">// 中文注释版：仅补充解释，保留原示例的执行语句。&#10;// 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;var deploymentDetails = DeploymentDetails.Select(kvp =&gt; $"{kvp.Key}:{kvp.Value}");&#10;Log($"deploymentDetails: {string.Join(", ", deploymentDetails)}");</code></pre>
<pre><code class="language-python"># 中文注释版：仅补充解释，保留原示例的执行语句。&#10;# 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;deployment_details = [f'{kvp.key}:{kvp.value}' for kvp in self.deployment_details]&#10;# 记录常规运行信息，消息写入日志并计入日志额度。&#10;# 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;self.log(f'deployment_details: {deployment_details}')</code></pre>
</div>
<p>也可在算法外通过 /live/read 响应的 deploymentDetails 读取详情。</p>

