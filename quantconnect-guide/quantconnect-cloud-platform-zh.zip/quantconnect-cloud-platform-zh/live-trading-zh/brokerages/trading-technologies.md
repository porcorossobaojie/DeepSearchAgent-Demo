# Trading Technologies

非官方中文翻译，按原文小节排列；专有名词、按钮、错误消息和代码字段保留英文对照。费用、IP、权限及产品范围为所标源码版本的记录。各节保留官方链接，代码保留执行语句并添加中文注释。

## 简介 · 01 Introduction

<p>QuantConnect 支持使用实时行情运行实盘模式的算法。</p>
<p>Trading Technologies（TT）由 Gary Kemp 于 1994 年创立，提供专业交易软件、基础设施和数据方案，涉及期货、期权、加密资产，以及图表和风控工具。它并非券商，而是可连接 30 多个执行目的地的订单路由商。</p>
<p>实现见 Lean.Brokerages.TradingTechnologies 仓库。</p>

## 账户类型 · 02 Account Types

<p>TradingTechnologiesBrokerageModel 不设统一手续费/滑点模型，因为 TT 路由到多家交易所及券商；实盘每次成交后报告总费用。回测要模拟费用和滑点，可向 SetBrokerageModel/set_brokerage_model 传入另一 BrokerageName，但须支持策略所用资产和订单。账户及模型设置见 TT 文档。</p>
<h4>创建账户</h4>
<p>按 TT 官网开户向导开立账户。</p>
<h4>模拟交易</h4>
<p>Trading Technologies 另提供独立的<a href="https://library.tradingtechnologies.com/trade/ttp-uat-trading-environment.html" rel="nofollow" target="_blank"></a>用户验收测试（UAT）认证环境 at <a href="https://uat.trade.tt" rel="nofollow" target="_blank">uat.trade.tt</a>。TT UAT 对接真实交易所的认证测试环境，行情和订单路由都使用该测试环境。<p>按 TT 官网 UAT 开户向导创建测试账户。</p>
<h4>创建部署凭据</h4>
<p>开户后按 Create TT Users 创建实盘部署凭据。</p>
</p>

## 资产类别 · 04 Asset Classes


<p>本集成支持期货交易。</p>

## 数据源 · 05 Data Providers

<p>推荐免费的 QuantConnect 期货实时数据源。使用 Trading Technologies 报价可能需购买行情订阅，详见 Datasets。</p>


## 订单 · 06 Orders

<p>本集成支持 TT 的多种订单、TimeInForce 属性和订单更新；实盘也可在 IDE 手动下单。</p>
<h4>订单类型</h4>
<p>下表列出本集成对各资产支持的订单类型：</p>
<table class="qc-table table">
<thead>
<tr>
<th style="width: 50%">订单类型</th>
<th>期货</th>
</tr>
</thead>
<tbody>
<tr>
<td>市价单（Market）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>限价单（Limit）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>止损市价单（Stop market）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>止损限价单（Stop limit）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
</tbody>
</table>

<p>TT 的订单规则如下：</p>
<ul>
<li>买入止损市价或止损限价单的止损价须高于当前价格；卖出则须低于当前价格。</li>
<li>买入止损限价单的限价须高于止损价；卖出则须低于止损价。</li>
</ul>
<h4>订单有效期</h4>
<p>支持 Day/DAY 与 GoodTilCanceled/GOOD_TIL_CANCELED 有效期。</p>
<h4>更新订单</h4>
<p>本集成支持更新 TT 订单。</p>


## 手续费 · 07 Fees

<p>TT 本身路由交易不计费用；目标执行方收费仍应单独核对，平台模型见 Fees。</p>


## 保证金 · 08 Margin

<p>平台模拟购买力和追加保证金，帮助算法遵守保证金要求。</p>


## 滑点 · 09 Slippage

<p>TT 回测和 QuantConnect Paper Trading 不计滑点，实盘可能产生滑点。</p>
<p>TT 滑点模型见 Slippage。</p>


## 成交 · 10 Fills

<p>QuantConnect 回测和 QuantConnect Paper Trading 会立即、全部成交市价单；实盘数量超过盘口可用量时按订单簿流动性成交。</p>
<p>TT 成交模型见 Fills。</p>


## 安全与稳定性 · 11 Security and Stability

<p>本集成的安全与稳定性说明如下。</p>
<h4>账户凭据</h4>
<p>通过 TT 部署时，平台不保存登录凭据。</p>
<h4>API 服务中断</h4>
<p>实盘订单通过 TT API 提交，API 有时可能中断；可在其状态页查看服务情况。</p>


## 入金与出金 · 12 Deposits and Withdrawals

<p>算法运行时仍可给关联券商账户出入金；平台每天美东时间 7:45 同步账户现金余额。</p>


## 演示算法 · 13 Demo Algorithm

<p>以下算法演示 TT 的功能：</p>
<div class="section-example-container testable">
<pre><code class="language-csharp">// 中文注释版：仅补充解释，保留原示例的执行语句。&#10;// Demonstrate Trading Technologies brokerage functionality with an EMA crossover strategy on ES Futures.&#10;public class TradingTechnologiesDemoAlgorithm : QCAlgorithm&#10;{&#10;    private Symbol _symbol;&#10;    private ExponentialMovingAverage _fast;&#10;    private ExponentialMovingAverage _slow;&#10;&#10;    public override void Initialize()&#10;    {&#10;        // 设置回测开始日期；实盘运行不以此恢复历史状态。&#10;        SetStartDate(2024, 9, 1);&#10;        // 设置回测结束日期。&#10;        SetEndDate(2024, 12, 31);&#10;        // 设置回测初始现金；实盘资金以券商账户和部署配置为准。&#10;        SetCash(100000);&#10;        // 设置券商模型和账户类型，决定资产、订单及现实约束。&#10;        SetBrokerageModel(BrokerageName.TradingTechnologies, AccountType.Margin);&#10;        var future = AddFuture(Futures.Indices.SP500EMini, Resolution.Daily);&#10;        future.SetFilter(0, 90);&#10;    }&#10;&#10;    public override void OnData(Slice slice)&#10;    {&#10;        if (Portfolio.Invested) return;&#10;        foreach (var chain in slice.FutureChains)&#10;        {&#10;            var contract = chain.Value.OrderBy(c =&gt; c.Expiry).FirstOrDefault();&#10;            if (contract == null) continue;&#10;            if (_fast == null)&#10;            {&#10;                _symbol = contract.Symbol;&#10;                // 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;                _fast = EMA(_symbol, 10, Resolution.Daily);&#10;                // 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;                _slow = EMA(_symbol, 50, Resolution.Daily);&#10;                return;&#10;            }&#10;            // 指标准备好后才使用信号，历史样本不足时退出。&#10;            if (!_slow.IsReady) return;&#10;            if (_fast &gt; _slow)&#10;                // 提交指定数量的市价单，正数买入、负数卖出。&#10;                MarketOrder(_symbol, 1);&#10;        }&#10;    }&#10;}</code></pre>
<pre><code class="language-python"># 中文注释版：仅补充解释，保留原示例的执行语句。&#10;# Demonstrate Trading Technologies brokerage functionality with an EMA crossover strategy on ES Futures.&#10;# 定义继承 QCAlgorithm 的策略类，由 LEAN 管理其生命周期。&#10;class TradingTechnologiesDemoAlgorithm(QCAlgorithm):&#10;    # 初始化只在算法开始时运行一次，设置回测条件和数据订阅。&#10;    def initialize(self) -&gt; None:&#10;        # 设置历史回测的开始日期。&#10;        # 设置回测开始日期；实盘运行不以此恢复历史状态。&#10;        self.set_start_date(2024, 9, 1)&#10;        # 设置历史回测的结束日期。&#10;        # 设置回测结束日期。&#10;        self.set_end_date(2024, 12, 31)&#10;        # 设置回测初始资金为 100,000 单位账户货币。&#10;        # 设置回测初始现金；实盘资金以券商账户和部署配置为准。&#10;        self.set_cash(100000)&#10;        # 设置券商模型和账户类型，决定资产、订单及现实约束。&#10;        self.set_brokerage_model(BrokerageName.TRADING_TECHNOLOGIES, AccountType.MARGIN)&#10;        future = self.add_future(Futures.Indices.SP_500_E_MINI, Resolution.DAILY)&#10;        future.set_filter(0, 90)&#10;        self._symbol = None&#10;        self._fast = None&#10;        self._slow = None&#10;&#10;    # 行情到达时执行；data 包含该时间片可用的数据。&#10;    def on_data(self, slice: Slice) -&gt; None:&#10;        if self.portfolio.invested:&#10;            return&#10;        for chain in slice.future_chains:&#10;            contracts = sorted(chain.value, key=lambda c: c.expiry)&#10;            if not contracts:&#10;                continue&#10;            contract = contracts[0]&#10;            if self._fast is None:&#10;                self._symbol = contract.symbol&#10;                # 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;                self._fast = self.ema(self._symbol, 10, Resolution.DAILY)&#10;                # 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;                self._slow = self.ema(self._symbol, 50, Resolution.DAILY)&#10;                return&#10;            # 指标准备好后才使用信号，历史样本不足时退出。&#10;            if not self._slow.is_ready:&#10;                return&#10;            if self._fast.current.value &gt; self._slow.current.value:&#10;                # 提交指定数量的市价单，正数买入、负数卖出。&#10;                self.market_order(self._symbol, 1)</code></pre>
</div>

## 创建 TT 用户 · 14 Create TT Users

<p>按以下步骤创建用户名、账户名、remote comp id、会话密码、app key 和 app secret：</p>
<div style="padding:56.25% 0 0 0;position:relative;"><iframe allow="autoplay; fullscreen; picture-in-picture; clipboard-write" frameborder="0" src="https://player.vimeo.com/video/1006924337?badge=0&amp;autopause=0&amp;player_id=0&amp;app_id=58479" style="position:absolute;top:0;left:0;width:100%;height:100%;" title="Creating Trading Technologies Accounts"></iframe></div>
<h4>第一部分：登录</h4>
<p>登录 TT 正式或 UAT 账户，尚无账户时见 Account Types。</p>
<h4>第二部分：添加用户</h4>
<ol>
<li>顶部导航点击 Setup。</li>
<li>Setup 页面点击 +New User。</li>
<li>New User 窗口选择该用户在公司的雇佣状态，点击 Continue。</li>
<li>在 New User 填写用户资料。</li>
<p>Username 字段是随后 LEAN 部署需要的用户名。</p>
<p>Status 区域的 Trade Mode 选择 TT Pro。</p>
<p>Advanced Settings 勾选 Can create TT Rest API Key 与 Can create TT.NET SDK Client Side key。</p>
<li>点击 Create。</li>
<li>回到 Setup，选中新用户，点击 Send Invitation。</li>
</ol>
<h4>第三部分：为用户创建 App Key</h4>
<ol>
<li>在 Setup 选中新用户，打开 App Keys 标签。</li>
<li>App Keys 区域点击 New。</li>
<li>填写 key 名称（如 qb_alex_app_key），类型选择 TT REST API，点击 Create。</li>
<li>点击 Copy Secret to Clipboard，在安全的本地位置保存。</li>
<p>复制内容由 App Key 和 App Secret 以冒号分隔；原文 UUID 仅为结构示例，不能作为可用凭据。</p>
<li>点击 OK。</li>
</ol>
<h4>第四部分：为用户创建账户</h4>
<ol>
<li>在 Setup 左侧点击 Accounts。</li>
<li>Accounts 页点击 +New Account。</li>
<li>按以下要求填写表单：</li>
<ul>
<li>设置易识别的账户名，例如 QC。</li>
<li>如有父账户，在 Parent 选择。</li>
<li>Parent 选择 Routing (internal sub-account)。（按原文保留此字段指引，具体界面以当前 TT 为准。）</li>
</ul>
<li>点击 Create。</li>
<li>在 Account 页选中新账户，打开 Users 标签。</li>
<li>Users 区域点击 +Add。</li>
<li>Select Users 窗口选择新用户，点击 Select。</li>
<li>点击 Save Changes。</li>
</ol>
<h4>第五部分：创建 FIX 会话</h4>
<ol>
<li>Setup 左侧点击 FIX Sessions。</li>
<li>点击 +New FIX Session。</li>
<li>按以下要求填写 FIX 会话表单：</li>
<ul>
<li>填写易识别的 FIX Session Name，例如 QC。</li>
<li>FIX Type 选择 FIX Order Routing。</li>
<li>填写易识别的 Remote Comp ID，例如 qc_alex_id。</li>
<p>此 ID 即部署 LEAN 所需的 remote comp id。</p>
<p>此表设置的 session password 也是部署所需密码。</p>
<li>勾选 Send unsolicited order and fill message。</li>
<li>Status 区域取消勾选 Inactive。</li>
</ul>
<li>点击 Create。</li>
<li>回到 FIX Sessions，选中新会话，打开 Users 标签。</li>
<li>Users 区域点击 +Add。</li>
<li>Select Users 窗口选择新用户，点击 Select。</li>
<li>点击 Save Changes。</li>
</ol>
<h4>第六部分：验证凭据</h4>
<ol>
<li>Setup 左侧点击 Users。</li>
<li>选择新用户，核对 FIX Sessions 和 App Keys 下的信息。</li>
</ol>


## 部署算法 · 15 Deploy Live Algorithms

<p>每个实盘算法必须有一个可用实盘节点。</p>
<p>按以下步骤部署实盘算法：</p>
<ol>
<li>打开要部署的项目。</li>
<li>点击 Deploy Live（部署实盘）图标。<img alt="Lightning icon" class="inline-icon" src="https://cdn.quantconnect.com/i/tu/deploy-live-icon.png"/></li>
<li>在 Deploy Live 页面点击 Brokerage 字段，从列表选择 Trading Technologies。</li>
<li>输入 TT 用户名、账户名、remote comp id、session password、app key 和 app secret。</li>
<p>凭据获取方式见 Create TT Users。</p>
<p>订单通过 TT FIX 4.4 路由；联系 TT 代表配置目标交易所。QuantConnect 不保存账户凭据。</p>
<p>持仓通过 REST 查询，所以这里的 app key/secret 应为 REST App 凭据。</p>
<li>点击 Environment，选择所需环境。</li>
<p>支持的环境如下：</p>
<table class="table qc-table">
<thead>
<tr>
<th>环境</th>
<th>说明</th>
</tr>
</thead>
<tbody>
<tr>
<td>实盘（Live）</td>
<td>在正式生产环境交易</td>
</tr>
<tr>
<td>用户验收测试（UAT）</td>
<td>在用户验收测试环境交易</td>
</tr>
</tbody>
</table> <li>在 Region 区域选择算法运行地区。</li>
<li>点击 Node 字段，选择要使用的实盘节点。</li>
<li>可选：在 Data Provider 区域点击 Show，修改数据源或添加其他数据源。</li>
<li>账户已有现金时，按以下步骤填写（有演示视频）：</li>
<ol>
<li>在 Algorithm Cash State 点击 Show。</li>
<li>点击 Add Currency。</li>
<li>填写币种代码（如 USD/CAD）及数量。</li>
</ol>
<li>可选：配置通知。</li>
<li>配置 Automatically restart algorithm（自动重启算法）选项。</li>
<p>开启自动重启后，平台会尽力重启因运行错误而失败的算法，有助于应对券商 API 暂时断线等故障。</p>
<li>点击 Deploy（部署）。</li>
</ol>
<p>部署最多可能需要 5 分钟，完成后显示实盘结果页。可核对运行统计中的权益、现金账簿和持仓，确认券商原有持仓正确载入。</p>
<p>重启、自动重启和重新部署都不会保存算法全部内部状态。恢复哪些状态、其余状态如何持久化，见 State Persistence。</p>


## 部署详情 · 16 Deployment Details

<p>部署 Trading Technologies 算法时，券商提供交易账户等详情，可区分并行部署和核对目标账户；这些详情不包含凭据。</p>
<p>下表列出 Trading Technologies 提供的部署详情：</p>
<table class="qc-table table">
<thead>
<tr>
<th>键名</th>
<th>说明</th>
</tr>
</thead>
<tbody>
<tr>
<td><code>tt-user-name</code></td>
<td>LEAN 登录使用的 TT 用户名。</td>
</tr>
<tr>
<td><code>tt-account-name</code></td>
<td>接收订单的 TT 账户。</td>
</tr>
<tr>
<td><code>tt-rest-environment</code></td>
<td>LEAN 查询持仓与合约详情所用的 TT REST 环境。</td>
</tr>
<tr>
<td><code>tt-order-routing-sender-comp-id</code></td>
<td>FIX 订单路由会话的 sender comp ID。</td>
</tr>
</tbody>
</table>
<p>算法的 DeploymentDetails/deployment_details 是只读字典，LEAN 在调用 Initialize/initialize 之前填充，因此在算法任何位置都可读取。</p>
<div class="section-example-container">
<pre><code class="language-csharp">// 中文注释版：仅补充解释，保留原示例的执行语句。&#10;// 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;var deploymentDetails = DeploymentDetails.Select(kvp =&gt; $"{kvp.Key}:{kvp.Value}");&#10;Log($"deploymentDetails: {string.Join(", ", deploymentDetails)}");</code></pre>
<pre><code class="language-python"># 中文注释版：仅补充解释，保留原示例的执行语句。&#10;# 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;deployment_details = [f'{kvp.key}:{kvp.value}' for kvp in self.deployment_details]&#10;# 记录常规运行信息，消息写入日志并计入日志额度。&#10;# 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;self.log(f'deployment_details: {deployment_details}')</code></pre>
</div>
<p>也可在算法外通过 /live/read 响应的 deploymentDetails 读取详情。</p>

