# Binance

非官方中文翻译，按原文小节排列；专有名词、按钮、错误消息和代码字段保留英文对照。费用、IP、权限及产品范围为所标源码版本的记录。各节保留官方链接，代码保留执行语句并添加中文注释。

## 简介 · 01 Introduction

<p>QuantConnect 支持使用实时行情运行实盘模式的算法。</p>
<p>Binance 由赵长鹏于 2017 年创立，目标是提高全球资金流动自由度，提供加密现货和永续期货。原文称加密入金无最低要求，并提供 NFT 市场、矿池及流动性池收益服务。实际集成支持见下文。</p>
<p>集成实现见 Lean.Brokerages.Binance 仓库。</p>

## 账户类型 · 02 Account Types

<p>Binance 现货支持现金和保证金账户，期货仅支持保证金账户；Binance US 只支持现金账户。算法账户设置见对应券商模型文档。</p>
<h4>创建账户</h4>
<p>在 Binance.com 或 Binance.us 按开户向导创建账户。</p>
<p>部署需要 API 凭据；开户后生成并妥善保存，按以下方式配置：</p>
<ul>
<li>选择系统生成、使用 HMAC 对称加密的 API key。</li>
<li>勾选 Restrict access to trusted IPs only，添加 146.59.85.21、57.128.231.46、57.128.233.143；Binance.us 使用 207.182.16.137。</li>
<li>交易加密期货时勾选 Enable Futures。</li>
</ul>
<h4>模拟交易</h4>
<p>Binance Spot Test Network 支持模拟现货，生成测试网凭据不需要真实 Binance 账户。</p>
<p>按以下步骤配置 Spot Test Network：</p>
<ol>
<li>用 GitHub 账户登录 Binance Spot Test Network。</li>
<li>在 API Keys 点击 Generate HMAC_SHA256 Key。</li>
<li>输入说明并点击 Generate。</li>
<li>妥善保存 API key 和 secret。</li>
</ol>
<p>当前不提供 Binance 加密期货或 Binance US 的模拟交易。</p>
<h4>子账户</h4>
<p>Binance 与 Binance US 集成都不支持子账户交易，必须用主账户。</p>


## 资产类别 · 04 Asset Classes

<p>本集成支持加密现货与加密期货。</p>
<p>本集成支持加密货币交易。</p>


## 数据源 · 05 Data Providers

<p>QuantConnect 数据源提供实时加密货币行情。</p>
<p>Binance 与 Bybit 限制从美国访问，交易和接收行情均需选择 Europe (WAW) 地区。</p>
<p>地区设置见 Deploy Live Algorithms。</p>


## 订单 · 06 Orders

<p>本集成支持 Binance/Binance US 的多种订单与属性，但不支持直接更新订单；实盘可通过 IDE 手动下单。</p>
<h4>订单类型</h4>
<p>下表列出 Binance/Binance US 集成对各资产支持的订单类型：</p>
<table class="qc-table table">
<thead>
<tr>
<th style="width: 50%">订单类型</th>
<th>加密货币</th>
<th>加密货币期货</th>
</tr>
</thead>
<tbody>
<tr>
<td>市价单（Market）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>限价单（Limit）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>止损市价单</td>
<td></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>止损限价单（Stop limit）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>括号订单（Bracket）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td></td>
</tr>
<tr>
<td>一单成交取消另一单（OCO）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td></td>
</tr>
<tr>
<td>一单触发另一单（OTO）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td></td>
</tr>
</tbody>
</table>

<h4>订单属性</h4>
<p>下表为 Binance/Binance US API 的自定义属性，可通过 BinanceOrderProperties 设置。</p>
<table class="table qc-table">
<thead>
<tr>
<th>属性</th>
<th>数据类型</th>
<th>说明</th>
<th>默认值</th>
</tr>
</thead>
<tbody>
<tr>
<td><code class="csharp">TimeInForce</code><code class="python">time_in_force</code></td>
<td><code>TimeInForce</code></td>
<td>
             A <a href="https://www.quantconnect.com/docs/v2/writing-algorithms/trading-and-orders/order-properties#03-Time-In-Force">TimeInForce</a>为订单设置有效期，支持以下取值：<ul>
<li>当日有效（Day / DAY）</li>
<li><code class="csharp">GoodTilCanceled</code><code class="python">GOOD_TIL_CANCELED</code></li>
<li>指定日期前有效（GoodTilDate / good_til_date）</li>
</ul>
</td>
<td><code class="csharp">TimeInForce.GoodTilCanceled</code><code class="python">TimeInForce.GOOD_TIL_CANCELED</code></td>
</tr>
<tr>
<td><code class="csharp">PostOnly</code><code class="python">post_only</code></td>
<td><code>bool</code></td>
<td>订单只能提供流动性，不能吃单；任意部分会吃单则整单拒绝，不会部分成交。</td>
<td></td>
</tr>
</tbody>
</table>
<h4>关联条件订单</h4>
<p>Binance 加密现货条件单遵循以下规则：</p>
<ul>
<li>同一证券每组最多三单，可为括号单、限价单触发一单，或 OCO 双单。</li>
<li>触发其他订单的父单必须是限价单，且不能处于 OCO 对中。</li>
<li>OCO 由同方向一笔限价单和一笔止损限价单组成。</li>
</ul>
<p>Binance US 和 Binance 的期货不支持条件单。</p>
<h4>更新订单</h4>
<p>Binance/Binance US 不支持改单，可先撤销再按新参数重下，详见不支持更新的券商替代方案。</p>


## 手续费 · 07 Fees

<p>Binance/Binance US 费用见 Binance.com 的 Trading Fees 或 Binance.us 的 Fee Structure；平台模型见 Fees。Spot Test Network 不收订单费用。</p>


## 保证金 · 08 Margin

<p>平台模拟购买力和追加保证金。加密永续期货的保证金成本与资金支付直接反映在组合现金中，详见 Binance Futures Model 的保证金利息说明。</p>

## 滑点 · 09 Slippage

<p>Binance/Binance US 回测和 QuantConnect Paper Trading 不计滑点，实盘可能产生滑点。</p>
<p>Binance/Binance US 滑点模型见 Slippage。</p>


## 成交 · 10 Fills

<p>QuantConnect 回测和 QuantConnect Paper Trading 会立即、全部成交市价单；实盘数量超过盘口可用量时按订单簿流动性成交。</p>
<p>Binance/Binance US 成交模型见 Fills。</p>


## 结算 · 11 Settlements

<p>交易后立即结算。</p>
<p>Binance/Binance US 结算模型见 Settlement。</p>


## 安全与稳定性 · 12 Security and Stability


<p>通过 Binance/Binance US 部署时，平台不保存这些凭据。</p>


## 入金与出金 · 13 Deposits and Withdrawals

<p>算法运行时仍可给关联券商账户出入金；平台每天美东时间 7:45 同步账户现金余额。</p>


## 演示算法 · 14 Demo Algorithm

<p>以下算法演示 Binance/Binance US 集成功能：</p>
<h4>Binance</h4>
<div class="section-example-container testable">
<pre><code class="language-csharp">// 中文注释版：仅补充解释，保留原示例的执行语句。&#10;// Demonstrate Binance brokerage functionality with an EMA crossover strategy.&#10;public class BinanceDemoAlgorithm : QCAlgorithm&#10;{&#10;    private Symbol _symbol;&#10;    private ExponentialMovingAverage _fast;&#10;    private ExponentialMovingAverage _slow;&#10;&#10;    public override void Initialize()&#10;    {&#10;        // 设置回测开始日期；实盘运行不以此恢复历史状态。&#10;        SetStartDate(2024, 9, 1);&#10;        // 设置回测结束日期。&#10;        SetEndDate(2024, 12, 31);&#10;        // 设置回测初始现金；实盘资金以券商账户和部署配置为准。&#10;        SetCash(100000);&#10;        // 设置券商模型和账户类型，决定资产、订单及现实约束。&#10;        SetBrokerageModel(BrokerageName.Binance, AccountType.Cash);&#10;        // 订阅指定市场的加密货币对。&#10;        _symbol = AddCrypto("BTCUSDT", Resolution.Daily, Market.Binance).Symbol;&#10;        // 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        _fast = EMA(_symbol, 10, Resolution.Daily);&#10;        // 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        _slow = EMA(_symbol, 50, Resolution.Daily);&#10;    }&#10;&#10;    public override void OnData(Slice slice)&#10;    {&#10;        // 指标准备好后才使用信号，历史样本不足时退出。&#10;        if (!_slow.IsReady) return;&#10;        if (_fast &gt; _slow &amp;&amp; !Portfolio.Invested)&#10;            // 按目标权重调整仓位；1 表示账户权益的 100%，不是买入 1 股。&#10;            SetHoldings(_symbol, 1);&#10;        else if (_fast &lt; _slow &amp;&amp; Portfolio.Invested)&#10;            // 请求平仓；实际成交仍取决于市场和券商。&#10;            Liquidate();&#10;    }&#10;}</code></pre>
<pre><code class="language-python"># 中文注释版：仅补充解释，保留原示例的执行语句。&#10;# Demonstrate Binance brokerage functionality with an EMA crossover strategy.&#10;# 定义继承 QCAlgorithm 的策略类，由 LEAN 管理其生命周期。&#10;class BinanceDemoAlgorithm(QCAlgorithm):&#10;    # 初始化只在算法开始时运行一次，设置回测条件和数据订阅。&#10;    def initialize(self) -&gt; None:&#10;        # 设置历史回测的开始日期。&#10;        # 设置回测开始日期；实盘运行不以此恢复历史状态。&#10;        self.set_start_date(2024, 9, 1)&#10;        # 设置历史回测的结束日期。&#10;        # 设置回测结束日期。&#10;        self.set_end_date(2024, 12, 31)&#10;        # 设置回测初始资金为 100,000 单位账户货币。&#10;        # 设置回测初始现金；实盘资金以券商账户和部署配置为准。&#10;        self.set_cash(100000)&#10;        # 设置券商模型和账户类型，决定资产、订单及现实约束。&#10;        self.set_brokerage_model(BrokerageName.BINANCE, AccountType.CASH)&#10;        # 订阅指定市场的加密货币对。&#10;        self._symbol = self.add_crypto("BTCUSDT", Resolution.DAILY, Market.BINANCE).symbol&#10;        # 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        self._fast = self.ema(self._symbol, 10, Resolution.DAILY)&#10;        # 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        self._slow = self.ema(self._symbol, 50, Resolution.DAILY)&#10;&#10;    # 行情到达时执行；data 包含该时间片可用的数据。&#10;    def on_data(self, slice: Slice) -&gt; None:&#10;        # 指标准备好后才使用信号，历史样本不足时退出。&#10;        if not self._slow.is_ready:&#10;            return&#10;        if self._fast.current.value &gt; self._slow.current.value and not self.portfolio.invested:&#10;            # 按目标权重调整仓位；1 表示账户权益的 100%，不是买入 1 股。&#10;            self.set_holdings(self._symbol, 1)&#10;        elif self._fast.current.value &lt; self._slow.current.value and self.portfolio.invested:&#10;            # 请求平仓；实际成交仍取决于市场和券商。&#10;            self.liquidate()</code></pre>
</div>
<h4>Binance US</h4>
<div class="section-example-container testable">
<pre><code class="language-csharp">// 中文注释版：仅补充解释，保留原示例的执行语句。&#10;// Demonstrate Binance US brokerage functionality with an EMA crossover strategy.&#10;public class BinanceUsDemoAlgorithm : QCAlgorithm&#10;{&#10;    private Symbol _symbol;&#10;    private ExponentialMovingAverage _fast;&#10;    private ExponentialMovingAverage _slow;&#10;&#10;    public override void Initialize()&#10;    {&#10;        // 设置回测开始日期；实盘运行不以此恢复历史状态。&#10;        SetStartDate(2024, 9, 1);&#10;        // 设置回测结束日期。&#10;        SetEndDate(2024, 12, 31);&#10;        // 设置回测初始现金；实盘资金以券商账户和部署配置为准。&#10;        SetCash(100000);&#10;        // 设置券商模型和账户类型，决定资产、订单及现实约束。&#10;        SetBrokerageModel(BrokerageName.BinanceUS, AccountType.Cash);&#10;        // 订阅指定市场的加密货币对。&#10;        _symbol = AddCrypto("BTCUSD", Resolution.Daily, Market.BinanceUS).Symbol;&#10;        // 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        _fast = EMA(_symbol, 10, Resolution.Daily);&#10;        // 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        _slow = EMA(_symbol, 50, Resolution.Daily);&#10;    }&#10;&#10;    public override void OnData(Slice slice)&#10;    {&#10;        // 指标准备好后才使用信号，历史样本不足时退出。&#10;        if (!_slow.IsReady) return;&#10;        if (_fast &gt; _slow &amp;&amp; !Portfolio.Invested)&#10;            // 按目标权重调整仓位；1 表示账户权益的 100%，不是买入 1 股。&#10;            SetHoldings(_symbol, 1);&#10;        else if (_fast &lt; _slow &amp;&amp; Portfolio.Invested)&#10;            // 请求平仓；实际成交仍取决于市场和券商。&#10;            Liquidate();&#10;    }&#10;}</code></pre>
<pre><code class="language-python"># 中文注释版：仅补充解释，保留原示例的执行语句。&#10;# Demonstrate Binance US brokerage functionality with an EMA crossover strategy.&#10;# 定义继承 QCAlgorithm 的策略类，由 LEAN 管理其生命周期。&#10;class BinanceUsDemoAlgorithm(QCAlgorithm):&#10;    # 初始化只在算法开始时运行一次，设置回测条件和数据订阅。&#10;    def initialize(self) -&gt; None:&#10;        # 设置历史回测的开始日期。&#10;        # 设置回测开始日期；实盘运行不以此恢复历史状态。&#10;        self.set_start_date(2024, 9, 1)&#10;        # 设置历史回测的结束日期。&#10;        # 设置回测结束日期。&#10;        self.set_end_date(2024, 12, 31)&#10;        # 设置回测初始资金为 100,000 单位账户货币。&#10;        # 设置回测初始现金；实盘资金以券商账户和部署配置为准。&#10;        self.set_cash(100000)&#10;        # 设置券商模型和账户类型，决定资产、订单及现实约束。&#10;        self.set_brokerage_model(BrokerageName.BINANCE_US, AccountType.CASH)&#10;        # 订阅指定市场的加密货币对。&#10;        self._symbol = self.add_crypto("BTCUSD", Resolution.DAILY, Market.BINANCE_US).symbol&#10;        # 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        self._fast = self.ema(self._symbol, 10, Resolution.DAILY)&#10;        # 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        self._slow = self.ema(self._symbol, 50, Resolution.DAILY)&#10;&#10;    # 行情到达时执行；data 包含该时间片可用的数据。&#10;    def on_data(self, slice: Slice) -&gt; None:&#10;        # 指标准备好后才使用信号，历史样本不足时退出。&#10;        if not self._slow.is_ready:&#10;            return&#10;        if self._fast.current.value &gt; self._slow.current.value and not self.portfolio.invested:&#10;            # 按目标权重调整仓位；1 表示账户权益的 100%，不是买入 1 股。&#10;            self.set_holdings(self._symbol, 1)&#10;        elif self._fast.current.value &lt; self._slow.current.value and self.portfolio.invested:&#10;            # 请求平仓；实际成交仍取决于市场和券商。&#10;            self.liquidate()</code></pre>
</div>

## 虚拟币对 · 15 Virtual Pairs

<p>每种法币和加密币都是独立资产。买入 BTCUSD 实际是用 USD 换 BTC，现金账簿减少 USD、增加 BTC；BTCUSD 持仓是表示交易的虚拟币对。部署时 LEAN 可载入各币种余额，却无法从余额反推每个虚拟币对的持仓。</p>


## 部署算法 · 16 Deploy Live Algorithms

<p>每个实盘算法必须有一个可用实盘节点。</p>
<p>按以下步骤部署实盘算法：</p>
<ol>
<li>打开要部署的项目。</li>
<li>点击 Deploy Live（部署实盘）图标。<img alt="Lightning icon" class="inline-icon" src="https://cdn.quantconnect.com/i/tu/deploy-live-icon.png"/></li>
<li>在 Deploy Live 页面点击 Brokerage，选择 Binance Exchange。</li>
<li>输入 API key 和 secret。</li>
<p>生成凭据见 Account Types；QuantConnect 不保存这些账户凭据。</p>
<li>点击 Environment 并选择运行环境。</li>
<p>支持的环境如下：</p>
<table class="table qc-table">
<thead>
<tr>
<th>环境</th>
<th>说明</th>
</tr>
</thead>
<tbody>
<tr>
<td>真实（Real）</td>
<td>使用真实资金交易</td>
</tr>
<tr>
<td>模拟（Demo）</td>
<td>通过 Binance Global 使用虚拟资金交易。</td>
</tr>
</tbody>
</table> <li>在 Region 区域选择算法运行地区。</li>
<p>Binance 与 Bybit 限制从美国访问，交易和接收行情均需选择 Europe (WAW) 地区。</p>
<li>点击 Node 字段，选择要使用的实盘节点。</li>
<li>可选：在 Data Provider 区域点击 Show，修改数据源或添加其他数据源。</li>
<li>账户已有现金时，按以下步骤填写（有演示视频）：</li>
<ol>
<li>在 Algorithm Cash State 点击 Show。</li>
<li>点击 Add Currency。</li>
<li>填写币种代码（如 USD/CAD）及数量。</li>
</ol>
<li>账户已有持仓时，按以下步骤填写（有演示视频）：</li>
<ol>
<li>在 Algorithm Holdings State 点击 Show。</li>
<li>点击 Add Holding。</li>
<li>填写 Symbol ID、代码、数量和平均价格。</li>
</ol>
<li>可选：配置通知。</li>
<li>配置 Automatically restart algorithm（自动重启算法）选项。</li>
<p>开启自动重启后，平台会尽力重启因运行错误而失败的算法，有助于应对券商 API 暂时断线等故障。</p>
<li>点击 Deploy（部署）。</li>
</ol>
<p>部署最多可能需要 5 分钟，完成后显示实盘结果页。可核对运行统计中的权益、现金账簿和持仓，确认券商原有持仓正确载入。</p>
<p>重启、自动重启和重新部署都不会保存算法全部内部状态。恢复哪些状态、其余状态如何持久化，见 State Persistence。</p>

