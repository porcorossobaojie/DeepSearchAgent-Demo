# Public

非官方中文翻译，按原文小节排列；专有名词、按钮、错误消息和代码字段保留英文对照。费用、IP、权限及产品范围为所标源码版本的记录。各节保留官方链接，代码保留执行语句并添加中文注释。

## 简介 · 01 Introduction

<p>QuantConnect 支持使用实时行情运行实盘模式的算法。</p>
<p>Public 是 2019 年成立的免佣投资平台，在美国由 Public Holdings 运营，券商服务由 FINRA/SIPC 成员 Open to the Public Investing 提供。Trading API 提供股票、股票期权、指数期权及加密货币；常规交易时段的美国上市股票和期权免佣。</p>



## 账户类型 · 02 Account Types

<p>Public 支持现金和保证金账户；算法设置方式见对应券商模型文档。</p>
<h4>创建账户</h4>
<p>按 Public 官网开户向导开立账户。</p>
<h4>创建 API 凭据</h4>
<p>交易需要 secret key 和目标账户号码，获取步骤如下；视频说明见其 YouTube 的 The Public API: How to Program Your Trading of Stocks, Options, and More。</p>
<ol>
<li>在 Public API 页面填写申请，等待 concierge 团队批准。</li>
<li>批准后登录 Public.com，打开 Settings，点击右侧 Security，再点击左侧 API。</li>
<li>生成并妥善保存 secret key，最多同时保留两把，可随时撤销。密钥继承账户读写权限，LEAN 自动将其换成短期访问令牌。</li>
<li>记录目标 Public 账户号码；同一用户可有多个账户，号码决定交易哪一个。</li>
</ol>
<h4>模拟交易</h4>
<p>Public API 不支持模拟交易，但可用 QuantConnect 按以下方法模拟：</p>
<ol>
<li>在 Initialize/initialize 中设置 Public 券商模型和账户类型。</li>
<li>使用 QuantConnect Paper Trading 券商部署算法。</li>
</ol>


## 资产类别 · 04 Asset Classes

<p>本集成支持以下资产类别：</p>
<ul>
<li>美国股票</li>
<li>股票期权</li>
<li>指数期权</li>
<li>加密货币</li>
</ul>
<p>Public 资产权限因所在地及账户而异，例如欧盟居民不能交易美国 ETF。请核对当地规定，必要时调整券商账户权限。</p>

## 数据源 · 05 Data Providers

<p>Public 不提供实时行情，推荐免费的 QuantConnect 数据源，覆盖美国股票、股票期权、指数期权、加密货币，并含 SPX/VIX 标的指数。详见 Datasets。</p>


## 订单 · 06 Orders

<p>本集成支持 Public 的多种订单、TimeInForce 属性和订单更新；实盘也可在 IDE 手动下单。</p>
<h4>订单类型</h4>
<p>下表列出本集成对各资产支持的订单类型：</p>
<table class="qc-table table">
<thead>
<tr>
<th style="width: 36%">订单类型</th>
<th style="width: 16%">股票</th>
<th style="width: 16%">股票期权</th>
<th style="width: 16%">指数期权</th>
<th style="width: 16%">加密货币</th>
</tr>
</thead>
<tbody>
<tr>
<td>市价单（Market）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>限价单（Limit）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>止损市价单（Stop market）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>止损限价单（Stop limit）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>组合限价单（Combo limit）</td>
<td></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td></td>
</tr>
</tbody>
</table>

<h4>订单属性</h4>
<p>下表为 Public 自定义订单属性，可用 PublicOrderProperties 对象设置。</p>
<table class="table qc-table">
<thead>
<tr>
<th>属性</th>
<th>数据类型</th>
<th>说明</th>
<th>默认值</th>
</tr>
</thead>
<tbody>
<tr>
<td><code class="csharp">TimeInForce</code><code class="python">time_in_force</code></td>
<td><code>TimeInForce</code></td>
<td>A <a href="https://www.quantconnect.com/docs/v2/writing-algorithms/trading-and-orders/order-properties#03-Time-In-Force">TimeInForce</a>为订单设置有效期，支持以下取值：<ul>
<li>当日有效（Day / DAY）</li>
<li><code class="csharp">GoodTilCanceled</code><code class="python">GOOD_TIL_CANCELED</code></li>
<li>指定日期前有效（GoodTilDate / good_til_date）</li>
</ul>Public 原生仅支持当日和指定日期有效，LEAN 将 GTC 转换为 90 天后到期的指定日期单。</td>
<td><code class="csharp">TimeInForce.GoodTilCanceled</code><code class="python">TimeInForce.GOOD_TIL_CANCELED</code></td>
</tr>
<tr>
<td><code class="csharp">OutsideRegularTradingHours</code><code class="python">outside_regular_trading_hours</code></td>
<td><code>bool</code></td>
<td>设为 true 允许盘外触发或成交，仅适用于当日有效的股票限价单，因为 Public 延长交易时段仅接受限价单。</td>
<td><code class="csharp">false</code><code class="python">False</code></td>
</tr>
<tr>
<td><code class="csharp">UseMargin</code><code class="python">use_margin</code></td>
<td><code>bool?</code></td>
<td>控制订单使用的购买力。true 在账户允许时使用保证金；false 仅用已结算现金。未设置时，保证金账户默认用保证金购买力，现金账户始终只用现金。</td>
<td><code class="csharp">null</code><code class="python">None</code></td>
</tr>
</tbody>
</table>
<h4>更新订单</h4>
<p>Public 只支持更新单腿订单，不支持更新多腿组合单。</p>
<h4>拆股处理</h4>
<p>使用原始价格（Raw）时，如果美国股票拆股，尚未成交订单中的以下属性会自动按拆股比例调整：</p>
<ul>
<li>数量</li>
<li>限价</li>
<li>止损价</li>
<li>触发价</li>
</ul>

## 请求限流 · 07 Rate Limit

<p>为遵守 Public 速率限制，本集成限制为每秒 10 次请求；同一标的最多同时有 10 笔新开仓待成交订单。</p>
<p>算法应控制下单频率，避免触发限制。</p>


## 手续费 · 08 Fees

<p>Public 常规时段股票、股票期权和 ETF 期权免佣；盘外股票每笔 2.99 美元，指数期权每份 0.50 美元，加密货币按金额收费。完整费用见 Fee Schedule，平台模型见 Fees。</p>


## 保证金 · 09 Margin

<p>平台模拟购买力和追加保证金，帮助算法遵守保证金要求。</p>
<p>Public 保证金交易包括做空和超出已结算现金的买入，账户现金、股票与债券合计至少 2,000 美元；UseMargin/use_margin 决定每笔单使用的购买力。</p>


## 滑点 · 10 Slippage

<p>Public 回测和 QuantConnect Paper Trading 不计滑点，实盘可能产生滑点。</p>
<p>Public 滑点模型见 Slippage。</p>


## 成交 · 11 Fills

<p>QuantConnect 回测和 QuantConnect Paper Trading 会立即、全部成交市价单；实盘数量超过盘口可用量时按订单簿流动性成交。</p>
<p>Public 成交模型见 Fills。</p>


## 结算 · 12 Settlements

<p>保证金账户的交易即时结算。（原模板此处仅输出这一分支；现金账户规则应结合券商结算说明核对。）</p>
<p>Public 结算模型见 Settlement。</p>


## 安全与稳定性 · 13 Security and Stability


<p>通过 Public 部署时，平台不保存登录凭据。</p>


## 入金与出金 · 14 Deposits and Withdrawals

<p>算法运行时仍可给关联券商账户出入金；平台每天美东时间 7:45 同步账户现金余额。</p>


## 演示算法 · 15 Demo Algorithm

<p>以下算法演示 Public 的功能：</p>
<div class="section-example-container testable">
<pre><code class="language-csharp">// 中文注释版：仅补充解释，保留原示例的执行语句。&#10;// Demonstrate Public brokerage functionality with an EMA crossover strategy on SPY.&#10;public class PublicDemoAlgorithm : QCAlgorithm&#10;{&#10;    private ExponentialMovingAverage _fast;&#10;    private ExponentialMovingAverage _slow;&#10;&#10;    public override void Initialize()&#10;    {&#10;        // 设置回测开始日期；实盘运行不以此恢复历史状态。&#10;        SetStartDate(2024, 9, 1);&#10;        // 设置回测结束日期。&#10;        SetEndDate(2024, 12, 31);&#10;        // 设置回测初始现金；实盘资金以券商账户和部署配置为准。&#10;        SetCash(100000);&#10;        // 设置券商模型和账户类型，决定资产、订单及现实约束。&#10;        SetBrokerageModel(BrokerageName.Public, AccountType.Margin);&#10;        // 订阅股票行情并取得对应证券。&#10;        var symbol = AddEquity("SPY", Resolution.Daily).Symbol;&#10;        // 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        _fast = EMA(symbol, 10, Resolution.Daily);&#10;        // 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        _slow = EMA(symbol, 50, Resolution.Daily);&#10;    }&#10;&#10;    public override void OnData(Slice slice)&#10;    {&#10;        // 指标准备好后才使用信号，历史样本不足时退出。&#10;        if (!_slow.IsReady) return;&#10;        if (_fast &gt; _slow &amp;&amp; !Portfolio.Invested)&#10;            // 按目标权重调整仓位；1 表示账户权益的 100%，不是买入 1 股。&#10;            SetHoldings("SPY", 1);&#10;        else if (_fast &lt; _slow &amp;&amp; Portfolio.Invested)&#10;            // 请求平仓；实际成交仍取决于市场和券商。&#10;            Liquidate();&#10;    }&#10;}</code></pre>
<pre><code class="language-python"># 中文注释版：仅补充解释，保留原示例的执行语句。&#10;# Demonstrate Public brokerage functionality with an EMA crossover strategy on SPY.&#10;# 定义继承 QCAlgorithm 的策略类，由 LEAN 管理其生命周期。&#10;class PublicDemoAlgorithm(QCAlgorithm):&#10;    # 初始化只在算法开始时运行一次，设置回测条件和数据订阅。&#10;    def initialize(self) -&gt; None:&#10;        # 设置历史回测的开始日期。&#10;        # 设置回测开始日期；实盘运行不以此恢复历史状态。&#10;        self.set_start_date(2024, 9, 1)&#10;        # 设置历史回测的结束日期。&#10;        # 设置回测结束日期。&#10;        self.set_end_date(2024, 12, 31)&#10;        # 设置回测初始资金为 100,000 单位账户货币。&#10;        # 设置回测初始现金；实盘资金以券商账户和部署配置为准。&#10;        self.set_cash(100000)&#10;        # 设置券商模型和账户类型，决定资产、订单及现实约束。&#10;        self.set_brokerage_model(BrokerageName.PUBLIC, AccountType.MARGIN)&#10;        # 订阅股票行情并取得对应证券。&#10;        symbol = self.add_equity("SPY", Resolution.DAILY).symbol&#10;        # 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        self._fast = self.ema(symbol, 10, Resolution.DAILY)&#10;        # 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        self._slow = self.ema(symbol, 50, Resolution.DAILY)&#10;&#10;    # 行情到达时执行；data 包含该时间片可用的数据。&#10;    def on_data(self, slice: Slice) -&gt; None:&#10;        # 指标准备好后才使用信号，历史样本不足时退出。&#10;        if not self._slow.is_ready:&#10;            return&#10;        if self._fast.current.value &gt; self._slow.current.value and not self.portfolio.invested:&#10;            # 按目标权重调整仓位；1 表示账户权益的 100%，不是买入 1 股。&#10;            self.set_holdings("SPY", 1)&#10;        elif self._fast.current.value &lt; self._slow.current.value and self.portfolio.invested:&#10;            # 请求平仓；实际成交仍取决于市场和券商。&#10;            self.liquidate()</code></pre>
</div>


## 部署算法 · 16 Deploy Live Algorithms

<p>每个实盘算法必须有一个可用实盘节点。</p>
<p>按以下步骤部署实盘算法：</p>
<ol>
<li>打开要部署的项目。</li>
<li>点击 Deploy Live（部署实盘）图标。<img alt="Lightning icon" class="inline-icon" src="https://cdn.quantconnect.com/i/tu/deploy-live-icon.png"/></li>
<li>在 Deploy Live 页面点击 Brokerage 字段，从列表选择 Public。</li>
<li>输入 Public secret key 和账户号码。</li><p>生成凭据见 Account Types；QuantConnect 不保存这些账户凭据。</p>
<li>在 Region 区域选择算法运行地区。</li>
<li>点击 Node 字段，选择要使用的实盘节点。</li>
<li>可选：在 Data Provider 区域点击 Show，修改数据源或添加其他数据源。</li>
<p>Public 没有实时数据流，须选择其他行情源；QuantConnect 提供美国股票、股票期权、指数期权、加密货币及 SPX/VIX 标的指数。</p> <li>可选：配置通知。</li>
<li>配置 Automatically restart algorithm（自动重启算法）选项。</li>
<p>开启自动重启后，平台会尽力重启因运行错误而失败的算法，有助于应对券商 API 暂时断线等故障。</p>
<li>点击 Deploy（部署）。</li>
</ol>
<p>部署最多可能需要 5 分钟，完成后显示实盘结果页。可核对运行统计中的权益、现金账簿和持仓，确认券商原有持仓正确载入。</p>
<p>重启、自动重启和重新部署都不会保存算法全部内部状态。恢复哪些状态、其余状态如何持久化，见 State Persistence。</p>


## 部署详情 · 17 Deployment Details

<p>部署 Public 算法时，券商提供交易账户等详情，可区分并行部署和核对目标账户；这些详情不包含凭据。</p>
<p>下表列出 Public 提供的部署详情：</p>
<table class="qc-table table">
<thead>
<tr>
<th>键名</th>
<th>说明</th>
</tr>
</thead>
<tbody>
<tr>
<td><code>public-account-number</code></td>
<td>接收订单的 Public 账户。</td>
</tr>
</tbody>
</table>
<p>算法的 DeploymentDetails/deployment_details 是只读字典，LEAN 在调用 Initialize/initialize 之前填充，因此在算法任何位置都可读取。</p>
<div class="section-example-container">
<pre><code class="language-csharp">// 中文注释版：仅补充解释，保留原示例的执行语句。&#10;// 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;var deploymentDetails = DeploymentDetails.Select(kvp =&gt; $"{kvp.Key}:{kvp.Value}");&#10;Log($"deploymentDetails: {string.Join(", ", deploymentDetails)}");</code></pre>
<pre><code class="language-python"># 中文注释版：仅补充解释，保留原示例的执行语句。&#10;# 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;deployment_details = [f'{kvp.key}:{kvp.value}' for kvp in self.deployment_details]&#10;# 记录常规运行信息，消息写入日志并计入日志额度。&#10;# 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;self.log(f'deployment_details: {deployment_details}')</code></pre>
</div>
<p>也可在算法外通过 /live/read 响应的 deploymentDetails 读取详情。</p>


## 故障排查 · 18 Troubleshooting

<p>下表说明部署 Public 时可能出现的错误：</p>
<table class="table qc-table">
<thead>
<tr>
<th>错误消息（保留英文便于检索）</th>
<th>可能原因与解决方法</th>
</tr>
</thead>
<tbody>
<tr>
<td>
<div class="error-messages">A deposit of $&lt;amount&gt; is required to place this order</div>
</td>
<td>订单所需购买力超过可用额，被券商拒绝，LEAN 发出无效订单事件。消息中的入金额是缺口。应缩小订单，或在保证金账户将 UseMargin/use_margin 设为 true/True 以使用保证金购买力。</td>
</tr>
<tr>
<td>
<div class="error-messages">You can have up to 10 pending orders opening new positions on the same underlying</div>
</td>
<td>Public 每个标的最多允许 10 笔新开仓待成交单，先取消其中一笔或多笔再下新单。</td>
</tr>
<tr>
<td>
<div class="error-messages">Short selling require margin</div>
</td>
<td>包括做空、超出已结算现金买入在内的保证金交易，需账户现金、股票和债券合计至少 2,000 美元。补足资金或避免需要保证金的订单。</td>
</tr>
</tbody>
</table>
<p>仍需帮助时新建支持工单，并附发生错误的部署。</p>

