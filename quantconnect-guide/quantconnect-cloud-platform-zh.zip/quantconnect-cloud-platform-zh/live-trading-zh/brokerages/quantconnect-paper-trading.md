# QuantConnect 模拟交易

非官方中文翻译，按原文小节排列；专有名词、按钮、错误消息和代码字段保留英文对照。费用、IP、权限及产品范围为所标源码版本的记录。各节保留官方链接，代码保留执行语句并添加中文注释。

## 简介 · 01 Introduction

<p>QuantConnect 支持使用实时行情运行实盘模式的算法。</p>
<p>QuantConnect Paper Trading 将实时行情送入算法，以虚拟资金模拟交易，订单不会发往交易所。可先用它检查策略运行情况与回测过拟合问题，无需开立真实券商账户。若未调用 SetBrokerageModel/set_brokerage_model 设置券商模型，默认使用 DefaultBrokerageModel 模拟交易。</p>
<p>模拟交易的实现见 LEAN GitHub 仓库的 PaperBrokerage.cs；回测券商的实现见 BacktestingBrokerage.cs。</p>

## 账户类型 · 02 Account Types

<p>QuantConnect Paper Trading 支持现金账户和保证金账户。算法中的账户类型设置见模拟交易券商模型文档。</p>
<p>向 SetBrokerageModel/set_brokerage_model 传入其他 BrokerageName 后，可用账户类型由新模型决定。</p>


## 资产类别 · 04 Asset Classes

<p>QuantConnect Paper Trading 支持下列资产类别：</p>
<ul>
<li>美国股票</li>
<li>加密货币</li>
<li>外汇</li>
<li>差价合约（CFD）</li>
<li>期货</li>
<li>期货期权</li>
</ul>
<p>使用 DefaultBrokerageModel 之外的模型后，可交易资产由新模型决定。</p>


## 数据馈送 · 05 Data Feeds

<p>只有具有实时数据源的资产才能用于模拟交易。</p>


## 订单 · 06 Orders

<p>下文说明 DefaultBrokerageModel 的订单处理；改用其他券商模型后，订单规则由新模型决定。</p>
<h4>订单类型</h4>
<p>下表列出 DefaultBrokerageModel 对各类资产支持的订单类型：</p>
<table class="qc-table table">
<thead>
<tr>
<th>订单类型</th>
<th>美国股票</th>
<th>加密货币</th>
<th>加密货币期货</th>
<th>外汇</th>
<th>差价合约（CFD）</th>
<th>期货</th>
<th>期货期权</th>
</tr>
</thead>
<tbody>
<tr>
<td>市价单（Market）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>限价单（Limit）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>触价限价单（Limit if touched）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>止损市价单（Stop market）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>止损限价单（Stop limit）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>开盘市价单（Market on open）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td></td>
<td></td>
</tr>
<tr>
<td>收盘市价单（Market on close）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>组合市价单（Combo market）</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>组合限价单（Combo limit）</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>分腿组合限价单（Combo leg limit）</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>期权行权</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
</tbody>
</table>

<p>实盘期权订单需要支持期权的第三方数据源，具体提供商见 Datasets。</p>
<h4>订单有效期</h4>
<p>DefaultBrokerageModel 支持以下 TimeInForce 有效期设置：</p>
<ul>
<li>当日有效（Day / DAY）</li>
<li>撤销前有效（GoodTilCanceled / good_til_canceled）</li>
<li>指定日期前有效（GoodTilDate / good_til_date）</li>
</ul>
<h4>更新订单</h4>
<p>DefaultBrokerageModel 支持更新订单。</p>
<h4>拆股处理</h4>
<p>使用原始价格（Raw）时，如果美国股票拆股，尚未成交订单中的以下属性会自动按拆股比例调整：</p>
<ul>
<li>数量</li>
<li>限价</li>
<li>止损价</li>
<li>触发价</li>
</ul>

## 手续费 · 07 Fees

<p>下表列出 DefaultBrokerageModel 对各资产类别采用的手续费：</p>
<table class="table qc-table">
<thead>
<tr>
<th style="width: 25%">资产类别</th>
<th style="width: 75%">手续费</th>
</tr>
</thead>
<tbody>
<tr>
<td>股票</td>
<td>每股 0.005 美元，每笔最低 1 美元</td>
</tr>
<tr>
<td>加密货币</td>
<td>$0</td>
</tr>
<tr>
<td>外汇</td>
<td>$0</td>
</tr>
<tr>
<td>差价合约</td>
<td>$0</td>
</tr>
<tr>
<td>期货</td>
<td>每份合约 1.85 美元</td>
</tr>
<tr>
<td>期货期权</td>
<td>每份合约 1.85 美元</td>
</tr>
</tbody>
</table>
<p>期权行权不收手续费。</p>
<p>使用其他券商模型时，手续费由新模型决定。</p>
<p>DefaultBrokerageModel 使用的手续费模型见 Fees。</p>

## 保证金 · 08 Margin

<p>平台模拟购买力和追加保证金，帮助算法遵守保证金要求；更换券商模型后，保证金规则由新模型决定。</p>


## 滑点 · 09 Slippage

<p>DefaultBrokerageModel 的回测和模拟交易均不计滑点，具体模型见 Slippage。</p>


## 成交 · 10 Fills

<p>DefaultBrokerageModel 会立即、全部成交市价单；若有买卖报价，则按买卖价差确定成交价格。</p>
<p>真实成交模拟方式见 Fills。</p>


## 结算 · 11 Settlements

<p>保证金账户的交易即时结算。（原模板此处仅输出这一分支；现金账户规则应结合券商结算说明核对。）</p>
<p>模拟交易的结算模型见 Settlement。</p>


## 券商模型 · 12 Brokerage Models

<p>QuantConnect Paper Trading 默认使用 DefaultBrokerageModel，也可以选择其他券商模型。</p>


## 入金与出金 · 13 Deposits and Withdrawals

<p>QuantConnect Paper Trading 支持入金和出金。</p>
<div class="section-example-container">
<pre><code class="language-csharp">// 中文注释版：仅补充解释，保留原示例的执行语句。&#10;// Deposit 100 units of account currency and withdraw 1 ETH.&#10;Porfolio.CashBook.Add(AccountCurrency, 100);&#10;Porfolio.CashBook.Add("ETH", -1);</code></pre>
<pre><code class="language-python"># 中文注释版：仅补充解释，保留原示例的执行语句。&#10;# Deposit 100 units of account currency and withdraw 1 ETH.&#10;self.porfolio.cash_book.add(self.account_currency, 100)&#10;self.porfolio.cash_book.add("ETH", -1)</code></pre>
</div>


## 演示算法 · 14 Demo Algorithm

<p>以下算法演示 QuantConnect Paper Trading 的功能：</p>
<div class="section-example-container testable">
<pre><code class="language-csharp">// 中文注释版：仅补充解释，保留原示例的执行语句。&#10;// Demonstrate QuantConnect Paper Trading brokerage functionality with an EMA crossover strategy on SPY.&#10;public class QuantConnectPaperTradingDemoAlgorithm : QCAlgorithm&#10;{&#10;    private ExponentialMovingAverage _fast;&#10;    private ExponentialMovingAverage _slow;&#10;&#10;    public override void Initialize()&#10;    {&#10;        // 设置回测开始日期；实盘运行不以此恢复历史状态。&#10;        SetStartDate(2024, 9, 1);&#10;        // 设置回测结束日期。&#10;        SetEndDate(2024, 12, 31);&#10;        // 设置回测初始现金；实盘资金以券商账户和部署配置为准。&#10;        SetCash(100000);&#10;        // 设置券商模型和账户类型，决定资产、订单及现实约束。&#10;        SetBrokerageModel(BrokerageName.QuantConnectBrokerage, AccountType.Margin);&#10;        // 订阅股票行情并取得对应证券。&#10;        var symbol = AddEquity("SPY", Resolution.Daily).Symbol;&#10;        // 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        _fast = EMA(symbol, 10, Resolution.Daily);&#10;        // 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        _slow = EMA(symbol, 50, Resolution.Daily);&#10;    }&#10;&#10;    public override void OnData(Slice slice)&#10;    {&#10;        // 指标准备好后才使用信号，历史样本不足时退出。&#10;        if (!_slow.IsReady) return;&#10;        if (_fast &gt; _slow &amp;&amp; !Portfolio.Invested)&#10;            // 按目标权重调整仓位；1 表示账户权益的 100%，不是买入 1 股。&#10;            SetHoldings("SPY", 1);&#10;        else if (_fast &lt; _slow &amp;&amp; Portfolio.Invested)&#10;            // 请求平仓；实际成交仍取决于市场和券商。&#10;            Liquidate();&#10;    }&#10;}</code></pre>
<pre><code class="language-python"># 中文注释版：仅补充解释，保留原示例的执行语句。&#10;# Demonstrate QuantConnect Paper Trading brokerage functionality with an EMA crossover strategy on SPY.&#10;# 定义继承 QCAlgorithm 的策略类，由 LEAN 管理其生命周期。&#10;class QuantConnectPaperTradingDemoAlgorithm(QCAlgorithm):&#10;    # 初始化只在算法开始时运行一次，设置回测条件和数据订阅。&#10;    def initialize(self) -&gt; None:&#10;        # 设置历史回测的开始日期。&#10;        # 设置回测开始日期；实盘运行不以此恢复历史状态。&#10;        self.set_start_date(2024, 9, 1)&#10;        # 设置历史回测的结束日期。&#10;        # 设置回测结束日期。&#10;        self.set_end_date(2024, 12, 31)&#10;        # 设置回测初始资金为 100,000 单位账户货币。&#10;        # 设置回测初始现金；实盘资金以券商账户和部署配置为准。&#10;        self.set_cash(100000)&#10;        # 设置券商模型和账户类型，决定资产、订单及现实约束。&#10;        self.set_brokerage_model(BrokerageName.QUANT_CONNECT_BROKERAGE, AccountType.MARGIN)&#10;        # 订阅股票行情并取得对应证券。&#10;        symbol = self.add_equity("SPY", Resolution.DAILY).symbol&#10;        # 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        self._fast = self.ema(symbol, 10, Resolution.DAILY)&#10;        # 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        self._slow = self.ema(symbol, 50, Resolution.DAILY)&#10;&#10;    # 行情到达时执行；data 包含该时间片可用的数据。&#10;    def on_data(self, slice: Slice) -&gt; None:&#10;        # 指标准备好后才使用信号，历史样本不足时退出。&#10;        if not self._slow.is_ready:&#10;            return&#10;        if self._fast.current.value &gt; self._slow.current.value and not self.portfolio.invested:&#10;            # 按目标权重调整仓位；1 表示账户权益的 100%，不是买入 1 股。&#10;            self.set_holdings("SPY", 1)&#10;        elif self._fast.current.value &lt; self._slow.current.value and self.portfolio.invested:&#10;            # 请求平仓；实际成交仍取决于市场和券商。&#10;            self.liquidate()</code></pre>
</div>

## 部署算法 · 15 Deploy Live Algorithms

<p>每个实盘算法必须有一个可用实盘节点。</p>
<p>按以下步骤部署实时行情驱动的模拟算法：</p>
<ol>
<li>打开要部署的项目。</li>
<li>点击 Deploy Live（部署实盘）图标。<img alt="Deploy live icon" class="inline-icon" src="https://cdn.quantconnect.com/i/tu/deploy-live-icon.png"/></li>
<li>在 Deploy Live 的 Brokerage 选择 Paper Trading。</li>
<li>在 Region 区域选择算法运行地区。</li>
<li>点击 Node 字段，选择要使用的实盘节点。</li>
<li>可选：在 Data Provider 区域点击 Show，修改数据源或添加其他数据源。</li>
<li>可选：按下列步骤设置算法初始现金（有演示视频）：</li>
<ol>
<li>在 Algorithm Cash State 点击 Show。</li>
<li>点击 Add Currency。</li>
<li>填写币种代码（如 USD 或 BTC）和数量。</li>
</ol>
<li>可选：按下列步骤设置算法初始持仓（有演示视频）：</li>
<ol>
<li>在 Algorithm Holdings State 点击 Show。</li>
<li>点击 Add Holding。</li>
<li>填写 Symbol ID、代码、数量和平均价格。</li>
</ol>
<li>可选：配置通知。</li>
<li>配置 Automatically restart algorithm（自动重启算法）选项。</li>
<p>开启自动重启后，平台会尽力重启因运行错误而失败的算法，有助于应对券商 API 暂时断线等故障。</p>
<li>点击 Deploy（部署）。</li>
</ol>
<p>部署最多可能需要 5 分钟，完成后显示实盘结果页。可核对运行统计中的权益、现金账簿和持仓，确认券商原有持仓正确载入。</p>
<p>重启、自动重启和重新部署都不会保存算法全部内部状态。恢复哪些状态、其余状态如何持久化，见 State Persistence。</p>

