# Bloomberg EMSX

非官方中文翻译，按原文小节排列；专有名词、按钮、错误消息和代码字段保留英文对照。费用、IP、权限及产品范围为所标源码版本的记录。各节保留官方链接，代码保留执行语句并添加中文注释。

## 简介 · 01 Introduction

<p>QuantConnect 支持使用实时行情运行实盘模式的算法。</p>
<img alt="Terminal link icon" class="docs-image" src="https://cdn.quantconnect.com/i/tu/terminal-link-logo.svg" style="width: 50%"/>
<p>QuantConnect 可在不同环境集成 Bloomberg Server API（SAPI）或 Desktop API（DAPI），用于研究、回测、优化和实盘。Terminal Link 是独立附加组件，未获 Bloomberg 关联或背书。组织添加后可接入 EMSX 网络中的 1,300 多家主经纪商。</p>
<p>QuantConnect Cloud 只支持通过 Bloomberg SAPI 路由订单，目标可为其支持的主经纪商，云端数据和服务器由 QuantConnect 管理。需加入 Trading Firm 或 Institution 套餐组织。</p>


## 账户类型 · 02 Account Types

<p>Terminal Link 通过 EMSX 路由订单，类似 FIX 保证金账户；部署至专业主经纪商时在向导设置购买力。</p>


## 资产类别 · 04 Asset Classes

<p>Terminal Link 支持以下资产：</p>
<ul>
<li>股票</li>
<li>股票期权</li>
<li>指数期权</li>
<li>期货</li>
</ul>

## 数据源 · 05 Data Providers

<p>此处 Bloomberg SAPI 连接不提供数据，推荐免费的 QuantConnect 数据源，覆盖美国股票、股票期权、指数期权、期货及 SPX/VIX 指数。详见 Datasets。</p>
<p>这一限制适用于通过 SAPI 的 QuantConnect Cloud。本地部署用 DAPI，可在 Bloomberg 许可范围内读取终端实时和历史数据；日内历史最多 6 个月，不提供历史未平仓量和自定义数据。详见 Terminal Link。</p>


## 订单 · 06 Orders

<p>Terminal Link 可创建与管理 Bloomberg 订单。</p>
<h4>订单类型</h4>
<p>下表列出 Terminal Link 对各资产支持的订单：</p>
<table class="qc-table table">
<thead>
<tr>
<th>订单类型</th>
<th>股票</th>
<th>股票期权</th>
<th>指数期权</th>
<th>期货</th>
</tr>
</thead>
<tbody>
<tr>
<td>市价单（Market）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>开盘市价单（Market on open）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>限价单（Limit）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>止损市价单（Stop market）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>止损限价单（Stop limit）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
</tbody>
</table>

<h4>订单属性</h4>
<p>下表为 Bloomberg EMSX API 的自定义订单属性，可用 TerminalLinkOrderProperties 设置。</p>
<table class="table qc-table">
<thead>
<tr>
<th style="width: 18%">属性</th>
<th style="width: 17%">数据类型</th>
<th style="width: 45%">说明</th>
<th style="width: 20%">默认值</th>
</tr>
</thead>
<tbody>
<tr>
<td><code class="csharp">TimeInForce</code><code class="python">time_in_force</code></td>
<td><code>TimeInForce</code></td>
<td>A <a href="https://www.quantconnect.com/docs/v2/writing-algorithms/trading-and-orders/order-properties#03-Time-In-Force">TimeInForce</a>为订单设置有效期，支持以下取值：<ul>
<li>当日有效（Day / DAY）</li>
<li><code class="csharp">GoodTilCanceled</code><code class="python">GOOD_TIL_CANCELED</code></li>
<li>指定日期前有效（GoodTilDate / good_til_date）</li>
</ul>
</td>
<td><code class="csharp">TimeInForce.GoodTilCanceled</code><code class="python">TimeInForce.GOOD_TIL_CANCELED</code></td>
</tr>
<tr>
<td><code class="csharp">Notes</code><code class="python">notes</code></td>
<td><code class="csharp">string</code><code class="python">str</code></td>
<td>发送给经纪商的自由格式指令。</td>
<td></td>
</tr>
<tr>
<td><code class="csharp">HandlingInstruction</code><code class="python">handling_instruction</code></td>
<td><code class="csharp">string</code><code class="python">str</code></td>
<td>订单/路由处理指令，可使用预配置值或经纪商自定义值。</td>
<td></td>
</tr>
<tr>
<td><code class="csharp">CustomNotes1</code><code class="python">custom_notes_1</code></td>
<td><code class="csharp">string</code><code class="python">str</code></td>
<td>自定义订单备注 1，格式见 EMSX 的 Custom Notes &amp; Free Text Fields。</td>
<td></td>
</tr>
<tr>
<td><code class="csharp">CustomNotes2</code><code class="python">custom_notes_2</code></td>
<td><code class="csharp">string</code><code class="python">str</code></td>
<td>自定义订单备注 2。</td>
<td></td>
</tr>
<tr>
<td><code class="csharp">CustomNotes3</code><code class="python">custom_notes_3</code></td>
<td><code class="csharp">string</code><code class="python">str</code></td>
<td>自定义订单备注 3。</td>
<td></td>
</tr>
<tr>
<td><code class="csharp">CustomNotes4</code><code class="python">custom_notes_4</code></td>
<td><code class="csharp">string</code><code class="python">str</code></td>
<td>自定义订单备注 4。</td>
<td></td>
</tr>
<tr>
<td><code class="csharp">CustomNotes5</code><code class="python">custom_notes_5</code></td>
<td><code class="csharp">string</code><code class="python">str</code></td>
<td>自定义订单备注 5。</td>
<td></td>
</tr>
<tr>
<td><code class="csharp">Account</code><code class="python">account</code></td>
<td><code class="csharp">string</code><code class="python">str</code></td>
<td>EMSX 账户。</td>
<td></td>
</tr>
<tr>
<td><code class="csharp">Broker</code><code class="python">broker</code></td>
<td><code class="csharp">string</code><code class="python">str</code></td>
<td>EMSX 经纪商代码。</td>
<td></td>
</tr>
<tr>
<td><code class="csharp">LocateBroker</code><code class="python">locate_broker</code></td>
<td><code class="csharp">string</code><code class="python">str</code></td>
<td>股票卖空的借券对手方代码，例如 BMTB，对应交易票据 LocBrkr。卖空时设置本属性或 LocateId/locate_id，会同时发送 EMSX_LOCATE_REQ="Y"。</td>
<td></td>
</tr>
<tr>
<td><code class="csharp">LocateId</code><code class="python">locate_id</code></td>
<td><code class="csharp">string</code><code class="python">str</code></td>
<td>借券经纪商提供的 locate 确认/票据 ID，对应 EMSX 的 LocId。</td>
<td></td>
</tr>
<tr>
<td><code class="csharp">IsCfdTrade</code><code class="python">is_cfd_trade</code></td>
<td><code>bool</code></td>
<td>将订单记为 CFD 而非普通交易，对应 Booking Type 的 CFD，设置 EMSX_CFD_FLAG。该标志按订单而非证券生效；普通交易是默认值，只有 true/True 时发送。</td>
<td><code class="csharp">false</code><code class="python">False</code></td>
</tr>
<tr>
<td><code class="csharp">Strategy</code><code class="python">strategy</code></td>
<td><code>StrategyParameters</code></td>
<td>EMSX 策略详情对象，参数必须按 API 预期顺序添加。支持 DMA、DESK、VWAP、TWAP、FLOAT、HIDDEN、VOLUMEINLINE、CUSTOM、TAP、CUSTOM2、WORKSTRIKE、TAPNOW、TIMED、LIMITTICK、STRIKE。</td>
</tr>
<tr>
<td><code class="csharp">ExecutionInstruction</code><code class="python">execution_instruction</code></td>
<td><code class="csharp">string</code><code class="python">str</code></td>
<td>执行指令字段。</td>
<td></td>
</tr>
<tr>
<td><code class="csharp">AutomaticPositionSides</code><code class="python">automatic_position_sides</code></td>
<td><code>bool</code></td>
<td>是否自动在买卖方向中包含开平仓信息（如买入开仓/卖出平仓），代替普通 buy/sell。</td>
<td></td>
</tr>
<tr>
<td><code class="csharp">PositionSide</code><code class="python">position_side</code></td>
<td><code class="csharp">OrderPosition?</code><code class="python">OrderPosition/NoneType</code></td>
<td>显式指定开平仓方向的 OrderPosition 对象，优先级高于 AutomaticPositionSides/automatic_position_sides。</td>
<td></td>
</tr>
<tr>
<td><code class="csharp">Exchange</code><code class="python">exchange</code></td>
<td>交易所</td>
<td>订单发送目标交易所名称。</td>
<td></td>
</tr>
<tr>
<td><code class="csharp">AdditionalProperties</code><code class="python">additional_properties</code></td>
<td><code class="csharp">BaseExtendedDictionary&lt;string, string&gt;</code><code class="python">BaseExtendedDictionary[str, str]</code></td>
<td>额外 EMSX 元素字典，键为元素名、值为元素值。专用属性优先，同名字典项不生效；未在 EMSX Schema 定义的项会跳过，不会因此拒单。</td>
<td>空字典</td>
</tr>
</tbody>
</table>

<p>AdditionalProperties/additional_properties 可设置尚无专用属性的 EMSX 元素。IsCfdTrade/is_cfd_trade 实际读写该字典的 EMSX_CFD_FLAG，两者等价。示例把订单标为 CFD，并添加尚无专用属性的零股元素。</p>
<p class="python">字典初始为空，不能直接替换成普通 Python dict。批量添加用 update，清空用 clear。</p>
<p>API 格式见 EMSX 的 Create Order and Route Extended Request，以及 MathWorks 的 createOrderAndRouteWithStrat。</p>
<h4>获取未完成订单</h4>
<p>Terminal Link 支持访问未完成订单。</p>
<h4>监测成交</h4>
<p>通过订单事件监测成交过程。</p>
<h4>更新订单</h4>
<p>Terminal Link 不支持直接改单，可先撤单再按新参数提交，详见对应替代方案。</p>
<h4>撤单</h4>
<p>Terminal Link 可以取消未完成订单。</p>
<h4>拆股处理</h4>
<p>使用原始价格（Raw）时，如果美国股票拆股，尚未成交订单中的以下属性会自动按拆股比例调整：</p>
<ul>
<li>数量</li>
<li>限价</li>
<li>止损价</li>
<li>触发价</li>
</ul>
<h4>券商端提交的订单</h4>
<p>算法默认不记录绕过 LEAN、由第三方直接向账户提交的订单；如需接收，创建自定义 brokerage message handler。</p>


## 手续费 · 07 Fees

<p>成交需支付 Bloomberg EMSX 及目标主经纪商费用；平台费用模型见 Fees。</p>


## 保证金 · 08 Margin

<p>部署至 EMSX 时在向导填写现金与持仓，平台据此模拟购买力和追加保证金。</p>


## 成交 · 09 Fills

<p>实盘中，LEAN 将订单路由至所选交易所或主经纪商，再接收成交结果。</p>
<p>EMSX 成交模型见 Fills。</p>


## 使用许可与合规要求 · 10 Compliance

<p>Bloomberg 与 QuantConnect 无关联且不背书 Terminal Link。使用需 SAPI 与 EMSX 权限，以及 QuantConnect Trading Firm 或 Institution 订阅。</p>
<p>以下规则适用：</p>
<ul>
<li>所有集成用户必须拥有 Bloomberg License，成为 Entitled User。</li>
<li>此 SAPI 连接只用于订单路由，不允许用于取数据，也不可用于 black-box trading；需符合 Bloomberg 许可规则。</li>
</ul>
<p>下表列出各 Bloomberg 技术支持的用途：</p>
<table class="qc-table table">
<thead>
<tr>
<th style="width: 20%;">技术</th>
<th style="width: 20%;">研究</th>
<th style="width: 20%;">回测</th>
<th style="width: 20%;">模拟/UAT 测试交易</th>
<th style="width: 20%;">实盘交易</th>
</tr>
</thead>
<tbody>
<tr>
<td>服务器 API</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
</tbody>
</table>



## 配置 SAPI · 11 Set Up SAPI

<p>下文说明下载 SAPI、安装到云服务器和配置防火墙，以连接 QuantConnect Cloud。</p>
<h4>下载 SAPI</h4>
<p>按以下步骤下载：</p>
<ol>
<li>安装 Bloomberg Terminal。</li>
<li>创建 Bloomberg Terminal 账户。</li>
<li>在终端运行 WAPI&lt;GO&gt;。</li>
<li>在 API Developer's Help Site 点击 EMSX API。</li>
<img class="docs-image" src="https://cdn.quantconnect.com/i/tu/bbg-sapi-1.png"/>
<li>在 EMSX API 页的 Server API Process 区域点击 Link。</li>
<img class="docs-image" src="https://cdn.quantconnect.com/i/tu/bbg-sapi-2.png"/>
<li>在 Server API Software Install 选择正确的下载图标。</li>
<img class="docs-image" src="https://cdn.quantconnect.com/i/tu/bbg-sapi-3.png"/>
<li>点击 System Requirements。</li>
<img class="docs-image" src="https://cdn.quantconnect.com/i/tu/bbg-sapi-4.png"/>
</ol>
<h4>安装 SAPI</h4>
<p>按以下步骤安装：</p>
<ol>
<li>启动由组织控制、原文记为 E12x9 或更高的 AWS 实例。（该规格标记需结合 Bloomberg 当前要求确认。）</li>
<li>在云服务器运行 SAPI 安装程序。</li>
<p>详细步骤见 EMSX Programmers Guide 的 How to install serverapi.exe；安装完成后会取得 registration key。</p>
<li>联系 Bloomberg Support 激活注册 key。</li>
<li>启动 serverapi 程序。</li>
<p>Windows 默认路径为 C:\BLP\ServerApi\bin\serverapi.exe。</p>
</ol>
<h4>设置账户</h4>
<p>按以下步骤配置 SAPI 账户：</p>
<ol>
<li>请 Bloomberg Support 启用 Server Side EMSX API。</li>
<li>向其索取唯一用户标识 UUID。</li>
<p>妥善保存 UUID，实盘部署时需要。</p>
<li>联系目标 EMSX 经纪商并提供 UUID。</li>
</ol>
<h4>添加防火墙规则</h4>
<p>按以下步骤配置 AWS 防火墙，使 SAPI 能连接 QuantConnect Cloud：</p>
<ol>
<li>点击 Start。</li>
<li>输入 Windows Defender Firewall with Advanced Security 并按 Enter。</li>
<li>左侧点击 Inbound Rules。</li>
<li>右侧点击 New Rule...。</li>
<li>按向导为 serverapi 建立程序规则。</li>
<li>在高级安全防火墙窗口双击 serverapi 行。</li>
<li>在 serverapi 窗口点击 Scope。</li>
<li>在 Remote IP address 中加入 QuantConnect Cloud IP：207.182.16.137。</li>
<li>点击 OK。</li>
<li>表内另一个 serverapi 规则也添加该 IP。</li>
</ol>


## 部署算法 · 12 Deploy Live Algorithms

<p>通过 Terminal Link 部署云端算法前，先完成 Bloomberg SAPI 配置。</p>
<p>每个实盘算法必须有一个可用实盘节点。</p>
<p>按以下步骤部署实盘算法：</p>
<ol>
<li>打开要部署的项目。</li>
<li>点击 Deploy Live（部署实盘）图标。<img alt="Lightning icon" class="inline-icon" src="https://cdn.quantconnect.com/i/tu/deploy-live-icon.png"/></li>
<li>在 Deploy Live 的 Brokerage 中选择 Terminal Link。</li>
<li>Connection Type 选择 SAPI。</li>
<li>Server Auth Id 填写 UUID。</li>
<p>UUID 是每个 Bloomberg Anywhere 用户独有的整数标识，不清楚时联系 Bloomberg。</p>
<li>EMSX Broker 填写目标经纪商。</li>
<li>Server Port 填写 SAPI 监听端口。</li>
<p>默认端口为 8194。</p>
<li>Server Host 填写 SAPI AWS 服务器公网 IP。</li>
<li>EMSX Account 填写 LEAN 订单目标账户。</li>
<li>EMSX Team 填写团队账户以接收团队订单事件。</li>
<p>默认空值表示忽略团队通知。</p>
<li>OpenFIGI Api Key 填写对应 key。</li>
<li>点击 Environment，选择目标环境。</li> <li>在 Region 区域选择算法运行地区。</li>
<li>点击 Node 字段，选择要使用的实盘节点。</li>
<li>可选：在 Data Provider 区域点击 Show，修改数据源或添加其他数据源。</li>
<li>账户已有现金时，按以下步骤填写（有演示视频）：</li>
<ol>
<li>在 Algorithm Cash State 点击 Show。</li>
<li>点击 Add Currency。</li>
<li>填写币种代码（如 USD/CAD）及数量。</li>
</ol>
<li>账户已有持仓时，按以下步骤填写（有演示视频）：</li>
<ol>
<li>在 Algorithm Holdings State 点击 Show。</li>
<li>点击 Add Holding。</li>
<li>填写 Symbol ID、代码、数量和平均价格。</li>
</ol>
<li>可选：配置通知。</li>
<li>配置 Automatically restart algorithm（自动重启算法）选项。</li>
<p>开启自动重启后，平台会尽力重启因运行错误而失败的算法，有助于应对券商 API 暂时断线等故障。</p>
<li>点击 Deploy（部署）。</li>
</ol>
<p>部署最多可能需要 5 分钟，完成后显示实盘结果页。可核对运行统计中的权益、现金账簿和持仓，确认券商原有持仓正确载入。</p>
<p>重启、自动重启和重新部署都不会保存算法全部内部状态。恢复哪些状态、其余状态如何持久化，见 State Persistence。</p>


## 部署详情 · 13 Deployment Details

<p>Terminal Link 提供账户等部署详情，用于区分并行部署和核对交易账户；不包含凭据。</p>
<p>下表为 Terminal Link 部署详情：</p>
<table class="qc-table table">
<thead>
<tr>
<th>键名</th>
<th>说明</th>
</tr>
</thead>
<tbody>
<tr>
<td><code>terminal-link-server-auth-id</code></td>
<td>Server Auth Id，即 Bloomberg Anywhere 用户 UUID。</td>
</tr>
<tr>
<td><code>terminal-link-emsx-broker</code></td>
<td>接收订单的 EMSX 经纪商。</td>
</tr>
<tr>
<td><code>terminal-link-emsx-account</code></td>
<td>LEAN 路由订单的 EMSX 账户。</td>
</tr>
<tr>
<td><code>terminal-link-emsx-team</code></td>
<td>接收团队订单事件的 EMSX 团队账户；未设置则为空。</td>
</tr>
</tbody>
</table>
<p>算法的 DeploymentDetails/deployment_details 是只读字典，LEAN 在调用 Initialize/initialize 之前填充，因此在算法任何位置都可读取。</p>
<div class="section-example-container">
<pre><code class="language-csharp">// 中文注释版：仅补充解释，保留原示例的执行语句。&#10;// 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;var deploymentDetails = DeploymentDetails.Select(kvp =&gt; $"{kvp.Key}:{kvp.Value}");&#10;Log($"deploymentDetails: {string.Join(", ", deploymentDetails)}");</code></pre>
<pre><code class="language-python"># 中文注释版：仅补充解释，保留原示例的执行语句。&#10;# 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;deployment_details = [f'{kvp.key}:{kvp.value}' for kvp in self.deployment_details]&#10;# 记录常规运行信息，消息写入日志并计入日志额度。&#10;# 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;self.log(f'deployment_details: {deployment_details}')</code></pre>
</div>
<p>也可在算法外通过 /live/read 响应的 deploymentDetails 读取详情。</p>

