# Bybit

非官方中文翻译，按原文小节排列；专有名词、按钮、错误消息和代码字段保留英文对照。费用、IP、权限及产品范围为所标源码版本的记录。各节保留官方链接，代码保留执行语句并添加中文注释。

## 简介 · 01 Introduction

<p>QuantConnect 支持使用实时行情运行实盘模式的算法。</p>
<p>Bybit 由 Ben Zhou 于 2018 年 3 月联合创立，定位为提供快速撮合、客户服务与多语言支持的加密交易平台，为非禁止地区用户提供现货及期货。开户最低入金较低，具体法币/加密入金要求见官网；另有质押、DEX 首发和空投服务。</p>
<p>集成实现见 Lean.Brokerages.Bybit 仓库。</p>

## 账户类型 · 02 Account Types

<p>Bybit 支持现金和保证金账户；算法设置方式见对应券商模型文档。</p>
<h4>创建账户</h4>
<p>按 Bybit 官网 How to Register an Account 教程开户。</p>
<p>部署需 API 凭据；开户后生成、妥善保存，并配置如下：</p>
<ul>
<li>API Key Usage 选择 API Transaction。</li>
<li>为 API key 命名。</li>
<li>API Key Permissions 选择 Read-Write。</li>
<li>勾选 Only IPs with permissions granted are allowed to access the OpenAPI，添加 146.59.85.21、57.128.231.46 和 57.128.233.143。</li>
<li>勾选 Unified Trading。</li>
<p>Unified Trading 为以下操作开启读写权限：
<ul>
<li>订单</li>
<li>持仓</li>
<li>交易</li>
</ul>
</p></ul>
<h4>模拟交易</h4>
<p>Bybit 的 Demo Trading 和 Testnet 都支持模拟；各环境使用独立 API 凭据，不能复用真实账户密钥。</p>
<p>Demo Trading 配置步骤：</p>
<ol>
<li>登录 Bybit 账户。</li>
<li>从账户菜单切换到 Demo Trading。</li>
<li>在 Demo Trading 中创建并保存独立 API 凭据。</li>
</ol>
<p>Testnet 配置步骤：</p>
<ol>
<li>登录 Bybit Testnet。</li>
<li>在测试网创建并保存独立 API 凭据。</li>
</ol>


## 资产类别 · 04 Asset Classes

<p>本集成支持加密现货与加密期货。</p>


## 数据源 · 05 Data Providers

<p>QuantConnect 数据源提供实时加密货币行情。</p>
<p>Binance 与 Bybit 限制从美国访问，交易和接收行情均需选择 Europe (WAW) 地区。</p>
<p>地区设置见 Deploy Live Algorithms。</p>


## 订单 · 06 Orders

<p>平台对 Bybit API 的订单类型、属性和更新进行建模；实盘部署后也可通过 IDE 手动下单。</p>
<h4>订单类型</h4>
<p>下表列出本集成对各资产支持的订单类型：</p>
<table class="qc-table table">
<thead>
<tr>
<th style="width: 50%">订单类型</th>
<th>加密货币</th>
<th>加密货币期货</th>
</tr>
</thead>
<tbody>
<tr>
<td>市价单（Market）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>限价单（Limit）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>止损市价单（Stop market）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
<tr>
<td>止损限价单（Stop limit）</td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
<td><img alt="支持" src="https://cdn.quantconnect.com/i/tu/check.png" title="支持" width="15px;"/></td>
</tr>
</tbody>
</table>

<h4>订单属性</h4>
<p>下表为 Bybit API 的自定义订单属性，可用 BybitBrokerageModel 设置。</p>
<table class="table qc-table">
<thead>
<tr>
<th>属性</th>
<th>数据类型</th>
<th>说明</th>
<th>默认值</th>
</tr>
</thead>
<tbody>
<tr>
<td><code class="csharp">TimeInForce</code><code class="python">time_in_force</code></td>
<td><code>TimeInForce</code></td>
<td>
             A <a href="https://www.quantconnect.com/docs/v2/writing-algorithms/trading-and-orders/order-properties#03-Time-In-Force">TimeInForce</a>为订单设置有效期，支持以下取值：<ul>
<li>当日有效（Day / DAY）</li>
<li><code class="csharp">GoodTilCanceled</code><code class="python">GOOD_TIL_CANCELED</code></li>
<li>指定日期前有效（GoodTilDate / good_til_date）</li>
</ul>
<td><code class="csharp">TimeInForce.GoodTilCanceled</code><code class="python">TimeInForce.GOOD_TIL_CANCELED</code></td>
</td>
</tr>
<tr>
<td><code class="csharp">PostOnly</code><code class="python">post_only</code></td>
<td><code>bool</code></td>
<td>仅限限价单：只提供流动性；若任何部分会吃单，整单拒绝且不部分成交。</td>
<td></td>
</tr>
<tr>
<td><code class="csharp">ReduceOnly</code><code class="python">reduce_only</code></td>
<td><code class="csharp">bool?</code><code class="python">bool/NoneType</code></td>
<td>只允许减少当前仓位的标志，详见券商 Reduce-Only Order。</td>
<td></td>
</tr>
</tbody>
</table>
<h4>更新订单</h4>
<p>本集成支持更新处于以下状态的加密期货订单：</p>
<ul>
<li><code class="csharp">OrderStatus.New</code><code class="python">OrderStatus.NEW</code></li>
<li><code class="csharp">OrderStatus.PartiallyFilled</code><code class="python">OrderStatus.PARTIALLY_FILLED</code></li>
<li><code class="csharp">OrderStatus.Submitted</code><code class="python">OrderStatus.SUBMITTED</code></li>
<li>OrderStatus.UpdateSubmitted / OrderStatus.FILLED（原表这两个名称不一致，不能当作等价枚举；应核对当前 LEAN OrderStatus 定义。）</li>
</ul>
<p>不能直接改单时，可先撤单再按新参数提交，详见不支持订单更新的券商替代方案。</p>


## 手续费 · 07 Fees

<p>Bybit 费用见 Trading Fees Schedule；平台模型见 Fees。</p>


## 保证金 · 08 Margin

<p>平台模拟购买力和追加保证金，帮助算法遵守保证金要求。</p>


## 滑点 · 09 Slippage

<p>Bybit 回测不计滑点；Bybit 模拟与实盘订单可能产生滑点。</p>
<p>Bybit 滑点模型见 Slippage。</p>

## 成交 · 10 Fills

<p>回测中 QuantConnect 立即、全部成交市价单。Bybit 模拟和实盘中，若数量超过盘口最优档可用数量，会按订单簿实际流动性成交。</p>
<p>Bybit 成交模型见 Fills。</p>

## 结算 · 11 Settlements

<p>交易后立即结算。</p>
<p>Bybit 结算模型见 Settlement。</p>


## 安全与稳定性 · 12 Security and Stability


<p>通过 Bybit 部署时，平台不保存登录凭据。</p>


## 入金与出金 · 13 Deposits and Withdrawals

<p>算法运行时仍可给关联券商账户出入金；平台每天美东时间 7:45 同步账户现金余额。</p>


## 演示算法 · 14 Demo Algorithm

<p>以下算法演示 Bybit 的功能：</p>
<div class="section-example-container testable">
<pre><code class="language-csharp">// 中文注释版：仅补充解释，保留原示例的执行语句。&#10;// Demonstrate Bybit brokerage functionality with an EMA crossover strategy.&#10;public class BybitDemoAlgorithm : QCAlgorithm&#10;{&#10;    private Symbol _symbol;&#10;    private ExponentialMovingAverage _fast;&#10;    private ExponentialMovingAverage _slow;&#10;&#10;    public override void Initialize()&#10;    {&#10;        // 设置回测开始日期；实盘运行不以此恢复历史状态。&#10;        SetStartDate(2024, 9, 1);&#10;        // 设置回测结束日期。&#10;        SetEndDate(2024, 12, 31);&#10;        // 设置回测初始现金；实盘资金以券商账户和部署配置为准。&#10;        SetCash(100000);&#10;        // 设置券商模型和账户类型，决定资产、订单及现实约束。&#10;        SetBrokerageModel(BrokerageName.Bybit, AccountType.Cash);&#10;        // 订阅指定市场的加密货币对。&#10;        _symbol = AddCrypto("BTCUSDT", Resolution.Daily, Market.Bybit).Symbol;&#10;        // 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        _fast = EMA(_symbol, 10, Resolution.Daily);&#10;        // 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        _slow = EMA(_symbol, 50, Resolution.Daily);&#10;    }&#10;&#10;    public override void OnData(Slice slice)&#10;    {&#10;        // 指标准备好后才使用信号，历史样本不足时退出。&#10;        if (!_slow.IsReady) return;&#10;        if (_fast &gt; _slow &amp;&amp; !Portfolio.Invested)&#10;            // 按目标权重调整仓位；1 表示账户权益的 100%，不是买入 1 股。&#10;            SetHoldings(_symbol, 1);&#10;        else if (_fast &lt; _slow &amp;&amp; Portfolio.Invested)&#10;            // 请求平仓；实际成交仍取决于市场和券商。&#10;            Liquidate();&#10;    }&#10;}</code></pre>
<pre><code class="language-python"># 中文注释版：仅补充解释，保留原示例的执行语句。&#10;# Demonstrate Bybit brokerage functionality with an EMA crossover strategy.&#10;# 定义继承 QCAlgorithm 的策略类，由 LEAN 管理其生命周期。&#10;class BybitDemoAlgorithm(QCAlgorithm):&#10;    # 初始化只在算法开始时运行一次，设置回测条件和数据订阅。&#10;    def initialize(self) -&gt; None:&#10;        # 设置历史回测的开始日期。&#10;        # 设置回测开始日期；实盘运行不以此恢复历史状态。&#10;        self.set_start_date(2024, 9, 1)&#10;        # 设置历史回测的结束日期。&#10;        # 设置回测结束日期。&#10;        self.set_end_date(2024, 12, 31)&#10;        # 设置回测初始资金为 100,000 单位账户货币。&#10;        # 设置回测初始现金；实盘资金以券商账户和部署配置为准。&#10;        self.set_cash(100000)&#10;        # 设置券商模型和账户类型，决定资产、订单及现实约束。&#10;        self.set_brokerage_model(BrokerageName.BYBIT, AccountType.CASH)&#10;        # 订阅指定市场的加密货币对。&#10;        self._symbol = self.add_crypto("BTCUSDT", Resolution.DAILY, Market.BYBIT).symbol&#10;        # 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        self._fast = self.ema(self._symbol, 10, Resolution.DAILY)&#10;        # 创建自动更新的指数移动平均线，周期是参数指定的数据条数。&#10;        self._slow = self.ema(self._symbol, 50, Resolution.DAILY)&#10;&#10;    # 行情到达时执行；data 包含该时间片可用的数据。&#10;    def on_data(self, slice: Slice) -&gt; None:&#10;        # 指标准备好后才使用信号，历史样本不足时退出。&#10;        if not self._slow.is_ready:&#10;            return&#10;        if self._fast.current.value &gt; self._slow.current.value and not self.portfolio.invested:&#10;            # 按目标权重调整仓位；1 表示账户权益的 100%，不是买入 1 股。&#10;            self.set_holdings(self._symbol, 1)&#10;        elif self._fast.current.value &lt; self._slow.current.value and self.portfolio.invested:&#10;            # 请求平仓；实际成交仍取决于市场和券商。&#10;            self.liquidate()</code></pre>
</div>

## 虚拟币对 · 15 Virtual Pairs

<p>每种法币和加密币都是独立资产。买入 BTCUSD 实际是用 USD 换 BTC，现金账簿减少 USD、增加 BTC；BTCUSD 持仓是表示交易的虚拟币对。部署时 LEAN 可载入各币种余额，却无法从余额反推每个虚拟币对的持仓。</p>


## 部署算法 · 16 Deploy Live Algorithms

<p>每个实盘算法必须有一个可用实盘节点。</p>
<p>按以下步骤部署实盘算法：</p>
<ol>
<li>打开要部署的项目。</li>
<li>点击 Deploy Live（部署实盘）图标。<img alt="Lightning icon" class="inline-icon" src="https://cdn.quantconnect.com/i/tu/deploy-live-icon.png"/></li>
<li>在 Deploy Live 页面点击 Brokerage，选择 Bybit Exchange。</li>
<li>输入 API key 和 secret。</li><p>生成凭据见 Account Types；QuantConnect 不保存这些账户凭据。</p>
<li>点击 VIP Level 并选择账户等级。</li>
<p>VIP 等级详见券商 FAQ — VIP Program。</p>
<li>点击 Environment 并选择运行环境。</li>
<p>支持的环境如下：</p>
<table class="table qc-table">
<thead>
<tr>
<th>环境</th>
<th>说明</th>
</tr>
</thead>
<tbody>
<tr>
<td>实盘（Live）</td>
<td>使用真实资金交易</td>
</tr>
<tr>
<td>模拟（Demo）</td>
<td>通过 Bybit Demo Trading 使用虚拟资金交易。</td>
</tr>
<tr>
<td>测试网（Testnet）</td>
<td>通过 Bybit Testnet 使用虚拟资金交易。</td>
</tr>
</tbody>
</table> <li>在 Region 区域选择算法运行地区。</li>
<p>Binance 与 Bybit 限制从美国访问，交易和接收行情均需选择 Europe (WAW) 地区。</p>
<li>点击 Node 字段，选择要使用的实盘节点。</li>
<li>可选：在 Data Provider 区域点击 Show，修改数据源或添加其他数据源。</li>
<li>账户已有持仓时，按以下步骤填写（有演示视频）：</li>
<ol>
<li>在 Algorithm Holdings State 点击 Show。</li>
<li>点击 Add Holding。</li>
<li>填写 Symbol ID、代码、数量和平均价格。</li>
</ol>
<li>可选：配置通知。</li>
<li>配置 Automatically restart algorithm（自动重启算法）选项。</li>
<p>开启自动重启后，平台会尽力重启因运行错误而失败的算法，有助于应对券商 API 暂时断线等故障。</p>
<li>点击 Deploy（部署）。</li>
</ol>
<p>部署最多可能需要 5 分钟，完成后显示实盘结果页。可核对运行统计中的权益、现金账簿和持仓，确认券商原有持仓正确载入。</p>
<p>重启、自动重启和重新部署都不会保存算法全部内部状态。恢复哪些状态、其余状态如何持久化，见 State Persistence。</p>


## 部署详情 · 17 Deployment Details

<p>部署 Bybit 算法时，券商提供交易账户等详情，可区分并行部署和核对目标账户；这些详情不包含凭据。</p>
<p>下表列出 Bybit 提供的部署详情：</p>
<table class="qc-table table">
<thead>
<tr>
<th>键名</th>
<th>说明</th>
</tr>
</thead>
<tbody>
<tr>
<td><code>bybit-vip-level</code></td>
<td>账户 VIP 等级决定 API 速率限制，例如 VIP0。</td>
</tr>
</tbody>
</table>
<p>算法的 DeploymentDetails/deployment_details 是只读字典，LEAN 在调用 Initialize/initialize 之前填充，因此在算法任何位置都可读取。</p>
<div class="section-example-container">
<pre><code class="language-csharp">// 中文注释版：仅补充解释，保留原示例的执行语句。&#10;// 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;var deploymentDetails = DeploymentDetails.Select(kvp =&gt; $"{kvp.Key}:{kvp.Value}");&#10;Log($"deploymentDetails: {string.Join(", ", deploymentDetails)}");</code></pre>
<pre><code class="language-python"># 中文注释版：仅补充解释，保留原示例的执行语句。&#10;# 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;deployment_details = [f'{kvp.key}:{kvp.value}' for kvp in self.deployment_details]&#10;# 记录常规运行信息，消息写入日志并计入日志额度。&#10;# 读取券商提供的只读部署详情，内容不包含认证凭据。&#10;self.log(f'deployment_details: {deployment_details}')</code></pre>
</div>
<p>也可在算法外通过 /live/read 响应的 deploymentDetails 读取详情。</p>


## 故障排查 · 18 Troubleshooting

<p>下表说明部署 Bybit 时可能出现的错误：</p>
<table class="table qc-table">
<thead>
<tr>
<th>错误消息（保留英文便于检索）</th>
<th>可能原因与解决方法</th>
</tr>
</thead>
<tbody>
<tr>
<td nowrap="">
<div class="error-messages">Invalid API-key, IP, or permissions for action.</div>
</td>
<td>凭据可能错误或带前后空格，也可能缺少读写权限。在本地编辑器核对 API key/secret，按 Account Types 检查权限。</td>
</tr>
<tr>
<td nowrap="">
<div class="error-messages">You haven't enabled Cross Margin Trading yet.</div>
</td>
<td>账户当前使用逐仓保证金，须在网页或 App 启用全仓保证金，详见 Isolated Margin/Cross Margin。</td>
</tr>
</tbody>
</table>
<p>仍需支持时新建工单并附出错部署。（原文 ticker 为 ticket 的笔误。）</p>
