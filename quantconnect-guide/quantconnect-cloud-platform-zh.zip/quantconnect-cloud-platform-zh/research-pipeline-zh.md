# 研究流程看板 · Research Pipeline

## 简介 · Introduction

看板将项目按想法、研究、回测、模拟交易和实时交易组织。每张卡片对应云端项目，可拖动改变阶段。登录 Algorithm Lab，点击 Research Pipeline。

可以添加专门负责各阶段的 AI 智能体，也可定义自有智能体；阶段移动本身不等于完成相应验证。

## 阶段 0：想法 · Stage 0%3A Ideas

Ideas 保存待探索交易假设。点击列表右上 Add card，输入说明并 Save。Ideas Agent 可从新闻和研究文章提出想法，概括逻辑、资产及数据，但仍需验证。

## 阶段 1：研究 · Stage 1%3A Research

Research 阶段先评估可行性、细化假设，避免过早投入实现。可从 Ideas 拖入或 Add card 新建。

Research Agent 可操作笔记本并生成研究报告；Research Validation Agent 检查残差平稳性、序列相关、异方差及训练／测试稳定性。输出可用于决定进入回测还是继续研究，不代表自动证明策略有效。

## 阶段 2：回测 · Stage 2%3A Backtest

将假设实现为事件驱动算法，用费用、成交等现实模型检验。可从前两阶段拖入或新建卡片。Backtest Agent 可写代码、修错、跑回测和优化，输出不适合继续的结论或准备进入模拟测试的算法。

## 阶段 3：模拟交易 · Stage 3%3A Paper Trading

从 Backtest 拖入，使用模拟账户检查真实时间运行行为。Paper Testing Agent 核对交易是否符合代码、同日期实时与回测是否匹配、样本外是否落在原回测统计预期内。

不满足时可能调查、修改和重部署；判断不适合真实资金时停止并生成报告。使用此类智能体前需理解其可执行操作权限。

## 阶段 4：实时交易 · Stage 4%3A Live Trading

从模拟阶段拖入真实资金运行项目，关注持续运行和必要干预。Live Monitoring Agent 可查看持仓和重大新闻，识别可能影响仓位的事件并通知用户；它不保证能预知或避免损失。

## 项目归档 · Project Archive

不再分配资源的项目可拖入底部 Archived Items，例如研究未通过或策略失效。原文允许以后恢复；看板归档不应直接等同于永久删除项目。

## 更新卡片 · Update Cards

点击卡片，在 Card 标签查看内容；点击 Edit Idea，修改标题和说明，再 Save。

## 查看任务部署 · View Deployments

智能体工作时卡片显示 Running，点击查看输出。部署视图顶部项目链接可打开项目，右上停止图标可中断智能体。

全部当前和历史任务在 **Organization > Agents > Tasks**。点击 Status 查看任务，Delete 从视图移除记录。

## 配额 · Quotas

原文将智能体描述为有公平使用限制，而非严格无限制；并发数和 Token 使用量取决于 Agent Nodes。实际额度及费用见节点和当前套餐页。
