# QuantConnect Cloud Platform 中文说明

直接打开 [cloud-platform-official-zh.html](cloud-platform-official-zh.html)。它包含全部正文；也可通过目录进入独立页面。下载压缩包后请完整解压，保留 HTML、CSS 和各子目录的相对位置。

本稿参照 QuantConnect 官方文档的目录层级和页面模板，以易懂中文说明操作、字段及代码。它是非官方整理，部分重复内容合并表达，API 代码按同版本 OpenAPI 校对，并非逐句直译。

## 范围

- 覆盖 Cloud Platform 源码中的 1,388 个正文小节，以及快速入门八步教程。
- 243 个 HTML 文件，包含完整总文档、各层中文页面、32 个目录索引和 5 份 API 模型词典。
- 包含组织、项目、学习中心、研究、回测、数据、实盘、优化、社区、安全、研究流程和对象存储。
- 实盘券商部分有 24 个页面、344 个小节，包含模拟交易、各家券商、FIX、OANDA 外汇与 CFD，以及尚未支持券商的说明。
- API 覆盖源码定义中的全部 90 个接口，另保留 HTML 与 OpenAPI 不一致处的说明。

Writing Algorithms、Local Platform、LEAN CLI、数据市场每个单独产品以及外站文档不属于本次 Cloud Platform 范围；相应引用仍保留官方链接。价格、配额、服务权限、券商接口和 IP 可能变动，以当前服务为准。

## 阅读方法

左侧目录按官方层级排列。页面内的子目录跳到当前页对应正文；正文提供独立中文页及官方原文链接。原文相关链接中，已有本地中文内容的页面旁会显示“中文页”。

Python、C# 和 HTML 示例附中文注释，解释订阅、账户类型、指标、订单、API 字段与返回处理。JSON 保持合法语法，字段含义写在相邻表格或正文中。按钮、模型名、枚举、错误消息及请求键保留英文，便于与平台界面对照。

所有 API 与交易代码均未连接用户账户执行。请求示例中的 ID、凭据和文本需要按说明填写；API 成功响应、算法部署成功与订单成交是不同阶段。原文用于演示语法错误、越界和逻辑错误的教学片段保留原错，并已注明。

官方截图和 GIF 仍引用 QuantConnect CDN，需要联网加载；当前生成环境无法访问该 CDN。正文、目录、CSS、代码和订单支持勾选标记可在本地使用。大表格可在表格区域横向滚动，也可用键盘聚焦后滚动。

## 校验结果

- 所有正文小节都有对应标识；没有缺失小节或“尚未翻译”的占位内容。
- 243 个 HTML 文件的本地文件链接、章节锚点和 ID 唯一性检查通过。
- Python 代码通过语法解析，原文故意出错的教学案例单独记录；C# 未在本任务中链接 LEAN 编译。
- 新增券商部分 44 段 Python、44 段 C# 与原始执行语句逐段比较一致。
- Chromium 中检查桌面宽度 1440 和手机宽度 390；样例页面没有整页横向溢出。

详细结果见 [完整校验报告](translation-complete-validation.json)、[原文小节覆盖表](translation-complete-source-coverage.json)、[浏览器检查](translation-browser-validation.json) 和 [券商代码比较](translation-brokerage-code-validation.json)。源 Markdown、各批覆盖表及构建辅助脚本保留在工作目录中；旧试读稿未收入本次交付包。

## 来源与许可

官方页面：<https://www.quantconnect.com/docs/v2/cloud-platform>

源码仓库：<https://github.com/QuantConnect/Documentation>

对应提交：`697eaf38f1d9b257aabb45e3a3210318276c2212`

最终交付日期：2026-10-18。

原始文档版权归 QuantConnect；译文与整理新增内容已作非官方标记。原始 Apache 2.0 许可证随包附在 [LICENSE-QuantConnect.txt](LICENSE-QuantConnect.txt)。
