# 加密资产 · Crypto

> 按所读源码翻译整理，重点是平台数据源的接入能力。历史范围、覆盖、延迟和费用为源码记录，不是当前可用性保证。

## 简介 · Introduction

QuantConnect 数据源在实时运行中向算法提供加密资产信息，供决策和持仓估值。

## 来源 · Sourcing

通过 WebSocket 来自 Binance／Binance US、Bitfinex、Bybit、Coinbase、Kraken。原文要求 Binance 和 Bybit 使用 Europe（WAW）区域，当前限制以服务条款为准。

## 标的集合选择 · Universe Selection

加密资产集合数据原文约 UTC 16:00 到达，选择在 16:00–16:30 运行，不能假定午夜可用。

```python
# 中文注释版：仅补充解释，保留原示例的执行语句。
# 在算法初始化中启用异步标的集合选择。
self.universe_settings.asynchronous = True
# 使用 Bitfinex 加密资产集合；筛选回调需要自行实现。
self.add_universe(CryptoUniverse.bitfinex(self._universe_selection_filter))
```

## 行情聚合 · Bar Building

LEAN 将 Tick 聚合成订阅频率的 Bar。实时按更细时间戳分桶，某些 Tick 可能与历史归入不同 Bar，导致 OHLCV 略有差异。

## 交付与延迟 · Delivery

算法通常运行在托管数据中心，减少本地网络和硬件故障影响。共享原文写行情延迟约 5–40 毫秒、券商订单往返约 100 毫秒至五秒，实际因源和市场而变，**不是延迟保证**。平台并非为高频交易设计。

## 历史数据 · Historical Data

history 与 warm-up 的可访问历史范围按源码为：

| 频率 | 向前可访问范围 |
| --- | --- |
| 日／小时 | 对应数据集全部历史 |
| 分钟 | 一年 |
| 秒 | 两个月 |
| Tick | 一个月 |

“全部历史”仍受数据集起始日期和组织许可限制。该表描述实时源配套历史请求，不能直接当成所有回测区间的上限。

## 费用 · Pricing

原文称平台数据源免费提供加密资产数据；组织节点、其他数据许可和券商交易费用并不因此全部免费。实际条件以当前平台为准。
