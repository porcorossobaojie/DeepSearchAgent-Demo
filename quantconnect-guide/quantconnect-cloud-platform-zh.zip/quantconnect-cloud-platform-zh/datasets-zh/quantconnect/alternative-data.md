# 另类数据 · Alternative Data

> 按所读源码翻译整理，重点是平台数据源的接入能力。历史范围、覆盖、延迟和费用为源码记录，不是当前可用性保证。

## 简介 · Introduction

QuantConnect 数据源在实时运行中向算法提供另类数据信息，供决策和持仓估值。

## 来源 · Sourcing

直接来自各数据供应商，完整名单见 Dataset Market。

## 交付与延迟 · Delivery

交付时间由数据集决定，多数日或小时更新；供应商提供后注入。Tiingo News 和 Benzinga News 等按实时流交付，延迟因数据集不同。

## 历史数据 · Historical Data

history 与 warm-up 的可访问历史范围按源码为：

| 频率 | 向前可访问范围 |
| --- | --- |
| 日／小时 | 对应数据集全部历史 |
| 分钟 | 一年 |
| 秒 | 两个月 |
| Tick | 一个月 |

“全部历史”仍受数据集起始日期和组织许可限制。该表描述实时源配套历史请求，不能直接当成所有回测区间的上限。

## 费用 · Pricing

具体许可与价格参见 Dataset Market 中相应另类数据集。
