# 美国股票 · US Equities

> 按所读源码翻译整理，重点是平台数据源的接入能力。历史范围、覆盖、延迟和费用为源码记录，不是当前可用性保证。

## 简介 · Introduction

QuantConnect 数据源在实时运行中向算法提供美国股票信息，供决策和持仓估值。 还提供公司行为、每日基本面和股票可借数量。

## 来源 · Sourcing

合并美国交易所 SIP 股票行情，不包含 OTC。平台原文称覆盖完整合并市场。公司行为如拆分和分红在交易日前交付。

## 标的集合选择 · Universe Selection

美股基本面集合的实时数据约 ET 6／7 点到达，选股约 ET 7–8 点执行；不要假定午夜已有当天数据。

```python
# 中文注释版：仅补充解释，保留原示例的执行语句。
# 片段放在算法初始化中；开启异步选股，回调不能假定与主事件同步。
self.universe_settings.asynchronous = True
# _select_fundamental 是你需要另外实现的基本面筛选函数。
self.add_universe(self._select_fundamental)
```

ETF 成分股集合示例：

```python
# 中文注释版：仅补充解释，保留原示例的执行语句。
# 异步选择 SPY 的成分股；它与直接买入 SPY ETF 不是同一操作。
self.universe_settings.asynchronous = True
spy = self.add_equity("SPY").symbol
# 筛选回调 _etf_constituents_filter 需事先实现，返回需要纳入的成分股。
self.add_universe(self.universe.etf(spy, self.universe_settings, self._etf_constituents_filter))
```

## 行情聚合 · Bar Building

LEAN 将 Tick 聚合成订阅频率的 Bar。实时按更细时间戳分桶，某些 Tick 可能与历史归入不同 Bar，导致 OHLCV 略有差异。
### 聚合与竞价

官方开闭市价可能延迟 2–30 秒，Bar 实时发出前未必来得及纳入。秒线更容易与后来历史修订不同。

### 排除规则

可疑 Tick 的价格不参与 Bar；被排除的成交量仍可能计入，若整个期间没有有效定价 Tick，可能不产生 Bar。

原文排除条件还包括：符合过滤条件的 FINRA 成交、仅有排除成交标记而无纳入标记、买卖双方报价数量均少于 100 股、无纳入报价标记或具有排除报价标记。

FINRA 过滤每天最初关闭。当当天第一笔通过条件标记的成交价格至少 5 美元，且有效成交累计金额达到 5,000,000 美元后启用。若首笔低于 5 美元，当天不启用。计数包括盘前；启用后 FINRA 价格不再参与定价，数量仍统计。

| 成交标记 | 状态与含义 |
| --- | --- |
| Regular | 纳入，常规成交 |
| FormT | 纳入，延长时段成交 |
| Cash | 纳入，当天交割 |
| ExtendedHours | 纳入，常规时段之外 |
| NextDay | 纳入，次工作日交割 |
| OfficialClose / OfficialOpen | 纳入，官方闭市／开市价 |
| ClosingPrints / OpeningPrints | 纳入，单价闭市／开市成交 |
| IntermarketSweep | 排除，跨市场扫单 |
| TradeThroughExempt | 排除，特定跨价交易豁免标记 |
| OddLot | 排除，少于 100 股的零股成交 |

| 报价标记 | 状态与含义 |
| --- | --- |
| Regular | 纳入，正常环境 |
| Slow | 纳入，慢速报价 |
| Gap | 纳入，非自动执行／非确定报价环境 |
| OpeningQuote | 纳入，参与者开市报价 |
| FastTrading | 纳入，短时活跃交易、尽力报价 |
| Closing | 排除，参与者最后报价 |
| NewsDissemination / NewsPending | 排除，新闻披露／待公布导致停牌 |
| TradingRangeIndication | 排除，预示可能的交易区间 |
| OrderImbalance | 排除，买卖订单严重不平衡 |
| Resume | 排除，该参与者恢复交易标记 |

技术标记保留英文，便于对照 API；实际条件组合按原文规则执行，不能只看一个标记推断全部聚合行为。


## 可疑逐笔数据 · Suspicious Ticks

Tick 是原始、未过滤数据，算法应避免把不可交易的异常点直接当信号。原文标记的情况包括：成交在最佳买价以下或卖价以上；远离当前市场；暗池成交；回撤成交；迟报。买卖价之间的成交也可能来自隐藏订单，不能一概视为错误。需要 Tick 的策略应具备自己的过滤逻辑。

## 交付与延迟 · Delivery

算法通常运行在托管数据中心，减少本地网络和硬件故障影响。共享原文写行情延迟约 5–40 毫秒、券商订单往返约 100 毫秒至五秒，实际因源和市场而变，**不是延迟保证**。平台并非为高频交易设计。

## 历史数据 · Historical Data

history 与 warm-up 的可访问历史范围按源码为：

| 频率 | 向前可访问范围 |
| --- | --- |
| 日／小时 | 对应数据集全部历史 |
| 分钟 | 一年 |
| 秒 | 两个月 |
| Tick | 一个月 |

“全部历史”仍受数据集起始日期和组织许可限制。该表描述实时源配套历史请求，不能直接当成所有回测区间的上限。

## 费用 · Pricing

原文称平台数据源免费提供美国股票数据；组织节点、其他数据许可和券商交易费用并不因此全部免费。实际条件以当前平台为准。
