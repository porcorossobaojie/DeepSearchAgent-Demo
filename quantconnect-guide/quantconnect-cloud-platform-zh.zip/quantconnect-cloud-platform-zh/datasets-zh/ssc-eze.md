# SSC Eze 数据源 · SSC Eze

> 本页说明行情接入，不等同于完整券商交易接入。按源码小节顺序转述，省略重复品牌宣传；资产、费用与权限以当前提供商和平台文档为准。

## 简介 · Introduction

SSC Eze 通过 Market Data API 提供股票、股票期权、指数、指数期权、期货和期货期权。本章说明 QuantConnect 对其数据 API 的接入；不能从供应商完整产品目录反推平台全部支持。

## 数据来源 · Sourcing

直接来自 SSC Eze 的 Market Data API。服务商提供证券价格；QuantConnect Cloud 提供相应辅助数据，例如公司行为和标的映射。

## 行情聚合 · Bar Building

通过 Protocol Buffers 收集价格流，再分发至平台算法。

## 混合数据源 · Hybrid Data Provider

部署时可选择平台数据源、该服务商或混用。**列表顺序决定优先级**：后面的源仅补前面不提供的标的，并非同一标的价格自动平均或故障时无条件切换。

原文优先建议平台源，其次平台源加补缺源，或服务商优先、平台补缺。公共片段关于平台期货期权覆盖的说法与各数据章节存在版本差异，实际应逐资产确认。使用其他源取得的资产不计入 IB 订阅额度，仅当涉及 IB 时才适用。

## 另类数据 · Alternative Data

第三方源可与多数非流式另类数据配合使用。Tiingo News、Benzinga News 等日内实时流需另外包含 QuantConnect 数据源；具体数据集文档优先。

## 历史数据 · Historical Data

history 与 warm-up 的历史可用范围取决于 SS&C Eze 数据方案。

## 费用 · Pricing

最新费用见 SS&C Eze EMS Portal 的 Market Data 页面。
