# Databento 数据源 · Databento

> 本页说明行情接入，不等同于完整券商交易接入。按源码小节顺序转述，省略重复品牌宣传；资产、费用与权限以当前提供商和平台文档为准。

## 简介 · Introduction

Databento 提供市场价格数据，部署实时算法时可凭其 API Key 使用。本源码版本的云端接入仅用于实时流；研究、回测和优化下载需查阅 CLI。本节另附开源 Lean.DataSource.Databento 实现链接。

## 支持的数据集 · Supported Datasets

本接入支持**美国期货**。辅助数据包括 US Futures Security Master、US Futures Universe、选股数据及非流式另类数据。第三方行情本身不包含全部辅助数据，CLI 情境还需下载相应元数据。

## 股票池与标的集合 · Universe Selection

云端实时使用 Databento 时，选股及标的集合数据由 QuantConnect 提供，而不是仅依赖该服务商的价格流。

## 另类数据 · Alternative Data

原文说明云端另类数据可以与 Databento 价格数据配合；流式数据的额外源要求仍需查对应数据集。

## 研究 · Research

所读原文明确：QuantConnect Cloud 不支持将 Databento 作为本章方式的研究数据源。使用其数据下载到本地需另查 CLI 与许可。

## 回测 · Backtesting

所读原文明确：QuantConnect Cloud 不支持将 Databento 作为本章方式的回测数据源。使用其数据下载到本地需另查 CLI 与许可。

## 参数优化 · Optimization

所读原文明确：QuantConnect Cloud 不支持将 Databento 作为本章方式的优化数据源。使用其数据下载到本地需另查 CLI 与许可。

## 实时交易 · Live Trading

每个算法需有可用实时节点。

1. 打开项目，点击 Deploy Live，选择券商并完成其认证。
2. Data Provider 区域点击 Show，在 Data Provider 1 选择 Databento。
3. 输入自己的 Databento API Key，点击 Save。
4. 按券商能力核对现金与持仓，设置通知和自动重启。
5. 点击 Deploy，之后核对连接及行情。

API Key 应在平台安全输入界面配置，不写进公开文档。

## 多个数据源 · Mutiple Data Providers

Databento 优先、平台次之时，平台只补充 Databento 不提供的资产；可用前者提供期货、后者提供股票。也可 Databento 优先、IB 补充股票。 每个源仍受自身许可、资产与额度限制。

## 历史数据 · Historical Data

实时算法中的 history 与 warm-up 可用范围取决于 Databento API 包。不能因此推断平台云端研究和回测已接入该数据源。

## 费用 · Pricing

费用见 Databento Pricing；供应商 API 包与平台节点费用需分别确认。
