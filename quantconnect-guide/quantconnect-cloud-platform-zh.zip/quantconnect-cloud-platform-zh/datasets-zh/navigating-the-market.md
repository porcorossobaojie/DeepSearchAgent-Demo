# 浏览数据市场 · Navigating the Market

## 简介 · Introduction

数据集是一连串供策略判断和成交建模使用的数据点。Dataset Market 汇集价格、基本面和另类数据，方便在云端或许可允许的本地环境中研究。

平台为各数据集提供示例算法，多数还带研究笔记本，可克隆学习，并查看用户评价。原文将数据描述为经团队筛选、预处理及尽量消除生存者偏差；这不表示所有数据无误，使用前仍需检查覆盖、时间与许可。

## 查看全部数据集 · View All Listings

顶部点击 **Data** 打开市场。列表展示名称、说明、覆盖数量、起始日期和价格。Coverage 可能指标的、合约、货币对或文章数量，需结合数据类型理解。

- **Category: All**：按分类过滤。
- **Delivery Options: All**：按交付方式过滤。
- 搜索框：按关键词查找。

点击数据集进入详情。

## 数据集主页 · Homepage

| 标签 | 内容 |
| --- | --- |
| About | 数据集和供应商概览 |
| Documentation | 回测和研究中的使用方法 |
| Research | 示例研究笔记本 |
| Examples | 完整策略示例 |
| Licenses | 可用许可 |
| CLI | 生成下载命令 |
| Pricing | 云端或本地访问价格 |
| Data Explorer | 查看文件、报告数据问题 |

About 常包含 Introduction、供应商背景、Getting Started 代码、Data Summary（起始时间、覆盖、频率、密度和时区）、应用思路、Data Point Attributes（字段与类型）、价格及评价。

## 侧边栏 · Sidebar

侧栏汇总许可选项数、起始日期、覆盖范围、交付方式和供应商网址。开始使用前先确认这些条件，而不是只复制示例代码。

## 使用文档 · Documentation

Documentation 分别展示 Python 和 C# 的订阅、事件中读取及历史请求方法。Data Point Attributes 展示字段；点击自定义类型可继续查看其成员。

## 因子研究 · Factor Research

部分数据集的 Research 标签分析数据字段。克隆步骤：登录，打开数据集详情，选择 Research，点击 **Clone This Notebook**，再点击 **Clone Algorithm**。

## 示例 · Examples

Examples 提供经典算法和框架算法的 Python／C# 示例。可复制后研究，也可按自己的假设修改。参数优化能比较历史表现，但不能取代样本外验证。

## 许可 · Licenses

Licensing／Licenses 展示供应商要求的具体许可。不同数据集条款不同；云端可用不等于可下载或转发。

## 评价 · Reviews

在页面底部，用 Most Recent 选择排序依据，用 All 选择星级筛选。登录后选星级、填写评价并点击 **Submit Review** 可提交。
