# 数据供应商 · Vendors

## 简介 · Introduction

数据公司可以提交新数据集，审核并集成后进入 QuantConnect 数据市场。

## 提交标准 · Submission Criteria

需要清晰稳定的数据定义；可靠的标的映射（如 ISIN、FIGI 或当时有效代码）；至少一年运营资金及历史数据；稳定 API、交付时间和格式；格式更新提前通知；无生存者偏差；文档充分。

另类数据还应遵循 IDSO 的 Alternative Investment Standards。原文以爬虫遵守 robots.txt 为合规采集示例，具体要求见链接。

## 审核流程 · Review Process

审核确认是否满足标准，可能持续数周。通过后开始集成；未通过会提供改进反馈。时长是原文预期，并非本次服务承诺。

## 贡献数据集 · Contributing Datasets

可自行按 Contributing Datasets 教程完成接入。原文称工程工作约一天；实际取决于数据和接口，不包含全部审核时间。

## 提供免费试用 · Give Free Trials

1. 登录并打开 Dataset Market 的目标数据集。
2. 在右侧点击 Dashboard，再点击 **give trial**。
3. 输入试用结束日期，点击 OK。
4. 输入目标组织所有者邮箱；若其拥有多个组织，选择目标组织。
5. 点击 OK 确认。

## 联系团队 · Contacting Our Team

希望讨论数据接入时，通过本节保留的官方联系链接咨询。本文未替你发送申请或开通试用。
