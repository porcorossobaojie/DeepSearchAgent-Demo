# Interactive Brokers 数据源 · Interactive Brokers

> 本页说明行情接入，不等同于完整券商交易接入。按源码小节顺序转述，省略重复品牌宣传；资产、费用与权限以当前提供商和平台文档为准。

## 简介 · Introduction

Interactive Brokers 通过 Trader Workstation API 提供相关资产价格，实际资产和市场支持需按平台券商文档核对。本章说明 QuantConnect 对其数据 API 的接入；不能从供应商完整产品目录反推平台全部支持。

## 数据来源 · Sourcing

直接来自 Interactive Brokers 的 Trader Workstation API。服务商提供证券价格；QuantConnect Cloud 提供相应辅助数据，例如公司行为和标的映射。

## 行情聚合 · Bar Building

原文为约每 300 毫秒一次的成交与报价汇总快照；不是逐笔完整成交重放。

## 混合数据源 · Hybrid Data Provider

部署时可选择平台数据源、该服务商或混用。**列表顺序决定优先级**：后面的源仅补前面不提供的标的，并非同一标的价格自动平均或故障时无条件切换。

原文优先建议平台源，其次平台源加补缺源，或服务商优先、平台补缺。公共片段关于平台期货期权覆盖的说法与各数据章节存在版本差异，实际应逐资产确认。使用其他源取得的资产不计入 IB 订阅额度，仅当涉及 IB 时才适用。

## 另类数据 · Alternative Data

第三方源可与多数非流式另类数据配合使用。Tiingo News、Benzinga News 等日内实时流需另外包含 QuantConnect 数据源；具体数据集文档优先。

## 财务顾问子账户 · Financial Advisors

使用 IB 数据管理客户子账户时，每个子账户都需要自己的 IB 行情订阅。

## 历史数据 · Historical Data

通过 history 或 warm-up 获取时，秒线最多六个月；不包含已退市股票和过期期权；过期期货超过两年不可用。Tick／秒线原文最多 50 个并发请求、每十分钟 60 次。TradeBar 与 QuoteBar 分别计一次。更细限制以 IB Historical Data Limitations 为准。

## 费用 · Pricing

需要在 IB 订阅相应市场行情。原文列举 US Securities Snapshot and Futures Value Bundle、US Equity and Options Add-On Streaming Bundle、CFE L1、CME S&P Indexes 和 CBOE 指数等。默认约 100 个同时流式标的，上限可能随权益和佣金改变；超额时记录错误，可咨询 Quote Booster。订阅可能等待 24 小时生效，且只分配给一个账户，需变更时联系 IB。

模拟账户共享行情：IB Client Portal 右上个人图标 > Settings，在 Account Configuration 进入 Paper Trading Account，选择 Yes 并 Save。具体费用以 IB 当前页面为准。
