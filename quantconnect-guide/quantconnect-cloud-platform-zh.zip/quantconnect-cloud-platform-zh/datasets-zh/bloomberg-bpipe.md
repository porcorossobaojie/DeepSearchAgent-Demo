# Bloomberg BPIPE 数据源 · Bloomberg BPIPE

> 本页说明行情接入，不等同于完整券商交易接入。按源码小节顺序转述，省略重复品牌宣传；资产、费用与权限以当前提供商和平台文档为准。

## 简介 · Introduction

Bloomberg BPIPE 用于实时行情，可访问组织已获授权的 Bloomberg 数据。只提供数据，不负责订单路由；通过 Bloomberg 交易另见 EMSX。研究和回测下载参见 CLI 的 Bloomberg DAPI。

## 数据授权 · Entitlements

需要为每项 Bloomberg 数据取得授权。Bloomberg 通过 ERMS 管理权限，启用后平台才交付对应数据。

## 专用行情服务 · Ticker Plant

组织需要专用 BPIPE ticker plant。QuantConnect 在后端部署和运维，并配置与组织绑定的访问权限。

## 行情聚合 · Bar Building

每次买价、卖价、最新成交价或未平仓量变化会生成 Tick，LEAN 按订阅频率聚合 Bar；分钟订阅收到分钟 Bar。原文称流不经过滤，包含 Bloomberg 发送的信息。

## 混合数据源 · Hybrid Data Provider

可将 BPIPE 与 Polygon、Databento 等第三方源组合，按列表优先级补缺。**原文规定不能与 QuantConnect 数据源混用**，原因是 BPIPE 运行在专属 ticker plant，而平台源仅在 QuantConnect Cloud 提供。

## 历史数据 · Historical Data

BPIPE 本身不提供历史，实时中的 history 和 warm-up 需依靠其他所选数据源。

## 附加数据集 · Additional Datasets

专用行情服务就绪后，可订阅组织获授权且 BPIPE 支持的数据，平台通过 BPIPE 向算法交付。

## 入门 · Getting Started

联系 QuantConnect 支持，安排需求沟通，确认 Bloomberg 授权和专用行情服务的配置流程。

## 费用 · Pricing

原文平台服务为一次设置费 2,000 美元、月费 240 美元，Bloomberg 数据许可及授权费另算。实际以双方确认报价为准。
