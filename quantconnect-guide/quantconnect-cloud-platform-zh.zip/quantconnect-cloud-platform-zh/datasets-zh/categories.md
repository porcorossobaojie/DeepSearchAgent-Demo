# 数据分类 · Categories

## 简介 · Introduction

数据分类用于区分价格、基本面与另类信息，帮助按研究问题寻找合适数据。分类不代表数据必然含有可盈利信号。

## 地理空间 · Geospatial

与现实位置相关的对象数据。

## 商业活动 · Commerce

消费者和企业的交易及行为数据。

## 金融市场 · Financial Market

交易所交易活动相关数据。

## 消费者 · Consumer

购物行为、人口特征与消费态度等。

## 企业间业务 · B2B

企业向其他企业销售产品或服务的活动。

## 运输与物流 · Transport and Logistics

商品运输及其组织流程数据。

## 环境 · Environmental

气象、生物多样性和污染等环境状态。

## 信用评级 · Credit Rating

个人和企业的财务状况。

## 房地产 · Real Estate

住宅与商业地产的产权、挂牌及人口特征。

## 互联网 · Web

互联网用户的行为。

## 法律 · Legal

法规、政府网站信息及诉讼历史。

## 医疗健康 · Health Care

就诊、理赔、可穿戴设备与健康记录。

## 娱乐 · Entertainment

媒体消费偏好与行为。

## 能源 · Energy

能源生产、分配和消费。

## 产业 · Industry

经济中不同产业群体相关数据。

## 政治 · Political

选举投票与政党政策等政治活动。

## 新闻与事件 · News and Events

新闻服务商收集的时事信息。
