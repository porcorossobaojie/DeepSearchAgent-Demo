# LEAN 引擎版本 · LEAN Engine Versions

## 简介 · Introduction

QuantConnect Cloud 的回测、研究和实时交易节点默认运行 LEAN 仓库最新的 master 分支。官方认为最新版本通常较安全，因为包含已有问题的修复。

对版本稳定性有特定需求的 Trading Firm 或 Institution 用户，可在 IDE 中选择较旧或自定义版本。自定义版本由官方 LEAN 仓库分支提供，并通过持续部署进入运行环境。新增自定义版本需要向 LEAN 提交 Pull Request，经平台团队审查。

## 更改分支 · Change Branches

1. 打开项目。
2. 在 Project 面板点击 **LEAN Engine** 字段。
3. 从下拉菜单选择分支。
4. 可点击 **About Version（关于版本）** 查看分支说明。
5. 如希望始终使用 master，勾选 **Always use Master Branch（始终使用 master 分支）**。
6. 点击 **Select（选择）**。

修改只影响当前项目。之后创建的新项目仍默认使用 master 分支。

## 请求新分支 · Request New Branches

准备通过 Pull Request 创建新分支前，先联系 QuantConnect，讨论该项目目标。
