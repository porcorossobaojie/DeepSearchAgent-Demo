# 代码会话 · Code Sessions

## 简介 · Introduction

代码会话提供云端 IDE，用于研究和开发交易算法。原文说明打开项目时会启动新会话，具备 LEAN 引擎、平台数据和云资源的访问能力。引擎版本选择另见“LEAN 引擎版本”。

## 查看代码会话 · View Code Sessions

登录 Algorithm Lab，在左侧导航点击 **Projects**，即可查看当前组织正在运行的代码会话。

![正在运行的代码会话](https://cdn.quantconnect.com/i/tu/view-live-environments.png)

点击项目名称可打开会话；点击名称旁的**停止**图标可结束会话。**退出登录不会自动停止代码会话。**

左侧导航 Projects 下方也会显示会话：蓝色表示当前打开，灰色表示最小化。

![左侧导航中的代码会话](https://cdn.quantconnect.com/i/tu/environments-in-navigation-bar.png)

## 代码会话配额 · Code Session Quotas

打开一个项目会占用一个代码会话。免费用户同一时刻只能打开一个会话；付费组织支持多个。下表为所读源码中的初始配额，实际限制以当前账号为准。

| 套餐 | 初始活动会话数 |
| --- | --- |
| Free | 1 |
| Quant Researcher | 2 |
| Team | 4 |
| Trading Firm | 8 |
| Institution | 16 |

若组织的实时交易节点数超过初始会话配额，配额会提升到该节点数，以便查看全部实时策略。

免费配额跨该用户的全部免费组织计算；付费配额按“账号在各组织中的额度”计算，不是整个组织的所有成员合用。例如同一用户加入两个 Quant Researcher 组织时，可以在每个组织分别使用两个会话；组织其他成员也拥有各自的额度。
