# 文件管理 · Files

## 简介 · Introduction

项目文件用于实现交易算法、开展研究及保存信息。Python 新项目包含 `main.py` 和 `research.ipynb`；C# 新项目包含 `Main.cs` 和 `Research.ipynb`。

在 `main.py` 或 `Main.cs` 中实现交易算法，通过 `.ipynb` 文件进入研究环境。

## 支持的文件类型 · Supported File Types

网页平台支持：`.cs`、`.ipynb`、`.py`、`.html`、`.css`。

## 添加文件 · Add Files

1. 打开项目，在右侧导航点击 **Explorer（资源管理器）**。
2. 在 Explorer 面板展开项目文件区域。
3. 点击 **New File（新建文件）** 图标。
4. 输入文件名和扩展名，按 **Enter**。

![添加文件示例](https://cdn.quantconnect.com/i/tu/add-file-gif.gif)

## 添加目录 · Add Directories

1. 打开项目，在右侧导航点击 **Explorer**。
2. 展开项目文件区域，点击 **New Directory（新建目录）** 图标。
3. 输入目录名，按 **Enter**。

![添加目录示例](https://cdn.quantconnect.com/i/tu/add-folder-gif.gif)

## 打开文件 · Open Files

打开项目，进入右侧 **Explorer** 面板，再点击需要打开的文件。

## 关闭文件 · Close Files

点击编辑器顶部对应文件标签上的 **×**。若要关闭全部文件，右键点击任一文件标签，选择 **Close All（全部关闭）**。

## 重命名文件和目录 · Rename Files and Directories

1. 打开项目并进入右侧 **Explorer**。
2. 右键点击目标文件或目录，选择 **Rename（重命名）**。
3. 输入新名称，按 **Enter**。

![重命名文件示例](https://cdn.quantconnect.com/i/tu/rename-file-gif.gif)

## 删除文件和目录 · Delete Files and Directories

1. 打开项目并进入右侧 **Explorer**。
2. 右键点击目标文件或目录，选择 **Delete Permanently（永久删除）**。
3. 点击 **Delete（删除）** 确认。

这里的文件永久删除与项目层面的回收站操作不同。

## 配额 · Quotas

每个项目的最大文件数量和单个文件大小取决于组织套餐。下面保留所读源码版本中的表格，**它不代表已核验当前账号或官网的最新配额**。

| 套餐 Tier | 每项目最多文件数 | 单文件最大大小（KB） |
| --- | --- | --- |
| Free | 25 | 32 |
| Quant Researcher | 50 | 64 |
| Team | 75 | 128 |
| Trading Firm | 100 | 256 |
| Institution | 250 | 256 |
