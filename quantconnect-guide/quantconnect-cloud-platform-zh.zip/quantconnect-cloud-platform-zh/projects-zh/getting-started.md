# 入门 · Getting Started

## 简介 · Introduction

项目包含运行回测、启动研究笔记本、优化参数和部署实时策略所需的文件。要开发策略或与其他成员分享成果，首先需要创建项目。回测完成后，还可以为项目生成表现报告。你可以从零编写，也可以使用现成代码库和第三方软件包加快开发。

Algorithm Lab 让你在云端创建、保存和管理项目。除非共享项目或添加协作者，否则其他用户不能访问你的项目。

## 查看所有项目 · View All Projects

All Projects 页面展示当前组织中的 QuantConnect 项目，包括代码库和 Boot Camp 课程项目。点击项目或目录即可打开。

1. 登录 Algorithm Lab。
2. 在左侧导航点击 **Projects（项目）**。
3. 点击 **Open Project（打开项目）**。

![所有项目页面](https://cdn.quantconnect.com/i/tu/view-all-projects.png)

## 创建项目 · Create Projects

1. 登录 Algorithm Lab。
2. 在左侧导航点击 **Projects**。
3. 在项目页面点击 **Create New Algorithm（创建新算法）**。

网页 IDE 随即打开新项目。

## 关闭项目 · Close Projects

在 **Project（项目）** 面板点击 **Close（关闭）**。

## 克隆项目 · Clone Projects

克隆会在同一组织中创建项目副本。项目文件会被复制，但回测结果和实时部署历史不会保留。可以用副本测试小改动，再将需要的修改合回原项目，也可以用副本开始新的实时部署记录。

打开项目，在 Project 面板点击 **Clone（克隆）**。

## 迁移项目 · Migrate Projects

迁移用于将项目从一个组织移动到另一个组织，以使用目标组织的资源或与其成员协作。将项目迁出组织需要组织管理员权限。迁移会复制项目文件，但**不会保留 Object Store 中的内容**。

打开项目，在 Project 面板点击 **Migrate（迁移）**；选择目标组织并确认迁移。

## 重命名项目 · Rename Projects

1. 打开项目。
2. 在 Project 面板中，将鼠标移到项目名上。
3. 点击出现的**铅笔**图标。
4. 在 **Name（名称）** 字段填写新名称。
5. 点击 **Save Changes（保存更改）**。

## 创建项目目录 · Create Project Directories

将项目名称设为 `directoryName/projectName`，即可建立项目目录。例如 `学习练习/第一个策略` 表示将该项目放在“学习练习”目录中。

## 设置描述 · Set Descriptions

1. 打开项目，在 Project 面板将鼠标移到项目名上。
2. 点击铅笔图标。
3. 在 **Description（描述）** 字段填写项目说明。
4. 点击 **Save Changes**。

## 编辑参数 · Edit Parameters

算法参数是在代码文件之外设置的项目变量。把固定数值移到参数中，既方便配置，也方便运行参数优化。

### 添加参数

1. 打开项目，在 Project 面板点击 **Add New Parameter（添加新参数）**。
2. 输入参数名。名称必须在当前项目中唯一。
3. 输入默认值。
4. 点击 **Create Parameter（创建参数）**。

在策略代码中通过 `get_parameter`（Python）或 `GetParameter`（C#）读取参数；具体 API 用法参见官方 Get Parameters 说明。

### 设置默认值

1. 在 Project 面板将鼠标移到参数上，点击铅笔图标。
2. 填写默认值并点击 **Save（保存）**。

面板会在参数名旁显示默认值。

### 删除参数

1. 将鼠标移到参数上，点击垃圾桶图标。
2. 同时删除代码中与该参数关联的 `get_parameter` 或 `GetParameter` 调用。

## 删除项目 · Delete Projects

可以删除打开或关闭的项目。删除后，项目移入项目列表中的 **Recycle Bin（回收站）**；回收站中的项目会在 **30 天后永久删除**。

### 删除已打开的项目

在 Project 面板点击 **Delete（删除）**，然后点击 **Yes（是）**。

### 删除未打开的项目

1. 打开 My Projects 项目列表。
2. 如果项目位于某个目录，逐层进入该目录。
3. 将鼠标移到项目上，点击垃圾桶图标。

出现“Project deleted”表示项目已删除。

![从项目列表删除项目](https://cdn.quantconnect.com/i/tu/delete-projects-when-closed.png)

### 恢复误删项目

1. 在项目列表打开 **Recycle Bin**。
2. 点击误删项目，将其打开。
3. 重命名项目，移除路径中的 `Recycle Bin/` 前缀。例如将 `Recycle Bin/My Legacy Project` 改为 `My Legacy Project`。

需要在 30 天的保留期内恢复。

## 加密项目 · Encrypt Projects

云端项目可以保存为加密文件，而不是可直接阅读的明文。用户提供自己的密钥，由本地浏览器保存并用于加密。详细步骤见本中文文档的“项目加密”。

## 获取项目 ID · Get Project Id

打开项目并查看地址栏。例如 `https://www.quantconnect.com/project/13946911` 对应的项目 ID 是 `13946911`。
