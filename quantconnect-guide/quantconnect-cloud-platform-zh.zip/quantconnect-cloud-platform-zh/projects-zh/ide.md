# 集成开发环境 · IDE

## 简介 · Introduction

IDE 可用于编写研究笔记本、开发回测和实时交易算法。打开项目后，IDE 自动出现。只要有浏览器和网络连接，就可以访问云端策略。

## 支持的语言 · Supported Languages

LEAN 支持 Python 和 C#。官方说明：Python 语法较简洁、第三方库较多，也是研究笔记本使用的语言；C# 通常执行更快，也便于向 C# 编写的 LEAN 模块贡献功能。

账号设置中的首选语言会影响自动补全和 IntelliSense 的校验，以及新项目默认文件类型：Python 对应 `.py`，C# 对应 `.cs`。

## 更改语言 · Change Languages

1. 登录 Algorithm Lab。
2. 在顶部导航点击 **用户名 > My Account（我的账号）**。
3. 在 **Account Settings（账号设置）** 中选择 **C#** 或 **Python**。

出现“Preferred language setting has been updated”表示首选语言已更新。

## 自动补全与智能提示 · Autocomplete and Intellisense

IntelliSense 根据正在输入的内容和上下文展示可用成员，帮助补全方法名和对象属性。弹出框会显示成员类型、说明以及方法所接受的参数。

所读原文说明，该工具适用于 LEAN 默认类成员，但尚不支持类名或用户自定义对象的相应智能提示。实际能力可能随平台更新变化。

## 使用自动补全 · Use Autocomplete

1. 打开项目。
2. 输入变量、函数、类或类成员的前几个字符，例如 Python 中的 `self.set`。
3. 按 **Ctrl+Space**。
4. 如果出现匹配项，选择需要补全的成员。

编辑器会自动填写其余部分。

## 控制台 · Console

IDE 底部面板提供开发时需要的信息。

### Cloud Terminal（云端终端）

展示 API 消息、错误和算法日志。点击面板右上角 **Clear Logs（清除日志）** 图标，可清空终端显示内容。

![云端终端](https://cdn.quantconnect.com/i/tu/cloud-terminal-qc-cloud.png)

### Problems（问题）

突出显示代码中的错误，帮助定位构建问题。

![Python 代码问题面板](https://cdn.quantconnect.com/i/tu/console-problems-py-qc-cloud.png)

## AI 对话 · AI Chats

**Ask Mia** 面板用于与 Mia 私密对话。Mia 是平台训练的 AI 助手，具备项目上下文，可使用工具修改项目文件、运行回测和部署实时策略。

打开项目后，在右侧导航点击 **Ask Mia** 图标即可进入。

![Ask Mia 面板](https://cdn.quantconnect.com/i/tu/ask-mia-python.png)

## 管理节点 · Manage Nodes

**Resources（资源）** 面板展示组织中的云端回测、研究和实时交易节点。打开项目后，在右侧导航点击 **Resources** 图标。

| 字段 | 含义 |
| --- | --- |
| Node | 节点名称和型号 |
| In Use By | 正在使用节点的项目所有者和项目名称 |

点击节点旁的停止按钮，可以停止自己使用的节点。停止其他成员使用的节点需要相应权限。

启动回测或研究笔记本时，平台默认选择资源集群中最佳可用节点。需要指定节点时，可勾选面板中对应节点旁的复选框。

![节点管理面板](https://cdn.quantconnect.com/i/tu/resource-panel.png)

## 文件大纲导航 · Navigate the File Outline

Explorer 中的 **Outline（大纲）** 列出当前文件中的类、成员和函数。点击名称，光标会跳到对应定义处。打开项目并点击右侧 **Explorer** 图标，即可查看该区域。

## 拆分编辑器 · Split the Editor

编辑器可水平或垂直拆分，同时展示多个文件。

1. 打开项目，点击右侧 **Explorer**。
2. 在 **QC (Workspace)** 区域拖放需要打开的文件，安排编辑器分屏。

官方建议用分屏代替在多个浏览器标签中打开同一项目。多个标签会创建多个代码会话，同时更新同一项目，可能造成会话不同步。

![拆分编辑器示例](https://cdn.quantconnect.com/i/tu/split-editor.gif)

## 显示和隐藏代码块 · Show and Hide Code Blocks

打开项目，点击行号旁的箭头图标，即可折叠或展开代码块，方便浏览长文件。

![折叠代码块](https://cdn.quantconnect.com/i/tu/toggle-code-block-displays-1.gif)

## 键盘快捷键 · Keyboard Shortcuts

1. 打开项目，按 **F1**。
2. 输入 `Preferences: Open Keyboard Shortcuts`。
3. 点击同名命令，查看快捷键列表。

要为命令设置快捷键，点击列表左侧铅笔图标，输入按键组合，再按 **Enter**。

## 主题 · Themes

1. 登录账号，在顶部导航选择 **用户名 > My Account**。
2. 在 **Account Settings** 中点击 **Light Theme（浅色主题）** 或 **Dark Theme（深色主题）**。

账号页面会刷新并显示新主题。

## 支持的浏览器 · Supported Browsers

IDE 支持 Chrome、Edge、Firefox 和 Safari。其他浏览器可能可用，但不在正式支持范围内；原文说明平台测试过 Brave 和 Opera，发现它们兼容。

## 故障排查 · Troubleshooting

若 IDE 无法载入，官方列出以下排查步骤：

1. 确认使用支持的浏览器。
2. 检查网络连接及速度。
3. 换用另一款支持的浏览器测试。
4. 检查 VPN 是否影响连接，按需暂时关闭后测试。
5. 检查浏览器扩展是否影响运行。
6. 检查杀毒软件设置。原文指出部分产品的网络保护会阻止 IDE 所需的 Service Workers。
7. 检查 DNS。部分网络可能无法解析相关服务；官方提供了 Google Public DNS 等配置资料。
8. 换一台电脑、平板或手机测试。
9. 清除浏览器缓存，特别是可能缓存旧版 IDE 内容的情况。
10. 检查硬盘空间。
11. 重启电脑和路由器。

原文相关参考：[Google Public DNS](https://developers.google.com/speed/public-dns/docs/using)、[Firefox DNS-over-HTTPS](https://support.mozilla.org/en-US/kb/firefox-dns-over-https)、[macOS 的 1.1.1.1 设置](https://developers.cloudflare.com/1.1.1.1/setup/macos/)。

若仍未解决，收集浏览器控制台日志并联系 Support Team。以上是原文排查建议的中文转述，不表示已经定位了你当前设备的问题。
