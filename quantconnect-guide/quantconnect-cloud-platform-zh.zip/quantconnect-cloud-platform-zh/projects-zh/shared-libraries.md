# 共享代码库 · Shared Libraries

## 简介 · Introduction

项目代码库本身也是 QuantConnect 项目，可添加到其他项目中，避免重复复制代码。如果多个项目使用同一工具，可以把它整理成代码库。

## 创建代码库 · Create Libraries

1. 创建一个新项目，在 Project 面板点击 **Add Library（添加代码库）**。
2. 点击 **Create New（新建）**。
3. 在 **Input Library Name（输入代码库名）** 填写名称，例如 `Calculators`。
4. 若需放在目录中，使用 `directoryName/libraryName`，例如 `Tools/Calculators`。
5. 点击 **Create Library（创建代码库）**。
6. 在右侧导航点击 **Explorer**，找到添加进项目的模板文件。
7. 将 `Library.py`（Python）或 `Library.cs`（C#）改为体现用途的名称，例如 `TaxesCalculator.py`，再实现代码。

## 添加代码库 · Add Libraries

1. 打开目标项目，在 Project 面板点击 **Add Library**。
2. 点击 **Choose a library...（选择代码库）**，从下拉菜单选择目标代码库。
3. 点击 **Add Library**。
4. 在右侧 **Explorer** 中查看加入的文件。
5. 在项目代码中导入代码库，才能使用其中的功能。

原文 Python 导入示例：

```python
# 中文注释版：仅补充解释，保留原示例的执行语句。
# 从已添加的共享代码库导入工具类；需先创建对应模块。
from Calculators.TaxesCalculator import TaxesCalculator

# 定义继承 QCAlgorithm 的策略类，由 LEAN 管理其生命周期。
class AddLibraryAlgorithm(QCAlgorithm):
    # 创建工具对象；此处写在类体中，属于类属性。
    taxes_calculator = TaxesCalculator()
```

这是导入用法示例，假设对应代码库、类和算法导入环境已经存在。

## 重命名代码库 · Rename Libraries

打开代码库对应的项目，然后按项目重命名的操作修改名称。

## 移除代码库 · Remove Libraries

1. 打开引用该代码库的项目。
2. 在 Project 面板将鼠标移到代码库名称上。
3. 点击出现的垃圾桶图标。

代码库文件会从当前项目移除。

## 删除代码库 · Delete Libraries

删除代码库对应的项目。与“从某个项目移除引用”不同，这里操作的是代码库项目本身。

## 最佳实践 · Best Practices

每个代码库都是项目，因此有自己的文件配额。项目超出配额时，可将部分代码拆入代码库。

共享代码库一经修改，引用它的所有项目都会接收到变动。只将稳定且多个项目都需要的代码放进共享库；尚在开发、或仅供一个项目使用的代码，先保留在该项目中。
