# 调试 · Debugging

## 简介 · Introduction

调试是使用工具系统地查找和修复程序错误的过程。错误可能导致意外交易、程序崩溃或错误的风险管理逻辑。可使用内置调试器逐行运行并查看变量，也可借助日志、图表和 Object Store。

## 代码错误 · Coding Errors

一般分为构建错误、运行时错误和逻辑错误。

### 构建错误 · Build Errors

语法检查未通过时产生。例如下列 Python 片段误将比较写成赋值，**这是原文用于演示错误的代码，不是正确写法**：

```python
# 中文注释版：故意出错的教学示例，保留错误用于说明语法检查。
a = 1
# 故意保留的语法错误：条件比较应使用 ==，不能使用赋值符号 =。
if a = 2:
    pass
```

发生构建错误时，不能依靠运行中的调试器、日志或自定义图表调查它。IDE 会通过错误行的红色下划线、底部 Problems 面板，以及 Explorer 中的红色提示标出问题。

### 运行时错误 · Runtime Errors

语法检查通过，但执行过程中出现异常。例如列表只有一个元素，却访问索引 1：

```python
# 中文注释版：仅补充解释，保留原示例的执行语句。
a = [1]
# 故意保留的越界访问：列表只有索引 0，这一行会抛出 IndexError。
a[1]  # 原文错误示例：IndexError
```

Cloud Terminal 和日志文件会记录错误堆栈。点击 **Open Stack Trace（打开堆栈跟踪）** 查看更多信息，定位文件与行号。如果堆栈没有指向项目文件，也可能涉及 LEAN 或依赖库，需要进一步调查。

### 逻辑错误 · Logic Errors

程序可以运行，但行为与预期不一致。例如原本想求平均值，却写成：

```python
# 中文注释版：仅补充解释，保留原示例的执行语句。
# 故意保留的逻辑错误：除法优先执行，求均值应写成 (x + y) / 2。
average = x + y / 2  # 错误示例；原本意图是 (x + y) / 2
```

此类问题通常不会停止程序，因此需要仔细追踪逻辑。可用 `log`、`debug` 或内置调试器检查变量和条件。

## 调试器 · Debugger

内置回测调试器可以减慢执行、逐行运行程序并检查变量，帮助理解内部状态。详细操作属于官方 Backtesting / Debugging 章节；此处保留原文的章节引用关系，不把它当作已经翻译的内容。

## 日志语句 · Logging Statements

日志把字符串消息写入文件，供回测后或实时运行中分析。适当记录条件分支和运行状态，有助于排查逻辑问题，也方便对比回测与实时行为。

### Log

`log` 在算法继续执行时写入日志。**不允许通过日志记录数据集信息。** 日志量受组织配额限制。

重复记录相同内容时，日志通常只保留第一次。需要区分多次事件时可在消息中带上时间戳。原文说明云端实时项目日志最多保留 100,000 行和一年的记录，超出时移除较旧内容；配额以当前平台为准。

```python
# 中文注释版：仅补充解释，保留原示例的执行语句。
# 记录常规运行信息，消息写入日志并计入日志额度。
self.log("我的日志消息")
```

需要记录停止时的算法状态，可在 `on_end_of_algorithm` 事件中写日志。

### Debug

`debug` 与日志类似，但消息在 Cloud Terminal 中以橙色显示，适合少量需要注意的信息。原文规定消息最多 200 个字符，且一秒内多条消息会受到限流。

```python
# 中文注释版：仅补充解释，保留原示例的执行语句。
# 输出醒目的调试信息；避免在高频回调中大量发送。
self.debug("需要关注的调试消息")
```

### Error

`error` 以红色显示消息，用于最需要注意的情况，也会受到限流。

```python
# 中文注释版：仅补充解释，保留原示例的执行语句。
# 用错误级别记录诊断消息；此调用本身不等于抛出异常。
self.error("错误信息")
```

### Quit

`quit` 请求停止项目运行，并可记录消息。调用后，当前方法仍会执行到结束；如需立即退出当前方法，应随后使用 `return`。

```python
# 中文注释版：仅补充解释，保留原示例的执行语句。
# 请求停止算法；下方 return 用来立即退出当前处理方法。
self.quit("停止原因")
return
```

### 日志最佳实践

每条日志都会消耗执行时间并计入配额。不要在每个时间步触发的 `on_data` 或高频定时事件中无条件大量写日志，只记录正在调查的条件。

常规记录优先使用 `log`。`debug` 经过消息系统，有额外开销和限流，留给少量需要突出显示的信息。

可以通过日志级别集中控制诊断输出：

```python
# 中文注释版：仅补充解释，保留原示例的执行语句。
# 将诊断输出集中到辅助方法，用 level 控制详细程度。
def _trace(self, level, message):
    # 只有消息级别未超过配置值时才记录。
    if level <= self._log_level:
        # 记录常规运行信息，消息写入日志并计入日志额度。
        self.log(message)
```

调用方会先构造消息，再执行方法。要连字符串格式化的成本也省去，应在高频调用处先检查级别：

```python
# 中文注释版：仅补充解释，保留原示例的执行语句。
# 先检查开关，再构造格式化字符串，减少关闭诊断时的计算开销。
if self._log_level >= 2:
    self._trace(2, f"{self.time}: {symbol} at {price}")
```

记录下单原因时，优先考虑订单标签：

```python
# 中文注释版：仅补充解释，保留原示例的执行语句。
# 提交止损市价卖单，并用标签记录原因；stop_price 需事先定义。
self.stop_market_order(symbol, -quantity, stop_price, tag="stop loss")
```

这些是局部用法片段，需要放入具备相应变量和配置的策略上下文。

## 订单标签 · Order Tagging

下单时可以通过 `tag` 记录原因，例如触发交易的指标值或条件。标签直接附在订单上，保存在可下载的结果中，不必再从日志中匹配交易，而且不会消耗日志配额。

以下保留官方 Python 示例：

```python
# 中文注释版：仅补充解释，保留原示例的执行语句。
# 定义继承 QCAlgorithm 的策略类，由 LEAN 管理其生命周期。
class OrderTaggingAlgorithm(QCAlgorithm):
    # 初始化只在算法开始时运行一次，设置回测条件和数据订阅。
    def initialize(self) -> None:
        # 设置历史回测的开始日期。
        self.set_start_date(2024, 9, 1)
        # 设置历史回测的结束日期。
        self.set_end_date(2024, 12, 31)
        # 设置回测初始资金为 100,000 单位账户货币。
        self.set_cash(100000)

        # 订阅 SPY 日线，并保存标的标识以供指标和订单使用。
        self._symbol = self.add_equity("SPY", Resolution.DAILY).symbol
        # 创建 10 期指数移动平均，作为短期信号。
        self._ema_short = self.ema(self._symbol, 10)
        # 创建 30 期指数移动平均，作为长期信号。
        self._ema_long = self.ema(self._symbol, 30)

    # 行情到达时执行；data 包含该时间片可用的数据。
    def on_data(self, data: Slice) -> None:
        # 两个指标都准备好才继续；不足所需历史数据时直接返回。
        if not self._ema_short.is_ready or not self._ema_long.is_ready:
            return

        # 读取短期 EMA 的当前数值。
        ema_short = self._ema_short.current.value
        # 读取长期 EMA 的当前数值。
        ema_long = self._ema_long.current.value
        # 短期线高于长期线且尚非多头时，进入买入分支。
        if ema_short > ema_long and not self.portfolio[self._symbol].is_long:
            # 提交买入 100 股的市价单，并把指标值写进订单标签；不是设置目标仓位。
            self.market_order(self._symbol, 100, tag=f'BUY: ema-short: {ema_short:.4f} > ema-long: {ema_long:.4f}')
        # 短期线低于长期线且尚非空头时，进入卖出分支。
        elif ema_short < ema_long and not self.portfolio[self._symbol].is_short:
            # 提交卖出 100 股的市价单；实际结果取决于已有持仓，不保证直接变成空头。
            self.market_order(self._symbol, -100, tag=f'SELL: ema-short: {ema_short:.4f} < ema-long: {ema_long:.4f}')
```

## 图表 · Charting

调用 `plot`，传入图表名称、序列名称和值，即可用图表观察变量随时间变化。

```python
# 中文注释版：仅补充解释，保留原示例的执行语句。
# 依次指定图表名、序列名和本次要绘制的数值。
self.plot("Chart Name", "Series Name", value)
```

所读原文规定每个序列的数据点上限为 4,000。超过上限时会出现：

```text
Exceeded maximum data points per series, chart update skipped.
```

中文含义：超过序列数据点上限，本次图表更新被跳过。大量图表数据可能无法高效传输和在浏览器中显示。

## 对象存储 · Object Store

Object Store 是低延迟键值存储。回测中可将较大的对象保存下来，供之后分析，尤其适合难以直接绘图或需要跨多次回测比较的情况。

```python
# 中文注释版：仅补充解释，保留原示例的执行语句。
# 使用键 key 保存 value；需有存储权限，且值满足此 API 的类型要求。
self.object_store.save("key", value)
```

官方 Object Store 文档另有保存指标后在研究环境绘图、以及保存订单数据后分析的示例。此代码同样是局部 API 用法，不是一份独立算法。
