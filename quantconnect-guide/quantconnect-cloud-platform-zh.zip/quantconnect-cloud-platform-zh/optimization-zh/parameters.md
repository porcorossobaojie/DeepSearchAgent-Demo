# 参数 · Parameters

## 简介 · Introduction

参数是在代码外配置、运行时传入算法的项目变量，例如指标周期和历史窗口长度。优化器按指定范围及步长改变参数，比较目标指标。

需要在 Project 面板创建参数，并在代码中实际读取它；仅在面板添加而代码仍用固定数值，不会产生预期的参数变化。

## 设置参数 · Set Parameters

添加：打开项目，在 Project 面板点击 **Add New Parameter**，填写唯一名称和默认值，点击 **Create Parameter**。

修改默认值：鼠标移到参数上点击铅笔，输入数值并 **Save**。

删除：点击参数旁垃圾桶，同时删除代码里关联的 `get_parameter`／`GetParameter` 调用。

## 获取参数 · Get Parameters

原文在此链接到 Writing Algorithms 的 Get Parameters API。具体返回类型和默认值应按该 API 使用；代码中的参数名须与面板一致。本节不虚构一份原文没有的完整策略。

## 参数数量 · Number of Parameters

所读云端优化器最多三个参数。原因包括：网格搜索会遍历全部组合，参数越多任务数增长越快；结果图最多三维；大量变量更容易过拟合。

超过三个参数的优化可查阅 CLI 本地流程。此上限是源码记录，实际以平台为准。
