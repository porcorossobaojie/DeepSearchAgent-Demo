# 入门 · Getting Started

## 简介 · Introduction

参数优化是在一组候选值中寻找让目标指标更大或更小的组合，例如改变指标周期以提高回测夏普比率。优化能改善历史表现，但可能过度适应过去；需要用未参与调参的数据验证。

## 启动优化任务 · Launch Optimization Jobs

准备条件：项目至少有一个算法参数；代码通过 `get_parameter`／`GetParameter` 或参数属性使用它；已有一次成功回测；组织有 QCC 点数。

1. 打开项目，点击 IDE 右上 **Optimize（优化）**。
2. 在 **Parameter & Constraints** 输入与 Project 面板完全一致的参数名。
3. 输入最小值和最大值，点击参数旁齿轮设置步长。
4. 可点击 **Add Parameter**，所读云端文档上限为三个参数；更多参数需查阅本地 CLI 优化。
5. 如需约束，点击 **Add Constraint**，选择统计目标、运算符并输入数值。
6. 在费用估算区域选择优化节点型号和最大节点数。
7. 在 **Strategy & Target** 选择搜索策略和目标，点击 **Maximize** 或 **Minimize**。
8. 点击 **Launch Optimization**。

任务在云端运行，可关闭或刷新页面。中止时在 Status 面板点击 **Abort** 并确认 **Yes**。

## 查看单次回测结果 · View Individual Backtest Results

结果页 Backtests 表格列出参数组合及各目标值。点击记录打开该次回测。

- 导出：右键一行，选择 **Export > CSV Export**。
- 过滤：表格右侧 **Filters**，选择列及数值运算条件。
- 列显示：右侧 **Columns** 勾选需要的列。
- 排序：点击列标题。

## 查看全部优化 · View All Optimizations

打开项目，点击顶部 **Results**。播放图标表示普通回测，快进图标表示优化。可通过 Show 过滤、Hide Error 隐藏错误结果，分页或点击列名排序。

鼠标移到优化记录，铅笔图标用于重命名，垃圾桶用于删除。

## 本地优化 · On-Premise Optimizations

原文链接到 Local Platform 入门。它是单独的本地流程，不要求为本篇云端操作先安装 Docker 或 CLI。

## 获取优化 ID · Get Optimization Id

打开优化结果页，滚动到单次回测结果表，表上方显示优化 ID，例如 `O-696d861d6dbbed45a8442659bd24e59f`。
