# 结果分析 · Results

## 简介 · Introduction

结果页比较各参数值的回测表现，用于理解敏感性和选择后续验证方向。不能仅凭最优单点认定策略有效。

## 查看优化结果 · View Optimization Results

启动任务后自动打开结果页，展示权益曲线、参数、目标值和服务器统计。云端执行中可以关闭或刷新，再从项目优化历史重新打开。

## 运行统计 · Runtime Statistics

| 字段 | 含义 |
| --- | --- |
| Completed | 成功完成的回测数 |
| Failed | 失败数 |
| Running | 正在执行数 |
| In Queue | 排队数 |
| Average Length | 单次回测平均耗时 |
| Total Runtime | 整个优化任务耗时 |
| Total | 任务回测总数 |
| Consumed | 已消耗 QCC |

## 权益曲线 · Equity Curves

Strategy Equities 图同时展示各次回测，随任务更新。可比较参数变化对收益路径的影响、观察敏感区间，并放大某段历史检查。

## 参数图 · Parameter Charts

一个参数用散点图，两个参数用热力图，三个参数用三维图。三维图可旋转、设置截断值，悬停点查看目标值。

相邻热力单元颜色接近，意味着该区域目标对参数相对不敏感，通常比孤立峰值更值得进一步验证。

图表可展示 Alpha、年化标准差与方差、平均盈亏、Beta、复合年化收益、回撤、估计容量、期望指标、信息比率、胜率与亏损率、净收益、PSR、盈亏比、夏普、总费用、交易数、跟踪误差和特雷诺比率。可画的统计项与启动时可选主目标不是同一列表。

添加图表：Parameter Chart 点击加号，选 Objective 和 Parameter 1；按参数数量再选 Parameter 2／3，点击 **Create Chart**。

## 单次回测结果 · Individual Backtest Results

Backtests 表列出参数及目标值，点击记录查看完整回测。右键 **Export > CSV Export** 下载；右侧 Filters 设置过滤，Columns 控制列，点击列标题排序。

## 服务器统计 · Server Stats

CPU、RAM 展示总使用量和各节点使用量；HOST 展示型号和节点数；Uptime 展示任务持续时间。资源需求较高时可改善代码效率，或在下次任务选择更强节点。

## 错误 · Errors

单次回测运行错误会导致该次失败，**仍可能计费**。原文称超过 700 MB 输出可能无法上传，使优化看起来永不完成。实际问题应结合任务状态与日志诊断。

## 查看全部优化 · View All Optimizations

打开项目顶部 Results，使用 Show、Hide Error、分页和排序定位记录。点击进入，悬停后的铅笔重命名，垃圾桶删除结果。
