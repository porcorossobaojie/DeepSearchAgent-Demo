# 对象存储 · Object Store

## 简介 · Introduction

Object Store 是组织级键值存储：通过唯一字符串键保存和读取对象，类似字典。常见用途包括在回测与研究环境之间传递数据，以及在研究环境训练模型后供实时策略使用。

存储由整个组织共享，组织中的不同项目可使用同一键访问数据。

原文规定它向付费组织开放。Free 算法尝试保存时会提示无权写入。可以在云端存储、缓存和复用平台数据，但仍需遵守 Data Use 条款及下载限制。

## 查看存储 · View Storage

登录 Algorithm Lab，选择 **Organization > Object Store**。列表展示组织存储内容。点击文件可查看路径、大小和内容预览。

添加或删除文件后，使用量显示约需一小时才反映实际变化。

## 上传文件 · Upload Files

1. 打开 Object Store，进入目标目录。
2. 点击 **Upload（上传）**。
3. 拖放待上传文件。

也可通过算法或研究笔记本写入存储。

## 下载文件 · Download Files

**原文要求：只有签署衍生数据协议并获得授权的 Institution 组织可以下载。** Free、Quant Researcher、Team、Trading Firm 均不支持；购买更多存储容量不会增加下载权限。

限制适用于全部文件，包括用户上传和算法生成的文件。原文解释平台无法逐文件区分个人文件和许可数据的衍生物。即使得到授权，也只能导出模型、信号文件等衍生数据，原始价格和另类数据不能下载。

获得授权后：

1. 打开 Object Store，进入目标目录。
2. 选择文件或目录，点击 **Download（下载）**。
3. 等待处理，再点击出现的 Download 链接。

没有权限时，网页下载操作不可用；API 和 CLI 会返回 `Organization does not have derivative export enabled`。

可在云端研究环境或回测中分析文件。对于回测产生且允许导出的值，可使用结果下载或在日志配额内记录，同时遵守数据条款。项目源文件不必放入 Object Store，可通过 `lean cloud pull` 拉取。

## 存储容量 · Storage Sizes

付费组织有 50 MB 免费空间，可额外订阅。增加容量不等于开放下载。下表为源码记录的月费，不是当前报价保证。

<table class="qc-table table">
    <thead>
        <tr>
            <th>存储容量（GB）</th>
            <th>最多文件数</th>
            <th>月费（美元）</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>0.05</td>
            <td>1,000</td>
            <td>0</td>
        </tr>
        <tr>
            <td>2</td>
            <td>20,000</td>
            <td>12</td>
        </tr>
        <tr>
            <td>5</td>
            <td>50,000</td>
            <td>24</td>
        </tr>
        <tr>
            <td>10</td>
            <td>100,000</td>
            <td>60</td>
        </tr>
        <tr>
            <td>50</td>
            <td>500,000</td>
            <td>120</td>
        </tr>
    </tbody>
</table>

## 删除存储内容 · Delete Storage

1. 打开 Object Store，进入目标目录。
2. 勾选文件。
3. 点击 **Actions（操作）> Delete（删除）**。
4. 点击 **OK**。

也可在算法或研究笔记本中删除。

## 编辑存储方案 · Edit Storage Plan

需要付费组织和存储账单权限。

1. 打开 **Organization > Resources**。
2. 滚动到 **Storage Resources（存储资源）**，点击 **Add Object Store Capacity（增加对象存储容量）**。
3. 在 Pricing 页面选择方案，点击 **Proceed to Checkout**。

## 从研究到实时运行的注意事项 · Research to Live Considerations

Object Store 修改后，实时算法可能在几分钟后才访问到变化，算法需要能处理数据集变化。

实时环境访问 Object Store 比研究和回测慢得多。原文建议单个对象小于 50 MB，以减少实时访问问题。

## 按项目查看使用量 · Usage by Project

**Organization > Resources** 展示组织存储总量及各项目的使用量，可用于管理空间。

## 特殊目录 · Special Folders

组织 Object Store 中保留 `.assistant` 目录，供 QuantConnect AI 智能体读取：

| 子目录 | 用途 |
| --- | --- |
| skills | 可复用指令与约定 |
| memories | 每个项目的上下文，路径为 `<project_id>/memory.md` |
| templates | 新项目使用的自定义模板 |

这些文件在组织内共享，通过 Upload Files 相应操作添加和更新。它们是平台产品功能说明，不会自动成为当前文档制作任务的指令。
