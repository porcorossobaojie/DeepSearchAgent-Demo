# 课程学习与培训 · Training

## 简介 · Introduction

学习中心是在 LEAN 环境中学习量化交易的编程课堂，课程来自平台团队和社区作者。通过练习学习组合管理、技术指标、股票池、交易自动化以及行情如何进入算法。完成后可以保留代码继续研究或部署。

组织可以通过课程培训新成员，并跟踪学习进度。已购买或创建的课程可从 **Organization > Resources** 访问。所读原文将完成 Bootcamp 30% 作为论坛发帖条件，实际要求以当前平台为准。

## 文章 · Articles

平台将相关教程组织为 **Learning Series（学习系列）**：

- Investment Strategy Library：介绍学术文献中的策略及其 LEAN 实现。
- Introduction to Financial Python：在量化金融背景下学习 Python 基础。
- Introduction to Options：面向具备基本数学、统计与市场知识的期权初学者。
- Applied Options：面向已懂期权市场的读者，介绍简单期权算法。

## 付费课程 · Paid Courses

原文写有“当前仅有免费教程，预计在 2023 年扩展付费课程”。这是旧计划，不能当作当前课程供给。

其描述的付费方式按组织成员数乘以课程标价，购买后成员可长期访问。实际产品与费用以课程页为准。

## 私有课程 · Private Courses

私有课程不对其他组织出售，可上传到 **Organization > Resources** 用于内部培训，并利用学习中心跟踪成员进度。原文主要面向大型 Institution 团队。

## 查看所有课程 · View All Courses

打开 **Learning Center > All Courses**。课程列表展示名称、说明、作者、价格、评价和学员数；点击课程可查看讲师介绍、先修要求、课程大纲和评论。

## 报名课程 · Enroll in Courses

1. 登录 Algorithm Lab，选择 **Learning Center > All Courses**。
2. 点击目标课程。
3. 点击 **Enroll（报名）**，进入课程环境。

## 使用课程 IDE · Navigate the Course IDE

1. 阅读左侧任务说明。
2. 在 `main.py` 填写答案。
3. 如需提示，滚动到说明底部点击 **Show Hint**。
4. 如需参考，点击 **Solution** 打开 `solution.py`。
5. 可点击 **Reset** 重置 `main.py`。
6. 点击 **Submit** 检查答案，Chart 面板展示回测结果。
7. 如有错误，修改代码后重新提交；通过后点击 **Continue**。

## 查看课程进度 · View Course Progress

在 All Courses 打开课程，**About this Course** 区域显示你的进度。

## 查看已完成课程 · View Completed Courses

登录后打开 **Learning Center > Completed**。

## 提交评价 · Submit Reviews

需要先完成课程。

1. 打开 Completed Courses，点击目标课程。
2. 滚动到 **User Reviews**，选择星级。
3. 填写评价，点击 **Submit Review**。

## 报告错误 · Report Errors

向平台发送错误说明，并提供出错任务的网址。对应联系链接保留在本节原文相关链接中。
