# 研究文章 · Research

## 简介 · Introduction

Research 页面收录平台和社区的策略研究，帮助学习完整 LEAN 实现。投稿可能用于社区展示、建立声誉或获得 QCC，但需审核。

## 提交研究提案 · Submit Proposals

正式投入前，先写明策略类型、资产和股票池、所需数据、预期结果及参考论文。平台偏好有金融概念、理论或模型的研究，而不只是指标和过拟合参数的拼接。

1. 打开 Research，点击 **Share New Research**。
2. 填 Title，采用规范标题大小写。
3. 在模板 Introduction 替换占位文字，说明研究问题与资源。
4. 有参考文献时填写 References。
5. 点击 **Publish Research**，等待审核邮件。

## 发布内容 · Publish Content

提案通过后，实现策略或笔记本。打开文章草稿，在 Introduction 右上三点 > Edit，补研究内容、附回测或笔记本，点击 Update。平台复核后决定是否推荐发布。

## 内容指南 · Content Guidelines

以下为官方投稿规则的中文转述，不是本中文说明文档的投稿声明：

- 有金融理论或模型依据，代码简洁并有充分注释。
- Python 遵循 PEP8，正文使用准确英文。
- 原文明确要求投稿文本不能由 ChatGPT 等 LLM 生成。
- 行内代码按投稿格式加粗，数学使用 LaTeX，资产类别名称按规定大写。
- 一级标题包含 Introduction、Background、Implementation、Results，可选 References。

Introduction 概括策略、数据和结果；Background 定义指标和组合方法；Implementation 逐步解释代码并链接文档；Results 说明区间、夏普、基准比较和参数敏感性，附夏普热力图，并讨论局限；References 按 APA 列出来源。

## 示例 · Examples

原文推荐 Low Beta Portfolios Across Industries、Opening Range Breakout for Stocks in Play、Kelly Criterion Applications in Trading Systems、Bitcoin as a Leading Indicator、Automating the Wheel Strategy。链接见下方来源，原文作品不视为收益推荐。
