# 论坛 · Forum

## 简介 · Introduction

论坛用于与社区、Mia、平台团队和集成合作伙伴讨论。原文要求完成 Bootcamp 30% 才能发帖，实际门槛以当前平台为准。

## 讨论 · Discussions

讨论由主题和评论组成，可附回测、笔记本、代码、图片、视频和文件，支持书签、评论链接、格式化文本、LaTeX、点赞和 QCC 奖励。求助前先完成自己的研究和测试。

## 分享回测 · Sharing Backtests

分享有助于复现策略、研究和问题，但会公开用于生成结果的项目文件。旧回测可能因引擎更新而产生不同结果。

原文只允许附不报错的回测，建议必要时在错误发生前调用 quit。这样只是在预定位置停止，不代表错误得到修复；报告问题时仍需说明复现条件。

## 平台点数 · Credit

可用 QCC 奖励贡献。下表保留已翻译的原文奖项及费用，实际金额以平台为准。

| 奖项（保留原名） | 中文说明 | QCC |
| --- | --- | --- |
| 银奖 · Silver Award | 量化研究者之间的认可，鼓励继续努力。 | 80 |
| 金奖 · Gold Award | 认可出色工作，送上一颗金星。 | 600 |
| 铂金奖 · Platinum Award | 表彰经得起时间考验、坚实而实用的贡献。 | 1,200 |
| 卓越勋章 · Medal for Excellence | 由平台工作人员授予对社区有卓越贡献的成员。 | 3,000 |
| 钚元素奖 · Plutonium Award | 认可令人惊叹的帖子，表达对作者的感谢。 | 2,000 |
| 文档莎士比亚奖 · Docs Shakespeare | 表彰文档贡献，其修改与示例可帮助后来者。 | 500 |
| 诺贝尔学者奖 · Nobel Laureate | 表彰量化研究方面的进展。 | 80 |
| 意大利面代码奖 · Spaghetti Code Award | 幽默地认可流程盘根错节却能编译运行的代码。 | 300 |
| 绝地量化师 · Jedi Quant | 认可展现量化潜力与编程能力的贡献。 | 200 |
| 实时交易者 · Live Trader | 认可看起来颇为惊险的交易经历。 | 50 |
| 今天学到了 · Today I Learned | 感谢分享新知识。 | 50 |
| 机器反学习 · Machine Unlearning | 幽默地表达希望让计算机承担全部工作的想法。 | 150 |
| 完全过拟合 · Totally Overfit | 幽默地评价到处堆满参数的过拟合现象。 | 80 |
| 脑洞大开奖 · Mind Blown Award | 表彰令人震撼、超出想象的内容。 | 80 |
| 研究伦勃朗奖 · Research Rembrandt | 认可将图表与分析组织得如艺术品的 Jupyter 笔记本。 | 100 |
| 开曼群岛奖 · Cayman Island Award | 幽默地表达一起坐船创办基金的愿望。 | 800 |
| 印钞机奖 · Printing Money Award | 奖励盈利算法。 | 100 |
| 团结力量奖 · Stronger Together Award | 表达携手合作的支持。 | 120 |
| 感谢支持奖 · Appreciate the Support Award | 量化交易路途艰难，感谢伸出援手。 | 250 |
| 匠心大师 · Master Craftsman | 表彰将原材料打磨成有益成果的精湛技艺。 | 600 |


## 通知 · Notifications

在 community feed 的 **Community Mailing List** 选择 Subscribe 或 Manage Subscriptions，可管理全部讨论邮件。单个讨论的订阅可通过添加或移除书签切换。

## 搜索讨论 · Search Discussions

打开论坛首页，点击放大镜，输入关键词。

## 创建讨论 · Create Discussions

1. 登录论坛，点击 **Start New Discussion**。
2. 填写标题和内容。
3. 如需附回测，点击 Attach Backtest，选择自己拥有的项目和回测。
4. 在 Discussion Tags 可点 Show All 选择相关标签。
5. 点击 **Publish Discussion**。

附回测意味着分享当次使用的全部项目文件。

## 发表评论 · Post Comments

只能评论开放中的讨论。打开主题，可点击某条下方 Reply 回复；或到页面底部填写顶层评论。顶层评论可以附自己项目的回测，最后点 Reply。

关闭讨论需要重新打开时联系平台。

## 采纳答案 · Accept Answers

仅主题创建者可采纳。打开讨论，在目标评论点 **Accept Answer**。讨论会关闭，采纳答案的副本会置于第一条评论。

## 赠送奖励 · Give Rewards

组织需有足够 QCC。打开讨论，对主题点 Reward Discussion，或对回答点 Reward Answer，选择奖项后 **Send Reward**。费用从组织余额扣除。点赞则点击拇指图标。

## 分享评论 · Share Comments

打开讨论，在目标评论右下角点分享图标，再选分享方式。

## 编辑评论 · Edit Comments

原文只允许发布后五分钟内编辑。评论右上角三点 > Edit，修改文本；需替换回测时点 Update Backtest，选择自己的项目及回测，最后点 Update。

## 删除评论 · Delete Comments

向平台发送评论网址和删除原因，由平台考虑处理。本文未发送此请求。

## 查看成员资料 · Access Member Profiles

打开讨论，点击成员头像。

## 管理书签 · Manage Bookmarks

登录后在讨论第一条评论右下角点击书签，再点一次移除。论坛首页 **Bookmarked** 展示已收藏讨论。
