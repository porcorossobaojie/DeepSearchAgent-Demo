# 集成合作伙伴 · Integration Partners

## 简介 · Introduction

合作伙伴是经平台筛选的独立顾问或公司，可提供咨询、培训、策略实现和代码开发，不是平台员工的同义词。

## 聘用合作伙伴 · Hire Integration Partners

伙伴需经过测试，自行确定价格及服务，可涵盖初级到高级框架学习、项目咨询、算法开发和组合优化。通过 Integration Partners 页面联系，具体交付和收费由双方约定。

## 加入伙伴计划 · Join the Integration Partner Team

联系平台并通过测试，获接纳后可列出服务。原文称伙伴保留服务收入的 100%，自行决定价格、内容和时间。实际合同以当前计划为准。
