# 个人资料 · Profile

## 简介 · Introduction

资料页可从论坛公开访问，展示个人信息、首选语言、近期活动和徽章。修改前需理解哪些信息公开。

## 个人信息 · Personal Information

页面包括用户名、头衔、头像、简介、社交账号、网站和加入日期。

头像：顶部 **用户名 > Change Profile Image**，Browse 选择 `.gif`／`.jpg`／`.png`，小于 1 MB，点击 Save。

用户名、头衔、简介及社交链接：打开 **用户名 > My Profile**，悬停对应内容点击 Edit，输入后点 OK。

## 组织 · Organizations

资料页展示加入的组织及各自加入日期。

## 活动 · Activity

展示最近五条论坛发言，以及经验、评论、讨论、算法分享等社区统计。也展示回测次数和 Bootcamp 完成比例等平台使用统计，便于其他人了解参与和经验。

## 徽章 · Badges

| 原名 | 原文获得方式 |
| --- | --- |
| Algorithm Sharing | 分享算法 |
| Chatter Box | 发布至少 100 条评论 |
| Backtester | 至少 100 次回测 |
| Live Trading / Parallel Live Trading | 部署实时算法／同时运行多个 |
| Connected With Discord | 关联官方 Discord |
| C# / Python Programming | 设置首选语言 |
| Popular | 获至少 10 位不同成员点赞 |
| Boot Camp Private / Corporal / Major | 完成初／中／高级训练 |
| Notebook Sharing / Broadcaster | 分享笔记本／运行中的算法 |
| Cloner | 克隆至少 100 个社区算法 |
| Bug Hunter | 报告至少 10 个问题 |
| Open Source Contributor | 向平台 GitHub 仓库提交 PR |
| Alpha Streams Developer / Artisan / Master | 原文分别为提交 1／3／10 个 Alpha |
| Alpha Winner #1 / #2 / #3 | 原文竞赛前三名 |
| Community Editor / Outstanding Community Service | 社区服务贡献 |

徽章及 Alpha Streams 相关活动可能含历史项目，不能据此认定当前仍开放。

## 登录 · Log In

顶部 Sign In，可使用注册时的 Google、Facebook 或邮箱方式。邮箱用户填写邮箱和密码。启用 2FA 时输入验证器代码；丢失设备可联系支持。

## 切换双重验证 · Toggle 2FA

**用户名 > My Account > Security**。启用：Activate，确认邮箱并按弹窗完成 Activate Two Factor。停用：Deactivate，输入邮箱后 Continue。实际流程以当前安全界面为准。

## 请求 API Token · Request API Token

My Account 的 Security 点击 **Request Email With Token and Your User-Id for API Requests**，点 OK。平台将用户 ID 和 Token 发到邮箱。不要将 Token 填入公开代码或论坛。

## 重置 API Token · Reset API Token

先停止正在运行的回测、优化、实时算法和笔记本，再到 My Account > Security，点击 Reset My Token，确认 OK，查看新 Token 邮件。

## 关闭活动会话 · Close Active Sessions

My Account > Security，在目标会话旁点 Sign Out。出现 Session terminated successfully 表示结束该登录会话。

## 管理邮件订阅 · Manage Email Subscriptions

My Account > Account Settings > Manage Email Subscriptions，勾选或取消所需订阅。

## 修改邮箱 · Change Email

My Account > Security > Change Email，填写当前邮箱、新邮箱并再次确认，点 Change Email。确认邮件发到**当前旧邮箱**，需进入邮件点击确认。

原文要求支持团队只接受从注册邮箱发起的更改请求。无法访问旧邮箱时，原文建议创建由自己控制邮箱的新账号；具体恢复条件需联系平台确认。

## 修改密码 · Change Password

顶部用户名 > Change Password，填写当前密码、新密码和确认，点击 Reset Password，再填写邮箱并 Continue。

## 退出登录 · Sign Out

顶部用户名 > Sign Out。

## 停用账号 · Deactivate Account

停用可恢复：资料和关联内容向他人隐藏，服务器保留相关数据，但原文排除超过 90 天的回测结果。

My Account 底部点 Deactivate Account，再次确认，输入邮箱并 Continue。以后登录可重新激活。保留规则以当前政策为准。

## 删除账号 · Remove Account

联系平台申请从服务器移除账号。它与可恢复的停用不同；本文仅翻译流程，未替你操作。
