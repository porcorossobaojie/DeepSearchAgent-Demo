# Discord 即时交流 · Discord

## 简介 · Introduction

加入官方 Discord，与社区成员、Mia 和平台团队实时交流。官方邀请地址保留在本节原文相关链接中。

## 行为准则 · Code of Conduct

Discord 同样适用社区行为准则。它不是付费私密工单或实时部署调试服务的替代品。
