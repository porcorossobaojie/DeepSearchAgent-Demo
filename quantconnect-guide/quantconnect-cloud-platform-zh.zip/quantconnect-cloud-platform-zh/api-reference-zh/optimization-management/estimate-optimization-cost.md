# 估算优化成本 · Estimate Optimization Cost

按源码小节排列；接口行为依据同仓库 OpenAPI 对照，重复内容合并展示。

## 简介 · 01 Introduction

估算优化执行成本和时间；最终费用可能与估算不同，不会因为估算成功就自动启动任务。

## 请求 · 02 Request

**`POST /optimizations/estimate`**

估算优化执行成本和时间；最终费用可能与估算不同，不会因为估算成功就自动启动任务。

### 请求字段

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `name` | `string` | 是 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `target` | `OptimizationTargetStatistic` | 是 | 优化目标统计。 允许值：`TotalPerformance.PortfolioStatistics.SharpeRatio`, `TotalPerformance.PortfolioStatistics.CompoundingAnnualReturn`, `TotalPerformance.PortfolioStatistics.ProbabilisticSharpeRatio`, `TotalPerformance.PortfolioStatistics.Drawdown`。 |
| `targetTo` | `OptimizationTargetTo` | 是 | 目标方向 min/max。 允许值：`min`, `max`。 |
| `targetValue` | `number` | 未列为必填 | 期望目标值。 |
| `strategy` | `OptimizationStrategy` | 是 | 优化搜索策略类名。 允许值：`QuantConnect.Optimizer.Strategies.GridSearchOptimizationStrategy`。 |
| `compileId` | `string` | 未列为必填 | 编译任务 ID；创建任务后用它查询状态。 |
| `parameters` | `array[OptimizationParameter]` | 是 | 参数列表；项目配置值与编译检测结果应按模型区分。 |
| `constraints` | `array[OptimizationConstraint]` | 未列为必填 | 优化约束。 |


嵌套对象的完整中文字段解释见 [运行与存储模型词典](../run-models.html)。

### 中文注释调用示例

以下为依据 OpenAPI 整理的调用示意，依赖身份验证章节 get_headers。ID、参数与文件均为示意，不是在本次执行的真实操作。

```python
# 中文注释版：payload 字段名保持 API 原样，含义见上方表格。
import requests

payload = {'projectId': 12345678,
 'name': 'Mia First Optimization Job',
 'target': 'TotalPerformance.PortfolioStatistics.SharpeRatio',
 'targetTo': 'min',
 'strategy': 'QuantConnect.Optimizer.Strategies.GridSearchOptimizationStrategy',
 'parameters': [{'name': 'rsi_period', 'min': 10, 'max': 20, 'step': 1}]}

# get_headers 每次生成新时间戳；本片段没有自动重试写入请求。
response = requests.post(
    "https://www.quantconnect.com/api/v2/optimizations/estimate",
    headers=get_headers(), json=payload, timeout=30
)
response.raise_for_status()
# HTTP 成功后再检查 API 业务状态。
result = response.json()
if not result.get("success", False):
    raise RuntimeError(result.get("errors", "API 未返回成功状态"))
# 后续检查 completed、status 或 url；不要把提交成功直接当作完成。
```

### 响应字段

#### HTTP 200

内容类型：`application/json`。

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `estimate` | `Estimate` | 未列为必填 | 估算结果。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


#### HTTP 401

认证失败，检查凭据、头部和客户端时间；本次没有进行在线认证验证。



## 响应 · 03 Responses

响应结构已列在本页请求说明下。更多嵌套对象见运行与存储模型词典。

## 示例 · 99 Examples

本页已提供带中文注释的最小调用。原文公共示例可能连带创建、更新或删除多个对象，完整动作保留在来源链接，未默认加入本页调用片段。
