# 创建实时算法 · Create Live Algorithm

本页按原文小节组织，并对照同仓库 OpenAPI。创建实时算法页面同时包含授权启动、读取授权和正式部署三个接口。所有示例仅供说明，没有调用用户账户。

## 简介 · 01 Introduction

本页涵盖：

- 为 alpaca、tradestation、charlesschwab 或 tastytrade 启动外部授权。成功是 HTTP 302，授权地址来自响应头，不是普通 JSON。
- 在授权流程完成后读取服务商授权结果，其中可能有访问或刷新令牌，不应输出到日志。
- 创建实时算法。需要项目、编译、实时节点、LEAN 版本及券商配置。此页示例明确采用 QuantConnect Paper Trading，不自动换成真实券商。券商配置与数据源配置是两回事。

## 请求 · 02 Request

### POST `/live/auth0/authorize`

为 alpaca、tradestation、charlesschwab 或 tastytrade 启动外部授权。成功是 HTTP 302，授权地址来自响应头，不是普通 JSON。

#### 请求字段

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `brokerage` | `string` | 是 | 券商配置对象，或外部授权时的服务商名称；按当前接口类型使用。 允许值：`alpaca`, `tradestation`, `charlesschwab`, `tastytrade`。 |


[实时交易模型词典](../live-models.html)列出券商、数据源及响应的所有引用模型。原始字段名与枚举保留英文。

#### 中文注释示例

示例依赖身份验证页的 get_headers，未在本次执行。ID、节点和命令都是待填写的示意。

```python
# 中文注释版：这不是自动运行脚本；先核对目标项目及接口行为。
import requests

# 本示例只填写最小请求字段；凭据由安全的 get_headers 提供。
payload = {'brokerage': 'alpaca'}

response = requests.post(
    "https://www.quantconnect.com/api/v2/live/auth0/authorize",
    headers=get_headers(), json=payload, timeout=30,
    # 保留 302，不让库自动跳转并丢掉授权流程的入口信息。
    allow_redirects=False
)
# 302 不是普通业务 JSON，不能直接 response.json()。
if response.status_code == 302:
    authorization_url = response.headers.get("Location")
    # 按正式授权流程使用链接；不打印或记录含会话参数的网址。
else:
    response.raise_for_status()
    raise RuntimeError("未收到预期的授权重定向")
```

#### 响应字段

##### HTTP 302

通过响应头提供授权重定向地址，定义未列 JSON 业务响应。

##### HTTP 401

认证错误；检查凭据、头部和时间，不靠无变化地重复请求解决。



### POST `/live/auth0/read`

在授权流程完成后读取服务商授权结果，其中可能有访问或刷新令牌，不应输出到日志。

#### 请求字段

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `brokerage` | `string` | 是 | 券商配置对象，或外部授权时的服务商名称；按当前接口类型使用。 允许值：`alpaca`, `tradestation`, `charlesschwab`, `tastytrade`。 |


[实时交易模型词典](../live-models.html)列出券商、数据源及响应的所有引用模型。原始字段名与枚举保留英文。

#### 中文注释示例

示例依赖身份验证页的 get_headers，未在本次执行。ID、节点和命令都是待填写的示意。

```python
# 中文注释版：这不是自动运行脚本；先核对目标项目及接口行为。
import requests

# 本示例只填写最小请求字段；凭据由安全的 get_headers 提供。
payload = {'brokerage': 'alpaca'}

response = requests.post(
    "https://www.quantconnect.com/api/v2/live/auth0/read",
    headers=get_headers(), json=payload, timeout=30
)
response.raise_for_status()
result = response.json()
# HTTP 成功后还需检查业务 success。
if not result.get("success", False):
    raise RuntimeError(result.get("errors", "API 未返回成功状态"))
# 返回对象可能含访问／刷新令牌，只在认证流程中使用，不输出。
authorization = result.get("authorization")
```

#### 响应字段

##### HTTP 200

类型：`application/json`。

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `authorization` | `object` | 未列为必填 | 授权信息对象，可能含 access/refresh token，不能打印或公开。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


##### HTTP 401

认证错误；检查凭据、头部和时间，不靠无变化地重复请求解决。



### POST `/live/create`

创建实时算法。需要项目、编译、实时节点、LEAN 版本及券商配置。此页示例明确采用 QuantConnect Paper Trading，不自动换成真实券商。券商配置与数据源配置是两回事。

#### 请求字段

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `versionId` | `string` | 是 | 部署的 LEAN 版本 ID；原文 -1 表示 master，需确认目标版本。 |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `compileId` | `string` | 是 | 编译任务 ID；创建任务后用它查询状态。 |
| `nodeId` | `string` | 是 | 运行算法的实时节点 ID。 |
| `brokerage` | `oneOf[QuantConnectBrokerageSettings, InteractiveBrokersBrokerageSettings, TradierBrokerageSettings, BitfinexSettings, CoinbaseBrokerageSettings, BinanceBrokerageSettings, BinanceUSBrokerageSettings, BinanceUSDMFuturesBrokerageSettings, BinanceCOINFuturesBrokerageSettings, TradingTechnologiesBrokerageSettings, KrakenSettings, BybitBrokerageSettings, OandaSettings, WolverineSettings, CharlesSchwabSettings, RBIBrokerageSettings, TerminalLinkSettings, TradeStationSettings, TastytradeSettings, AlpacaBrokerageSettings, WebullBrokerageSettings, PublicBrokerageSettings, ClearStreetBrokerageSettings, BloombergFixSettings]` | 是 | 券商配置对象，或外部授权时的服务商名称；按当前接口类型使用。 可选模型：`QuantConnectBrokerageSettings`, `InteractiveBrokersBrokerageSettings`, `TradierBrokerageSettings`, `BitfinexSettings`, `CoinbaseBrokerageSettings`, `BinanceBrokerageSettings`, `BinanceUSBrokerageSettings`, `BinanceUSDMFuturesBrokerageSettings`, `BinanceCOINFuturesBrokerageSettings`, `TradingTechnologiesBrokerageSettings`, `KrakenSettings`, `BybitBrokerageSettings`, `OandaSettings`, `WolverineSettings`, `CharlesSchwabSettings`, `RBIBrokerageSettings`, `TerminalLinkSettings`, `TradeStationSettings`, `TastytradeSettings`, `AlpacaBrokerageSettings`, `WebullBrokerageSettings`, `PublicBrokerageSettings`, `ClearStreetBrokerageSettings`, `BloombergFixSettings`。 |
| `dataProviders` | `object` | 未列为必填 | 数据源配置字典；顺序决定优先级，后面的源补前面的缺项。 |


[实时交易模型词典](../live-models.html)列出券商、数据源及响应的所有引用模型。原始字段名与枚举保留英文。

#### 中文注释示例

示例依赖身份验证页的 get_headers，未在本次执行。ID、节点和命令都是待填写的示意。

```python
# 中文注释版：这不是自动运行脚本；先核对目标项目及接口行为。
import requests

# 本示例只填写最小请求字段；凭据由安全的 get_headers 提供。
payload = {'projectId': 12345678,
 'compileId': '<替换自己的compileId>',
 'nodeId': '<替换自己的nodeId>',
 'versionId': '-1',
 'brokerage': {'id': 'QuantConnectBrokerage',
               'holdings': [],
               'cash': [{'amount': 100000, 'currency': 'USD'}]},
 'dataProviders': {'QuantConnectBrokerage': {'id': 'QuantConnectBrokerage'}}}

response = requests.post(
    "https://www.quantconnect.com/api/v2/live/create",
    headers=get_headers(), json=payload, timeout=30
)
response.raise_for_status()
result = response.json()
# HTTP 成功后还需检查业务 success。
if not result.get("success", False):
    raise RuntimeError(result.get("errors", "API 未返回成功状态"))
# 读取结果对应字段；快照更新周期和字段缺省需按本接口说明判断。
```

#### 响应字段

##### HTTP 200

类型：`application/json`。

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `responseCode` | `string` | 未列为必填 | 响应代码。 |
| `source` | `string` | 未列为必填 | API 调用来源。 |
| `deployId` | `string` | 未列为必填 | 部署 ID；订单和交易请求省略时可能读取项目全部部署。 |
| `versionId` | `integer` | 未列为必填 | 部署的 LEAN 版本 ID；原文 -1 表示 master，需确认目标版本。 |
| `projectId` | `integer` | 未列为必填 | 目标项目 ID。 |
| `live` | `LiveAlgorithm` | 未列为必填 | 新建或已有实时算法信息。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


##### HTTP 401

认证错误；检查凭据、头部和时间，不靠无变化地重复请求解决。



## 响应 · 03 Responses

各端点的返回类型、状态及字段在本页请求说明中分别展示，引用模型见实时交易模型词典。未执行请求，不能把结构示意当作实际运行结果。

## 示例 · 99 Examples

本页的中文最小示例逐接口说明含义；官方公共示例可能包括批量部署或控制操作，完整源码仍保留在本节相关链接，不会被悄悄串联执行。
