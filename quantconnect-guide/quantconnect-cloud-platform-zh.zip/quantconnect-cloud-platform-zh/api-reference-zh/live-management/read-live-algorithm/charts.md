# 图表 · Charts

本页按原文小节组织，并对照同仓库 OpenAPI。所有示例仅供说明，没有调用用户账户。

## 简介 · 01 Introduction

本页涵盖：

- 读取实时图表，start/end 为 Unix 时间。加载响应可能带 progress/status，不应把请求成功等同于图表数据已全部准备好。

## 请求 · 02 Request

### POST `/live/chart/read`

读取实时图表，start/end 为 Unix 时间。加载响应可能带 progress/status，不应把请求成功等同于图表数据已全部准备好。

#### 请求字段

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `name` | `string` | 是 | 图表名称，例如 Strategy Equity。 |
| `count` | `integer` | 是 | 数量；图表请求是数据点数，分析模型是出现次数。 |
| `start` | `integer` | 是 | 开始 Unix 时间。 |
| `end` | `integer` | 是 | 结束 Unix 时间。 |


[实时交易模型词典](../../live-models.html)列出券商、数据源及响应的所有引用模型。原始字段名与枚举保留英文。

#### 中文注释示例

示例依赖身份验证页的 get_headers，未在本次执行。ID、节点和命令都是待填写的示意。

```python
# 中文注释版：这不是自动运行脚本；先核对目标项目及接口行为。
import requests

# 本示例只填写最小请求字段；凭据由安全的 get_headers 提供。
payload = {'projectId': 12345678,
 'start': 1717801200,
 'end': 1743462000,
 'name': 'Strategy Equity',
 'count': 100}

response = requests.post(
    "https://www.quantconnect.com/api/v2/live/chart/read",
    headers=get_headers(), json=payload, timeout=30
)
response.raise_for_status()
result = response.json()
# HTTP 成功后还需检查业务 success。
if not result.get("success", False):
    raise RuntimeError(result.get("errors", "API 未返回成功状态"))
# 读取结果对应字段；快照更新周期和字段缺省需按本接口说明判断。
```

#### 响应字段

##### HTTP 200

类型：`application/json`。

### 配置模式 1：`LoadingResponse`

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `progress` | `number` | 未列为必填 | 进度，原文范围 0–1，不是 0–100。 |
| `status` | `string` | 未列为必填 | 任务或订单状态，按当前模型枚举解释。 允许值：`loading`。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |


### 配置模式 2：`ReadChartResponse`

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `chart` | `Chart` | 未列为必填 | 请求的图表对象。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


##### HTTP 401

认证错误；检查凭据、头部和时间，不靠无变化地重复请求解决。



## 响应 · 03 Responses

各端点的返回类型、状态及字段在本页请求说明中分别展示，引用模型见实时交易模型词典。未执行请求，不能把结构示意当作实际运行结果。

## 示例 · 99 Examples

本页的中文最小示例逐接口说明含义；官方公共示例可能包括批量部署或控制操作，完整源码仍保留在本节相关链接，不会被悄悄串联执行。
