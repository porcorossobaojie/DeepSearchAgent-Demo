# 订单 · Orders

本页按原文小节组织，并对照同仓库 OpenAPI。所有示例仅供说明，没有调用用户账户。

## 简介 · 01 Introduction

本页涵盖：

- 分页读取订单快照，原文约十分钟更新。可用 deployId 限定一次部署，省略则包括项目全部部署。页差原文最多 1,000。

## 请求 · 02 Request

### POST `/live/orders/read`

分页读取订单快照，原文约十分钟更新。可用 deployId 限定一次部署，省略则包括项目全部部署。页差原文最多 1,000。

#### 请求字段

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `deployId` | `string` | 未列为必填 | 部署 ID；订单和交易请求省略时可能读取项目全部部署。 |
| `start` | `integer` | 是 | 起始记录索引；页差和终点是否包含，以当前接口专属描述为准。 |
| `end` | `integer` | 是 | 终止记录索引；页差和终点是否包含，以当前接口专属描述为准。 |
| `projectId` | `integer` | 是 | 目标项目 ID。 |


[实时交易模型词典](../../live-models.html)列出券商、数据源及响应的所有引用模型。原始字段名与枚举保留英文。

#### 中文注释示例

示例依赖身份验证页的 get_headers，未在本次执行。ID、节点和命令都是待填写的示意。

```python
# 中文注释版：这不是自动运行脚本；先核对目标项目及接口行为。
import requests

# 本示例只填写最小请求字段；凭据由安全的 get_headers 提供。
payload = {'start': 0, 'end': 99, 'projectId': 12345678}

response = requests.post(
    "https://www.quantconnect.com/api/v2/live/orders/read",
    headers=get_headers(), json=payload, timeout=30
)
response.raise_for_status()
result = response.json()
# HTTP 成功后还需检查业务 success。
if not result.get("success", False):
    raise RuntimeError(result.get("errors", "API 未返回成功状态"))
# 读取结果对应字段；快照更新周期和字段缺省需按本接口说明判断。
```

#### 响应字段

##### HTTP 200

类型：`application/json`。

### 配置模式 1：`LoadingResponse`

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `progress` | `number` | 未列为必填 | 进度，原文范围 0–1，不是 0–100。 |
| `status` | `string` | 未列为必填 | 任务或订单状态，按当前模型枚举解释。 允许值：`loading`。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |


### 配置模式 2：`LiveOrdersResponse`

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `orders` | `array[Order]` | 未列为必填 | 订单集合。 |
| `length` | `integer` | 未列为必填 | 返回长度或全部部署匹配日志总数，具体按模型。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


##### HTTP 401

认证错误；检查凭据、头部和时间，不靠无变化地重复请求解决。



## 响应 · 03 Responses

各端点的返回类型、状态及字段在本页请求说明中分别展示，引用模型见实时交易模型词典。未执行请求，不能把结构示意当作实际运行结果。

## 示例 · 99 Examples

本页的中文最小示例逐接口说明含义；官方公共示例可能包括批量部署或控制操作，完整源码仍保留在本节相关链接，不会被悄悄串联执行。
