# 导出订单 CSV · Export Orders

本页按原文小节组织，并对照同仓库 OpenAPI。所有示例仅供说明，没有调用用户账户。

## 简介 · 01 Introduction

本页涵盖：

- 返回项目全部部署订单 CSV，Time 为 UTC。最多覆盖所选区间最后 750 天；更早数据可另设 end 或用读取接口。返回可能超出请求区间，精确范围须按 Time 再过滤。

## 说明 · 02 Description

导出仅限平台允许的正常交易结果，不用以传送行情或数据集值。CSV 的 UTC 时间和范围说明见上文接口描述。

## 请求 · 03 Request

### POST `/live/export/orders`

返回项目全部部署订单 CSV，Time 为 UTC。最多覆盖所选区间最后 750 天；更早数据可另设 end 或用读取接口。返回可能超出请求区间，精确范围须按 Time 再过滤。

#### 请求字段

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `start` | `integer` | 未列为必填 | 开始 Unix 时间。 |
| `end` | `integer` | 未列为必填 | 结束 Unix 时间。 |


[实时交易模型词典](../../live-models.html)列出券商、数据源及响应的所有引用模型。原始字段名与枚举保留英文。

#### 中文注释示例

示例依赖身份验证页的 get_headers，未在本次执行。ID、节点和命令都是待填写的示意。

```python
# 中文注释版：这不是自动运行脚本；先核对目标项目及接口行为。
import requests

# 本示例只填写最小请求字段；凭据由安全的 get_headers 提供。
payload = {'projectId': 12345678}

response = requests.post(
    "https://www.quantconnect.com/api/v2/live/export/orders",
    headers=get_headers(), json=payload, timeout=30
)
response.raise_for_status()
# CSV 按文本读取，不能调用 response.json()。
csv_text = response.text
# 需要时按合法结果字段解析；这里不下载到磁盘或打印交易记录。
```

#### 响应字段

##### HTTP 200

类型：`text/csv`。

CSV 文本；不要当作 JSON 模型。

##### HTTP 401

认证错误；检查凭据、头部和时间，不靠无变化地重复请求解决。



## 响应 · 04 Responses

各端点的返回类型、状态及字段在本页请求说明中分别展示，引用模型见实时交易模型词典。未执行请求，不能把结构示意当作实际运行结果。

## 示例 · 99 Examples

本页的中文最小示例逐接口说明含义；官方公共示例可能包括批量部署或控制操作，完整源码仍保留在本节相关链接，不会被悄悄串联执行。
