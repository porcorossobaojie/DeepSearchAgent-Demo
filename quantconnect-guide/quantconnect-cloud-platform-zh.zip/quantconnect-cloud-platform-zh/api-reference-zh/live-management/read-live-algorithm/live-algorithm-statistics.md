# 实时算法统计 · Live Algorithm Statistics

本页按原文小节组织，并对照同仓库 OpenAPI。所有示例仅供说明，没有调用用户账户。

## 简介 · 01 Introduction

本页涵盖：

- 读取实时部署详情、统计、文件和组件提供的 deploymentDetails。返回内容不能一概视为交易所逐笔实时推送。

## 请求 · 02 Request

### POST `/live/read`

读取实时部署详情、统计、文件和组件提供的 deploymentDetails。返回内容不能一概视为交易所逐笔实时推送。

#### 请求字段

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |


[实时交易模型词典](../../live-models.html)列出券商、数据源及响应的所有引用模型。原始字段名与枚举保留英文。

#### 中文注释示例

示例依赖身份验证页的 get_headers，未在本次执行。ID、节点和命令都是待填写的示意。

```python
# 中文注释版：这不是自动运行脚本；先核对目标项目及接口行为。
import requests

# 本示例只填写最小请求字段；凭据由安全的 get_headers 提供。
payload = {'projectId': 12345678}

response = requests.post(
    "https://www.quantconnect.com/api/v2/live/read",
    headers=get_headers(), json=payload, timeout=30
)
response.raise_for_status()
result = response.json()
# HTTP 成功后还需检查业务 success。
if not result.get("success", False):
    raise RuntimeError(result.get("errors", "API 未返回成功状态"))
# 读取结果对应字段；快照更新周期和字段缺省需按本接口说明判断。
```

#### 响应字段

##### HTTP 200

类型：`application/json`。

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `message` | `string` | 未列为必填 | 交易所或系统消息。 |
| `deployId` | `string` | 未列为必填 | 部署 ID；订单和交易请求省略时可能读取项目全部部署。 |
| `status` | `string` | 未列为必填 | 任务或订单状态，按当前模型枚举解释。 允许值：`DeployError`, `InQueue`, `Running`, `Stopped`, `Liquidated`, `Deleted`, `Completed`, `RuntimeError`, `Invalid`, `LoggingIn`, `Initializing`, `History`。 |
| `cloneId` | `integer` | 未列为必填 | 原始被克隆项目 ID。 |
| `launched` | `string` | 未列为必填 | 启动 UTC 时间。 |
| `stopped` | `['string', 'null']` | 未列为必填 | 停止 UTC 时间，仍运行时可为空。 |
| `brokerage` | `string` | 未列为必填 | 券商配置对象，或外部授权时的服务商名称；按当前接口类型使用。 |
| `securityTypes` | `string` | 未列为必填 | 涉及的资产类型数量。 |
| `datacenter` | `string` | 未列为必填 | 运行数据中心。 |
| `isPublicStreaming` | `boolean` | 未列为必填 | 是否开放公开结果流。 |
| `public` | `boolean` | 未列为必填 | 版本是否公开可用，按定义类型及取值使用。 |
| `description` | `['string', 'null']` | 未列为必填 | 对象描述，具体含义以当前模型为准。 |
| `files` | `array[ProjectFile]` | 未列为必填 | 项目文件列表。 |
| `runtimeStatistics` | `RuntimeStatistics` | 未列为必填 | 结果页顶部运行统计。 |
| `serverStatistics` | `ServerStatistics` | 未列为必填 | 运行节点统计，具体键随 LEAN 版本变化。 |
| `deploymentDetails` | `dictionary[string, string]` | 未列为必填 | 组件提供的账户等部署详情，未提供则可能省略，不应当作凭据字段。 |
| `charts` | `ChartSummary` | 未列为必填 | 图表集合或图表更新。 |
| `projectName` | `string` | 未列为必填 | 占用节点的项目名称。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


##### HTTP 401

认证错误；检查凭据、头部和时间，不靠无变化地重复请求解决。



## 响应 · 03 Responses

各端点的返回类型、状态及字段在本页请求说明中分别展示，引用模型见实时交易模型词典。未执行请求，不能把结构示意当作实际运行结果。

## 示例 · 99 Examples

本页的中文最小示例逐接口说明含义；官方公共示例可能包括批量部署或控制操作，完整源码仍保留在本节相关链接，不会被悄悄串联执行。
