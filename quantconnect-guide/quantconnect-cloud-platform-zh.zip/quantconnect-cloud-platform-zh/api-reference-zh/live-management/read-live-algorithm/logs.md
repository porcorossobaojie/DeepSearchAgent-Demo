# 日志 · Logs

本页按原文小节组织，并对照同仓库 OpenAPI。所有示例仅供说明，没有调用用户账户。

## 简介 · 01 Introduction

本页涵盖：

- 原文快照约五分钟更新。startLine 为零基包含、endLine 不包含，页差最多 250。过滤 query 后索引针对匹配结果；deploymentOffset 则按之前全部行计算。

## 请求 · 02 Request

### POST `/live/logs/read`

原文快照约五分钟更新。startLine 为零基包含、endLine 不包含，页差最多 250。过滤 query 后索引针对匹配结果；deploymentOffset 则按之前全部行计算。

#### 请求字段

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `format` | `object` | 未列为必填 | 日志返回格式。 |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `algorithmId` | `string` | 是 | 用于定位日志的实时部署 ID。 |
| `startLine` | `integer` | 是 | 日志匹配行起点，零基且包含。 |
| `endLine` | `integer` | 是 | 日志匹配行终点，不包含；endLine-startLine ≤ 250。 |
| `deploymentLogs` | `boolean` | 未列为必填 | 是否仅包含指定部署日志。 |
| `query` | `string` | 未列为必填 | 不区分大小写的日志关键字；行索引针对匹配结果，省略或空字符串表示不过滤。 |


[实时交易模型词典](../../live-models.html)列出券商、数据源及响应的所有引用模型。原始字段名与枚举保留英文。

#### 中文注释示例

示例依赖身份验证页的 get_headers，未在本次执行。ID、节点和命令都是待填写的示意。

```python
# 中文注释版：这不是自动运行脚本；先核对目标项目及接口行为。
import requests

# 本示例只填写最小请求字段；凭据由安全的 get_headers 提供。
payload = {'projectId': 12345678,
 'algorithmId': '<替换自己的algorithmId>',
 'startLine': 0,
 'endLine': 99}

response = requests.post(
    "https://www.quantconnect.com/api/v2/live/logs/read",
    headers=get_headers(), json=payload, timeout=30
)
response.raise_for_status()
result = response.json()
# HTTP 成功后还需检查业务 success。
if not result.get("success", False):
    raise RuntimeError(result.get("errors", "API 未返回成功状态"))
# 读取结果对应字段；快照更新周期和字段缺省需按本接口说明判断。
```

#### 响应字段

##### HTTP 200

类型：`application/json`。

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `logs` | `array[string]` | 未列为必填 | 编译日志列表。 |
| `length` | `integer` | 未列为必填 | 返回长度或全部部署匹配日志总数，具体按模型。 |
| `deploymentOffset` | `integer` | 未列为必填 | 指定部署前的日志总行数，仍按未过滤行计数。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


##### HTTP 401

认证错误；检查凭据、头部和时间，不靠无变化地重复请求解决。



## 响应 · 03 Responses

各端点的返回类型、状态及字段在本页请求说明中分别展示，引用模型见实时交易模型词典。未执行请求，不能把结构示意当作实际运行结果。

## 示例 · 99 Examples

本页的中文最小示例逐接口说明含义；官方公共示例可能包括批量部署或控制操作，完整源码仍保留在本节相关链接，不会被悄悄串联执行。
