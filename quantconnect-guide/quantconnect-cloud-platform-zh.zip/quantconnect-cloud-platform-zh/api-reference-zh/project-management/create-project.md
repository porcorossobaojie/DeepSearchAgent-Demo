# 创建项目 · Create Project

本页按 HTML 原文小节顺序组织；重复生成的 Request／Responses 文件仍保留对应小节入口。

## 简介 · 01 Introduction

创建项目；不提供 organizationId 时按定义使用首选组织。语言值 Py 表示 Python。

## 请求 · 02 Request

**方法与路径：`POST /projects/create`**

创建项目；不提供 organizationId 时按定义使用首选组织。语言值 Py 表示 Python。

### 请求字段

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `name` | `string` | 是 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `language` | `string` | 是 | 项目语言，通常为 Py 或 C#，按枚举取值。 允许值：`C#`, `Py`。 |
| `organizationId` | `string` | 未列为必填 | 组织 ID；创建项目未提供时按定义使用首选组织。 |


嵌套类型及响应对象的中文字段解释见 [共享模型词典](../models.html)。字段名、类型、必填和枚举依据仓库 OpenAPI，不根据示例猜测。

### 带注释的 Python 调用

以下是按定义整理的最小调用示意，不是官方示例逐字复制，也没有实际执行。先使用身份验证页的 `get_headers`；替换示例 ID，并检查当前组织与权限。

```python
# 中文注释版：get_headers 来自身份验证章节；此片段需 requests。
import requests

# 只展示请求结构；ID 和文件内容要换成自己确认的目标。
payload = {'name': '中文示例项目', 'language': 'Py'}

# 每次重新生成认证头，避免使用过期时间戳。
response = requests.post(
    "https://www.quantconnect.com/api/v2/projects/create",
    headers=get_headers(),
    json=payload,
    timeout=30
)
# HTTP 失败先抛出；HTTP 200 仍需继续检查业务 success。
response.raise_for_status()
result = response.json()
if not result.get("success", False):
    raise RuntimeError(result.get("errors", "API 未返回成功状态"))
# result 的字段含义见下方响应表；此处不打印账号或文件内容。
```

### 响应结构

#### HTTP 200

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projects` | `array[Project]` | 未列为必填 | 项目列表。 |
| `versions` | `array[LeanVersion]` | 未列为必填 | LEAN 版本列表。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


#### HTTP 401

认证缺失、无效或时间戳问题，不能靠重复发送相同旧请求修复。

该响应的具体格式见原文定义。



## 请求 · 03 Request

同一请求在原文存在重复生成版本。上方已合并字段和模式，仍保留本小节原文链接供对照。

## 响应 · 03 Responses

响应字段及状态码见本页请求下方；共享模型词典提供全部嵌套对象的中文含义。

## 响应 · 04 Responses

响应字段及状态码见本页请求下方；共享模型词典提供全部嵌套对象的中文含义。

## 示例 · 99 Examples

本页提供最小中文调用示意。原文 Examples 引用公共示例，可能包含创建后删除、批量删除等额外动作；本译稿不把那些动作偷偷附加到最小调用中，完整原文可通过下方链接阅读。
