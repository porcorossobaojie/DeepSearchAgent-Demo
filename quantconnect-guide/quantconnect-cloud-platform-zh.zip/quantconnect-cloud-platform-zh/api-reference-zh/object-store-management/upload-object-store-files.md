# 上传对象存储文件 · Upload Object Store Files

按源码小节排列；接口行为依据同仓库 OpenAPI 对照，重复内容合并展示。

## 简介 · 01 Introduction

multipart/form-data 上传：organizationId 与 key 是普通表单字段，objectData 是二进制文件。不要把文件内容随意塞进 json 参数。

## 请求 · 02 Request

**`POST /object/set`**

multipart/form-data 上传：organizationId 与 key 是普通表单字段，objectData 是二进制文件。不要把文件内容随意塞进 json 参数。

### 请求字段

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `organizationId` | `string` | 是 | 组织 ID；创建项目未提供时按定义使用首选组织。 |
| `key` | `string` | 是 | 对象存储唯一键。 |
| `objectData` | `string (binary)` | 是 | multipart 上传的二进制文件，不是 JSON 字符串。 |


嵌套对象的完整中文字段解释见 [运行与存储模型词典](../run-models.html)。

### 中文注释调用示例

以下为依据 OpenAPI 整理的调用示意，依赖身份验证章节 get_headers。ID、参数与文件均为示意，不是在本次执行的真实操作。

```python
# 中文注释版：上传单个文件，requests 自动生成 multipart 边界。
import requests

# 这是用户自行提供的文件路径；本示例没有读取或上传任何实际文件。
with open("<自己的文件路径>", "rb") as local_file:
    response = requests.post(
        "https://www.quantconnect.com/api/v2/object/set",
        headers=get_headers(),
        data={"organizationId": "<自己的组织ID>", "key": "example/model.bin"},
        files={"objectData": local_file},
        timeout=60
    )
response.raise_for_status()
result = response.json()
if not result.get("success", False):
    raise RuntimeError(result.get("errors", "上传未成功"))
```

### 响应字段

#### HTTP 200

内容类型：`application/json`。

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


#### HTTP 401

认证失败，检查凭据、头部和客户端时间；本次没有进行在线认证验证。



## 响应 · 03 Responses

响应结构已列在本页请求说明下。更多嵌套对象见运行与存储模型词典。

## 示例 · 99 Examples

本页已提供带中文注释的最小调用。原文公共示例可能连带创建、更新或删除多个对象，完整动作保留在来源链接，未默认加入本页调用片段。
