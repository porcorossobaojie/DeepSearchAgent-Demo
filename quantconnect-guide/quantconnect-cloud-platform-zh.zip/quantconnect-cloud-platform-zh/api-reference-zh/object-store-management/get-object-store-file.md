# 获取存储下载链接 · Get Object Store File

按源码小节排列；接口行为依据同仓库 OpenAPI 对照，重复内容合并展示。

## 简介 · 01 Introduction

两阶段接口：先传 organizationId 与 keys 获取 jobId，再传 organizationId 与 jobId 查询 url。url 可为 null，表示尚未可用。原文要求签署衍生数据协议且获授权的 Institution 才能下载；增加容量不授予下载权。

## 说明 · 02 Description

两阶段接口：先传 organizationId 与 keys 获取 jobId，再传 organizationId 与 jobId 查询 url。url 可为 null，表示尚未可用。原文要求签署衍生数据协议且获授权的 Institution 才能下载；增加容量不授予下载权。 数据与访问权限按正式条款执行。

## 请求 · 03 Request

**`POST /object/get`**

两阶段接口：先传 organizationId 与 keys 获取 jobId，再传 organizationId 与 jobId 查询 url。url 可为 null，表示尚未可用。原文要求签署衍生数据协议且获授权的 Institution 才能下载；增加容量不授予下载权。

### 请求字段

### 请求模式 1

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `organizationId` | `string` | 是 | 组织 ID；创建项目未提供时按定义使用首选组织。 |
| `keys` | `array[string]` | 是 | 要下载的存储键数组。 |


### 请求模式 2

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `organizationId` | `string` | 是 | 组织 ID；创建项目未提供时按定义使用首选组织。 |
| `jobId` | `string` | 是 | 异步下载任务 ID。 |


嵌套对象的完整中文字段解释见 [运行与存储模型词典](../run-models.html)。

### 中文注释调用示例

以下为依据 OpenAPI 整理的调用示意，依赖身份验证章节 get_headers。ID、参数与文件均为示意，不是在本次执行的真实操作。

```python
# 中文注释版：仅在组织拥有正式下载授权时使用。
import requests

# 第一步只创建下载任务；keys 是存储键的数组。
response = requests.post(
    "https://www.quantconnect.com/api/v2/object/get",
    headers=get_headers(),
    json={"organizationId": "<自己的组织ID>", "keys": ["example/model.bin"]},
    timeout=30
)
response.raise_for_status()
result = response.json()
if not result.get("success", False):
    raise RuntimeError(result.get("errors", "下载任务未创建"))
job_id = result["jobId"]

# 第二步使用同一个 jobId 查询；不要把首次提交重复当成查询。
response = requests.post(
    "https://www.quantconnect.com/api/v2/object/get",
    headers=get_headers(),
    json={"organizationId": "<同一组织ID>", "jobId": job_id},
    timeout=30
)
response.raise_for_status()
result = response.json()
if not result.get("success", False):
    raise RuntimeError(result.get("errors", "链接查询失败"))
# 可能仍为 None；稍后按平台规则查询，不能假定立刻可用。
download_url = result.get("url")
# 本示例到此为止，不实际访问链接、下载或打印带查询参数的 URL。
```

### 响应字段

#### HTTP 200

内容类型：`application/json`。

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `jobId` | `string` | 未列为必填 | 异步下载任务 ID。 |
| `url` | `string` | 未列为必填 | 下载链接，可能为空；使用时须保留完整查询参数。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


#### HTTP 401

认证失败，检查凭据、头部和客户端时间；本次没有进行在线认证验证。



## 响应 · 04 Responses

响应结构已列在本页请求说明下。更多嵌套对象见运行与存储模型词典。

## 示例 · 99 Examples

本页已提供带中文注释的最小调用。原文公共示例可能连带创建、更新或删除多个对象，完整动作保留在来源链接，未默认加入本页调用片段。
