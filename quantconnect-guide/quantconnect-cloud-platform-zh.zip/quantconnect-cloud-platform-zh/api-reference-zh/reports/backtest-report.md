# 回测报告 · Backtest Report

按官方原有小节组织。以下代码为附中文注释的最小调用示例，未发送请求。

## 简介 · 01 Introduction

读取回测报告。响应可能是正在生成的状态，也可能是含 base64 图片的 HTML；应先检查 generating，再读取 report。

## 请求与注释示例 · 02 Request

### POST `/backtests/read/report`

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `backtestId` | `string` | 是 | 回测标识。 |


```python
# 中文注释版：此片段仅用于说明接口，没有自动执行。
import requests

# 使用身份验证页的 get_headers；请求字段名须保持英文。
payload = {'projectId': 12345678, 'backtestId': '<替换自己的回测 ID>'}

# 读取指定回测或问题列表。
response = requests.post(
    "https://www.quantconnect.com/api/v2/backtests/read/report",
    headers=get_headers(), json=payload, timeout=30
)
# 分别检查 HTTP 错误和 API 业务状态。
response.raise_for_status()
result = response.json()
if not result.get("success", False):
    raise RuntimeError(result.get("errors", "接口未成功"))
# 生成中没有最终 HTML；稍后再查，避免无间隔重试。
if not result.get("generating", False):
    report_html = result.get("report")
```



## 响应 · 03 Responses

### HTTP 200

### 配置模式 1：`BacktestReport`

原定义为开放对象，未列固定字段；不要自行把猜测的键当成平台支持。

### 配置模式 2：`BacktestReportGeneratingResponse`

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `generating` | `boolean` | 未列为必填 | 报告是否仍在生成；为 true 时不能假设已有 report。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


### HTTP 401

认证失败：检查 API 凭据、签名和时间戳。



## 示例 · 99 Examples

上方提供中文注释版最小示例。官方示例的原始代码及其引用资源保留在本节相关链接中。
