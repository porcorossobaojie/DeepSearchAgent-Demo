# 创建工单或评论 · Create Support Ticket

对照官方原有小节和 OpenAPI 整理。示例仅为说明，未执行平台请求。

## 简介 · 01 Introduction

创建工单或追加评论。新建时提供 subject 和 message，消耗支持席位的一次工单额度；评论时提供 hash 和 message。对已关闭工单发表评论会重新打开它，除非 close=true。仅新建时可附项目、回测、已停止实时部署或 AI 对话；评论时这些字段被忽略。附带这些内容代表授权支持团队查看项目及其全部代码库。必须具有该组织的支持席位。

## 使用说明 · 02 Description

创建工单或追加评论。新建时提供 subject 和 message，消耗支持席位的一次工单额度；评论时提供 hash 和 message。对已关闭工单发表评论会重新打开它，除非 close=true。仅新建时可附项目、回测、已停止实时部署或 AI 对话；评论时这些字段被忽略。附带这些内容代表授权支持团队查看项目及其全部代码库。必须具有该组织的支持席位。

## 请求与代码说明 · 03 Request

### POST `/organizations/support/tickets/create`

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `organizationId` | `string` | 是 | 目标组织 ID。 |
| `subject` | `string` | 未列为必填 | 新工单主题；创建新工单时必填。 |
| `message` | `string` | 是 | 错误信息、工具确认消息或支持工单的 HTML 正文，按所属模型区分。 |
| `hash` | `string` | 未列为必填 | API 中的工单 ID；新建时省略，评论已有工单时提供。 |
| `close` | `boolean` | 未列为必填 | 评论后是否关闭工单；必须同时提供 hash。 |
| `projectId` | `integer` | 未列为必填 | 目标项目 ID。 |
| `backtestId` | `string` | 未列为必填 | 回测标识。 |
| `deployId` | `string` | 未列为必填 | 部署 ID；订单和交易请求省略时可能读取项目全部部署。 |
| `agentDeploymentId` | `string` | 未列为必填 | 新工单附带的 AI 对话部署 ID；依赖 projectId。 |


[完整中文模型词典](../remaining-models.html)

```python
# 中文注释版：仅演示字段及调用过程，不会在文档生成时执行。
import requests

# ID 和文本需要替换；get_headers 见身份验证页。
payload = {'organizationId': '<替换自己的组织 ID>',
 'message': '<p>填写复现步骤、预期行为和实际行为</p>',
 'subject': '<填写问题主题>'}

# 本接口的具体效果见简介；创建、更新、删除或部署会更改平台状态。
response = requests.post(
    "https://www.quantconnect.com/api/v2/organizations/support/tickets/create",
    headers=get_headers(), json=payload, timeout=30
)
# 先检查 HTTP 状态，再检查所属接口的业务状态。
response.raise_for_status()
result = response.json()
if not result.get("success", False):
    raise RuntimeError(result.get("errors", "接口未成功"))
# 在相应字段读取智能体、任务、部署或工单，不打印令牌。
```


## 响应 · 04 Responses

### HTTP 200

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `hash` | `string` | 未列为必填 | API 中的工单 ID；新建时省略，评论已有工单时提供。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


### HTTP 401

身份验证失败；核对 API Key、签名和时间戳。



## 示例 · 99 Examples

本页请求小节提供附中文注释的最小示例。完整官方示例及其相关资源见本节保留的原文链接；不要把批量示例直接用于真实账号。
