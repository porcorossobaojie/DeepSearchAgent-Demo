# 读取工单消息 · Read Support Ticket

对照官方原有小节和 OpenAPI 整理。示例仅为说明，未执行平台请求。

## 简介 · 01 Introduction

读取工单消息。hash 可通过工单列表取得。

## 使用说明 · 02 Description

读取工单消息。hash 可通过工单列表取得。

## 请求与代码说明 · 03 Request

### POST `/organizations/support/tickets/read`

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `organizationId` | `string` | 是 | 目标组织 ID。 |
| `hash` | `string` | 是 | API 中的工单 ID；新建时省略，评论已有工单时提供。 |


[完整中文模型词典](../remaining-models.html)

```python
# 中文注释版：仅演示字段及调用过程，不会在文档生成时执行。
import requests

# ID 和文本需要替换；get_headers 见身份验证页。
payload = {'organizationId': '<替换自己的组织 ID>', 'hash': '<按字段表填写>'}

# 本接口的具体效果见简介；创建、更新、删除或部署会更改平台状态。
response = requests.post(
    "https://www.quantconnect.com/api/v2/organizations/support/tickets/read",
    headers=get_headers(), json=payload, timeout=30
)
# 先检查 HTTP 状态，再检查所属接口的业务状态。
response.raise_for_status()
result = response.json()
if not result.get("success", False):
    raise RuntimeError(result.get("errors", "接口未成功"))
# 在相应字段读取智能体、任务、部署或工单，不打印令牌。
```


## 响应 · 04 Responses

### HTTP 200

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `messages` | `array[SupportTicketMessage]` | 未列为必填 | 按顺序排列的对话消息或工单消息，按模型区分。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


### HTTP 401

身份验证失败；核对 API Key、签名和时间戳。



## 示例 · 99 Examples

本页请求小节提供附中文注释的最小示例。完整官方示例及其相关资源见本节保留的原文链接；不要把批量示例直接用于真实账号。
