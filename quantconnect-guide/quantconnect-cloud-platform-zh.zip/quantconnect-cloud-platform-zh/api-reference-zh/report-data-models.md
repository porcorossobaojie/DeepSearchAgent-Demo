# 报告与数据问题模型词典

请求键、枚举及模型名称保留英文，含义以中文说明。

## BacktestReport

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `report` | `string` | 未列为必填 | 回测报告 HTML，图片以 base64 内嵌。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


## BacktestReportGeneratingResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `generating` | `boolean` | 未列为必填 | 报告是否仍在生成；为 true 时不能假设已有 report。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


## BacktestReportRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `backtestId` | `string` | 是 | 回测标识。 |


## CreateDataIssueRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `ticker` | `string` | 是 | 发生问题的证券代码。 |
| `security` | `string` | 是 | 资产类别；允许值须保留英文。 允许值：`Equity`, `Equity Option`, `Index`, `Index Option`, `Future`, `Future Option`, `Forex`, `CFD`, `Crypto`, `Crypto Future`。 |
| `market` | `string` | 是 | 市场；有效值取决于资产类别，以数据问题页面下拉框为准。 |
| `resolution` | `string` | 是 | 数据分辨率；有效值取决于资产类别和市场。 允许值：`Tick`, `Second`, `Minute`, `Hour`, `Daily`, `Coarse Fundamental`, `Fine Fundamental`, `Margin`。 |
| `from-date` | `string` | 是 | 问题起始日期，YYYY-MM-DD。 |
| `to-date` | `string` | 是 | 问题结束日期，YYYY-MM-DD，必须晚于起始日期。 |
| `from-time` | `string` | 未列为必填 | 起始时刻 HH:MM；Second/Minute 且区间短于七天时必需。 |
| `to-time` | `string` | 未列为必填 | 结束时刻 HH:MM；Second/Minute 且区间短于七天时必需。 |
| `corrupted-files` | `string` | 未列为必填 | 报告文件损坏时包含此字段；至少选择一种问题类型。 允许值：`Corrupted Files`。 |
| `missing-points` | `string` | 未列为必填 | 报告缺少数据点时包含此字段；至少选择一种问题类型。 允许值：`Missing Points`。 |
| `missing-files` | `string` | 未列为必填 | 报告缺少文件时包含此字段；至少选择一种问题类型。 允许值：`Missing Files`。 |
| `wrong-values` | `string` | 未列为必填 | 报告数值错误时包含此字段；至少选择一种问题类型。 允许值：`Wrong Values`。 |
| `listing-error` | `string` | 未列为必填 | 报告上市信息错误时包含此字段；至少选择一种问题类型。 允许值：`Listing Error`。 |
| `split-error` | `string` | 未列为必填 | 报告拆股错误时包含此字段；至少选择一种问题类型。 允许值：`Split Error`。 |
| `dividend-error` | `string` | 未列为必填 | 报告分红错误时包含此字段；至少选择一种问题类型。 允许值：`Dividend Error`。 |
| `name-mapping-error` | `string` | 未列为必填 | 报告代码映射错误时包含此字段；至少选择一种问题类型。 允许值：`Name Mapping Error`。 |
| `content` | `string` | 是 | 问题的 HTML 描述，须给出可复现代码或关联项目及回测。 |
| `select-project` | `integer` | 未列为必填 | 关联的本人项目 ID，便于数据团队查看复现代码。 |
| `select-backtest` | `string` | 未列为必填 | 关联项目内的回测 ID；依赖 select-project。 |


## CreateDataIssueResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `discussionId` | `integer` | 未列为必填 | 问题 ID；详情地址为 https://www.quantconnect.com/datasets/issue/{discussionId}。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


## DataIssue

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `discussionId` | `integer` | 未列为必填 | 问题 ID；详情地址为 https://www.quantconnect.com/datasets/issue/{discussionId}。 |
| `ticker` | `string` | 未列为必填 | 发生问题的证券代码。 |
| `security` | `string` | 未列为必填 | 资产类别；允许值须保留英文。 |
| `market` | `string` | 未列为必填 | 市场；有效值取决于资产类别，以数据问题页面下拉框为准。 |
| `resolution` | `string` | 未列为必填 | 数据分辨率；有效值取决于资产类别和市场。 |
| `from` | `string` | 未列为必填 | 问题开始时间，YYYY-MM-DD HH:MM:SS。 |
| `to` | `string` | 未列为必填 | 问题结束时间，YYYY-MM-DD HH:MM:SS。 |
| `status` | `string` | 未列为必填 | 列表请求用 open/closed；问题响应列出具体处理状态。 允许值：`In queue`, `In progress`, `Waiting Review`, `Waiting for Data Vendor`, `Resolved`, `Closed`, `Cannot Be Resolved`。 |
| `corruptedFile` | `integer` | 未列为必填 | 是否报告文件损坏：1 表示是，0 表示否。 |
| `missingPoints` | `integer` | 未列为必填 | 是否报告缺少数据点：1 表示是，0 表示否。 |
| `missingFile` | `integer` | 未列为必填 | 是否报告缺少文件：1 表示是，0 表示否。 |
| `wrongValues` | `integer` | 未列为必填 | 是否报告数值错误：1 表示是，0 表示否。 |
| `listingError` | `integer` | 未列为必填 | 是否报告上市信息错误：1 表示是，0 表示否。 |
| `splitError` | `integer` | 未列为必填 | 是否报告拆股错误：1 表示是，0 表示否。 |
| `dividendError` | `integer` | 未列为必填 | 是否报告分红错误：1 表示是，0 表示否。 |
| `mappingError` | `integer` | 未列为必填 | 是否报告代码映射错误：1 表示是，0 表示否。 |
| `reported` | `integer` | 未列为必填 | 报告提交时的 Unix 时间戳。 |
| `subscribed` | `boolean` | 未列为必填 | 是否只查询本人订阅的问题；响应中表示本人是否订阅。 |
| `userName` | `string` | 未列为必填 | 报告人的显示名称。 |
| `userPublicId` | `string` | 未列为必填 | 报告人的公开用户 ID。 |
| `userProfile` | `string` | 未列为必填 | 报告人的头像 URL。 |


## DataIssueListResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `results` | `array[DataIssue]` | 未列为必填 | 当前区间的数据问题列表。 |
| `resultsFound` | `integer` | 未列为必填 | 匹配筛选条件的问题总数，不是当前页长度。 |
| `openIssuesCount` | `integer` | 未列为必填 | 数据问题页面全部未关闭问题数。 |
| `closedIssuesCount` | `integer` | 未列为必填 | 数据问题页面全部已关闭问题数。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


## ListDataIssuesRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `status` | `string` | 未列为必填 | 列表请求用 open/closed；问题响应列出具体处理状态。 允许值：`open`, `closed`。 |
| `start` | `integer` | 未列为必填 | 起始索引，默认 0，包含。 |
| `end` | `integer` | 未列为必填 | 终点索引，默认 20，不包含。 |
| `search` | `string` | 未列为必填 | 按证券代码精确筛选，不区分大小写。 |
| `subscribed` | `boolean` | 未列为必填 | 是否只查询本人订阅的问题；响应中表示本人是否订阅。 |


## inline_response_200_1

### 配置模式 1：`BacktestReport`

原定义为开放对象，未列固定字段；不要自行把猜测的键当成平台支持。

### 配置模式 2：`BacktestReportGeneratingResponse`

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `generating` | `boolean` | 未列为必填 | 报告是否仍在生成；为 true 时不能假设已有 report。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


[官方 OpenAPI 定义](https://github.com/QuantConnect/Documentation/blob/697eaf38f1d9b257aabb45e3a3210318276c2212/QuantConnect-Platform-2.0.0.yaml)
