# AI、智能体与支持模型词典

包含全部引用模型和继承字段。字段名、模型名、枚举值保留英文。标记未列为必填不等于没有条件依赖，须结合接口正文。

## Agent

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `integer` | 未列为必填 | 该模型对象的标识符，类型与含义见当前模型。 |
| `name` | `string` | 未列为必填 | 智能体、任务或文件名称，按所属模型区分。 |
| `description` | `string` | 未列为必填 | 智能体简要描述。 |
| `profileImage` | `string` | 未列为必填 | 智能体头像文件名。 |
| `systemPrompt` | `string` | 未列为必填 | 定义智能体行为的系统提示词。 |
| `reasoningEffort` | `string` | 未列为必填 | 底层模型使用的推理强度。 允许值：`low`, `medium`, `high`。 |
| `maxTurns` | `integer` | 未列为必填 | 一次部署最多允许的智能体轮次。 |
| `toolChoice` | `string` | 未列为必填 | 工具选择策略。 |
| `tools` | `array[string]` | 未列为必填 | 可使用的工具标识符列表。 |
| `public` | `boolean` | 未列为必填 | 是否在组织内公开分享该智能体。 |
| `model` | `['string', 'null']` | 未列为必填 | 使用的模型标识符。 |
| `pipeline` | `['string', 'null']` | 未列为必填 | 分配给智能体的流水线。 |
| `outputSchema` | `['object', 'null']` | 未列为必填 | 约束结构化输出的 JSON Schema。 |
| `created` | `string` | 未列为必填 | 创建时间戳。 |
| `updated` | `string` | 未列为必填 | 最近更新时间戳。 |
| `author` | `AgentTaskOwner` | 未列为必填 | 作者信息对象。 |
| `organization` | `AgentOrganization` | 未列为必填 | 所属组织对象。 |
| `chainedAgents` | `array[AgentChainedEntry]` | 未列为必填 | 依次接续运行的智能体列表。 |
| `subAgents` | `array[AgentSubAgentEntry]` | 未列为必填 | 该智能体可调用的子智能体列表。 |
| `token` | `oneOf[AgentToken, null]` | 未列为必填 | 模型提供商令牌配置对象，含令牌及提供商标识。 可选模型：`AgentToken`, `null`。 |
| `useQCC` | `boolean` | 未列为必填 | 是否使用 QuantConnect Cloud 的模型服务；false 时需要用户令牌。 |
| `node` | `AgentNode` | 未列为必填 | 智能体的计算节点信息。 |


## AgentChainedEntry

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `agentId` | `integer` | 是 | 智能体 ID。 |
| `step` | `integer` | 是 | 智能体在执行链中的顺序。 |
| `agent` | `object` | 未列为必填 | 展开后的智能体定义。 |


## AgentConversation

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 未列为必填 | 该模型对象的标识符，类型与含义见当前模型。 |
| `userId` | `integer` | 未列为必填 | 拥有该部署的用户 ID。 |
| `organizationId` | `string` | 未列为必填 | 目标组织 ID。 |
| `channel` | `string` | 未列为必填 | 部署内部发布/订阅通道。 |
| `projectId` | `integer` | 未列为必填 | 目标项目 ID。 |
| `prompt` | `string` | 未列为必填 | 任务部署后执行的提示词；更新部署时为后续追加提示。 |
| `agents` | `array[object]` | 未列为必填 | 组织的智能体列表，或参与当前对话的智能体定义。 |
| `notificationTargets` | `array[object]` | 未列为必填 | 部署配置的通知目标。 |
| `messages` | `array[AgentConversationMessage]` | 未列为必填 | 按顺序排列的对话消息或工单消息，按模型区分。 |
| `agentProperties` | `object` | 未列为必填 | 各智能体的运行时属性。 |
| `chatMessages` | `array[object]` | 未列为必填 | 展开为聊天形式的对话记录。 |
| `inputTokens` | `integer` | 未列为必填 | 截至目前消耗的输入 token 总数。 |
| `outputTokens` | `integer` | 未列为必填 | 截至目前产生的输出 token 总数。 |
| `aggregateStatus` | `string` | 未列为必填 | 部署的汇总状态。 |


## AgentConversationMessage

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 未列为必填 | 该模型对象的标识符，类型与含义见当前模型。 |
| `role` | `string` | 未列为必填 | 消息作者角色，例如 user 或 assistant。 |
| `parts` | `array[AgentConversationMessagePart]` | 未列为必填 | 组成消息的有序片段。 |
| `time` | `string` | 未列为必填 | 消息产生或工单最近更新的时间。 |


## AgentConversationMessagePart

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `type` | `string` | 未列为必填 | 搜索类别（Stubs/Forum/Docs/Examples）、搜索结果类别编号（0/1/2/3），或消息片段种类；按所属模型区分。 |
| `text` | `string` | 未列为必填 | 文本或推理片段的文字内容。 |
| `state` | `string` | 未列为必填 | 工具执行状态，End 表示结束，Error 表示错误，具体取值见枚举。 |
| `toolName` | `string` | 未列为必填 | 动态工具片段调用的工具名称。 |
| `input` | `object` | 未列为必填 | 搜索输入文本或工具调用的输入对象，按模型区分。 |
| `output` | `object` | 未列为必填 | 动态工具返回的对象。 |
| `messages` | `array[object]` | 未列为必填 | 按顺序排列的对话消息或工单消息，按模型区分。 |


## AgentConversationResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `conversation` | `AgentConversation` | 未列为必填 | 部署的完整对话及元数据。 |


## AgentDeployment

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `deploymentId` | `string` | 未列为必填 | 智能体部署 ID。 |
| `agentId` | `integer` | 未列为必填 | 智能体 ID。 |
| `status` | `string` | 未列为必填 | 部署状态或任务活动部署的状态条目；工单模型中为 open/closed 或 Open/Closed，保留原文枚举。 允许值：`InQueue`, `Running`, `Completed`, `Stopped`, `Failed`。 |
| `taskId` | `integer` | 未列为必填 | 任务 ID。 |
| `model` | `string` | 未列为必填 | 使用的模型标识符。 |
| `created` | `string` | 未列为必填 | 创建时间戳。 |
| `started` | `['string', 'null']` | 未列为必填 | 开始时间，尚未开始时可为 null。 |
| `ended` | `['string', 'null']` | 未列为必填 | 结束时间，仍活动时可为 null。 |
| `machine` | `['string', 'null']` | 未列为必填 | 运行机器，可能为 null。 |
| `mcpTools` | `array[string]` | 未列为必填 | 部署可以使用的 MCP 工具列表。 |
| `hostName` | `['string', 'null']` | 未列为必填 | 运行中的主机名称，可能为 null。 |
| `prompt` | `string` | 未列为必填 | 任务部署后执行的提示词；更新部署时为后续追加提示。 |
| `projectId` | `integer` | 未列为必填 | 目标项目 ID。 |
| `versionId` | `integer` | 未列为必填 | 此模型中的 LEAN 版本整数 ID。 |
| `runtimeError` | `['string', 'null']` | 未列为必填 | 部署运行错误，没有错误时可为 null。 |


## AgentDeploymentListResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `deployments` | `array[AgentDeployment]` | 未列为必填 | 任务累计部署次数或部署列表，按模型类型区分。 |


## AgentDeploymentResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `deployment` | `AgentDeployment` | 未列为必填 | 单个智能体部署信息。 |


## AgentListResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `agents` | `array[Agent]` | 未列为必填 | 组织的智能体列表，或参与当前对话的智能体定义。 |


## AgentNode

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `integer` | 未列为必填 | 该模型对象的标识符，类型与含义见当前模型。 |
| `sku` | `string` | 未列为必填 | 分配的计算节点 SKU。 |


## AgentOrganization

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 未列为必填 | 该模型对象的标识符，类型与含义见当前模型。 |
| `name` | `string` | 未列为必填 | 智能体、任务或文件名称，按所属模型区分。 |
| `profile` | `string` | 未列为必填 | 组织、成员或作者的头像文件名或 URL，按模型区分。 |


## AgentResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `agent` | `Agent` | 未列为必填 | 展开后的智能体定义。 |


## AgentSubAgentEntry

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `agentId` | `integer` | 是 | 智能体 ID。 |
| `callableCount` | `integer` | 未列为必填 | 单次部署可调用该子智能体的最多次数。 |


## AgentTask

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `integer` | 未列为必填 | 该模型对象的标识符，类型与含义见当前模型。 |
| `name` | `string` | 未列为必填 | 智能体、任务或文件名称，按所属模型区分。 |
| `organizationId` | `string` | 未列为必填 | 目标组织 ID。 |
| `agentId` | `integer` | 未列为必填 | 智能体 ID。 |
| `prompt` | `string` | 未列为必填 | 任务部署后执行的提示词；更新部署时为后续追加提示。 |
| `deployments` | `integer` | 未列为必填 | 任务累计部署次数或部署列表，按模型类型区分。 |
| `lastDeploymentId` | `['integer', 'null']` | 未列为必填 | 最近一次部署的数值 ID，未部署时可为 null。 |
| `lastDeploymentTime` | `['string', 'null']` | 未列为必填 | 最近部署时间。 |
| `created` | `string` | 未列为必填 | 创建时间戳。 |
| `updated` | `string` | 未列为必填 | 最近更新时间戳。 |
| `projectId` | `['integer', 'null']` | 未列为必填 | 目标项目 ID。 |
| `owner` | `AgentTaskOwner` | 未列为必填 | 任务所有者信息。 |
| `upcomingDeployments` | `['array', 'null']` | 未列为必填 | 已排期的待运行部署。 |
| `status` | `array[AgentTaskStatusEntry]` | 未列为必填 | 部署状态或任务活动部署的状态条目；工单模型中为 open/closed 或 Open/Closed，保留原文枚举。 |
| `schedule` | `['string', 'null']` | 未列为必填 | 任务的 Cron 排期表达式。 |
| `scheduleHuman` | `['string', 'null']` | 未列为必填 | 排期的易读说明。 |
| `projectPreference` | `string` | 未列为必填 | 项目与部署的映射策略：project-each-task-deployment 为每次部署创建项目；project-for-task 为任务共用项目。 允许值：`project-each-task-deployment`, `project-for-task`。 |
| `notifications` | `array[object]` | 未列为必填 | 任务通知目标配置列表。 |


## AgentTaskListResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `tasks` | `array[AgentTask]` | 未列为必填 | 组织所属任务列表。 |


## AgentTaskOwner

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `publicId` | `string` | 未列为必填 | 用户公开个人资料标识。 |
| `name` | `string` | 未列为必填 | 智能体、任务或文件名称，按所属模型区分。 |
| `image` | `string` | 未列为必填 | 用户头像文件名。 |


## AgentTaskResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `task` | `AgentTask` | 未列为必填 | 任务定义对象。 |


## AgentTaskStatusEntry

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `deploymentId` | `string` | 未列为必填 | 智能体部署 ID。 |
| `status` | `string` | 未列为必填 | 部署状态或任务活动部署的状态条目；工单模型中为 open/closed 或 Open/Closed，保留原文枚举。 |


## AgentToken

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `llmApiTokenUser` | `string` | 未列为必填 | 用户提供的模型服务 API 令牌，不应公开或输出日志。 |
| `llmProviderApi` | `string` | 未列为必填 | 该令牌对应的模型提供商标识。 |


## BacktestInitResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `state` | `string` | 未列为必填 | 工具执行状态，End 表示结束，Error 表示错误，具体取值见枚举。 允许值：`End`, `Error`。 |
| `version` | `number` | 未列为必填 | 工具响应协议版本。 |
| `payload` | `string` | 未列为必填 | 工具结果；初始化为信息文本，补全及语法检查为字符串数组，错误增强为建议文本，PEP8 转换为文件名到代码的字典。 |
| `payloadType` | `string` | 未列为必填 | payload 的类型标签，不是代码语言。 |


## BasicFilesRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `language` | `string` | 是 | 编程语言：Py 或 C#。 允许值：`C#`, `Py`。 |
| `files` | `array[File]` | 是 | 需要处理的源文件列表，元素含 name 和 content。 |


## CodeCompletionRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `language` | `string` | 是 | 编程语言：Py 或 C#。 允许值：`C#`, `Py`。 |
| `sentence` | `string` | 是 | 需要补全的代码文本。 |
| `responseSizeLimit` | `integer` | 未列为必填 | 最多返回的补全项数。 |


## CodeCompletionResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `state` | `string` | 未列为必填 | 工具执行状态，End 表示结束，Error 表示错误，具体取值见枚举。 允许值：`End`。 |
| `version` | `number` | 未列为必填 | 工具响应协议版本。 |
| `payload` | `array[string]` | 未列为必填 | 工具结果；初始化为信息文本，补全及语法检查为字符串数组，错误增强为建议文本，PEP8 转换为文件名到代码的字典。 |
| `payloadType` | `string` | 未列为必填 | payload 的类型标签，不是代码语言。 |


## CreateAgentDeploymentRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `taskId` | `integer` | 是 | 任务 ID。 |


## CreateAgentDeploymentResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `deployment` | `AgentDeployment` | 未列为必填 | 单个智能体部署信息。 |
| `debug` | `object` | 未列为必填 | 内部调试信息，描述智能体、版本和资源控制。 |


## CreateAgentRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `organizationId` | `string` | 是 | 目标组织 ID。 |
| `name` | `string` | 是 | 智能体、任务或文件名称，按所属模型区分。 |
| `description` | `string` | 未列为必填 | 智能体简要描述。 |
| `profileImage` | `string` | 未列为必填 | 智能体头像文件名。 |
| `systemPrompt` | `string` | 未列为必填 | 定义智能体行为的系统提示词。 |
| `reasoningEffort` | `string` | 未列为必填 | 底层模型使用的推理强度。 允许值：`low`, `medium`, `high`。 |
| `maxTurns` | `integer` | 未列为必填 | 一次部署最多允许的智能体轮次。 |
| `toolChoice` | `string` | 未列为必填 | 工具选择策略。 |
| `tools` | `array[string]` | 未列为必填 | 可使用的工具标识符列表。 |
| `public` | `boolean` | 未列为必填 | 是否在组织内公开分享该智能体。 |
| `model` | `string` | 未列为必填 | 使用的模型标识符。 |
| `chainedAgents` | `array[AgentChainedEntry]` | 未列为必填 | 依次接续运行的智能体列表。 |
| `subAgents` | `array[AgentSubAgentEntry]` | 未列为必填 | 该智能体可调用的子智能体列表。 |
| `token` | `AgentToken` | 未列为必填 | 模型提供商令牌配置对象，含令牌及提供商标识。 |
| `useQCC` | `boolean` | 未列为必填 | 是否使用 QuantConnect Cloud 的模型服务；false 时需要用户令牌。 |
| `pipeline` | `string` | 未列为必填 | 分配给智能体的流水线。 |
| `author` | `AgentTaskOwner` | 未列为必填 | 作者信息对象。 |
| `organization` | `AgentOrganization` | 未列为必填 | 所属组织对象。 |
| `node` | `AgentNode` | 未列为必填 | 智能体的计算节点信息。 |


## CreateAgentTaskRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `organizationId` | `string` | 是 | 目标组织 ID。 |
| `agentId` | `integer` | 是 | 智能体 ID。 |
| `name` | `string` | 是 | 智能体、任务或文件名称，按所属模型区分。 |
| `prompt` | `string` | 是 | 任务部署后执行的提示词；更新部署时为后续追加提示。 |
| `projectPreference` | `string` | 是 | 项目与部署的映射策略：project-each-task-deployment 为每次部署创建项目；project-for-task 为任务共用项目。 允许值：`project-each-task-deployment`, `project-for-task`。 |


## CreateSupportTicketRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `organizationId` | `string` | 是 | 目标组织 ID。 |
| `subject` | `string` | 未列为必填 | 新工单主题；创建新工单时必填。 |
| `message` | `string` | 是 | 错误信息、工具确认消息或支持工单的 HTML 正文，按所属模型区分。 |
| `hash` | `string` | 未列为必填 | API 中的工单 ID；新建时省略，评论已有工单时提供。 |
| `close` | `boolean` | 未列为必填 | 评论后是否关闭工单；必须同时提供 hash。 |
| `projectId` | `integer` | 未列为必填 | 目标项目 ID。 |
| `backtestId` | `string` | 未列为必填 | 回测标识。 |
| `deployId` | `string` | 未列为必填 | 部署 ID；订单和交易请求省略时可能读取项目全部部署。 |
| `agentDeploymentId` | `string` | 未列为必填 | 新工单附带的 AI 对话部署 ID；依赖 projectId。 |


## CreateSupportTicketResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `hash` | `string` | 未列为必填 | API 中的工单 ID；新建时省略，评论已有工单时提供。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


## DeleteAgentDeploymentRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `deploymentId` | `string` | 是 | 智能体部署 ID。 |


## DeleteAgentRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `agentId` | `integer` | 是 | 智能体 ID。 |


## DeleteAgentTaskRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `taskId` | `integer` | 是 | 任务 ID。 |


## Error

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `message` | `string` | 是 | 错误信息、工具确认消息或支持工单的 HTML 正文，按所属模型区分。 |
| `stacktrace` | `string` | 未列为必填 | 错误堆栈。 |


## ErrorEnhanceRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `language` | `string` | 是 | 编程语言：Py 或 C#。 允许值：`C#`, `Py`。 |
| `error` | `Error` | 是 | 需要增强说明的错误对象。 |


## ErrorEnhanceResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `state` | `string` | 未列为必填 | 工具执行状态，End 表示结束，Error 表示错误，具体取值见枚举。 |
| `version` | `number` | 未列为必填 | 工具响应协议版本。 |
| `payload` | `string` | 未列为必填 | 工具结果；初始化为信息文本，补全及语法检查为字符串数组，错误增强为建议文本，PEP8 转换为文件名到代码的字典。 |
| `payloadType` | `string` | 未列为必填 | payload 的类型标签，不是代码语言。 |


## File

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `name` | `string` | 未列为必填 | 智能体、任务或文件名称，按所属模型区分。 |
| `content` | `string` | 未列为必填 | 问题的 HTML 描述，须给出可复现代码或关联项目及回测。 |


## ListAgentDeploymentsRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `taskId` | `integer` | 是 | 任务 ID。 |


## ListAgentTasksRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `organizationId` | `string` | 是 | 目标组织 ID。 |


## ListAgentsRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `organizationId` | `string` | 是 | 目标组织 ID。 |


## ListSupportTicketsRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `organizationId` | `string` | 是 | 目标组织 ID。 |
| `closedPage` | `integer` | 未列为必填 | 已关闭工单的页码，从 0 开始，每页 10 条，默认 0。 |


## PEP8ConvertRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `files` | `array[File]` | 是 | 需要处理的源文件列表，元素含 name 和 content。 |


## PEP8ConvertResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `state` | `string` | 未列为必填 | 工具执行状态，End 表示结束，Error 表示错误，具体取值见枚举。 |
| `version` | `number` | 未列为必填 | 工具响应协议版本。 |
| `payload` | `object` | 未列为必填 | 工具结果；初始化为信息文本，补全及语法检查为字符串数组，错误增强为建议文本，PEP8 转换为文件名到代码的字典。 |
| `payloadType` | `string` | 未列为必填 | payload 的类型标签，不是代码语言。 |


## ReadAgentConversationRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `deploymentId` | `string` | 是 | 智能体部署 ID。 |
| `callableId` | `string` | 未列为必填 | 要读取对话的 callable 标识符。 |


## ReadAgentDeploymentRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `deploymentId` | `string` | 是 | 智能体部署 ID。 |


## ReadAgentRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `agentId` | `integer` | 是 | 智能体 ID。 |


## ReadAgentTaskRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `taskId` | `integer` | 是 | 任务 ID。 |


## ReadSupportTicketRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `organizationId` | `string` | 是 | 目标组织 ID。 |
| `hash` | `string` | 是 | API 中的工单 ID；新建时省略，评论已有工单时提供。 |


## RestResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


## SearchCriteria

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `input` | `string` | 是 | 搜索输入文本或工具调用的输入对象，按模型区分。 |
| `type` | `string` | 是 | 搜索类别（Stubs/Forum/Docs/Examples）、搜索结果类别编号（0/1/2/3），或消息片段种类；按所属模型区分。 允许值：`Stubs`, `Forum`, `Docs`, `Examples`。 |
| `count` | `integer` | 是 | 希望返回的搜索结果数。 |


## SearchRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `language` | `string` | 是 | 编程语言：Py 或 C#。 允许值：`C#`, `Py`。 |
| `criteria` | `array[SearchCriteria]` | 是 | 搜索条件数组。 |


## SearchResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `state` | `string` | 未列为必填 | 工具执行状态，End 表示结束，Error 表示错误，具体取值见枚举。 允许值：`End`, `Error`。 |
| `version` | `number` | 未列为必填 | 工具响应协议版本。 |
| `retrivals` | `array[SearchRetrieval]` | 未列为必填 | 搜索结果数组；这是原定义的拼写，不要改成 retrievals。 |
| `messageId` | `integer` | 未列为必填 | 搜索对应的消息 ID。 |


## SearchRetrieval

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `url` | `string` | 未列为必填 | 搜索结果链接，原定义示例可能采用 Markdown 链接格式。 |
| `score` | `number` | 未列为必填 | 结果相关性得分。 |
| `content` | `string` | 未列为必填 | 问题的 HTML 描述，须给出可复现代码或关联项目及回测。 |
| `type` | `number` | 未列为必填 | 搜索类别（Stubs/Forum/Docs/Examples）、搜索结果类别编号（0/1/2/3），或消息片段种类；按所属模型区分。 |


## StopAgentDeploymentRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `deploymentId` | `string` | 是 | 智能体部署 ID。 |


## SupportTicket

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `hash` | `string` | 未列为必填 | API 中的工单 ID；新建时省略，评论已有工单时提供。 |
| `title` | `string` | 未列为必填 | 工单主题。 |
| `status` | `string` | 未列为必填 | 部署状态或任务活动部署的状态条目；工单模型中为 open/closed 或 Open/Closed，保留原文枚举。 允许值：`Open`, `Closed`。 |
| `time` | `string` | 未列为必填 | 消息产生或工单最近更新的时间。 |
| `timeUnix` | `integer` | 未列为必填 | 工单最近更新的 Unix 时间戳。 |
| `data` | `SupportTicketData` | 未列为必填 | 工单详情对象。 |
| `profiles` | `array[SupportTicketMember]` | 未列为必填 | 参与工单的成员列表。 |


## SupportTicketData

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `external_id` | `string` | 未列为必填 | 支持系统内部工单 ID，联系支持团队时引用此 ID。 |
| `ticket_hash` | `string` | 未列为必填 | API 工单 ID，与 hash 相同。 |
| `status` | `string` | 未列为必填 | 部署状态或任务活动部署的状态条目；工单模型中为 open/closed 或 Open/Closed，保留原文枚举。 允许值：`open`, `closed`。 |
| `subject` | `string` | 未列为必填 | 新工单主题；创建新工单时必填。 |
| `created_time` | `string` | 未列为必填 | 工单创建时间，YYYY-MM-DD HH:MM:SS。 |
| `updated_time` | `string` | 未列为必填 | 工单最近更新时间，YYYY-MM-DD HH:MM:SS。 |
| `project_id` | `integer` | 未列为必填 | 附带的项目 ID。 |
| `backtest_id` | `string` | 未列为必填 | 附带的回测 ID。 |
| `live_deploy_id` | `string` | 未列为必填 | 附带的实时部署 ID。 |


## SupportTicketListResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `open` | `array[SupportTicket]` | 未列为必填 | 组织全部未关闭工单。 |
| `closed` | `array[SupportTicket]` | 未列为必填 | 当前页已关闭工单。 |
| `closedPage` | `integer` | 未列为必填 | 已关闭工单的页码，从 0 开始，每页 10 条，默认 0。 |
| `totalClosed` | `integer` | 未列为必填 | 已关闭工单总数。 |
| `allowance` | `integer` | 未列为必填 | 支持席位在一个月滚动窗口内允许新建的工单数。 |
| `remaining` | `integer` | 未列为必填 | 当前还能新建的工单数，为 allowance 减去过去一个月新建的工单数，已关闭工单也计入。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


## SupportTicketMember

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `name` | `string` | 未列为必填 | 智能体、任务或文件名称，按所属模型区分。 |
| `profile` | `string` | 未列为必填 | 组织、成员或作者的头像文件名或 URL，按模型区分。 |


## SupportTicketMessage

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `message` | `string` | 未列为必填 | 错误信息、工具确认消息或支持工单的 HTML 正文，按所属模型区分。 |
| `name` | `string` | 未列为必填 | 智能体、任务或文件名称，按所属模型区分。 |
| `profile` | `string` | 未列为必填 | 组织、成员或作者的头像文件名或 URL，按模型区分。 |
| `time` | `string` | 未列为必填 | 消息产生或工单最近更新的时间。 |
| `myself` | `boolean` | 未列为必填 | 该消息是否由当前用户撰写。 |


## SupportTicketMessagesResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `messages` | `array[SupportTicketMessage]` | 未列为必填 | 按顺序排列的对话消息或工单消息，按模型区分。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


## SyntaxCheckResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `state` | `string` | 未列为必填 | 工具执行状态，End 表示结束，Error 表示错误，具体取值见枚举。 允许值：`End`, `Error`。 |
| `version` | `number` | 未列为必填 | 工具响应协议版本。 |
| `payload` | `array[string]` | 未列为必填 | 工具结果；初始化为信息文本，补全及语法检查为字符串数组，错误增强为建议文本，PEP8 转换为文件名到代码的字典。 |
| `payloadType` | `string` | 未列为必填 | payload 的类型标签，不是代码语言。 |


## UpdateAgentDeploymentRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `deploymentId` | `string` | 是 | 智能体部署 ID。 |
| `prompt` | `string` | 是 | 任务部署后执行的提示词；更新部署时为后续追加提示。 |


## UpdateAgentDeploymentResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `message` | `string` | 未列为必填 | 错误信息、工具确认消息或支持工单的 HTML 正文，按所属模型区分。 |


## UpdateAgentRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `agentId` | `integer` | 是 | 智能体 ID。 |
| `name` | `string` | 未列为必填 | 智能体、任务或文件名称，按所属模型区分。 |
| `description` | `string` | 未列为必填 | 智能体简要描述。 |
| `profileImage` | `string` | 未列为必填 | 智能体头像文件名。 |
| `systemPrompt` | `string` | 未列为必填 | 定义智能体行为的系统提示词。 |
| `reasoningEffort` | `string` | 未列为必填 | 底层模型使用的推理强度。 允许值：`low`, `medium`, `high`。 |
| `maxTurns` | `integer` | 未列为必填 | 一次部署最多允许的智能体轮次。 |
| `toolChoice` | `string` | 未列为必填 | 工具选择策略。 |
| `tools` | `array[string]` | 未列为必填 | 可使用的工具标识符列表。 |
| `public` | `boolean` | 未列为必填 | 是否在组织内公开分享该智能体。 |
| `model` | `string` | 未列为必填 | 使用的模型标识符。 |
| `chainedAgents` | `array[AgentChainedEntry]` | 未列为必填 | 依次接续运行的智能体列表。 |
| `subAgents` | `array[AgentSubAgentEntry]` | 未列为必填 | 该智能体可调用的子智能体列表。 |
| `token` | `AgentToken` | 未列为必填 | 模型提供商令牌配置对象，含令牌及提供商标识。 |
| `useQCC` | `boolean` | 未列为必填 | 是否使用 QuantConnect Cloud 的模型服务；false 时需要用户令牌。 |
| `pipeline` | `string` | 未列为必填 | 分配给智能体的流水线。 |
| `author` | `AgentTaskOwner` | 未列为必填 | 作者信息对象。 |
| `organization` | `AgentOrganization` | 未列为必填 | 所属组织对象。 |
| `node` | `AgentNode` | 未列为必填 | 智能体的计算节点信息。 |


## UpdateAgentTaskRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `taskId` | `integer` | 是 | 任务 ID。 |
| `name` | `string` | 未列为必填 | 智能体、任务或文件名称，按所属模型区分。 |


[官方 OpenAPI 定义](https://github.com/QuantConnect/Documentation/blob/697eaf38f1d9b257aabb45e3a3210318276c2212/QuantConnect-Platform-2.0.0.yaml)
