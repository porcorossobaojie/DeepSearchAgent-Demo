# 投资见解 · Insights

按源码小节排列；接口行为依据同仓库 OpenAPI 对照，重复内容合并展示。

## 简介 · 01 Introduction

分页读取算法见解；字段与 Webhook 见解序列化不一定相同。

## 请求 · 02 Request

**`POST /backtests/read/insights`**

分页读取算法见解；字段与 Webhook 见解序列化不一定相同。

### 请求字段

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `start` | `integer` | 是 | 记录分页起点。 |
| `end` | `integer` | 是 | 记录分页终点；原文订单 end-start < 100，但示例写 100，本文使用 99 避免歧义。 |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `backtestId` | `string` | 是 | 回测标识。 |


嵌套对象的完整中文字段解释见 [运行与存储模型词典](../../run-models.html)。

### 中文注释调用示例

以下为依据 OpenAPI 整理的调用示意，依赖身份验证章节 get_headers。ID、参数与文件均为示意，不是在本次执行的真实操作。

```python
# 中文注释版：payload 字段名保持 API 原样，含义见上方表格。
import requests

payload = {'start': 0, 'end': 99, 'projectId': 12345678, 'backtestId': '<替换为自己的backtestId>'}

# get_headers 每次生成新时间戳；本片段没有自动重试写入请求。
response = requests.post(
    "https://www.quantconnect.com/api/v2/backtests/read/insights",
    headers=get_headers(), json=payload, timeout=30
)
response.raise_for_status()
# HTTP 成功后再检查 API 业务状态。
result = response.json()
if not result.get("success", False):
    raise RuntimeError(result.get("errors", "API 未返回成功状态"))
# 后续检查 completed、status 或 url；不要把提交成功直接当作完成。
```

### 响应字段

#### HTTP 200

内容类型：`application/json`。

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `insights` | `array[Insight]` | 未列为必填 | 投资见解数组。 |
| `length` | `integer` | 未列为必填 | 返回记录数量。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |


#### HTTP 401

认证失败，检查凭据、头部和客户端时间；本次没有进行在线认证验证。



## 响应 · 03 Responses

响应结构已列在本页请求说明下。更多嵌套对象见运行与存储模型词典。

## 示例 · 99 Examples

本页已提供带中文注释的最小调用。原文公共示例可能连带创建、更新或删除多个对象，完整动作保留在来源链接，未默认加入本页调用片段。
