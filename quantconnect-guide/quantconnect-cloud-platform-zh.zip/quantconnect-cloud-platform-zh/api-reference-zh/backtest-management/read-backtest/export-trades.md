# 导出交易 CSV · Export Trades

按源码小节排列；接口行为依据同仓库 OpenAPI 对照，重复内容合并展示。

## 简介 · 01 Introduction

返回已结束交易 CSV，按文本解析或保存；不是 JSON 响应。

## 说明 · 02 Description

返回已结束交易 CSV，按文本解析或保存；不是 JSON 响应。 数据与访问权限按正式条款执行。

## 请求 · 03 Request

**`POST /backtests/export/trades`**

返回已结束交易 CSV，按文本解析或保存；不是 JSON 响应。

### 请求字段

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `backtestId` | `string` | 是 | 回测标识。 |


嵌套对象的完整中文字段解释见 [运行与存储模型词典](../../run-models.html)。

### 中文注释调用示例

以下为依据 OpenAPI 整理的调用示意，依赖身份验证章节 get_headers。ID、参数与文件均为示意，不是在本次执行的真实操作。

```python
# 中文注释版：payload 字段名保持 API 原样，含义见上方表格。
import requests

payload = {'backtestId': '<替换为自己的backtestId>'}

# get_headers 每次生成新时间戳；本片段没有自动重试写入请求。
response = requests.post(
    "https://www.quantconnect.com/api/v2/backtests/export/trades",
    headers=get_headers(), json=payload, timeout=30
)
response.raise_for_status()
# 此接口返回 CSV：保留文本，不调用 response.json()。
csv_text = response.text
# 需要分析时可用 csv 或 pandas 读取；示例不写入或打印实际结果。
```

### 响应字段

#### HTTP 200

内容类型：`text/csv`。

CSV 文本，按列解释而不是 JSON 对象。

#### HTTP 401

认证失败，检查凭据、头部和客户端时间；本次没有进行在线认证验证。



## 响应 · 04 Responses

响应结构已列在本页请求说明下。更多嵌套对象见运行与存储模型词典。

## 示例 · 99 Examples

本页已提供带中文注释的最小调用。原文公共示例可能连带创建、更新或删除多个对象，完整动作保留在来源链接，未默认加入本页调用片段。
