# 实时交易模型词典

本词典覆盖本批接口的引用模型，包括通过字典值 additionalProperties 引用的现金及持仓模型。字段标识符保持原样，中文用于解释；开放对象与可选券商模式不被当作统一固定配置。原文示例凭据不复制为真实可用值。

## AlpacaBrokerageSettings

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 是 | 该模型对象的标识符，类型与含义见当前模型。 允许值：`AlpacaBrokerage`。 |
| `alpaca-access-token` | `string` | 是 | alpaca 的访问令牌；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `alpaca-environment` | `string` | 是 | alpaca 的运行环境；仅按所选提供商的正式配置填写，真实凭据不得公开。 允许值：`live`, `paper`。 |


原文模型说明：Settings for using Alpaca as the brokerage for a live algorithm.

## AlpacaDataProviderSettings

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 是 | 该模型对象的标识符，类型与含义见当前模型。 允许值：`AlpacaBrokerage`。 |
| `alpaca-api-key` | `string` | 是 | alpaca 的API Key；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `alpaca-api-secret` | `string` | 是 | alpaca 的API 密钥秘密部分；仅按所选提供商的正式配置填写，真实凭据不得公开。 |


原文模型说明：Settings for using Alpaca as a data provider for a live algorithm.

## AuthorizeExternalConnectionRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `brokerage` | `string` | 是 | 券商配置对象，或外部授权时的服务商名称；按当前接口类型使用。 允许值：`alpaca`, `tradestation`, `charlesschwab`, `tastytrade`。 |


原文模型说明：Request for authenticating with an external brokerage or data provider for a live algorithm.

## AuthorizeExternalConnectionResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `authorization` | `object` | 未列为必填 | 授权信息对象，可能含 access/refresh token，不能打印或公开。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


原文模型说明：Response for authenticating with an external brokerage or data provider for a live algorithm.

## BinanceBrokerageAndDataProviderSettings

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 是 | 该模型对象的标识符，类型与含义见当前模型。 允许值：`BinanceBrokerage`。 |
| `binance-exchange-name` | `string` | 是 | Binance 交易所实例名称。 允许值：`Binance`。 |
| `binance-api-key` | `string` | 是 | binance 的API Key；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `binance-api-secret` | `string` | 是 | binance 的API 密钥秘密部分；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `binance-use-testnet` | `string` | 是 | 是否使用测试网。 允许值：`live`, `paper`。 |


## BinanceBrokerageSettings

原定义为开放对象，未列固定字段；不要自行把猜测的键当成平台支持。

原文模型说明：Settings for using Binance as the brokerage for a live algorithm.

## BinanceCOINFuturesBrokerageAndDataProviderSettings

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 是 | 该模型对象的标识符，类型与含义见当前模型。 允许值：`BinanceBrokerage`。 |
| `binance-exchange-name` | `string` | 是 | Binance 交易所实例名称。 允许值：`Binance-COIN-Futures`。 |
| `binance-api-key` | `string` | 是 | binance 的API Key；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `binance-api-secret` | `string` | 是 | binance 的API 密钥秘密部分；仅按所选提供商的正式配置填写，真实凭据不得公开。 |


## BinanceCOINFuturesBrokerageSettings

原定义为开放对象，未列固定字段；不要自行把猜测的键当成平台支持。

原文模型说明：Settings for using Binance as the brokerage for a live algorithm.

## BinanceCOINFuturesDataProviderSettings

原定义为开放对象，未列固定字段；不要自行把猜测的键当成平台支持。

原文模型说明：Settings for using Binance as a data provider for a live algorithm.

## BinanceDataProviderSettings

原定义为开放对象，未列固定字段；不要自行把猜测的键当成平台支持。

原文模型说明：Settings for using Binance as a data provider for a live algorithm.

## BinanceUSBrokerageAndDataProviderSettings

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 是 | 该模型对象的标识符，类型与含义见当前模型。 允许值：`BinanceBrokerage`。 |
| `binance-exchange-name` | `string` | 是 | Binance 交易所实例名称。 允许值：`BinanceUS`。 |
| `binanceus-api-key` | `string` | 是 | binanceus 的API Key；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `binanceus-api-secret` | `string` | 是 | binanceus 的API 密钥秘密部分；仅按所选提供商的正式配置填写，真实凭据不得公开。 |


## BinanceUSBrokerageSettings

原定义为开放对象，未列固定字段；不要自行把猜测的键当成平台支持。

原文模型说明：Settings for using Binance as the brokerage for a live algorithm.

## BinanceUSDMFuturesBrokerageAndDataProviderSettings

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 是 | 该模型对象的标识符，类型与含义见当前模型。 允许值：`BinanceBrokerage`。 |
| `binance-exchange-name` | `string` | 是 | Binance 交易所实例名称。 允许值：`Binance-USDM-Futures`。 |
| `binance-api-key` | `string` | 是 | binance 的API Key；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `binance-api-secret` | `string` | 是 | binance 的API 密钥秘密部分；仅按所选提供商的正式配置填写，真实凭据不得公开。 |


## BinanceUSDMFuturesBrokerageSettings

原定义为开放对象，未列固定字段；不要自行把猜测的键当成平台支持。

原文模型说明：Settings for using Binance as the brokerage for a live algorithm.

## BinanceUSDMFuturesDataProviderSettings

原定义为开放对象，未列固定字段；不要自行把猜测的键当成平台支持。

原文模型说明：Settings for using Binance as a data provider for a live algorithm.

## BinanceUSDataProviderSettings

原定义为开放对象，未列固定字段；不要自行把猜测的键当成平台支持。

原文模型说明：Settings for using Binance as a data provider for a live algorithm.

## BitfinexSettings

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 是 | 该模型对象的标识符，类型与含义见当前模型。 允许值：`BitfinexBrokerage`。 |
| `bitfinex-api-key` | `string` | 是 | bitfinex 的API Key；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `bitfinex-api-secret` | `string` | 是 | bitfinex 的API 密钥秘密部分；仅按所选提供商的正式配置填写，真实凭据不得公开。 |


原文模型说明：Settings for using Bitfinex as the brokerage or a data provider for a live algorithm.

## BloombergFixSettings

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 是 | 该模型对象的标识符，类型与含义见当前模型。 允许值：`BloombergFixBrokerage`。 |
| `bloomberg-fix-sender-sub-id` | `string` | 是 | QuantConnect 用户 ID，经 FIX tag 50 发送。 |
| `bloomberg-fix-on-behalf-of-comp-id` | `string` | 是 | 交易公司 CompID，由 Bloomberg 配置，经 FIX tag 115 发送。 |
| `bloomberg-fix-deliver-to-comp-id` | `string` | 是 | 接收订单的主经纪商 CompID，经 FIX tag 128 发送。 |
| `bloomberg-fix-environment` | `string` | 是 | bloomberg 的运行环境；仅按所选提供商的正式配置填写，真实凭据不得公开。 允许值：`Live`。 |
| `cash` | `array[CashAmount]` | 未列为必填 | 初始现金列表或以币种为键的字典，按模型区分。 |
| `holdings` | `array[BrokerageHolding]` | 未列为必填 | 券商初始持仓列表，或以 Symbol ID 为键的持仓字典，按模型区分。 |


原文模型说明：Settings for using Bloomberg FIX as the brokerage for a live algorithm.

## BroadcastLiveCommandRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `organizationId` | `string` | 是 | 组织 ID；创建项目未提供时按定义使用首选组织。 |
| `excludeProjectId` | `integer` | 未列为必填 | 广播时排除的项目；为空则包含全部目标项目。 |
| `command` | `object` | 是 | 算法支持的命令对象；可能触发下单，具体格式由内置或自定义命令决定。 |


原文模型说明：Request to create a live command.

## BrokerageHolding

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `symbolId` | `string` | 未列为必填 | 标的 Symbol ID。 |
| `symbol` | `string` | 未列为必填 | 标的标识。 |
| `quantity` | `number` | 未列为必填 | 交易或订单数量；正负及绝对值口径按模型。 |
| `averagePrice` | `number` | 未列为必填 | 持仓均价，按标的报价币种。 |


原文模型说明：Holding object class for creating a live algorithm.

## BybitBrokerageAndDataProviderSettings

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 是 | 该模型对象的标识符，类型与含义见当前模型。 允许值：`BybitBrokerage`。 |
| `bybit-api-key` | `string` | 是 | bybit 的API Key；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `bybit-api-secret` | `string` | 是 | bybit 的API 密钥秘密部分；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `bybit-vip-level` | `string` | 是 | Bybit VIP 等级。 允许值：`VIP0`, `VIP1`, `VIP2`, `VIP3`, `VIP4`, `VIP5`, `SupremeVIP`, `Pro1`, `Pro2`, `Pro3`, `Pro4`, `Pro5`。 |


## BybitBrokerageSettings

原定义为开放对象，未列固定字段；不要自行把猜测的键当成平台支持。

原文模型说明：Settings for using Bybit as the brokerage for a live algorithm.

## BybitDataProviderSettings

原定义为开放对象，未列固定字段；不要自行把猜测的键当成平台支持。

原文模型说明：Settings for using Bybit as a data provider for a live algorithm.

## Cash

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `securitySymbols` | `array[object]` | 未列为必填 | 相关证券 Symbol 列表。 |
| `symbol` | `string` | 未列为必填 | 标的标识。 |
| `amount` | `number` | 未列为必填 | 现金数额。 |
| `conversionRate` | `number` | 未列为必填 | 换算到账户基础币种的汇率。 |
| `currencySymbol` | `string` | 未列为必填 | 币种显示符号。 |
| `valueInAccountCurrency` | `number` | 未列为必填 | 换算到账户基础币种后的价值。 |


原文模型说明：Represents a holding of a currency in cash.

## CashAmount

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `amount` | `number` | 是 | 现金数额。 |
| `currency` | `string` | 是 | 币种代码。 |


原文模型说明：Represents a cash amount which can be converted to account currency using a currency converter.

## CharlesSchwabSettings

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 是 | 该模型对象的标识符，类型与含义见当前模型。 允许值：`CharlesSchwabBrokerage`。 |
| `charles-schwab-account-number` | `string` | 是 | charles 的账户号码；仅按所选提供商的正式配置填写，真实凭据不得公开。 |


原文模型说明：Settings for using Charles Schwab as a data provider or the brokerage for a live algorithm.

## Chart

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `name` | `string` | 未列为必填 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `chartType` | `integer` | 未列为必填 | 图类型，按 Overlayed/Stacked 枚举。 允许值：`0`, `1`。 |
| `series` | `dictionary[string, Series]` | 未列为必填 | 图表序列。 |


原文模型说明：Single Parent Chart Object for Custom Charting.

## ChartSummary

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `name` | `string` | 未列为必填 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |


原文模型说明：Contains the names of all charts

## ClearStreetBrokerageSettings

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 是 | 该模型对象的标识符，类型与含义见当前模型。 允许值：`ClearStreetBrokerage`。 |
| `clearstreet-access-token` | `string` | 是 | clearstreet 的访问令牌；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `clearstreet-account-id` | `string` | 是 | clearstreet 的账户 ID；仅按所选提供商的正式配置填写，真实凭据不得公开。 |


原文模型说明：Settings for using Clear Street as the brokerage for a live algorithm.

## ClosedTradeWithOrders

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 未列为必填 | 该模型对象的标识符，类型与含义见当前模型。 |
| `symbols` | `array[Symbol]` | 未列为必填 | 交易涉及的标的。 |
| `entryTime` | `string` | 未列为必填 | 进入交易时间。 |
| `entryPrice` | `number` | 未列为必填 | 进入价格，多次进入时可能为均价。 |
| `direction` | `integer` | 未列为必填 | 方向枚举，订单 Buy/Sell 与交易 Long/Short 不是同一语义。 允许值：`0`, `1`。 |
| `quantity` | `number` | 未列为必填 | 交易或订单数量；正负及绝对值口径按模型。 |
| `exitTime` | `string` | 未列为必填 | 退出交易时间。 |
| `exitPrice` | `number` | 未列为必填 | 退出价格或均价。 |
| `profitLoss` | `number` | 未列为必填 | 该笔毛盈亏。 |
| `totalFees` | `number` | 未列为必填 | 交易费用总额。 |
| `mae` | `number` | 未列为必填 | 最大不利变动。 |
| `mfe` | `number` | 未列为必填 | 最大有利变动。 |
| `duration` | `string` | 未列为必填 | 交易持续时间。 |
| `endTradeDrawdown` | `number` | 未列为必填 | 退出前回吐利润。 |
| `isWin` | `boolean` | 未列为必填 | 是否盈利结束。 |
| `orderIds` | `array[integer]` | 未列为必填 | 组成该交易的订单 ID。 |
| `orders` | `array[Order]` | 未列为必填 | 订单集合。 |


原文模型说明：Represents a closed trade of a backtest or a live algorithm, with the orders that opened and closed it.

## CoinbaseBrokerageAndDataProviderSettings

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 是 | 该模型对象的标识符，类型与含义见当前模型。 允许值：`CoinbaseBrokerage`。 |
| `coinbase-api-name` | `string` | 是 | Coinbase Advanced Trade API 名称。 |
| `coinbase-api-private-key` | `string` | 是 | Coinbase API 私钥，属于认证秘密。 |


## CoinbaseBrokerageSettings

原定义为开放对象，未列固定字段；不要自行把猜测的键当成平台支持。

原文模型说明：Settings for using Coinbase Advanced Trade as the brokerage for a live algorithm.

## CoinbaseDataProviderSettings

原定义为开放对象，未列固定字段；不要自行把猜测的键当成平台支持。

原文模型说明：Settings for using Coinbase Advanced Trade as a data provider for a live algorithm.

## CreateLiveAlgorithmRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `versionId` | `string` | 是 | 部署的 LEAN 版本 ID；原文 -1 表示 master，需确认目标版本。 |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `compileId` | `string` | 是 | 编译任务 ID；创建任务后用它查询状态。 |
| `nodeId` | `string` | 是 | 运行算法的实时节点 ID。 |
| `brokerage` | `oneOf[QuantConnectBrokerageSettings, InteractiveBrokersBrokerageSettings, TradierBrokerageSettings, BitfinexSettings, CoinbaseBrokerageSettings, BinanceBrokerageSettings, BinanceUSBrokerageSettings, BinanceUSDMFuturesBrokerageSettings, BinanceCOINFuturesBrokerageSettings, TradingTechnologiesBrokerageSettings, KrakenSettings, BybitBrokerageSettings, OandaSettings, WolverineSettings, CharlesSchwabSettings, RBIBrokerageSettings, TerminalLinkSettings, TradeStationSettings, TastytradeSettings, AlpacaBrokerageSettings, WebullBrokerageSettings, PublicBrokerageSettings, ClearStreetBrokerageSettings, BloombergFixSettings]` | 是 | 券商配置对象，或外部授权时的服务商名称；按当前接口类型使用。 可选模型：`QuantConnectBrokerageSettings`, `InteractiveBrokersBrokerageSettings`, `TradierBrokerageSettings`, `BitfinexSettings`, `CoinbaseBrokerageSettings`, `BinanceBrokerageSettings`, `BinanceUSBrokerageSettings`, `BinanceUSDMFuturesBrokerageSettings`, `BinanceCOINFuturesBrokerageSettings`, `TradingTechnologiesBrokerageSettings`, `KrakenSettings`, `BybitBrokerageSettings`, `OandaSettings`, `WolverineSettings`, `CharlesSchwabSettings`, `RBIBrokerageSettings`, `TerminalLinkSettings`, `TradeStationSettings`, `TastytradeSettings`, `AlpacaBrokerageSettings`, `WebullBrokerageSettings`, `PublicBrokerageSettings`, `ClearStreetBrokerageSettings`, `BloombergFixSettings`。 |
| `dataProviders` | `object` | 未列为必填 | 数据源配置字典；顺序决定优先级，后面的源补前面的缺项。 |


## CreateLiveAlgorithmResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `responseCode` | `string` | 未列为必填 | 响应代码。 |
| `source` | `string` | 未列为必填 | API 调用来源。 |
| `deployId` | `string` | 未列为必填 | 部署 ID；订单和交易请求省略时可能读取项目全部部署。 |
| `versionId` | `integer` | 未列为必填 | 部署的 LEAN 版本 ID；原文 -1 表示 master，需确认目标版本。 |
| `projectId` | `integer` | 未列为必填 | 目标项目 ID。 |
| `live` | `LiveAlgorithm` | 未列为必填 | 新建或已有实时算法信息。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


原文模型说明：Response received when deploying a live algorithm.

## CreateLiveCommandRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `command` | `object` | 是 | 算法支持的命令对象；可能触发下单，具体格式由内置或自定义命令决定。 |


原文模型说明：Request to create a live command.

## ExportLiveOrdersRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `start` | `integer` | 未列为必填 | 起始记录索引；页差和终点是否包含，以当前接口专属描述为准。 |
| `end` | `integer` | 未列为必填 | 终止记录索引；页差和终点是否包含，以当前接口专属描述为准。 |


原文模型说明：Request to download the orders of the live deployments of a project.

## ExportLiveTradesRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `start` | `integer` | 未列为必填 | 起始记录索引；页差和终点是否包含，以当前接口专属描述为准。 |


原文模型说明：Request to download the closed trades of the live deployments of a project.

## GroupOrderManager

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `integer` | 未列为必填 | 该模型对象的标识符，类型与含义见当前模型。 |
| `quantity` | `number` | 未列为必填 | 交易或订单数量；正负及绝对值口径按模型。 |
| `count` | `integer` | 未列为必填 | 数量；图表请求是数据点数，分析模型是出现次数。 |
| `limitPrice` | `number` | 未列为必填 | 限价。 |
| `orderIds` | `array[integer]` | 未列为必填 | 组成该交易的订单 ID。 |
| `direction` | `integer` | 未列为必填 | 方向枚举，订单 Buy/Sell 与交易 Long/Short 不是同一语义。 |


原文模型说明：Manager of a group of orders.

## Holding

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `a` | `number` | 未列为必填 | 持仓平均买入价，按标的报价币种。 |
| `q` | `number` | 未列为必填 | 资产持仓数量。 |
| `p` | `number` | 未列为必填 | 标的当前市场价。 |
| `v` | `number` | 未列为必填 | 持仓当前市值。 |
| `u` | `number` | 未列为必填 | 持仓未实现盈亏。 |
| `up` | `number` | 未列为必填 | 持仓未实现盈亏百分比。 |


原文模型说明：Summary of asset holding.

## Insight

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 未列为必填 | 该模型对象的标识符，类型与含义见当前模型。 |
| `groupId` | `string` | 未列为必填 | 见解分组 ID。 |
| `sourceModel` | `string` | 未列为必填 | 见解来源模型标识。 |
| `generatedTime` | `integer` | 未列为必填 | 见解生成 Unix 时间。 |
| `closeTime` | `integer` | 未列为必填 | 见解结束 Unix 时间。 |
| `symbol` | `string` | 未列为必填 | 标的标识。 |
| `ticker` | `string` | 未列为必填 | 显示代码。 |
| `type` | `string` | 未列为必填 | 订单类型或其他模型类型，按当前枚举解释。 允许值：`price`, `volatility`。 |
| `reference` | `number` | 未列为必填 | 见解产生时的参考值。 |
| `referenceFinal` | `number` | 未列为必填 | 用于最终评分的参考值。 |
| `direction` | `string` | 未列为必填 | 方向枚举，订单 Buy/Sell 与交易 Long/Short 不是同一语义。 允许值：`down`, `flat`, `up`。 |
| `period` | `integer` | 未列为必填 | 预测持续时长，秒。 |
| `magnitude` | `number` | 未列为必填 | 预期变化幅度，可为空。 |
| `confidence` | `number` | 未列为必填 | 置信度，可为空。 |
| `weight` | `number` | 未列为必填 | 组合权重，可为空。 |
| `scoreFinal` | `boolean` | 未列为必填 | 是否为最终评分。 |
| `scoreDirection` | `number` | 未列为必填 | 方向得分。 |
| `scoreMagnitude` | `number` | 未列为必填 | 幅度得分。 |
| `estimatedValue` | `number` | 未列为必填 | 估计价值，账户货币。 |
| `tag` | `string` | 未列为必填 | 订单自定义标签。 |


原文模型说明：Insight struct for emitting new prediction.

## InteractiveBrokersBrokerageSettings

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 是 | 该模型对象的标识符，类型与含义见当前模型。 允许值：`InteractiveBrokersBrokerage`。 |
| `ib-user-name` | `string` | 是 | ib 的用户名；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `ib-account` | `string` | 是 | ib 的账户标识；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `ib-password` | `string` | 是 | ib 的密码；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `ib-weekly-restart-utc-time` | `string` | 是 | IB 每周日重认证 UTC 时间，hh:mm:ss；届时可能需要 2FA。 |
| `ib-financial-advisors-group-filter` | `string` | 未列为必填 | IB 财务顾问分组过滤，空值表示全部。 |


原文模型说明：Settings for using Interactive Brokers as the brokerage or a data provider for a live algorithm.

## InteractiveBrokersDataProviderSettings

原定义为开放对象，未列固定字段；不要自行把猜测的键当成平台支持。

原文模型说明：Settings for using Interactive Brokers as a data provider for a live algorithm.

## KrakenSettings

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 是 | 该模型对象的标识符，类型与含义见当前模型。 允许值：`KrakenBrokerage`。 |
| `kraken-api-key` | `string` | 是 | kraken 的API Key；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `kraken-api-secret` | `string` | 是 | kraken 的API 密钥秘密部分；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `kraken-verification-tier` | `string` | 是 | Kraken 验证等级。 允许值：`Starter`, `Intermediate`, `Pro`。 |


原文模型说明：Settings for using Kraken as the brokerage or a data provider for a live algorithm.

## LiquidateLiveAlgorithmRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |


原文模型说明：Request to liquidate a live algorithm.

## ListLiveAlgorithmsRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 未列为必填 | 目标项目 ID。 |
| `status` | `string` | 未列为必填 | 任务或订单状态，按当前模型枚举解释。 允许值：`Running`, `Stopped`, `RuntimeError`, `Liquidated`。 |


原文模型说明：Request for a list of past and present live deployments.

## LiveAlgorithm

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `message` | `string` | 未列为必填 | 交易所或系统消息。 |
| `deployId` | `string` | 未列为必填 | 部署 ID；订单和交易请求省略时可能读取项目全部部署。 |
| `status` | `string` | 未列为必填 | 任务或订单状态，按当前模型枚举解释。 允许值：`DeployError`, `InQueue`, `Running`, `Stopped`, `Liquidated`, `Deleted`, `Completed`, `RuntimeError`, `Invalid`, `LoggingIn`, `Initializing`, `History`。 |
| `cloneId` | `integer` | 未列为必填 | 原始被克隆项目 ID。 |
| `launched` | `string` | 未列为必填 | 启动 UTC 时间。 |
| `stopped` | `['string', 'null']` | 未列为必填 | 停止 UTC 时间，仍运行时可为空。 |
| `description` | `['string', 'null']` | 未列为必填 | 对象描述，具体含义以当前模型为准。 |
| `projectName` | `string` | 未列为必填 | 占用节点的项目名称。 |
| `brokerage` | `string` | 未列为必填 | 券商配置对象，或外部授权时的服务商名称；按当前接口类型使用。 |
| `securityTypes` | `string` | 未列为必填 | 涉及的资产类型数量。 |
| `datacenter` | `string` | 未列为必填 | 运行数据中心。 |
| `isPublicStreaming` | `boolean` | 未列为必填 | 是否开放公开结果流。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `public` | `boolean` | 未列为必填 | 版本是否公开可用，按定义类型及取值使用。 |
| `files` | `array[ProjectFile]` | 未列为必填 | 项目文件列表。 |
| `runtimeStatistics` | `RuntimeStatistics` | 未列为必填 | 结果页顶部运行统计。 |
| `charts` | `ChartSummary` | 未列为必填 | 图表集合或图表更新。 |


原文模型说明：Live algorithm instance result from the QuantConnect Rest API.

## LiveAlgorithmListResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `live` | `array[LiveAlgorithmSummary]` | 未列为必填 | 新建或已有实时算法信息。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


原文模型说明：List of the live algorithms running which match the requested status.

## LiveAlgorithmResults

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `message` | `string` | 未列为必填 | 交易所或系统消息。 |
| `deployId` | `string` | 未列为必填 | 部署 ID；订单和交易请求省略时可能读取项目全部部署。 |
| `status` | `string` | 未列为必填 | 任务或订单状态，按当前模型枚举解释。 允许值：`DeployError`, `InQueue`, `Running`, `Stopped`, `Liquidated`, `Deleted`, `Completed`, `RuntimeError`, `Invalid`, `LoggingIn`, `Initializing`, `History`。 |
| `cloneId` | `integer` | 未列为必填 | 原始被克隆项目 ID。 |
| `launched` | `string` | 未列为必填 | 启动 UTC 时间。 |
| `stopped` | `['string', 'null']` | 未列为必填 | 停止 UTC 时间，仍运行时可为空。 |
| `brokerage` | `string` | 未列为必填 | 券商配置对象，或外部授权时的服务商名称；按当前接口类型使用。 |
| `securityTypes` | `string` | 未列为必填 | 涉及的资产类型数量。 |
| `datacenter` | `string` | 未列为必填 | 运行数据中心。 |
| `isPublicStreaming` | `boolean` | 未列为必填 | 是否开放公开结果流。 |
| `public` | `boolean` | 未列为必填 | 版本是否公开可用，按定义类型及取值使用。 |
| `description` | `['string', 'null']` | 未列为必填 | 对象描述，具体含义以当前模型为准。 |
| `files` | `array[ProjectFile]` | 未列为必填 | 项目文件列表。 |
| `runtimeStatistics` | `RuntimeStatistics` | 未列为必填 | 结果页顶部运行统计。 |
| `serverStatistics` | `ServerStatistics` | 未列为必填 | 运行节点统计，具体键随 LEAN 版本变化。 |
| `deploymentDetails` | `dictionary[string, string]` | 未列为必填 | 组件提供的账户等部署详情，未提供则可能省略，不应当作凭据字段。 |
| `charts` | `ChartSummary` | 未列为必填 | 图表集合或图表更新。 |
| `projectName` | `string` | 未列为必填 | 占用节点的项目名称。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


原文模型说明：Details a live algorithm from the live/read API endpoint.

## LiveAlgorithmSummary

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 未列为必填 | 目标项目 ID。 |
| `deployId` | `string` | 未列为必填 | 部署 ID；订单和交易请求省略时可能读取项目全部部署。 |
| `status` | `string` | 未列为必填 | 任务或订单状态，按当前模型枚举解释。 |
| `launched` | `string` | 未列为必填 | 启动 UTC 时间。 |
| `stopped` | `string` | 未列为必填 | 停止 UTC 时间，仍运行时可为空。 |
| `brokerage` | `string` | 未列为必填 | 券商配置对象，或外部授权时的服务商名称；按当前接口类型使用。 |
| `subscription` | `string` | 未列为必填 | 订阅的图表信息。 |
| `equity` | `number` | 未列为必填 | 部署权益。 |
| `environment` | `string` | 未列为必填 | 运行环境。 |
| `description` | `string` | 未列为必填 | 对象描述，具体含义以当前模型为准。 |
| `error` | `string` | 未列为必填 | 错误信息。 |
| `leagues` | `array[string]` | 未列为必填 | 所属 Quant Leagues。 |


原文模型说明：Summary of the live algorithm.

## LiveInsightsResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `insights` | `array[Insight]` | 未列为必填 | 投资见解数组。 |
| `length` | `integer` | 未列为必填 | 返回长度或全部部署匹配日志总数，具体按模型。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |


原文模型说明：Contains insights and the number of insights of the live algorithm in the request criteria.

## LiveOrdersResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `orders` | `array[Order]` | 未列为必填 | 订单集合。 |
| `length` | `integer` | 未列为必填 | 返回长度或全部部署匹配日志总数，具体按模型。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


原文模型说明：Contains orders and the number of orders of the live algorithm in the request criteria.

## LivePortfolioResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `portfolio` | `Portfolio` | 未列为必填 | 现金与持仓状态。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


原文模型说明：Contains holdings and cash of the live algorithm in the request criteria.

## LiveTradesResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `trades` | `array[ClosedTradeWithOrders]` | 未列为必填 | 交易数量或交易集合，按模型类型区分。 |
| `length` | `integer` | 未列为必填 | 返回长度或全部部署匹配日志总数，具体按模型。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


原文模型说明：Contains the closed trades and the number of closed trades of the live algorithm in the request criteria.

## LoadingResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `progress` | `number` | 未列为必填 | 进度，原文范围 0–1，不是 0–100。 |
| `status` | `string` | 未列为必填 | 任务或订单状态，按当前模型枚举解释。 允许值：`loading`。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |


原文模型说明：Response when the requested chart or orders are being generated.

## OandaSettings

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 是 | 该模型对象的标识符，类型与含义见当前模型。 允许值：`OandaBrokerage`。 |
| `oanda-account-id` | `string` | 是 | OANDA 账户 ID，原文格式 ###-###-######-###。 |
| `oanda-access-token` | `string` | 是 | oanda 的访问令牌；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `oanda-environment` | `string` | 是 | OANDA 环境：Practice 或 Trade，按允许值配置。 允许值：`Practice`, `Trade`。 |


原文模型说明：Settings for using Oanda as the brokerage or a data provider for a live algorithm.

## Order

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `integer` | 未列为必填 | 该模型对象的标识符，类型与含义见当前模型。 |
| `contingentId` | `integer` | 未列为必填 | 处理前须先处理的关联订单 ID。 |
| `brokerId` | `array[string]` | 未列为必填 | 券商订单 ID，可能拆分为多段。 |
| `symbol` | `Symbol` | 未列为必填 | 标的标识。 |
| `limitPrice` | `number` | 未列为必填 | 限价。 |
| `stopPrice` | `number` | 未列为必填 | 止损触发价。 |
| `stopTriggered` | `boolean` | 未列为必填 | 止损是否已触发。 |
| `price` | `number` | 未列为必填 | 订单价格。 |
| `priceCurrency` | `string` | 未列为必填 | 订单价格币种。 |
| `time` | `string` | 未列为必填 | 订单创建 UTC 时间。 |
| `createdTime` | `string` | 未列为必填 | 订单创建时间，原文是 time 的别名。 |
| `lastFillTime` | `string` | 未列为必填 | 最近成交 UTC 时间，可为空。 |
| `lastUpdateTime` | `string` | 未列为必填 | 最近更新 UTC 时间，可为空。 |
| `canceledTime` | `string` | 未列为必填 | 取消 UTC 时间，可为空。 |
| `quantity` | `number` | 未列为必填 | 交易或订单数量；正负及绝对值口径按模型。 |
| `type` | `integer` | 未列为必填 | 订单类型或其他模型类型，按当前枚举解释。 允许值：`0`, `1`, `2`, `3`, `4`, `5`, `6`, `7`, `8`, `9`, `10`, `11`。 |
| `status` | `integer` | 未列为必填 | 任务或订单状态，按当前模型枚举解释。 允许值：`0`, `1`, `2`, `3`, `5`, `6`, `7`, `8`, `9`。 |
| `tag` | `string` | 未列为必填 | 订单自定义标签。 |
| `securityType` | `integer` | 未列为必填 | 资产类型枚举。 允许值：`0`, `1`, `2`, `3`, `4`, `5`, `6`, `7`, `8`, `9`, `10`, `11`。 |
| `direction` | `integer` | 未列为必填 | 方向枚举，订单 Buy/Sell 与交易 Long/Short 不是同一语义。 允许值：`0`, `1`, `2`。 |
| `value` | `number` | 未列为必填 | 参数的值，按模型类型处理。 |
| `orderSubmissionData` | `OrderSubmissionData` | 未列为必填 | 提交时的价格信息。 |
| `isMarketable` | `boolean` | 未列为必填 | 是否可立即与市场成交。 |
| `properties` | `OrderProperties` | 未列为必填 | 订单附加属性。 |
| `events` | `array[OrderEvent]` | 未列为必填 | 订单事件。 |
| `trailingAmount` | `number` | 未列为必填 | 追踪止损距离。 |
| `trailingAsPercentage` | `boolean` | 未列为必填 | 距离是否按百分比解释。 |
| `groupOrderManager` | `GroupOrderManager` | 未列为必填 | 组合订单管理信息。 |
| `triggerPrice` | `number` | 未列为必填 | 触碰后触发限价单的价格。 |
| `triggerTouched` | `boolean` | 未列为必填 | 触发价是否已触碰。 |


原文模型说明：Order struct for placing new trade.

## OrderDirection

类型：`string`；取值：`buy`, `sell`, `hold`。

原文模型说明：Direction of the order.

## OrderEvent

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `algorithmId` | `string` | 未列为必填 | 算法、回测或部署 ID。 |
| `symbol` | `string` | 未列为必填 | 标的标识。 |
| `symbolValue` | `string` | 未列为必填 | 当前显示代码。 |
| `symbolPermtick` | `string` | 未列为必填 | 生成标识时使用的原始代码。 |
| `orderId` | `integer` | 未列为必填 | 所属订单 ID。 |
| `orderEventId` | `integer` | 未列为必填 | 订单内唯一事件 ID。 |
| `id` | `string` | 未列为必填 | 该模型对象的标识符，类型与含义见当前模型。 |
| `status` | `string` | 未列为必填 | 任务或订单状态，按当前模型枚举解释。 允许值：`new`, `submitted`, `partiallyFilled`, `filled`, `canceled`, `none`, `invalid`, `cancelPending`, `updateSubmitted`。 |
| `orderFeeAmount` | `number` | 未列为必填 | 费用金额。 |
| `orderFeeCurrency` | `string` | 未列为必填 | 费用币种。 |
| `fillPrice` | `number` | 未列为必填 | 成交价。 |
| `fillPriceCurrency` | `string` | 未列为必填 | 成交价币种。 |
| `fillQuantity` | `number` | 未列为必填 | 本次事件成交数量。 |
| `direction` | `OrderDirection` | 未列为必填 | 方向枚举，订单 Buy/Sell 与交易 Long/Short 不是同一语义。 允许值：`buy`, `sell`, `hold`。 |
| `message` | `string` | 未列为必填 | 交易所或系统消息。 |
| `isAssignment` | `boolean` | 未列为必填 | 是否期权指派。 |
| `stopPrice` | `number` | 未列为必填 | 止损触发价。 |
| `limitPrice` | `number` | 未列为必填 | 限价。 |
| `quantity` | `number` | 未列为必填 | 交易或订单数量；正负及绝对值口径按模型。 |
| `time` | `number` | 未列为必填 | 订单创建 UTC 时间。 |
| `isInTheMoney` | `boolean` | 未列为必填 | 期权是否实值。 |


原文模型说明：Change in an order state applied to user algorithm portfolio

## OrderProperties

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `timeInForce` | `object` | 未列为必填 | 订单有效期限。 |


原文模型说明：Additional properties of the order

## OrderSubmissionData

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `bidPrice` | `number` | 未列为必填 | 提交时最佳买价。 |
| `askPrice` | `number` | 未列为必填 | 提交时最佳卖价。 |
| `lastPrice` | `number` | 未列为必填 | 提交时最新成交价。 |


原文模型说明：Stores time and price information available at the time an order was submitted.

## PolygonDataProviderSettings

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 是 | 该模型对象的标识符，类型与含义见当前模型。 允许值：`Polygon`。 |
| `polygon-api-key` | `string` | 是 | polygon 的API Key；仅按所选提供商的正式配置填写，真实凭据不得公开。 |


原文模型说明：Settings for using Polygon as a data provider for a live algorithm.

## Portfolio

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `holdings` | `dictionary[string, Holding]` | 未列为必填 | 券商初始持仓列表，或以 Symbol ID 为键的持仓字典，按模型区分。 |
| `cash` | `dictionary[string, Cash]` | 未列为必填 | 初始现金列表或以币种为键的字典，按模型区分。 |


原文模型说明：Portfolio object with the holdings and cash information.

## ProjectFile

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `integer` | 未列为必填 | 该模型对象的标识符，类型与含义见当前模型。 |
| `projectId` | `integer` | 未列为必填 | 目标项目 ID。 |
| `name` | `string` | 未列为必填 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `content` | `string` | 未列为必填 | 文件内容；更新时是完整新内容，不是补丁。 |
| `modified` | `string` | 未列为必填 | 最近修改时间。 |
| `open` | `boolean` | 未列为必填 | 文件是否在编辑器打开。 |
| `isLibrary` | `boolean` | 未列为必填 | 是否为代码库文件；部分运行读取响应固定为 false。 |


原文模型说明：File for a project.

## PublicBrokerageSettings

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 是 | 该模型对象的标识符，类型与含义见当前模型。 允许值：`PublicBrokerage`。 |
| `public-secret-key` | `string` | 是 | Public 认证私密键。 |
| `public-account-number` | `string` | 是 | public 的账户号码；仅按所选提供商的正式配置填写，真实凭据不得公开。 |


原文模型说明：Settings for using Public as the brokerage for a live algorithm.

## QuantConnectBrokerageSettings

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 是 | 该模型对象的标识符，类型与含义见当前模型。 允许值：`QuantConnectBrokerage`。 |
| `holdings` | `array[BrokerageHolding]` | 是 | 券商初始持仓列表，或以 Symbol ID 为键的持仓字典，按模型区分。 |
| `cash` | `array[CashAmount]` | 是 | 初始现金列表或以币种为键的字典，按模型区分。 |


原文模型说明：Settings for using Paper Trading as the brokerage for a live algorithm.

## QuantConnectDataProviderSettings

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 是 | 该模型对象的标识符，类型与含义见当前模型。 允许值：`QuantConnectBrokerage`。 |


原文模型说明：Settings for using QuantConnect as a data provider for a live algorithm.

## RBIBrokerageSettings

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 是 | 该模型对象的标识符，类型与含义见当前模型。 允许值：`RBIBrokerage`。 |
| `rbi-on-behalf-of-comp-id` | `string` | 是 | 代表交易公司的 CompID。 |
| `rbi-account` | `string` | 是 | rbi 的账户标识；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `cash` | `array[CashAmount]` | 未列为必填 | 初始现金列表或以币种为键的字典，按模型区分。 |
| `holdings` | `array[BrokerageHolding]` | 未列为必填 | 券商初始持仓列表，或以 Symbol ID 为键的持仓字典，按模型区分。 |


原文模型说明：Settings for using RBI as the brokerage for a live algorithm.

## ReadChartResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `chart` | `Chart` | 未列为必填 | 请求的图表对象。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


原文模型说明：Response with the requested chart from a live algorithm or backtest

## ReadLiveAlgorithmRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |


原文模型说明：Request to read out a live algorithm.

## ReadLiveChartRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `name` | `string` | 是 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `count` | `integer` | 是 | 数量；图表请求是数据点数，分析模型是出现次数。 |
| `start` | `integer` | 是 | 起始记录索引；页差和终点是否包含，以当前接口专属描述为准。 |
| `end` | `integer` | 是 | 终止记录索引；页差和终点是否包含，以当前接口专属描述为准。 |


原文模型说明：Request to body to obtain a chart from a live algorithm.

## ReadLiveInsightsRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `algorithmId` | `string` | 未列为必填 | 算法、回测或部署 ID。 |
| `start` | `integer` | 未列为必填 | 起始记录索引；页差和终点是否包含，以当前接口专属描述为准。 |
| `end` | `integer` | 是 | 终止记录索引；页差和终点是否包含，以当前接口专属描述为准。 |
| `projectId` | `integer` | 是 | 目标项目 ID。 |


原文模型说明：Request to read insights from a live algorithm.

## ReadLiveLogsRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `format` | `object` | 未列为必填 | 日志返回格式。 |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `algorithmId` | `string` | 是 | 算法、回测或部署 ID。 |
| `startLine` | `integer` | 是 | 日志匹配行起点，零基且包含。 |
| `endLine` | `integer` | 是 | 日志匹配行终点，不包含；endLine-startLine ≤ 250。 |
| `deploymentLogs` | `boolean` | 未列为必填 | 是否仅包含指定部署日志。 |
| `query` | `string` | 未列为必填 | 不区分大小写的日志关键字；行索引针对匹配结果，省略或空字符串表示不过滤。 |


原文模型说明：Request to read the logs of a specific algorithm.

## ReadLiveLogsResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `logs` | `array[string]` | 未列为必填 | 编译日志列表。 |
| `length` | `integer` | 未列为必填 | 返回长度或全部部署匹配日志总数，具体按模型。 |
| `deploymentOffset` | `integer` | 未列为必填 | 指定部署前的日志总行数，仍按未过滤行计数。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


原文模型说明：Logs from a live algorithm.

## ReadLiveOrdersRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `deployId` | `string` | 未列为必填 | 部署 ID；订单和交易请求省略时可能读取项目全部部署。 |
| `start` | `integer` | 是 | 起始记录索引；页差和终点是否包含，以当前接口专属描述为准。 |
| `end` | `integer` | 是 | 终止记录索引；页差和终点是否包含，以当前接口专属描述为准。 |
| `projectId` | `integer` | 是 | 目标项目 ID。 |


原文模型说明：Request to read orders from a live algorithm.

## ReadLivePortfolioRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |


原文模型说明：Request to read the portfolio state from a live algorithm.

## ReadLiveTradesRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `deployId` | `string` | 未列为必填 | 部署 ID；订单和交易请求省略时可能读取项目全部部署。 |
| `start` | `integer` | 是 | 起始记录索引；页差和终点是否包含，以当前接口专属描述为准。 |
| `end` | `integer` | 是 | 终止记录索引；页差和终点是否包含，以当前接口专属描述为准。 |


原文模型说明：Request to read closed trades from a live algorithm.

## RestResponse

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


原文模型说明：Base API response class for the QuantConnect API.

## RuntimeStatistics

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `Equity` | `string` | 未列为必填 | 组合总权益。 |
| `Fees` | `string` | 未列为必填 | 交易费用。 |
| `Holdings` | `string` | 未列为必填 | 持仓价值。 |
| `Net Profit` | `string` | 未列为必填 | 净收益。 |
| `Probabilistic Sharpe Ratio` | `string` | 未列为必填 | 概率夏普比率。 |
| `Return` | `string` | 未列为必填 | 收益率。 |
| `Unrealized` | `string` | 未列为必填 | 未实现盈亏。 |
| `Volume` | `string` | 未列为必填 | 总交易量／金额指标，具体单位按模型。 |


## Series

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `name` | `string` | 未列为必填 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `unit` | `string` | 未列为必填 | 图表序列坐标轴单位。 |
| `index` | `integer` | 未列为必填 | 序列在图表中的位置索引。 |
| `values` | `oneOf[array[array[object]], array[object]]` | 未列为必填 | 按时间升序排列的数据点。 可选模型：`array[array[object]]`, `array[object]`。 |
| `seriesType` | `integer` | 未列为必填 | 图表类型：0 折线、1 散点、2 蜡烛、3 柱状、4 标记、5 堆积面积、6 饼图、7 树图、9 热力图、10 三维散点。 允许值：`0`, `1`, `2`, `3`, `4`, `5`, `6`, `7`, `9`, `19`。 |
| `color` | `string` | 未列为必填 | 序列颜色。 |
| `scatterMarkerSymbol` | `string` | 未列为必填 | 散点图标记形状。 允许值：`none`, `circle`, `square`, `diamond`, `triangle`, `triangle-down`。 |


原文模型说明：Chart Series Object - Series data and properties for a chart.

## ServerStatistics

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `CPU Usage` | `string` | 未列为必填 | CPU 使用百分比。 |
| `Used RAM (MB)` | `string` | 未列为必填 | 算法已用内存 MB。 |
| `Total RAM (MB)` | `string` | 未列为必填 | 节点可用内存 MB。 |
| `Hostname` | `string` | 未列为必填 | 运行主机名称。 |
| `LEAN Version` | `string` | 未列为必填 | 引擎版本。 |
| `Up Time` | `string` | 未列为必填 | 节点运行时长。 |


## StopLiveAlgorithmRequest

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |


原文模型说明：Request to stop a live algorithm.

## Symbol

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `value` | `string` | 未列为必填 | 参数的值，按模型类型处理。 |
| `id` | `string` | 未列为必填 | 该模型对象的标识符，类型与含义见当前模型。 |
| `permtick` | `string` | 未列为必填 | 标的最初／永久代码。 |


原文模型说明：Represents a unique security identifier. This is made of two components, the unique SID and the Value. The value is the current ticker symbol while the SID is constant over the life of a security.

## TastytradeSettings

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 是 | 该模型对象的标识符，类型与含义见当前模型。 允许值：`TastytradeBrokerage`。 |
| `tastytrade-account-number` | `integer` | 是 | tastytrade 的账户号码；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `tastytrade-refresh-token` | `string` | 是 | tastytrade 刷新令牌；原文误写 TradeStation，不能混用另一家凭据。 |


原文模型说明：Settings for using Tastytrade as the brokerage or a data provider for a live algorithm.

## TerminalLinkSettings

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 是 | 该模型对象的标识符，类型与含义见当前模型。 允许值：`TerminalLinkBrokerage`。 |
| `terminal-link-connection-type` | `string` | 是 | Terminal Link 连接类型。 允许值：`SAPI`。 |
| `terminal-link-server-auth-id` | `string` | 是 | Bloomberg Anywhere 用户 UUID，不知道时向 Bloomberg 确认。 |
| `terminal-link-environment` | `string` | 是 | terminal 的运行环境；仅按所选提供商的正式配置填写，真实凭据不得公开。 允许值：`Production`, `Beta`。 |
| `terminal-link-server-host` | `string` | 是 | SAPI AWS 服务的公网 IP。 |
| `terminal-link-server-port` | `integer` | 是 | SAPI 端口，原文默认 8194。 |
| `terminal-link-emsx-broker` | `string` | 是 | EMSX 使用的券商。 |
| `terminal-link-emsx-account` | `string` | 是 | 订单路由目标账户。 |
| `terminal-link-openfigi-api-key` | `string` | 是 | 用于期权映射的 OpenFIGI API Key。 |
| `terminal-link-emsx-team` | `string` | 未列为必填 | EMSX 团队。 |
| `cash` | `array[CashAmount]` | 未列为必填 | 初始现金列表或以币种为键的字典，按模型区分。 |
| `holdings` | `array[BrokerageHolding]` | 未列为必填 | 券商初始持仓列表，或以 Symbol ID 为键的持仓字典，按模型区分。 |


原文模型说明：Settings for using TerminalLink as the brokerage for a live algorithm.

## TradeStationSettings

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 是 | 该模型对象的标识符，类型与含义见当前模型。 允许值：`TradeStationBrokerage`。 |
| `trade-station-client-id` | `string` | 是 | trade 的客户端应用 ID；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `trade-station-account-id` | `string` | 是 | trade 的账户 ID；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `trade-station-refresh-token` | `string` | 是 | trade 的刷新令牌；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `trade-station-environment` | `string` | 是 | trade 的运行环境；仅按所选提供商的正式配置填写，真实凭据不得公开。 允许值：`live`, `paper`。 |


原文模型说明：Settings for using TradeStation as the brokerage or a data provider for a live algorithm.

## TradierBrokerageSettings

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 是 | 该模型对象的标识符，类型与含义见当前模型。 允许值：`TradierBrokerage`。 |
| `tradier-account-id` | `string` | 是 | tradier 的账户 ID；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `tradier-access-token` | `string` | 是 | tradier 的访问令牌；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `tradier-environment` | `string` | 是 | tradier 的运行环境；仅按所选提供商的正式配置填写，真实凭据不得公开。 允许值：`live`, `paper`。 |


原文模型说明：Settings for using Tradier as the brokerage for a live algorithm.

## TradierDataProviderSettings

原定义为开放对象，未列固定字段；不要自行把猜测的键当成平台支持。

原文模型说明：Settings for using Tradier as a data provider for a live algorithm.

## TradingTechnologiesBrokerageSettings

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 是 | 该模型对象的标识符，类型与含义见当前模型。 允许值：`TradingTechnologiesBrokerage`。 |
| `tt-user-name` | `string` | 是 | tt 的用户名；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `tt-session-password` | `string` | 是 | tt 的会话密码；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `tt-account-name` | `string` | 是 | tt 的账户名；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `tt-rest-app-key` | `string` | 是 | tt 的应用键；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `tt-rest-app-secret` | `string` | 是 | tt 的应用秘密；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `tt-rest-environment` | `string` | 是 | tt 的运行环境；仅按所选提供商的正式配置填写，真实凭据不得公开。 允许值：`live`, `uat`。 |
| `tt-order-routing-sender-comp-id` | `string` | 是 | TT 订单路由发送方 CompID。 |
| `cash` | `array[CashAmount]` | 是 | 初始现金列表或以币种为键的字典，按模型区分。 |


原文模型说明：Settings for using Trading Technologies as the brokerage for a live algorithm.

## WebullBrokerageSettings

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 是 | 该模型对象的标识符，类型与含义见当前模型。 允许值：`WebullBrokerage`。 |
| `webull-app-key` | `string` | 是 | webull 的应用键；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `webull-app-secret` | `string` | 是 | webull 的应用秘密；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `webull-account-id` | `string` | 是 | webull 的账户 ID；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `webull-use-2fa` | `boolean` | 未列为必填 | Webull 应用是否启用双重验证。 |


原文模型说明：Settings for using Webull as the brokerage for a live algorithm.

## WolverineSettings

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `id` | `string` | 是 | 该模型对象的标识符，类型与含义见当前模型。 允许值：`WolverineBrokerage`。 |
| `wolverine-on-behalf-of-comp-id` | `string` | 是 | 代表交易公司的 CompID。 |
| `wolverine-account` | `string` | 是 | wolverine 的账户标识；仅按所选提供商的正式配置填写，真实凭据不得公开。 |
| `cash` | `array[CashAmount]` | 未列为必填 | 初始现金列表或以币种为键的字典，按模型区分。 |
| `holdings` | `array[BrokerageHolding]` | 未列为必填 | 券商初始持仓列表，或以 Symbol ID 为键的持仓字典，按模型区分。 |


原文模型说明：Settings for using Wolverine Execution Services as the brokerage for a live algorithm.

## inline_response_200_3

### 配置模式 1：`LoadingResponse`

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `progress` | `number` | 未列为必填 | 进度，原文范围 0–1，不是 0–100。 |
| `status` | `string` | 未列为必填 | 任务或订单状态，按当前模型枚举解释。 允许值：`loading`。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |


### 配置模式 2：`ReadChartResponse`

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `chart` | `Chart` | 未列为必填 | 请求的图表对象。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


## 原始定义

[官方 OpenAPI](https://github.com/QuantConnect/Documentation/blob/697eaf38f1d9b257aabb45e3a3210318276c2212/QuantConnect-Platform-2.0.0.yaml)。本稿为中文说明，不是部署权限、密钥或实盘验证结果。
