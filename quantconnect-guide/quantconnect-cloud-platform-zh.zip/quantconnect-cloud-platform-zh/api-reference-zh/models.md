# 共享模型字段词典

本页提供当前这批项目、文件、编译、账号与版本接口引用的全部模型字段。中文含义按当前模型解释；同名字段在不同模型中可能有细节差异。每个模型附 OpenAPI 原文描述，方便核对。认证等开放对象无固定键时明确标注。

## AccountResponse

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `organizationId` | `string` | 未列为必填 | 组织 ID；创建项目未提供时按定义使用首选组织。 |
| `creditBalance` | `number` | 未列为必填 | 账户 QCC 余额。 |
| `card` | `Card` | 未列为必填 | 组织信用卡概览对象，不是完整卡号。 |


原文模型说明：Account information for an organization.

## BrokerageData

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `id` | `string` | 是 | 该模型对象的标识符，类型与含义见当前模型。 |
| `authentication` | `LiveAuthenticationData` | 未列为必填 | 券商认证字段；不得把真实认证内容写入公开示例。 |


原文模型说明：Brokerage data saved on live deployment.

## BrokerageId

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `id` | `string` | 未列为必填 | 该模型对象的标识符，类型与含义见当前模型。 |


原文模型说明：Brokerage Id.

## Card

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `brand` | `string` | 未列为必填 | 卡品牌。 |
| `expiration` | `string` | 未列为必填 | 卡有效期，格式 mm/yy。 |
| `last4` | `string` | 未列为必填 | 卡号末四位。 |


原文模型说明：Credit card information.

## Collaborator

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `uid` | `integer` | 是 | 用户 ID。 |
| `liveControl` | `boolean` | 是 | 是否拥有实时部署和停止控制权限。 |
| `permission` | `string` | 是 | 当前授权级别，保留 read/write 等原始值。 允许值：`read`, `write`。 |
| `publicId` | `string/null` | 是 | 用户公开 ID。 |
| `profileImage` | `string` | 是 | 头像网址。 |
| `email` | `string` | 是 | 用户注册邮箱。 |
| `name` | `string` | 是 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `bio` | `string` | 未列为必填 | 用户简介。 |
| `owner` | `boolean` | 是 | 是否为项目所有者。 |


## CreateCollaboratorRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `collaboratorUserId` | `string` | 是 | 要添加或修改的协作者用户 ID。 |
| `collaborationLiveControl` | `boolean` | 是 | 新增协作者是否可部署和停止实时算法。 |
| `collaborationWrite` | `boolean` | 是 | 新增协作者是否可编辑代码。 |


原文模型说明：Request to add a new collaborator to a project.

## CreateCollaboratorResponse

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `collaborators` | `array[Collaborator]` | 未列为必填 | 项目协作者列表。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |


原文模型说明：Response received when creating collaborator.

## CreateCompileRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |


原文模型说明：Request to compile a project.

## CreateCompileResponse

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `compileId` | `string` | 未列为必填 | 编译任务 ID；创建任务后用它查询状态。 |
| `state` | `string` | 未列为必填 | 编译状态，按 InQueue、BuildSuccess、BuildError 等枚举判断。 允许值：`InQueue`, `BuildSuccess`, `BuildError`。 |
| `parameters` | `array[FileParameters]` | 未列为必填 | 参数列表；项目配置值与编译检测结果应按模型区分。 |
| `projectId` | `integer` | 未列为必填 | 目标项目 ID。 |
| `signature` | `string` | 未列为必填 | 编译签名。 |
| `signatureOrder` | `array[string]` | 未列为必填 | 编译文件的签名顺序。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


原文模型说明：Response received from creating a compile job.

## CreateProjectFileRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `name` | `string` | 是 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `content` | `string` | 未列为必填 | 文件内容；更新时是完整新内容，不是补丁。 |
| `codeSourceId` | `string` | 未列为必填 | 发起编辑的环境名称，例如 MCP Server；不是项目 ID。 |


原文模型说明：Request to add a file to a project.

## CreateProjectRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `name` | `string` | 是 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `language` | `string` | 是 | 项目语言，通常为 Py 或 C#，按枚举取值。 允许值：`C#`, `Py`。 |
| `organizationId` | `string` | 未列为必填 | 组织 ID；创建项目未提供时按定义使用首选组织。 |


原文模型说明：Request to create a project with the specified name and language via QuantConnect.com API.

## DeleteCollaboratorRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `collaboratorId` | `string` | 是 | 要移除的协作者用户 ID。 |


原文模型说明：Request to remove a collaborator from a project.

## DeleteCollaboratorResponse

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `collaborators` | `array[Collaborator]` | 未列为必填 | 项目协作者列表。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |


原文模型说明：Response received when removing collaborator.

## DeleteFileRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `name` | `string` | 是 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `codeSourceId` | `string` | 未列为必填 | 发起编辑的环境名称，例如 MCP Server；不是项目 ID。 |


原文模型说明：Request to delete a file in a project.

## DeleteProjectRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |


原文模型说明：Request to delete a project.

## EncryptionKey

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `id` | `string` | 未列为必填 | 该模型对象的标识符，类型与含义见当前模型。 |
| `name` | `string` | 未列为必填 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |


原文模型说明：Encryption key details.

## FileParameters

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `file` | `string` | 未列为必填 | 项目内文件路径。 |
| `parameters` | `array[ParameterDetail]` | 未列为必填 | 参数列表；项目配置值与编译检测结果应按模型区分。 |


## Grid

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `xs` | `array[GridChart]` | 是 | 超小屏幕布局项。 |
| `sm` | `array[GridChart]` | 是 | 小屏布局项。 |
| `md` | `array[GridChart]` | 是 | 中屏布局项。 |
| `lg` | `array[GridChart]` | 是 | 大屏布局项。 |
| `xl` | `array[GridChart]` | 是 | 超大屏布局项。 |


原文模型说明：The grid arrangement of charts.

## GridChart

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `chartName` | `string` | 是 | 图表名称。 |
| `width` | `integer` | 是 | 图表宽度。 |
| `height` | `integer` | 是 | 图表高度。 |
| `row` | `integer` | 是 | 布局行。 |
| `column` | `integer` | 是 | 布局列。 |
| `sort` | `integer` | 未列为必填 | 排序信息。 |
| `definition` | `array[string]` | 未列为必填 | 图表定义标签。 |


原文模型说明：The chart display properties.

## LeanVersion

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `id` | `integer` | 未列为必填 | 该模型对象的标识符，类型与含义见当前模型。 |
| `created` | `string` | 未列为必填 | 创建时间。 |
| `description` | `string` | 未列为必填 | 对象描述，具体含义以当前模型为准。 |
| `leanHash` | `string` | 未列为必填 | LEAN 仓库提交哈希。 |
| `leanCloudHash` | `string` | 未列为必填 | 云端仓库提交哈希。 |
| `name` | `string` | 未列为必填 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `ref` | `string` | 未列为必填 | 分支或提交引用。 |
| `public` | `boolean` | 未列为必填 | 版本是否公开可用，按定义类型及取值使用。 |


## LeanVersionsResponse

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `versions` | `array[LeanVersion]` | 未列为必填 | LEAN 版本列表。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


原文模型说明：Contains the LEAN versions with their basic descriptions.

## Library

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `libraryName` | `string` | 未列为必填 | 代码库名称。 |
| `ownerName` | `string` | 未列为必填 | 代码库所有者名称。 |
| `access` | `boolean` | 未列为必填 | 当前用户是否可访问代码库。 |


## LiveAuthenticationData

定义未列出固定字段；它可能是空对象或由专属接口定义的开放对象，不应自行假设内部键。

原文模型说明：Authentication details of the live brokerage. Details on each brokerage refers to https://www.quantconnect.com/docs/v2/lean-cli/api-reference/lean-cloud-live-deploy.

## LiveForm

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `brokerageData` | `object` | 是 | 券商标识和认证配置对象。 |
| `dataProvidersData` | `array[BrokerageId]` | 是 | 部署使用的数据源配置。 |
| `node` | `string` | 是 | 实时节点 ID。 |
| `notifyInsights` | `boolean` | 是 | 是否对新投资见解发通知。 |
| `notifyOrderEvents` | `boolean` | 是 | 是否对新订单事件发通知。 |
| `autoRestart` | `boolean` | 是 | 运行出错后是否允许自动重启。 |


原文模型说明：The live wizard content used.

## LockCollaboratorRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `codeSourceId` | `string` | 是 | 发起编辑的环境名称，例如 MCP Server；不是项目 ID。 |


原文模型说明：Lock a project so you can edit it. This is necessary when the project has collaborators or when an LLM is editing files on your behalf via our MCP Server.

## Node

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `speed` | `number` | 未列为必填 | CPU 频率，GHz。 |
| `price` | `NodePrices` | 未列为必填 | 节点月付／年付美元价格信息。 |
| `cpu` | `integer` | 未列为必填 | CPU 核心数。 |
| `ram` | `number` | 未列为必填 | 内存 GB。 |
| `name` | `string` | 未列为必填 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `sku` | `string` | 未列为必填 | 节点型号标识。 |
| `description` | `string` | 未列为必填 | 对象描述，具体含义以当前模型为准。 |
| `usedBy` | `string` | 未列为必填 | 当前使用节点的用户。 |
| `userProfile` | `string` | 未列为必填 | 该用户资料链接。 |
| `projectName` | `string` | 未列为必填 | 占用节点的项目名称。 |
| `projectId` | `integer/null` | 未列为必填 | 目标项目 ID。 |
| `busy` | `boolean` | 未列为必填 | 节点是否忙碌。 |
| `id` | `string` | 未列为必填 | 该模型对象的标识符，类型与含义见当前模型。 |
| `assets` | `integer` | 未列为必填 | 建议最大标的数。 |
| `host` | `string/null` | 未列为必填 | 主机标识。 |
| `active` | `boolean` | 未列为必填 | 节点是否被当前项目选中。 |
| `hasGpu` | `integer` | 未列为必填 | 是否具有 GPU，按模型原始取值。 |


原文模型说明：Contains all relevant information on a Node to interact through API endpoints.

## NodePrices

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `monthly` | `integer` | 未列为必填 | 月费美元。 |
| `yearly` | `integer` | 未列为必填 | 年费美元。 |


原文模型说明：Node prices from node object.

## ParameterDetail

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `line` | `integer` | 未列为必填 | 检测到参数的代码行号。 |
| `type` | `string` | 未列为必填 | 检测结果的类型描述。 |


## ParameterSet

### 请求模式 1

定义未列出固定字段；它可能是空对象或由专属接口定义的开放对象，不应自行假设内部键。

### 请求模式 2

定义未列出固定字段；它可能是空对象或由专属接口定义的开放对象，不应自行假设内部键。

## PatchFileRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `patch` | `string` | 是 | unified diff 补丁字符串，包含文件头、index、---/+++ 和 @@ 区块，并与现有空白、缩进及换行精确匹配。 |
| `codeSourceId` | `string` | 未列为必填 | 发起编辑的环境名称，例如 MCP Server；不是项目 ID。 |


原文模型说明：Request to apply a patch (unified diff) to a file in a project.

## Project

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `organizationId` | `string` | 是 | 组织 ID；创建项目未提供时按定义使用首选组织。 |
| `name` | `string` | 是 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `modified` | `string` | 是 | 最近修改时间。 |
| `created` | `string` | 是 | 创建时间。 |
| `ownerId` | `integer` | 是 | 所有者用户 ID。 |
| `language` | `string` | 是 | 项目语言，通常为 Py 或 C#，按枚举取值。 允许值：`C#`, `Py`。 |
| `collaborators` | `array[Collaborator]` | 是 | 项目协作者列表。 |
| `leanVersionId` | `integer` | 是 | 项目使用的 LEAN 版本 ID。 |
| `leanPinnedToMaster` | `boolean` | 是 | 是否始终使用 master 分支。 |
| `owner` | `boolean` | 是 | 是否为项目所有者。 |
| `description` | `string` | 是 | 对象描述，具体含义以当前模型为准。 |
| `channelId` | `string` | 是 | 项目通道 ID。 |
| `parameters` | `ParameterSet` | 是 | 参数列表；项目配置值与编译检测结果应按模型区分。 |
| `libraries` | `array[Library]` | 是 | 引用的共享代码库列表。 |
| `grid` | `object` | 是 | 回测结果视图布局。 |
| `liveGrid` | `object` | 是 | 实时结果视图布局。 |
| `paperEquity` | `number/null` | 是 | 最近模拟交易实例的权益。 |
| `lastLiveDeployment` | `string/null` | 是 | 最近实时部署的活动时间。 |
| `liveForm` | `object` | 是 | 最近使用的部署向导配置。 |
| `encrypted` | `boolean` | 是 | 项目是否加密。 |
| `codeRunning` | `boolean` | 是 | 项目是否正在运行。 |
| `leanEnvironment` | `integer` | 是 | 项目运行的软件包／LEAN 环境标识。 |
| `encryptionKey` | `object` | 是 | 加密密钥信息；请求与响应可能分别为文件内容或元数据对象，按模型类型使用。 |
| `isPinned` | `boolean` | 是 | 是否在工作台首页固定项目。 |
| `maxFileSize` | `integer` | 是 | 文件大小上限字段，单位与具体口径查对应原文。 |
| `sharingTokenBacktest` | `string/null` | 未列为必填 | 私密回测分享认证信息，不能公开真实值。 |


原文模型说明：Response from reading a project by id.

## ProjectFile

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `id` | `integer` | 未列为必填 | 该模型对象的标识符，类型与含义见当前模型。 |
| `projectId` | `integer` | 未列为必填 | 目标项目 ID。 |
| `name` | `string` | 未列为必填 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `content` | `string` | 未列为必填 | 文件内容；更新时是完整新内容，不是补丁。 |
| `modified` | `string` | 未列为必填 | 最近修改时间。 |
| `open` | `boolean` | 未列为必填 | 文件是否在编辑器打开。 |
| `isLibrary` | `boolean` | 未列为必填 | 是否为代码库文件；部分运行读取响应固定为 false。 |


原文模型说明：File for a project.

## ProjectFilesResponse

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `files` | `array[ProjectFile]` | 未列为必填 | 项目文件列表。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


原文模型说明：Response received when creating or reading project files.

## ProjectListResponse

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projects` | `array[Project]` | 未列为必填 | 项目列表。 |
| `versions` | `array[LeanVersion]` | 未列为必填 | LEAN 版本列表。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


原文模型说明：Project list response.

## ProjectNodes

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `backtest` | `array[Node]` | 未列为必填 | 回测节点集合。 |
| `live` | `array[Node]` | 未列为必填 | 实时节点集合。 |
| `research` | `array[Node]` | 未列为必填 | 研究节点集合。 |


原文模型说明：Contains sets of node lists for each target environment.

## ProjectNodesResponse

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `nodes` | `ProjectNodes` | 未列为必填 | 节点选择列表或节点集合，按当前模型类型区分。 |
| `autoSelectNode` | `boolean` | 未列为必填 | 是否自动选择最佳可用节点。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


原文模型说明：Response received when reading all nodes of a project.

## ReadCollaboratorsRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |


原文模型说明：Request to list the collaborators in a project.

## ReadCollaboratorsResponse

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `collaborators` | `array[Collaborator]` | 未列为必填 | 项目协作者列表。 |
| `userLiveControl` | `boolean` | 未列为必填 | 当前用户／所有者的实时控制能力，具体见模型原文。 |
| `userPermissions` | `string` | 未列为必填 | 用户权限信息。 允许值：`write`, `read`。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |


原文模型说明：Response received when reading the collaborators of a project.

## ReadCompileRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `compileId` | `string` | 是 | 编译任务 ID；创建任务后用它查询状态。 |


原文模型说明：Request to read a compile packet job.

## ReadCompileResponse

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `compileId` | `string` | 未列为必填 | 编译任务 ID；创建任务后用它查询状态。 |
| `state` | `string` | 未列为必填 | 编译状态，按 InQueue、BuildSuccess、BuildError 等枚举判断。 允许值：`InQueue`, `BuildSuccess`, `BuildError`。 |
| `logs` | `array[string]` | 未列为必填 | 编译日志列表。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


原文模型说明：Response received from reading a compile job.

## ReadFilesRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `name` | `string` | 未列为必填 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `codeSourceId` | `string` | 未列为必填 | 发起编辑的环境名称，例如 MCP Server；不是项目 ID。 |


原文模型说明：Request to read all files from a project or just one (if the name is provided).

## ReadProjectNodesRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |


原文模型说明：Request to get details about the nodes in your organization, including which nodes may be used by the project.

## ReadProjectRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 未列为必填 | 目标项目 ID。 |
| `start` | `integer` | 未列为必填 | 项目分页起点，零基且包含；使用时不同时指定单项目 ID。 默认：`0`。 |
| `end` | `integer` | 未列为必填 | 项目分页终点，不包含；与 start 搭配。 |


原文模型说明：Request to get details about a specific project or a subset of your projects.

## RestResponse

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


原文模型说明：Base API response class for the QuantConnect API.

## UpdateCollaboratorRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `collaboratorUserId` | `string` | 是 | 要添加或修改的协作者用户 ID。 |
| `liveControl` | `boolean` | 是 | 是否拥有实时部署和停止控制权限。 |
| `write` | `boolean` | 是 | 是否允许编辑代码。 |


原文模型说明：Request to update an existing collaborator on a project.

## UpdateCollaboratorResponse

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `collaborators` | `array[Collaborator]` | 未列为必填 | 项目协作者列表。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |


原文模型说明：Response received when updating collaborator.

## UpdateFileContentsRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `name` | `string` | 是 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `content` | `string` | 是 | 文件内容；更新时是完整新内容，不是补丁。 |
| `codeSourceId` | `string` | 未列为必填 | 发起编辑的环境名称，例如 MCP Server；不是项目 ID。 |


原文模型说明：Request to update the contents of a file.

## UpdateFileNameRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `name` | `string` | 是 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `newName` | `string` | 是 | 文件的新名称。 |
| `codeSourceId` | `string` | 未列为必填 | 发起编辑的环境名称，例如 MCP Server；不是项目 ID。 |


原文模型说明：Request to update the name of a file.

## UpdateProjectNodesRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `nodes` | `array[string]` | 未列为必填 | 节点选择列表或节点集合，按当前模型类型区分。 |


原文模型说明：Request to update the nodes of a project.

## UpdateProjectRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `name` | `string` | 未列为必填 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `description` | `string` | 未列为必填 | 对象描述，具体含义以当前模型为准。 |


原文模型说明：Update a project's name or description.

## files_update_body

### 请求模式 1

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `name` | `string` | 是 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `newName` | `string` | 是 | 文件的新名称。 |
| `codeSourceId` | `string` | 未列为必填 | 发起编辑的环境名称，例如 MCP Server；不是项目 ID。 |


### 请求模式 2

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `name` | `string` | 是 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `content` | `string` | 是 | 文件内容；更新时是完整新内容，不是补丁。 |
| `codeSourceId` | `string` | 未列为必填 | 发起编辑的环境名称，例如 MCP Server；不是项目 ID。 |


## 原始定义

来源：[官方 OpenAPI 文件](https://github.com/QuantConnect/Documentation/blob/697eaf38f1d9b257aabb45e3a3210318276c2212/QuantConnect-Platform-2.0.0.yaml)。本页为字段中文说明，不是实际 API 响应或在线验证记录。
