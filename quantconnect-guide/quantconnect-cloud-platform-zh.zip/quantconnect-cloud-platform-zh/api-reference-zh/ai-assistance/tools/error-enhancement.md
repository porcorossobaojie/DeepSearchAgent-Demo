# 错误增强说明 · Error Enhancement

对照官方原有小节和 OpenAPI 整理。示例仅为说明，未执行平台请求。

## 简介 · 01 Introduction

提供错误信息及可选堆栈，取得附加上下文和建议；建议仍需结合代码验证。

## 请求与代码说明 · 02 Request

### POST `/ai/tools/error-enhance`

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `language` | `string` | 是 | 编程语言：Py 或 C#。 允许值：`C#`, `Py`。 |
| `error` | `Error` | 是 | 需要增强说明的错误对象。 |


[完整中文模型词典](../../remaining-models.html)

```python
# 中文注释版：仅演示字段及调用过程，不会在文档生成时执行。
import requests

# ID 和文本需要替换；get_headers 见身份验证页。
payload = {'language': 'Py', 'error': {'message': 'NameError: name example is not defined'}}

# 本接口的具体效果见简介；创建、更新、删除或部署会更改平台状态。
response = requests.post(
    "https://www.quantconnect.com/api/v2/ai/tools/error-enhance",
    headers=get_headers(), json=payload, timeout=30
)
# 先检查 HTTP 状态，再检查所属接口的业务状态。
response.raise_for_status()
result = response.json()
# AI 工具使用 state/payload 或 retrivals，不能强制要求 success 字段。
state = result.get("state")
if state == "Error":
    raise RuntimeError(result.get("payload", "工具处理失败"))
# End 仅表示工具处理结束；返回内容仍需审阅。
```


## 响应 · 03 Responses

### HTTP 200

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `state` | `string` | 未列为必填 | 工具执行状态，End 表示结束，Error 表示错误，具体取值见枚举。 |
| `version` | `number` | 未列为必填 | 工具响应协议版本。 |
| `payload` | `string` | 未列为必填 | 工具结果；初始化为信息文本，补全及语法检查为字符串数组，错误增强为建议文本，PEP8 转换为文件名到代码的字典。 |
| `payloadType` | `string` | 未列为必填 | payload 的类型标签，不是代码语言。 |


### HTTP 401

身份验证失败；核对 API Key、签名和时间戳。



## 示例 · 99 Examples

本页请求小节提供附中文注释的最小示例。完整官方示例及其相关资源见本节保留的原文链接；不要把批量示例直接用于真实账号。
