# 账号 · Account

## 简介 · Introduction

读取组织的账户状态。账号认证与组织账单状态不同：认证成功不代表有特定套餐或资源权限。

## 说明 · Description

原文账户状态包括组织 ID、QCC 余额及信用卡概览。不要将信用卡品牌和末四位误认为完整支付凭据。

## 请求 · Request

接口为 `POST /account/read`，需要公共认证头，定义未列出业务请求体。完整字段模型和中文示例见下方接口说明。

**方法与路径：`POST /account/read`**

读取组织账户概览，包含 QCC 余额和信用卡概要，不会发起收费。

### 请求字段

定义未列出业务请求体；仍需要身份验证。

嵌套类型及响应对象的中文字段解释见 [共享模型词典](models.html)。字段名、类型、必填和枚举依据仓库 OpenAPI，不根据示例猜测。

### 带注释的 Python 调用

以下是按定义整理的最小调用示意，不是官方示例逐字复制，也没有实际执行。先使用身份验证页的 `get_headers`；替换示例 ID，并检查当前组织与权限。

```python
# 中文注释版：get_headers 来自身份验证章节；此片段需 requests。
import requests

# 只展示请求结构；ID 和文件内容要换成自己确认的目标。
payload = {}

# 每次重新生成认证头，避免使用过期时间戳。
response = requests.post(
    "https://www.quantconnect.com/api/v2/account/read",
    headers=get_headers(),
    json=payload,
    timeout=30
)
# HTTP 失败先抛出；HTTP 200 仍需继续检查业务 success。
response.raise_for_status()
result = response.json()
if not result.get("success", False):
    raise RuntimeError(result.get("errors", "API 未返回成功状态"))
# result 的字段含义见下方响应表；此处不打印账号或文件内容。
```

### 响应结构

#### HTTP 200

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `organizationId` | `string` | 未列为必填 | 组织 ID；创建项目未提供时按定义使用首选组织。 |
| `creditBalance` | `number` | 未列为必填 | 账户 QCC 余额。 |
| `card` | `Card` | 未列为必填 | 组织信用卡概览对象，不是完整卡号。 |


#### HTTP 401

认证缺失、无效或时间戳问题，不能靠重复发送相同旧请求修复。

该响应的具体格式见原文定义。



## 响应 · Responses

主要返回 organizationId、creditBalance 和 card。card 包含 brand、expiration 和 last4。请求成功标志与 errors 需按模型检查；示意数据不代表真实账单。

## 示例 · Examples

本页“请求”内附带中文注释的最小调用。官方更完整示例链接见本节相关来源，本文未访问任何实际账号状态。
