# 回测管理与标签 · Backtest Management

本组根页面的原文并非目录说明，而是生成到了标签更新接口；子目录另有创建、读取和导出。本稿保留这一结构差异。

## 简介 · Introduction

根页面描述更新回测标签集合，对应 `/backtests/tags/update`。本次 OpenAPI paths 没有该端点，所以不把它伪装成已交叉核验接口。

## 请求 · Request

HTML 原文列出 projectId、backtestId 和 tags 为必填，tags 为字符串数组。backtestId 的类型一栏存在生成异常。本页仅转述字段，不生成未经交叉确认的调用代码。

## 响应 · Responses

原文提供 RestResponse，success 为布尔值，errors 为错误列表。具体可用性需以当前官方接口为准。

## 示例 · Examples

根页面引用公共回测示例。下方子章节已有创建、查询、导出和结果管理的中文注释示例；它们都没有在本次任务中执行。
