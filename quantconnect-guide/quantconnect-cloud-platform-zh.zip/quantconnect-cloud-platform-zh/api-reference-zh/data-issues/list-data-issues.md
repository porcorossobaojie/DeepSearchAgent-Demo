# 查询数据问题 · List Data Issues

按官方原有小节组织。以下代码为附中文注释的最小调用示例，未发送请求。

## 简介 · 01 Introduction

分页查询数据问题。start 包含、end 不包含；resultsFound 是匹配总数。需要所有结果时，可将 end 设为不小于 resultsFound 的值。默认查询 open；开放状态包括 In queue、In progress、Waiting Review 和 Waiting for Data Vendor，关闭状态包括 Resolved、Closed 和 Cannot Be Resolved。

## 使用说明 · 02 Description

分页查询数据问题。start 包含、end 不包含；resultsFound 是匹配总数。需要所有结果时，可将 end 设为不小于 resultsFound 的值。默认查询 open；开放状态包括 In queue、In progress、Waiting Review 和 Waiting for Data Vendor，关闭状态包括 Resolved、Closed 和 Cannot Be Resolved。

## 请求与注释示例 · 03 Request

### POST `/community/data-library/issues/list`

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `status` | `string` | 未列为必填 | 列表请求用 open/closed；问题响应列出具体处理状态。 允许值：`open`, `closed`。 |
| `start` | `integer` | 未列为必填 | 起始索引，默认 0，包含。 |
| `end` | `integer` | 未列为必填 | 终点索引，默认 20，不包含。 |
| `search` | `string` | 未列为必填 | 按证券代码精确筛选，不区分大小写。 |
| `subscribed` | `boolean` | 未列为必填 | 是否只查询本人订阅的问题；响应中表示本人是否订阅。 |


```python
# 中文注释版：此片段仅用于说明接口，没有自动执行。
import requests

# 使用身份验证页的 get_headers；请求字段名须保持英文。
payload = {'status': 'open', 'start': 0, 'end': 20, 'search': 'SPY'}

# 读取指定回测或问题列表。
response = requests.post(
    "https://www.quantconnect.com/api/v2/community/data-library/issues/list",
    headers=get_headers(), json=payload, timeout=30
)
# 分别检查 HTTP 错误和 API 业务状态。
response.raise_for_status()
result = response.json()
if not result.get("success", False):
    raise RuntimeError(result.get("errors", "接口未成功"))
# 当前页结果与匹配总数分开读取，后续按需要翻页。
issues = result.get("results", [])
total = result.get("resultsFound", 0)
```



## 响应 · 04 Responses

### HTTP 200

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `results` | `array[DataIssue]` | 未列为必填 | 当前区间的数据问题列表。 |
| `resultsFound` | `integer` | 未列为必填 | 匹配筛选条件的问题总数，不是当前页长度。 |
| `openIssuesCount` | `integer` | 未列为必填 | 数据问题页面全部未关闭问题数。 |
| `closedIssuesCount` | `integer` | 未列为必填 | 数据问题页面全部已关闭问题数。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


### HTTP 401

认证失败：检查 API 凭据、签名和时间戳。



## 示例 · 99 Examples

上方提供中文注释版最小示例。官方示例的原始代码及其引用资源保留在本节相关链接中。
