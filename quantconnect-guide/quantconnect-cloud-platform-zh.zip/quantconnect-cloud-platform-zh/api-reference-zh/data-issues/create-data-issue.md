# 提交数据问题 · Create Data Issue

按官方原有小节组织。以下代码为附中文注释的最小调用示例，未发送请求。

## 简介 · 01 Introduction

提交数据问题。先查询同一代码和分辨率是否已有未关闭问题。每份报告必须能复现：用 select-project 和 select-backtest 关联项目及回测，或在 content 内给出代码。至少选择一种问题类型。

## 使用说明 · 02 Description

提交数据问题。先查询同一代码和分辨率是否已有未关闭问题。每份报告必须能复现：用 select-project 和 select-backtest 关联项目及回测，或在 content 内给出代码。至少选择一种问题类型。

## 请求与注释示例 · 03 Request

### POST `/community/data-library/issues/create`

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `ticker` | `string` | 是 | 发生问题的证券代码。 |
| `security` | `string` | 是 | 资产类别；允许值须保留英文。 允许值：`Equity`, `Equity Option`, `Index`, `Index Option`, `Future`, `Future Option`, `Forex`, `CFD`, `Crypto`, `Crypto Future`。 |
| `market` | `string` | 是 | 市场；有效值取决于资产类别，以数据问题页面下拉框为准。 |
| `resolution` | `string` | 是 | 数据分辨率；有效值取决于资产类别和市场。 允许值：`Tick`, `Second`, `Minute`, `Hour`, `Daily`, `Coarse Fundamental`, `Fine Fundamental`, `Margin`。 |
| `from-date` | `string` | 是 | 问题起始日期，YYYY-MM-DD。 |
| `to-date` | `string` | 是 | 问题结束日期，YYYY-MM-DD，必须晚于起始日期。 |
| `from-time` | `string` | 未列为必填 | 起始时刻 HH:MM；Second/Minute 且区间短于七天时必需。 |
| `to-time` | `string` | 未列为必填 | 结束时刻 HH:MM；Second/Minute 且区间短于七天时必需。 |
| `corrupted-files` | `string` | 未列为必填 | 报告文件损坏时包含此字段；至少选择一种问题类型。 允许值：`Corrupted Files`。 |
| `missing-points` | `string` | 未列为必填 | 报告缺少数据点时包含此字段；至少选择一种问题类型。 允许值：`Missing Points`。 |
| `missing-files` | `string` | 未列为必填 | 报告缺少文件时包含此字段；至少选择一种问题类型。 允许值：`Missing Files`。 |
| `wrong-values` | `string` | 未列为必填 | 报告数值错误时包含此字段；至少选择一种问题类型。 允许值：`Wrong Values`。 |
| `listing-error` | `string` | 未列为必填 | 报告上市信息错误时包含此字段；至少选择一种问题类型。 允许值：`Listing Error`。 |
| `split-error` | `string` | 未列为必填 | 报告拆股错误时包含此字段；至少选择一种问题类型。 允许值：`Split Error`。 |
| `dividend-error` | `string` | 未列为必填 | 报告分红错误时包含此字段；至少选择一种问题类型。 允许值：`Dividend Error`。 |
| `name-mapping-error` | `string` | 未列为必填 | 报告代码映射错误时包含此字段；至少选择一种问题类型。 允许值：`Name Mapping Error`。 |
| `content` | `string` | 是 | 问题的 HTML 描述，须给出可复现代码或关联项目及回测。 |
| `select-project` | `integer` | 未列为必填 | 关联的本人项目 ID，便于数据团队查看复现代码。 |
| `select-backtest` | `string` | 未列为必填 | 关联项目内的回测 ID；依赖 select-project。 |


```python
# 中文注释版：此片段仅用于说明接口，没有自动执行。
import requests

# 使用身份验证页的 get_headers；请求字段名须保持英文。
payload = {'ticker': '<按字段表填写>',
 'security': 'Equity',
 'market': '<按字段表填写>',
 'resolution': 'Tick',
 'from-date': '<按字段表填写>',
 'to-date': '<按字段表填写>',
 'content': '<p>替换为实际问题说明和最小复现代码</p>',
 'missing-points': 'Missing Points'}

# 此接口会公开提交问题；只有核实复现材料后才手动调用。
response = requests.post(
    "https://www.quantconnect.com/api/v2/community/data-library/issues/create",
    headers=get_headers(), json=payload, timeout=30
)
# 分别检查 HTTP 错误和 API 业务状态。
response.raise_for_status()
result = response.json()
if not result.get("success", False):
    raise RuntimeError(result.get("errors", "接口未成功"))
# 成功后用 discussionId 定位新报告，不代表数据已经修复。
issue_id = result.get("discussionId")
```



## 响应 · 04 Responses

### HTTP 200

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `discussionId` | `integer` | 未列为必填 | 问题 ID；详情地址为 https://www.quantconnect.com/datasets/issue/{discussionId}。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


### HTTP 401

认证失败：检查 API 凭据、签名和时间戳。



## 示例 · 99 Examples

上方提供中文注释版最小示例。官方示例的原始代码及其引用资源保留在本节相关链接中。
