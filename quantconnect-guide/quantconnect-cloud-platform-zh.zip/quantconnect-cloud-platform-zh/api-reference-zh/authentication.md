# 身份验证 · Authentication

## 简介 · Introduction

API 基础地址是 `https://www.quantconnect.com/api/v2`。使用账号 User ID 和 API Token 生成每次请求的认证头。可以在 My Account > Security 请求邮件发送 Token 和用户 ID；组织 ID 可在 Organization > Home 的网址查看。

本页代码是依据原文流程整理的中文示例，未发出实际请求。凭据通过环境变量读取，不将真实值写进示例。

## 认证请求 · Authenticating Requests

把 `API_TOKEN:当前Unix秒数` 做 SHA-256，再将 `用户ID:哈希值` 做 Base64。Authorization 使用 Basic，另带 Timestamp。Base64 是认证格式，不是加密；应使用 HTTPS。

```python
# 中文注释版：为每次请求生成新时间戳和认证头。
from os import environ
from base64 import b64encode
from hashlib import sha256
from time import time

# 先在自己的安全环境配置这两个变量；缺失时直接报错，不使用假凭据。
USER_ID = environ['QC_USER_ID']
API_TOKEN = environ['QC_API_TOKEN']


def get_headers():
    # 使用 Unix 秒数；客户端系统时间需与服务端相近。
    timestamp = str(int(time()))
    # 哈希输入顺序是 Token:Timestamp，不是 UserID:Token。
    token_with_time = f'{API_TOKEN}:{timestamp}'.encode('utf-8')
    hashed_token = sha256(token_with_time).hexdigest()
    # 将 UserID:哈希 的 UTF-8 字节转成 Basic 认证需要的 Base64 字符串。
    encoded = b64encode(f'{USER_ID}:{hashed_token}'.encode('utf-8')).decode('ascii')
    return {'Authorization': f'Basic {encoded}', 'Timestamp': timestamp}
```

每次调用重新执行 get_headers，不要长时间复用旧的 Timestamp。不要向日志输出 Token 或完整认证头。原文还提供 C#、cURL 和 PowerShell 实现，对应链接保留在下方。

## 认证状态请求 · Authenticated State Request

`POST /authenticate` 不需要业务参数，需有认证头。下面调用只检查认证，不会创建项目：

```python
# 中文注释版：本片段使用上文的 get_headers 函数。
import requests

# 使用空 JSON 请求体，认证信息放在 HTTPS 请求头。
response = requests.post(
    'https://www.quantconnect.com/api/v2/authenticate',
    headers=get_headers(),
    json={},
    timeout=30
)
# 先检查 HTTP 层失败，再读取 API JSON，二者不能混为一谈。
response.raise_for_status()
result = response.json()
# 仅输出成功标志，不输出认证头或凭据。
print(result.get('success'))
```

## 认证状态响应 · Authenticated State Responses

原文成功状态为 HTTP 200，JSON 中 `success` 为布尔值。HTTP 401 可能是凭据缺失、无效，或时间戳过旧；响应模型含 `www_authenticate`。

下方仅为结构示意，并非本次实际响应：

```json
{"success": true}
```

JSON 不支持注释，字段含义放在正文。HTTP 成功不表示每个业务请求都成功，其他接口还需检查 success 和 errors。
