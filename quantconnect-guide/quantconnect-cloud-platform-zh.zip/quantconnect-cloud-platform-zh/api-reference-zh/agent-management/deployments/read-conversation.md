# 读取对话 · Read Conversation

对照官方原有小节和 OpenAPI 整理。示例仅为说明，未执行平台请求。

## 简介 · 01 Introduction

读取部署及指定 callable 的对话记录，包括消息片段、工具输入输出与 token 统计。

## 请求与代码说明 · 02 Request

### POST `/agents/deployments/conversation/read`

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `deploymentId` | `string` | 是 | 智能体部署 ID。 |
| `callableId` | `string` | 未列为必填 | 要读取对话的 callable 标识符。 |


[完整中文模型词典](../../remaining-models.html)

```python
# 中文注释版：仅演示字段及调用过程，不会在文档生成时执行。
import requests

# ID 和文本需要替换；get_headers 见身份验证页。
payload = {'deploymentId': '<替换自己的部署 ID>'}

# 本接口的具体效果见简介；创建、更新、删除或部署会更改平台状态。
response = requests.post(
    "https://www.quantconnect.com/api/v2/agents/deployments/conversation/read",
    headers=get_headers(), json=payload, timeout=30
)
# 先检查 HTTP 状态，再检查所属接口的业务状态。
response.raise_for_status()
result = response.json()
if not result.get("success", False):
    raise RuntimeError(result.get("errors", "接口未成功"))
# 在相应字段读取智能体、任务、部署或工单，不打印令牌。
```


## 响应 · 03 Responses

### HTTP 200

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `conversation` | `AgentConversation` | 未列为必填 | 部署的完整对话及元数据。 |


### HTTP 401

身份验证失败；核对 API Key、签名和时间戳。



## 示例 · 99 Examples

本页请求小节提供附中文注释的最小示例。完整官方示例及其相关资源见本节保留的原文链接；不要把批量示例直接用于真实账号。
