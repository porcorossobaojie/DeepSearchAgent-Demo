# 创建智能体 · Create Agent

对照官方原有小节和 OpenAPI 整理。示例仅为说明，未执行平台请求。

## 简介 · 01 Introduction

在指定组织下创建智能体。可配置模型、系统提示、工具、执行链、子智能体和模型服务令牌；仅填写与你的实际需求对应的可选项。

## 请求与代码说明 · 02 Request

### POST `/agents/create`

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `organizationId` | `string` | 是 | 目标组织 ID。 |
| `name` | `string` | 是 | 智能体、任务或文件名称，按所属模型区分。 |
| `description` | `string` | 未列为必填 | 智能体简要描述。 |
| `profileImage` | `string` | 未列为必填 | 智能体头像文件名。 |
| `systemPrompt` | `string` | 未列为必填 | 定义智能体行为的系统提示词。 |
| `reasoningEffort` | `string` | 未列为必填 | 底层模型使用的推理强度。 允许值：`low`, `medium`, `high`。 |
| `maxTurns` | `integer` | 未列为必填 | 一次部署最多允许的智能体轮次。 |
| `toolChoice` | `string` | 未列为必填 | 工具选择策略。 |
| `tools` | `array[string]` | 未列为必填 | 可使用的工具标识符列表。 |
| `public` | `boolean` | 未列为必填 | 是否在组织内公开分享该智能体。 |
| `model` | `string` | 未列为必填 | 使用的模型标识符。 |
| `chainedAgents` | `array[AgentChainedEntry]` | 未列为必填 | 依次接续运行的智能体列表。 |
| `subAgents` | `array[AgentSubAgentEntry]` | 未列为必填 | 该智能体可调用的子智能体列表。 |
| `token` | `AgentToken` | 未列为必填 | 模型提供商令牌配置对象，含令牌及提供商标识。 |
| `useQCC` | `boolean` | 未列为必填 | 是否使用 QuantConnect Cloud 的模型服务；false 时需要用户令牌。 |
| `pipeline` | `string` | 未列为必填 | 分配给智能体的流水线。 |
| `author` | `AgentTaskOwner` | 未列为必填 | 作者信息对象。 |
| `organization` | `AgentOrganization` | 未列为必填 | 所属组织对象。 |
| `node` | `AgentNode` | 未列为必填 | 智能体的计算节点信息。 |


[完整中文模型词典](../../remaining-models.html)

```python
# 中文注释版：仅演示字段及调用过程，不会在文档生成时执行。
import requests

# ID 和文本需要替换；get_headers 见身份验证页。
payload = {'organizationId': '<替换自己的组织 ID>', 'name': '<按字段表填写>'}

# 本接口的具体效果见简介；创建、更新、删除或部署会更改平台状态。
response = requests.post(
    "https://www.quantconnect.com/api/v2/agents/create",
    headers=get_headers(), json=payload, timeout=30
)
# 先检查 HTTP 状态，再检查所属接口的业务状态。
response.raise_for_status()
result = response.json()
if not result.get("success", False):
    raise RuntimeError(result.get("errors", "接口未成功"))
# 在相应字段读取智能体、任务、部署或工单，不打印令牌。
```


## 响应 · 03 Responses

### HTTP 200

| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


| 字段 | 类型 | 必填 | 中文说明 |
| --- | --- | --- | --- |
| `agent` | `Agent` | 未列为必填 | 展开后的智能体定义。 |


### HTTP 401

身份验证失败；核对 API Key、签名和时间戳。



## 示例 · 99 Examples

本页请求小节提供附中文注释的最小示例。完整官方示例及其相关资源见本节保留的原文链接；不要把批量示例直接用于真实账号。
