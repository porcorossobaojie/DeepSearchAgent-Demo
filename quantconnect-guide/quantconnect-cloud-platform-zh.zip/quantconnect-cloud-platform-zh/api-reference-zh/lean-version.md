# LEAN 版本 · Lean Version

## 简介 · Introduction

读取可用 LEAN 版本的基本信息，用于了解版本 ID、分支引用和提交哈希。

## 请求 · Request

接口为 `POST /lean/versions/read`。所读定义没有业务请求字段，但仍需认证。

**方法与路径：`POST /lean/versions/read`**

读取版本列表，不会为项目切换版本。

### 请求字段

定义未列出业务请求体；仍需要身份验证。

嵌套类型及响应对象的中文字段解释见 [共享模型词典](models.html)。字段名、类型、必填和枚举依据仓库 OpenAPI，不根据示例猜测。

### 带注释的 Python 调用

以下是按定义整理的最小调用示意，不是官方示例逐字复制，也没有实际执行。先使用身份验证页的 `get_headers`；替换示例 ID，并检查当前组织与权限。

```python
# 中文注释版：get_headers 来自身份验证章节；此片段需 requests。
import requests

# 只展示请求结构；ID 和文件内容要换成自己确认的目标。
payload = {}

# 每次重新生成认证头，避免使用过期时间戳。
response = requests.post(
    "https://www.quantconnect.com/api/v2/lean/versions/read",
    headers=get_headers(),
    json=payload,
    timeout=30
)
# HTTP 失败先抛出；HTTP 200 仍需继续检查业务 success。
response.raise_for_status()
result = response.json()
if not result.get("success", False):
    raise RuntimeError(result.get("errors", "API 未返回成功状态"))
# result 的字段含义见下方响应表；此处不打印账号或文件内容。
```

### 响应结构

#### HTTP 200

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `versions` | `array[LeanVersion]` | 未列为必填 | LEAN 版本列表。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |




## 响应 · Responses

versions 返回版本列表，字段包含 id、created、description、leanHash、leanCloudHash、name、ref、public。public 的类型和枚举应按当前定义；不要把“可读取”直接视为当前项目已切换到该版本。

## 示例 · Examples

上方调用示例演示读取列表，不会切换项目版本。实际切换需使用相应项目配置或界面。
