# 运行、优化与存储模型词典

本页覆盖本批接口引用的模型。保留技术标识符，中文描述按字段及所在模型解释；原文描述冲突已明确提示，不把字段名猜测当成已核验行为。

## AbortOptimizationRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `optimizationId` | `string` | 是 | 优化任务 ID，或所属优化的标识。 |


原文模型说明：Abort an optimization.

## AlgorithmPerformance

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `tradeStatistics` | `TradeStatistics` | 未列为必填 | 交易统计。 |
| `portfolioStatistics` | `PortfolioStatistics` | 未列为必填 | 组合统计。 |
| `closedTrades` | `array[ClosedTrade]` | 未列为必填 | 已结束交易列表。 |


原文模型说明：The AlgorithmPerformance class is a wrapper for TradeStatistics and PortfolioStatistics.

## AnalysisResult

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `name` | `string` | 是 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `issue` | `string` | 是 | 触发分析的简短问题说明。 |
| `sample` | `object` | 是 | 分析问题的代表性样本值，不应当作可自由导出的数据许可。 |
| `count` | `integer` | 未列为必填 | 数量；图表请求是数据点数，分析模型是出现次数。 |
| `solutions` | `array[string]` | 是 | 可读的解决建议。 |


原文模型说明：The result of an analysis performed on a result.

## BacktestInsightsResponse

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `insights` | `array[Insight]` | 未列为必填 | 投资见解数组。 |
| `length` | `integer` | 未列为必填 | 返回记录数量。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |


原文模型说明：Contains insights and the number of insights of the backtest in the request criteria.

## BacktestOrdersResponse

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `orders` | `array[Order]` | 未列为必填 | 订单集合。 |
| `length` | `integer` | 未列为必填 | 返回记录数量。 |


原文模型说明：Contains orders and the number of orders of the backtest in the request criteria.

## BacktestResponse

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `backtest` | `BacktestResult` | 未列为必填 | 回测结果对象。 |
| `debugging` | `boolean` | 未列为必填 | 是否以调试模式运行。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


原文模型说明：Collection container for a list of backtests for a project.

## BacktestResult

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `note` | `['string', 'null']` | 未列为必填 | 用户备注。 |
| `name` | `string` | 是 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `organizationId` | `string` | 是 | 组织 ID；创建项目未提供时按定义使用首选组织。 |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `completed` | `boolean` | 是 | 任务是否完成；完成后仍要检查错误。 |
| `optimizationId` | `['string', 'null']` | 未列为必填 | 优化任务 ID，或所属优化的标识。 |
| `backtestId` | `string` | 是 | 回测标识。 |
| `tradeableDates` | `integer` | 是 | 可交易天数。 |
| `researchGuide` | `ResearchGuide` | 未列为必填 | 研究过程与过拟合风险提示，不是有效性认证。 |
| `backtestStart` | `string (date-time)` | 是 | 回测开始时间。 |
| `backtestEnd` | `string (date-time)` | 是 | 回测结束时间。 |
| `created` | `string (date-time)` | 是 | 创建时间。 |
| `snapshotId` | `integer` | 是 | 结果快照 ID。 |
| `status` | `string` | 是 | 任务或订单状态，按当前模型枚举解释。 允许值：`Completed.`, `In Queue...`, `In Progress...`, `Runtime Error`。 |
| `error` | `['string', 'null']` | 是 | 错误信息。 |
| `stacktrace` | `['string', 'null']` | 是 | 错误堆栈。 |
| `progress` | `number (float)` | 是 | 进度，原文范围 0–1，不是 0–100。 |
| `hasInitializeError` | `boolean` | 未列为必填 | 是否在初始化阶段出错。 |
| `charts` | `object` | 是 | 图表集合或图表更新。 |
| `parameterSet` | `ParameterSet` | 是 | 当次运行采用的参数。 |
| `rollingWindow` | `object` | 未列为必填 | 滚动窗口统计。 |
| `runtimeStatistics` | `RuntimeStatistics` | 是 | 结果页顶部运行统计。 |
| `serverStatistics` | `ServerStatistics` | 未列为必填 | 运行节点统计，具体键随 LEAN 版本变化。 |
| `statistics` | `StatisticsResult` | 是 | 整体统计。 |
| `totalPerformance` | `object` | 是 | 整体表现模型。 |
| `nodeName` | `string` | 是 | 回测节点名称。 |
| `outOfSampleMaxEndDate` | `['string', 'null'] (date-time)` | 未列为必填 | 样本外范围的最大结束日期。 |
| `outOfSampleDays` | `['integer', 'null']` | 未列为必填 | 样本外天数。 |
| `analysis` | `['array', 'null']` | 未列为必填 | 引擎分析结果。 |


原文模型说明：Results object class. Results are exhaust from backtest or live algorithms running in LEAN.

## BacktestSummaryResponse

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `backtests` | `array[BacktestSummaryResult]` | 未列为必填 | 回测概要列表。 |
| `count` | `integer` | 未列为必填 | 数量；图表请求是数据点数，分析模型是出现次数。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


原文模型说明：Collection container for a list of backtest summaries for a project.

## BacktestSummaryResult

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `backtestId` | `string` | 是 | 回测标识。 |
| `status` | `string` | 是 | 任务或订单状态，按当前模型枚举解释。 允许值：`Completed.`, `In Queue...`, `In Progress...`, `Runtime Error`。 |
| `name` | `string` | 是 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `created` | `string (date-time)` | 是 | 创建时间。 |
| `progress` | `number (float)` | 是 | 进度，原文范围 0–1，不是 0–100。 |
| `optimizationId` | `['string', 'null']` | 未列为必填 | 优化任务 ID，或所属优化的标识。 |
| `tradeableDates` | `integer` | 是 | 可交易天数。 |
| `parameterSet` | `ParameterSet` | 是 | 当次运行采用的参数。 |
| `snapshotId` | `integer` | 是 | 结果快照 ID。 |
| `tags` | `array[string]` | 未列为必填 | 回测标签数组。 |
| `sharpeRatio` | `['number', 'null']` | 未列为必填 | 夏普比率，计算口径按该模型。 |
| `alpha` | `['number', 'null']` | 未列为必填 | 阿尔法。 |
| `beta` | `['number', 'null']` | 未列为必填 | 贝塔。 |
| `compoundingAnnualReturn` | `['number', 'null']` | 未列为必填 | 复合年化收益率。 |
| `drawdown` | `['number', 'null']` | 未列为必填 | 最大回撤。 |
| `lossRate` | `['number', 'null']` | 未列为必填 | 亏损率。 |
| `netProfit` | `['number', 'null']` | 未列为必填 | 净收益比例。 |
| `parameters` | `integer` | 未列为必填 | 参数列表；项目配置值与编译检测结果应按模型区分。 |
| `psr` | `['number', 'null']` | 未列为必填 | 该字段原文写作 Price-to-sales ratio，与其他页面的概率夏普 PSR 不一致，未擅自确定实际口径。 |
| `securityTypes` | `integer` | 未列为必填 | 涉及的资产类型数量。 |
| `sortinoRatio` | `['number', 'null']` | 未列为必填 | 索提诺比率，计算口径按该模型。 |
| `trades` | `['integer', 'null']` | 未列为必填 | 交易数量或交易集合，按模型类型区分。 |
| `treynorRatio` | `['number', 'null']` | 未列为必填 | 特雷诺比率。 |
| `winRate` | `['number', 'null']` | 未列为必填 | 胜率。 |


原文模型说明：Result object class for the List Backtest response from the API.

## BacktestTradesResponse

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `trades` | `array[ClosedTradeWithOrders]` | 未列为必填 | 交易数量或交易集合，按模型类型区分。 |
| `length` | `integer` | 未列为必填 | 返回记录数量。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


原文模型说明：Contains the closed trades and the number of closed trades of the backtest in the request criteria.

## Chart

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `name` | `string` | 未列为必填 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `chartType` | `integer` | 未列为必填 | 图类型，按 Overlayed/Stacked 枚举。 允许值：`0`, `1`。 |
| `series` | `object` | 未列为必填 | 图表序列。 |


原文模型说明：Single Parent Chart Object for Custom Charting.

## ClosedTrade

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `id` | `string` | 未列为必填 | 该模型对象的标识符，类型与含义见当前模型。 |
| `symbols` | `array[Symbol]` | 未列为必填 | 交易涉及的标的。 |
| `entryTime` | `string (date-time)` | 未列为必填 | 进入交易时间。 |
| `entryPrice` | `number (float)` | 未列为必填 | 进入价格，多次进入时可能为均价。 |
| `direction` | `integer` | 未列为必填 | 方向枚举，订单 Buy/Sell 与交易 Long/Short 不是同一语义。 允许值：`0`, `1`。 |
| `quantity` | `number (float)` | 未列为必填 | 交易或订单数量；正负及绝对值口径按模型。 |
| `exitTime` | `string (date-time)` | 未列为必填 | 退出交易时间。 |
| `exitPrice` | `number (float)` | 未列为必填 | 退出价格或均价。 |
| `profitLoss` | `number (float)` | 未列为必填 | 该笔毛盈亏。 |
| `totalFees` | `number (float)` | 未列为必填 | 交易费用总额。 |
| `mae` | `number (float)` | 未列为必填 | 最大不利变动。 |
| `mfe` | `number (float)` | 未列为必填 | 最大有利变动。 |
| `duration` | `string` | 未列为必填 | 交易持续时间。 |
| `endTradeDrawdown` | `number (float)` | 未列为必填 | 退出前回吐利润。 |
| `isWin` | `boolean` | 未列为必填 | 是否盈利结束。 |
| `orderIds` | `array[integer]` | 未列为必填 | 组成该交易的订单 ID。 |


原文模型说明：Represents a closed trade of a backtest or a live algorithm.

## ClosedTradeWithOrders

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `id` | `string` | 未列为必填 | 该模型对象的标识符，类型与含义见当前模型。 |
| `symbols` | `array[Symbol]` | 未列为必填 | 交易涉及的标的。 |
| `entryTime` | `string (date-time)` | 未列为必填 | 进入交易时间。 |
| `entryPrice` | `number (float)` | 未列为必填 | 进入价格，多次进入时可能为均价。 |
| `direction` | `integer` | 未列为必填 | 方向枚举，订单 Buy/Sell 与交易 Long/Short 不是同一语义。 允许值：`0`, `1`。 |
| `quantity` | `number (float)` | 未列为必填 | 交易或订单数量；正负及绝对值口径按模型。 |
| `exitTime` | `string (date-time)` | 未列为必填 | 退出交易时间。 |
| `exitPrice` | `number (float)` | 未列为必填 | 退出价格或均价。 |
| `profitLoss` | `number (float)` | 未列为必填 | 该笔毛盈亏。 |
| `totalFees` | `number (float)` | 未列为必填 | 交易费用总额。 |
| `mae` | `number (float)` | 未列为必填 | 最大不利变动。 |
| `mfe` | `number (float)` | 未列为必填 | 最大有利变动。 |
| `duration` | `string` | 未列为必填 | 交易持续时间。 |
| `endTradeDrawdown` | `number (float)` | 未列为必填 | 退出前回吐利润。 |
| `isWin` | `boolean` | 未列为必填 | 是否盈利结束。 |
| `orderIds` | `array[integer]` | 未列为必填 | 组成该交易的订单 ID。 |
| `orders` | `array[Order]` | 未列为必填 | 订单集合。 |


原文模型说明：Represents a closed trade of a backtest or a live algorithm, with the orders that opened and closed it.

## CreateBacktestRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `compileId` | `string` | 是 | 编译任务 ID；创建任务后用它查询状态。 |
| `backtestName` | `string` | 是 | 新回测名称。 |
| `parameters` | `object` | 未列为必填 | 参数列表；项目配置值与编译检测结果应按模型区分。 |


原文模型说明：Request to create a new backtest.

## CreateOptimizationRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `name` | `string` | 是 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `target` | `OptimizationTargetStatistic` | 是 | 优化目标统计。 允许值：`TotalPerformance.PortfolioStatistics.SharpeRatio`, `TotalPerformance.PortfolioStatistics.CompoundingAnnualReturn`, `TotalPerformance.PortfolioStatistics.ProbabilisticSharpeRatio`, `TotalPerformance.PortfolioStatistics.Drawdown`。 |
| `targetTo` | `OptimizationTargetTo` | 是 | 目标方向 min/max。 允许值：`min`, `max`。 |
| `targetValue` | `number` | 未列为必填 | 期望目标值。 |
| `strategy` | `OptimizationStrategy` | 是 | 优化搜索策略类名。 允许值：`QuantConnect.Optimizer.Strategies.GridSearchOptimizationStrategy`。 |
| `compileId` | `string` | 是 | 编译任务 ID；创建任务后用它查询状态。 |
| `parameters` | `array[OptimizationParameter]` | 是 | 参数列表；项目配置值与编译检测结果应按模型区分。 |
| `constraints` | `array[OptimizationConstraint]` | 未列为必填 | 优化约束。 |
| `estimatedCost` | `number` | 是 | 优化估算成本。 |
| `nodeType` | `OptimizationNodeType` | 是 | 优化节点型号。 允许值：`O2-8`, `O4-12`, `O8-16`。 |
| `parallelNodes` | `integer` | 是 | 并行节点数。 |


原文模型说明：Request to create an optimization job.

## CreateOptimizationResponse

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `optimizationId` | `string` | 未列为必填 | 优化任务 ID，或所属优化的标识。 |
| `projectId` | `integer` | 未列为必填 | 目标项目 ID。 |
| `name` | `string` | 未列为必填 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `status` | `OptimizationStatus` | 未列为必填 | 任务或订单状态，按当前模型枚举解释。 允许值：`new`, `aborted`, `running`, `completed`。 |
| `nodeType` | `OptimizationNodeType` | 未列为必填 | 优化节点型号。 允许值：`O2-8`, `O4-12`, `O8-16`。 |
| `criterion` | `OptimizationTarget` | 未列为必填 | 目标统计。 |
| `created` | `string (date-time)` | 未列为必填 | 创建时间。 |
| `psr` | `['number', 'null']` | 未列为必填 | 该字段原文写作 Price-to-sales ratio，与其他页面的概率夏普 PSR 不一致，未擅自确定实际口径。 |
| `sharpeRatio` | `['number', 'null']` | 未列为必填 | 夏普比率，计算口径按该模型。 |
| `trades` | `['integer', 'null']` | 未列为必填 | 交易数量或交易集合，按模型类型区分。 |
| `cloneId` | `integer` | 未列为必填 | 原始被克隆项目 ID。 |
| `outOfSampleDays` | `integer` | 未列为必填 | 样本外天数。 |
| `outOfSampleMaxEndDate` | `string (date-time)` | 未列为必填 | 样本外范围的最大结束日期。 |
| `parameters` | `array[OptimizationParameter]` | 未列为必填 | 参数列表；项目配置值与编译检测结果应按模型区分。 |


原文模型说明：Response received when launching an optimization job or listing all the optimization jobs of a project.

## DeleteBacktestRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `backtestId` | `string` | 是 | 回测标识。 |


原文模型说明：Request to delete a backtest.

## DeleteObjectStoreRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `organizationId` | `string` | 是 | 组织 ID；创建项目未提供时按定义使用首选组织。 |
| `key` | `string` | 是 | 对象存储唯一键。 |


原文模型说明：Request to delete an object in the Object Store for a specific organization and key.

## DeleteOptimizationRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `optimizationId` | `string` | 是 | 优化任务 ID，或所属优化的标识。 |


原文模型说明：Delete an optimization.

## Estimate

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `estimateId` | `string` | 未列为必填 | 估算 ID。 |
| `time` | `integer` | 未列为必填 | 订单创建 UTC 时间。 |
| `balance` | `integer` | 未列为必填 | 组织 QCC 余额。 |


原文模型说明：Response received when estimating the time to run an optimization job.

## EstimateOptimizationRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `name` | `string` | 是 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `target` | `OptimizationTargetStatistic` | 是 | 优化目标统计。 允许值：`TotalPerformance.PortfolioStatistics.SharpeRatio`, `TotalPerformance.PortfolioStatistics.CompoundingAnnualReturn`, `TotalPerformance.PortfolioStatistics.ProbabilisticSharpeRatio`, `TotalPerformance.PortfolioStatistics.Drawdown`。 |
| `targetTo` | `OptimizationTargetTo` | 是 | 目标方向 min/max。 允许值：`min`, `max`。 |
| `targetValue` | `number` | 未列为必填 | 期望目标值。 |
| `strategy` | `OptimizationStrategy` | 是 | 优化搜索策略类名。 允许值：`QuantConnect.Optimizer.Strategies.GridSearchOptimizationStrategy`。 |
| `compileId` | `string` | 未列为必填 | 编译任务 ID；创建任务后用它查询状态。 |
| `parameters` | `array[OptimizationParameter]` | 是 | 参数列表；项目配置值与编译检测结果应按模型区分。 |
| `constraints` | `array[OptimizationConstraint]` | 未列为必填 | 优化约束。 |


原文模型说明：Request to estimate the cost of an optimization job.

## EstimateOptimizationResponse

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `estimate` | `Estimate` | 未列为必填 | 估算结果。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


原文模型说明：Response received when estimating the cost of an optimization.

## ExportBacktestOrdersRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `backtestId` | `string` | 是 | 回测标识。 |


原文模型说明：Request to download the orders of a backtest.

## ExportBacktestTradesRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `backtestId` | `string` | 是 | 回测标识。 |


原文模型说明：Request to download the closed trades of a backtest.

## GetObjectStoreJobIdRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `organizationId` | `string` | 是 | 组织 ID；创建项目未提供时按定义使用首选组织。 |
| `keys` | `array[string]` | 是 | 要下载的存储键数组。 |


原文模型说明：Request to create a download job for some Object Store files.

## GetObjectStorePropertiesRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `organizationId` | `string` | 是 | 组织 ID；创建项目未提供时按定义使用首选组织。 |
| `key` | `string` | 是 | 对象存储唯一键。 |


原文模型说明：Request to get Object Store properties of a specific organization and key.

## GetObjectStorePropertiesResponse

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `metadata` | `ObjectStoreProperties` | 未列为必填 | 存储属性。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


原文模型说明：Response received when fetching Object Store file properties.

## GetObjectStoreResponse

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `jobId` | `string` | 未列为必填 | 异步下载任务 ID。 |
| `url` | `string` | 未列为必填 | 下载链接，可能为空；使用时须保留完整查询参数。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


原文模型说明：Response received when fetching an Object Store file.

## GetObjectStoreURLRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `organizationId` | `string` | 是 | 组织 ID；创建项目未提供时按定义使用首选组织。 |
| `jobId` | `string` | 是 | 异步下载任务 ID。 |


原文模型说明：Request to get a download URL for some Object Store files.

## GridChart

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `chartName` | `string` | 是 | 图表名称。 |
| `width` | `integer` | 是 | 图表宽度。 |
| `height` | `integer` | 是 | 图表高度。 |
| `row` | `integer` | 是 | 布局行。 |
| `column` | `integer` | 是 | 布局列。 |
| `sort` | `integer` | 未列为必填 | 排序信息。 |
| `definition` | `array[string]` | 未列为必填 | 图表定义标签。 |


原文模型说明：The chart display properties.

## GroupOrderManager

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `id` | `integer` | 未列为必填 | 该模型对象的标识符，类型与含义见当前模型。 |
| `quantity` | `number` | 未列为必填 | 交易或订单数量；正负及绝对值口径按模型。 |
| `count` | `integer` | 未列为必填 | 数量；图表请求是数据点数，分析模型是出现次数。 |
| `limitPrice` | `number` | 未列为必填 | 限价。 |
| `orderIds` | `array[integer]` | 未列为必填 | 组成该交易的订单 ID。 |
| `direction` | `integer` | 未列为必填 | 方向枚举，订单 Buy/Sell 与交易 Long/Short 不是同一语义。 |


原文模型说明：Manager of a group of orders.

## Insight

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `id` | `string` | 未列为必填 | 该模型对象的标识符，类型与含义见当前模型。 |
| `groupId` | `string` | 未列为必填 | 见解分组 ID。 |
| `sourceModel` | `string` | 未列为必填 | 见解来源模型标识。 |
| `generatedTime` | `integer (unix-time)` | 未列为必填 | 见解生成 Unix 时间。 |
| `closeTime` | `integer (unix-time)` | 未列为必填 | 见解结束 Unix 时间。 |
| `symbol` | `string` | 未列为必填 | 标的标识。 |
| `ticker` | `string` | 未列为必填 | 显示代码。 |
| `type` | `string` | 未列为必填 | 订单类型或其他模型类型，按当前枚举解释。 允许值：`price`, `volatility`。 |
| `reference` | `number` | 未列为必填 | 见解产生时的参考值。 |
| `referenceFinal` | `number` | 未列为必填 | 用于最终评分的参考值。 |
| `direction` | `string` | 未列为必填 | 方向枚举，订单 Buy/Sell 与交易 Long/Short 不是同一语义。 允许值：`down`, `flat`, `up`。 |
| `period` | `integer` | 未列为必填 | 预测持续时长，秒。 |
| `magnitude` | `number (float)` | 未列为必填 | 预期变化幅度，可为空。 |
| `confidence` | `number (float)` | 未列为必填 | 置信度，可为空。 |
| `weight` | `number (float)` | 未列为必填 | 组合权重，可为空。 |
| `scoreFinal` | `boolean` | 未列为必填 | 是否为最终评分。 |
| `scoreDirection` | `number` | 未列为必填 | 方向得分。 |
| `scoreMagnitude` | `number` | 未列为必填 | 幅度得分。 |
| `estimatedValue` | `number` | 未列为必填 | 估计价值，账户货币。 |
| `tag` | `string` | 未列为必填 | 订单自定义标签。 |


原文模型说明：Insight struct for emitting new prediction.

## ListBacktestRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `includeStatistics` | `boolean` | 未列为必填 | 列表是否附统计。 |


原文模型说明：Request to list the backtests from a project.

## ListObjectStoreRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `organizationId` | `string` | 是 | 组织 ID；创建项目未提供时按定义使用首选组织。 |
| `path` | `string` | 未列为必填 | 对象存储目录路径。 |


原文模型说明：Request to list the Object Store files under a specific directory in an organization.

## ListObjectStoreResponse

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `path` | `string` | 未列为必填 | 对象存储目录路径。 |
| `objects` | `array[ObjectStoreSummary]` | 未列为必填 | 当前目录的对象列表，不递归展开子目录。 |
| `page` | `integer` | 未列为必填 | 分页页码。 |
| `totalPages` | `integer` | 未列为必填 | 总页数。 |
| `objectStorageUsed` | `integer` | 未列为必填 | 全部存储已用字节数。 |
| `objectStorageUsedHuman` | `string` | 未列为必填 | 便于阅读的已用容量文本。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


原文模型说明：Response received containing a list of stored objects metadata, as well as the total size of all of them.

## ListOptimizationRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |


原文模型说明：Id of the Project to get a list of optimizations for.

## ListOptimizationResponse

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `optimizations` | `array[CreateOptimizationResponse]` | 未列为必填 | 优化概要列表。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


原文模型说明：Response received when creating an optimization or listing optimizations of a project.

## LoadingResponse

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `progress` | `number` | 未列为必填 | 进度，原文范围 0–1，不是 0–100。 |
| `status` | `string` | 未列为必填 | 任务或订单状态，按当前模型枚举解释。 允许值：`loading`。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |


原文模型说明：Response when the requested chart or orders are being generated.

## ObjectStoreBinaryFile

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `organizationId` | `string` | 是 | 组织 ID；创建项目未提供时按定义使用首选组织。 |
| `key` | `string` | 是 | 对象存储唯一键。 |
| `objectData` | `string (binary)` | 是 | multipart 上传的二进制文件，不是 JSON 字符串。 |


原文模型说明：Represents a binary file we we'd like to upload the file to upload to the Object Store.

## ObjectStoreProperties

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `key` | `string` | 未列为必填 | 对象存储唯一键。 |
| `modified` | `string (date-time)` | 未列为必填 | 最近修改时间。 |
| `created` | `string (date-time)` | 未列为必填 | 创建时间。 |
| `size` | `number` | 未列为必填 | 文件大小，单位见具体模型。 |
| `md5` | `string` | 未列为必填 | 文件 MD5 校验标识。 |
| `mime` | `string` | 未列为必填 | MIME 类型。 |
| `preview` | `string` | 未列为必填 | 文件预览。 |


原文模型说明：Object Store file properties.

## ObjectStoreSummary

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `key` | `string` | 未列为必填 | 对象存储唯一键。 |
| `name` | `string` | 未列为必填 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `modified` | `string (date-time)` | 未列为必填 | 最近修改时间。 |
| `mime` | `string` | 未列为必填 | MIME 类型。 |
| `folder` | `boolean` | 未列为必填 | 是否目录。 |
| `size` | `number` | 未列为必填 | 文件大小，单位见具体模型。 |


原文模型说明：Summary information of the Object Store.

## Optimization

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `optimizationId` | `string` | 是 | 优化任务 ID，或所属优化的标识。 |
| `snapshotId` | `integer` | 是 | 结果快照 ID。 |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `name` | `string` | 是 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `extremum` | `OptimizationTargetTo` | 未列为必填 | 优化方向。 允许值：`min`, `max`。 |
| `status` | `OptimizationStatus` | 是 | 任务或订单状态，按当前模型枚举解释。 允许值：`new`, `aborted`, `running`, `completed`。 |
| `nodeType` | `OptimizationNodeType` | 是 | 优化节点型号。 允许值：`O2-8`, `O4-12`, `O8-16`。 |
| `parallelNodes` | `integer` | 未列为必填 | 并行节点数。 |
| `criterion` | `OptimizationTarget` | 是 | 目标统计。 |
| `runtimeStatistics` | `OptimizationRuntimeStatistics` | 未列为必填 | 结果页顶部运行统计。 |
| `constraints` | `array[OptimizationConstraint]` | 未列为必填 | 优化约束。 |
| `parameters` | `array[OptimizationParameter]` | 是 | 参数列表；项目配置值与编译检测结果应按模型区分。 |
| `backtests` | `object` | 未列为必填 | 回测概要列表。 |
| `strategy` | `OptimizationStrategy` | 未列为必填 | 优化搜索策略类名。 允许值：`QuantConnect.Optimizer.Strategies.GridSearchOptimizationStrategy`。 |
| `requested` | `string (date-time)` | 未列为必填 | 任务请求时间。 |
| `optimizationTarget` | `OptimizationTargetStatistic` | 未列为必填 | 正在优化的统计。 允许值：`TotalPerformance.PortfolioStatistics.SharpeRatio`, `TotalPerformance.PortfolioStatistics.CompoundingAnnualReturn`, `TotalPerformance.PortfolioStatistics.ProbabilisticSharpeRatio`, `TotalPerformance.PortfolioStatistics.Drawdown`。 |
| `targetValue` | `['number', 'null']` | 未列为必填 | 期望目标值。 |
| `gridLayout` | `array[GridChart]` | 未列为必填 | 参数图布局。 |
| `outOfSampleMaxEndDate` | `string (date-time)` | 是 | 样本外范围的最大结束日期。 |
| `outOfSampleDays` | `integer` | 是 | 样本外天数。 |
| `created` | `string (date-time)` | 是 | 创建时间。 |
| `psr` | `['number', 'null']` | 是 | 该字段原文写作 Price-to-sales ratio，与其他页面的概率夏普 PSR 不一致，未擅自确定实际口径。 |
| `sharpeRatio` | `['number', 'null']` | 是 | 夏普比率，计算口径按该模型。 |
| `trades` | `['integer', 'null']` | 是 | 交易数量或交易集合，按模型类型区分。 |
| `cloneId` | `integer` | 是 | 原始被克隆项目 ID。 |


原文模型说明：Response received when reading an optimization job.

## OptimizationConstraint

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `target` | `OptimizationTargetStatistic` | 是 | 优化目标统计。 允许值：`TotalPerformance.PortfolioStatistics.SharpeRatio`, `TotalPerformance.PortfolioStatistics.CompoundingAnnualReturn`, `TotalPerformance.PortfolioStatistics.ProbabilisticSharpeRatio`, `TotalPerformance.PortfolioStatistics.Drawdown`。 |
| `operator` | `string` | 是 | 比较运算符。 允许值：`LessOrEqual`, `Less`, `GreaterOrEqual`, `Greater`, `NotEqual`, `Equals`。 |
| `targetValue` | `number` | 是 | 期望目标值。 |


原文模型说明：Backtests in the optimization job that don't respect this constraint are excluded from the optimization result.

## OptimizationNodeType

类型：`string`。允许值：`O2-8`, `O4-12`, `O8-16`。


原文模型说明：Optimization node types available in QuantConnect Cloud.

## OptimizationParameter

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `name` | `string` | 是 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `min` | `number` | 是 | 候选最小值。 |
| `max` | `number` | 是 | 候选最大值。 |
| `step` | `number` | 是 | 正数步长。 |
| `minStep` | `number` | 未列为必填 | 某些策略的最小步长；字段说明提到 Euler，但当前策略枚举只列网格搜索，不代表已开放 Euler。 |


## OptimizationRuntimeStatistics

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `Completed` | `string` | 未列为必填 | 完成回测数。 |
| `Failed` | `string` | 未列为必填 | 失败数。 |
| `Running` | `string` | 未列为必填 | 运行中数量。 |
| `In Queue` | `string` | 未列为必填 | 排队数。 |
| `Average Length` | `string (time)` | 未列为必填 | 单次平均耗时 HH:MM:SS。 |
| `Total Runtime` | `string (time)` | 未列为必填 | 总耗时 HH:MM:SS。 |
| `Total` | `string` | 未列为必填 | 总回测数。 |
| `Consumed` | `string` | 未列为必填 | 消耗 QCC。 |


## OptimizationStatus

类型：`object`。允许值：`new`, `aborted`, `running`, `completed`。


原文模型说明：Status of the optimization job.

## OptimizationStrategy

类型：`string`。允许值：`QuantConnect.Optimizer.Strategies.GridSearchOptimizationStrategy`。


## OptimizationTarget

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `target` | `OptimizationTargetStatistic` | 未列为必填 | 优化目标统计。 允许值：`TotalPerformance.PortfolioStatistics.SharpeRatio`, `TotalPerformance.PortfolioStatistics.CompoundingAnnualReturn`, `TotalPerformance.PortfolioStatistics.ProbabilisticSharpeRatio`, `TotalPerformance.PortfolioStatistics.Drawdown`。 |
| `extremum` | `OptimizationTargetTo` | 未列为必填 | 优化方向。 允许值：`min`, `max`。 |
| `targetValue` | `['number', 'null']` | 未列为必填 | 期望目标值。 |


## OptimizationTargetStatistic

类型：`string`。允许值：`TotalPerformance.PortfolioStatistics.SharpeRatio`, `TotalPerformance.PortfolioStatistics.CompoundingAnnualReturn`, `TotalPerformance.PortfolioStatistics.ProbabilisticSharpeRatio`, `TotalPerformance.PortfolioStatistics.Drawdown`。


## OptimizationTargetTo

类型：`string`。允许值：`min`, `max`。


## Order

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `id` | `integer` | 未列为必填 | 该模型对象的标识符，类型与含义见当前模型。 |
| `contingentId` | `integer` | 未列为必填 | 处理前须先处理的关联订单 ID。 |
| `brokerId` | `array[string]` | 未列为必填 | 券商订单 ID，可能拆分为多段。 |
| `symbol` | `Symbol` | 未列为必填 | 标的标识。 |
| `limitPrice` | `number` | 未列为必填 | 限价。 |
| `stopPrice` | `number` | 未列为必填 | 止损触发价。 |
| `stopTriggered` | `boolean` | 未列为必填 | 止损是否已触发。 |
| `price` | `number (float)` | 未列为必填 | 订单价格。 |
| `priceCurrency` | `string` | 未列为必填 | 订单价格币种。 |
| `time` | `string (date-time)` | 未列为必填 | 订单创建 UTC 时间。 |
| `createdTime` | `string (date-time)` | 未列为必填 | 订单创建时间，原文是 time 的别名。 |
| `lastFillTime` | `string (date-time)` | 未列为必填 | 最近成交 UTC 时间，可为空。 |
| `lastUpdateTime` | `string (date-time)` | 未列为必填 | 最近更新 UTC 时间，可为空。 |
| `canceledTime` | `string (date-time)` | 未列为必填 | 取消 UTC 时间，可为空。 |
| `quantity` | `number (float)` | 未列为必填 | 交易或订单数量；正负及绝对值口径按模型。 |
| `type` | `integer` | 未列为必填 | 订单类型或其他模型类型，按当前枚举解释。 允许值：`0`, `1`, `2`, `3`, `4`, `5`, `6`, `7`, `8`, `9`, `10`, `11`。 |
| `status` | `integer` | 未列为必填 | 任务或订单状态，按当前模型枚举解释。 允许值：`0`, `1`, `2`, `3`, `5`, `6`, `7`, `8`, `9`。 |
| `tag` | `string` | 未列为必填 | 订单自定义标签。 |
| `securityType` | `integer` | 未列为必填 | 资产类型枚举。 允许值：`0`, `1`, `2`, `3`, `4`, `5`, `6`, `7`, `8`, `9`, `10`, `11`。 |
| `direction` | `integer` | 未列为必填 | 方向枚举，订单 Buy/Sell 与交易 Long/Short 不是同一语义。 允许值：`0`, `1`, `2`。 |
| `value` | `number (float)` | 未列为必填 | 参数的值，按模型类型处理。 |
| `orderSubmissionData` | `OrderSubmissionData` | 未列为必填 | 提交时的价格信息。 |
| `isMarketable` | `boolean` | 未列为必填 | 是否可立即与市场成交。 |
| `properties` | `OrderProperties` | 未列为必填 | 订单附加属性。 |
| `events` | `array[OrderEvent]` | 未列为必填 | 订单事件。 |
| `trailingAmount` | `number` | 未列为必填 | 追踪止损距离。 |
| `trailingAsPercentage` | `boolean` | 未列为必填 | 距离是否按百分比解释。 |
| `groupOrderManager` | `GroupOrderManager` | 未列为必填 | 组合订单管理信息。 |
| `triggerPrice` | `number` | 未列为必填 | 触碰后触发限价单的价格。 |
| `triggerTouched` | `boolean` | 未列为必填 | 触发价是否已触碰。 |


原文模型说明：Order struct for placing new trade.

## OrderDirection

类型：`string`。允许值：`buy`, `sell`, `hold`。


原文模型说明：Direction of the order.

## OrderEvent

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `algorithmId` | `string` | 未列为必填 | 算法、回测或部署 ID。 |
| `symbol` | `string` | 未列为必填 | 标的标识。 |
| `symbolValue` | `string` | 未列为必填 | 当前显示代码。 |
| `symbolPermtick` | `string` | 未列为必填 | 生成标识时使用的原始代码。 |
| `orderId` | `integer` | 未列为必填 | 所属订单 ID。 |
| `orderEventId` | `integer` | 未列为必填 | 订单内唯一事件 ID。 |
| `id` | `string` | 未列为必填 | 该模型对象的标识符，类型与含义见当前模型。 |
| `status` | `string` | 未列为必填 | 任务或订单状态，按当前模型枚举解释。 允许值：`new`, `submitted`, `partiallyFilled`, `filled`, `canceled`, `none`, `invalid`, `cancelPending`, `updateSubmitted`。 |
| `orderFeeAmount` | `number` | 未列为必填 | 费用金额。 |
| `orderFeeCurrency` | `string` | 未列为必填 | 费用币种。 |
| `fillPrice` | `number (float)` | 未列为必填 | 成交价。 |
| `fillPriceCurrency` | `string` | 未列为必填 | 成交价币种。 |
| `fillQuantity` | `number (float)` | 未列为必填 | 本次事件成交数量。 |
| `direction` | `OrderDirection` | 未列为必填 | 方向枚举，订单 Buy/Sell 与交易 Long/Short 不是同一语义。 允许值：`buy`, `sell`, `hold`。 |
| `message` | `string` | 未列为必填 | 交易所或系统消息。 |
| `isAssignment` | `boolean` | 未列为必填 | 是否期权指派。 |
| `stopPrice` | `number (float)` | 未列为必填 | 止损触发价。 |
| `limitPrice` | `number (float)` | 未列为必填 | 限价。 |
| `quantity` | `number (float)` | 未列为必填 | 交易或订单数量；正负及绝对值口径按模型。 |
| `time` | `number` | 未列为必填 | 订单创建 UTC 时间。 |
| `isInTheMoney` | `boolean` | 未列为必填 | 期权是否实值。 |


原文模型说明：Change in an order state applied to user algorithm portfolio

## OrderProperties

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `timeInForce` | `object` | 未列为必填 | 订单有效期限。 |


原文模型说明：Additional properties of the order

## OrderSubmissionData

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `bidPrice` | `number (float)` | 未列为必填 | 提交时最佳买价。 |
| `askPrice` | `number (float)` | 未列为必填 | 提交时最佳卖价。 |
| `lastPrice` | `number (float)` | 未列为必填 | 提交时最新成交价。 |


原文模型说明：Stores time and price information available at the time an order was submitted.

## ParameterSet

### 请求模式 1

定义未列出固定子字段，使用前查看当前模型原文。

### 请求模式 2

定义未列出固定子字段，使用前查看当前模型原文。

## PortfolioStatistics

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `averageWinRate` | `string` | 未列为必填 | 盈利交易平均收益率。 |
| `averageLossRate` | `string` | 未列为必填 | 亏损交易平均收益率。 |
| `profitLossRatio` | `string` | 未列为必填 | 平均盈利与平均亏损比。 |
| `winRate` | `string` | 未列为必填 | 胜率。 |
| `lossRate` | `string` | 未列为必填 | 亏损率。 |
| `expectancy` | `string` | 未列为必填 | 期望收益指标。 |
| `startEquity` | `string` | 未列为必填 | 初始权益。 |
| `endEquity` | `string` | 未列为必填 | 期末权益。 |
| `compoundingAnnualReturn` | `string` | 未列为必填 | 复合年化收益率。 |
| `drawdown` | `string` | 未列为必填 | 最大回撤。 |
| `totalNetProfit` | `string` | 未列为必填 | 净收益百分比。 |
| `sharpeRatio` | `string` | 未列为必填 | 夏普比率，计算口径按该模型。 |
| `probabilisticSharpeRatio` | `string` | 未列为必填 | 估计夏普超过基准的概率。 |
| `sortinoRatio` | `string` | 未列为必填 | 索提诺比率，计算口径按该模型。 |
| `alpha` | `string` | 未列为必填 | 阿尔法。 |
| `beta` | `string` | 未列为必填 | 贝塔。 |
| `annualStandardDeviation` | `string` | 未列为必填 | 年化标准差。 |
| `annualVariance` | `string` | 未列为必填 | 年化方差。 |
| `informationRatio` | `string` | 未列为必填 | 信息比率。 |
| `trackingError` | `string` | 未列为必填 | 跟踪误差。 |
| `treynorRatio` | `string` | 未列为必填 | 特雷诺比率。 |
| `portfolioTurnover` | `string` | 未列为必填 | 组合换手率。 |
| `valueAtRisk99` | `string` | 未列为必填 | 99% 置信的一日 VaR；原文假定正态、使用一年窗口及协方差方法。 |
| `valueAtRisk95` | `string` | 未列为必填 | 95% 置信的一日 VaR；原文假定正态、使用一年窗口及协方差方法。 |
| `drawdownRecovery` | `string` | 未列为必填 | 回撤恢复指标，原文未提供详细定义。 |


原文模型说明：Represents a set of statistics calculated from equity and benchmark samples.

## ReadBacktestChartRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `backtestId` | `string` | 是 | 回测标识。 |
| `name` | `string` | 是 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `count` | `integer` | 是 | 数量；图表请求是数据点数，分析模型是出现次数。 |
| `start` | `integer` | 是 | 分页起点或 Unix 起始时间；本接口专属说明优先。 |
| `end` | `integer` | 是 | 分页终点或 Unix 结束时间；本接口专属说明优先。 |


原文模型说明：Request body to obtain a chart from a backtest.

## ReadBacktestInsightsRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `start` | `integer` | 是 | 分页起点或 Unix 起始时间；本接口专属说明优先。 |
| `end` | `integer` | 是 | 分页终点或 Unix 结束时间；本接口专属说明优先。 |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `backtestId` | `string` | 是 | 回测标识。 |


原文模型说明：Request to read insights from a backtest.

## ReadBacktestLogsRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `backtestId` | `string` | 是 | 回测标识。 |
| `start` | `integer` | 是 | 分页起点或 Unix 起始时间；本接口专属说明优先。 |
| `end` | `integer` | 是 | 分页终点或 Unix 结束时间；本接口专属说明优先。 |
| `query` | `string` | 是 | 不区分大小写的日志过滤词；空字符串或 null 表示全部。 |


原文模型说明：Request to read logs from a backtest.

## ReadBacktestLogsResponse

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `logs` | `array[string]` | 未列为必填 | 编译日志列表。 |
| `length` | `integer` | 未列为必填 | 返回记录数量。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


原文模型说明：Logs from a backtest.

## ReadBacktestOrdersRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `start` | `integer` | 是 | 分页起点或 Unix 起始时间；本接口专属说明优先。 |
| `end` | `integer` | 是 | 分页终点或 Unix 结束时间；本接口专属说明优先。 |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `backtestId` | `string` | 是 | 回测标识。 |


原文模型说明：Request to read orders from a backtest.

## ReadBacktestRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `backtestId` | `string` | 是 | 回测标识。 |


原文模型说明：Request to read a single backtest from a project.

## ReadBacktestTradesRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `start` | `integer` | 是 | 分页起点或 Unix 起始时间；本接口专属说明优先。 |
| `end` | `integer` | 是 | 分页终点或 Unix 结束时间；本接口专属说明优先。 |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `backtestId` | `string` | 是 | 回测标识。 |


原文模型说明：Request to read closed trades from a backtest.

## ReadChartResponse

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `chart` | `Chart` | 未列为必填 | 请求的图表对象。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


原文模型说明：Response with the requested chart from a live algorithm or backtest

## ReadOptimizationRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `optimizationId` | `string` | 是 | 优化任务 ID，或所属优化的标识。 |


原文模型说明：Request to read an optimization from a project.

## ReadOptimizationResponse

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `optimization` | `Optimization` | 未列为必填 | 单个优化对象。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


原文模型说明：Response received when reading an optimization.

## ResearchGuide

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `minutes` | `integer` | 未列为必填 | 用于研究开发的分钟数。 |
| `backtestCount` | `integer` | 未列为必填 | 项目累计回测次数。 |
| `parameters` | `integer` | 未列为必填 | 参数列表；项目配置值与编译检测结果应按模型区分。 |


原文模型说明：A power gauge for backtests, time and parameters to estimate the overfitting risk.

## RestResponse

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


原文模型说明：Base API response class for the QuantConnect API.

## RuntimeStatistics

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `Equity` | `string` | 未列为必填 | 组合总权益。 |
| `Fees` | `string` | 未列为必填 | 交易费用。 |
| `Holdings` | `string` | 未列为必填 | 持仓价值。 |
| `Net Profit` | `string` | 未列为必填 | 净收益。 |
| `Probabilistic Sharpe Ratio` | `string` | 未列为必填 | 概率夏普比率。 |
| `Return` | `string` | 未列为必填 | 收益率。 |
| `Unrealized` | `string` | 未列为必填 | 未实现盈亏。 |
| `Volume` | `string` | 未列为必填 | 总交易量／金额指标，具体单位按模型。 |


## ServerStatistics

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `CPU Usage` | `string` | 未列为必填 | CPU 使用百分比。 |
| `Used RAM (MB)` | `string` | 未列为必填 | 算法已用内存 MB。 |
| `Total RAM (MB)` | `string` | 未列为必填 | 节点可用内存 MB。 |
| `Hostname` | `string` | 未列为必填 | 运行主机名称。 |
| `LEAN Version` | `string` | 未列为必填 | 引擎版本。 |
| `Up Time` | `string` | 未列为必填 | 节点运行时长。 |


## StatisticsResult

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `Total Orders` | `string` | 未列为必填 | 订单总数。 |
| `Average Win` | `string` | 未列为必填 | 盈利交易平均收益率。 |
| `Average Loss` | `string` | 未列为必填 | 亏损交易平均收益率。 |
| `Compounding Annual Return` | `string` | 未列为必填 | 复合年化收益率。 |
| `Drawdown` | `string` | 未列为必填 | 最大回撤。 |
| `Expectancy` | `string` | 未列为必填 | 期望收益指标。 |
| `Start Equity` | `string` | 未列为必填 | 初始权益。 |
| `End Equity` | `string` | 未列为必填 | 期末权益。 |
| `Net Profit` | `string` | 未列为必填 | 净收益。 |
| `Sharpe Ratio` | `string` | 未列为必填 | 夏普比率。 |
| `Sortino Ratio` | `string` | 未列为必填 | 索提诺比率。 |
| `Probabilistic Sharpe Ratio` | `string` | 未列为必填 | 概率夏普比率。 |
| `Loss Rate` | `string` | 未列为必填 | 亏损交易占比。 |
| `Win Rate` | `string` | 未列为必填 | 盈利交易占比。 |
| `Profit-Loss Ratio` | `string` | 未列为必填 | 平均盈利与平均亏损之比。 |
| `Alpha` | `string` | 未列为必填 | 阿尔法指标。 |
| `Beta` | `string` | 未列为必填 | 相对基准的贝塔。 |
| `Annual Standard Deviation` | `string` | 未列为必填 | 年化标准差。 |
| `Annual Variance` | `string` | 未列为必填 | 年化方差。 |
| `Information Ratio` | `string` | 未列为必填 | 信息比率。 |
| `Tracking Error` | `string` | 未列为必填 | 跟踪误差。 |
| `Treynor Ratio` | `string` | 未列为必填 | 特雷诺比率。 |
| `Total Fees` | `string` | 未列为必填 | 费用总额。 |
| `Estimated Strategy Capacity` | `string` | 未列为必填 | 估计策略容量。 |
| `Lowest Capacity Asset` | `string` | 未列为必填 | 限制容量的标的。 |
| `Portfolio Turnover` | `string` | 未列为必填 | 组合换手率。 |
| `Drawdown Recovery` | `string` | 未列为必填 | 回撤恢复指标；原文未给具体说明。 |


原文模型说明：Statistics information sent during the algorithm operations.

## Symbol

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `value` | `string` | 未列为必填 | 参数的值，按模型类型处理。 |
| `id` | `string` | 未列为必填 | 该模型对象的标识符，类型与含义见当前模型。 |
| `permtick` | `string` | 未列为必填 | 标的最初／永久代码。 |


原文模型说明：Represents a unique security identifier. This is made of two components, the unique SID and the Value. The value is the current ticker symbol while the SID is constant over the life of a security.

## TradeStatistics

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `startDateTime` | `['string', 'null'] (date-time)` | 未列为必填 | 第一笔交易的进入时间。 |
| `endDateTime` | `['string', 'null'] (date-time)` | 未列为必填 | 原文描述为第一笔交易退出时间。 |
| `totalNumberOfTrades` | `integer` | 未列为必填 | 总交易数。 |
| `numberOfWinningTrades` | `integer` | 未列为必填 | 盈利交易数。 |
| `numberOfLosingTrades` | `integer` | 未列为必填 | 亏损交易数。 |
| `totalProfitLoss` | `string` | 未列为必填 | 全部交易盈亏合计，币种以模型为准。 |
| `totalProfit` | `string` | 未列为必填 | 盈利交易利润合计。 |
| `totalLoss` | `string` | 未列为必填 | 亏损交易亏损合计。 |
| `largestProfit` | `string` | 未列为必填 | 单笔最大盈利。 |
| `largestLoss` | `string` | 未列为必填 | 单笔最大亏损。 |
| `averageProfitLoss` | `string` | 未列为必填 | 每笔平均盈亏。 |
| `averageProfit` | `string` | 未列为必填 | 盈利交易平均利润。 |
| `averageLoss` | `string` | 未列为必填 | 亏损交易平均亏损；原文个别描述误写 winning。 |
| `averageTradeDuration` | `string` | 未列为必填 | 平均交易持续时间。 |
| `averageWinningTradeDuration` | `string` | 未列为必填 | 盈利交易平均时长。 |
| `averageLosingTradeDuration` | `string` | 未列为必填 | 亏损交易平均时长。 |
| `medianTradeDuration` | `string` | 未列为必填 | 交易时长中位数。 |
| `medianWinningTradeDuration` | `string` | 未列为必填 | 盈利交易时长中位数。 |
| `medianLosingTradeDuration` | `string` | 未列为必填 | 亏损交易时长中位数。 |
| `maxConsecutiveWinningTrades` | `integer` | 未列为必填 | 最多连续盈利次数。 |
| `maxConsecutiveLosingTrades` | `integer` | 未列为必填 | 最多连续亏损次数。 |
| `profitLossRatio` | `string` | 未列为必填 | 平均盈利与平均亏损比。 |
| `winLossRatio` | `string` | 未列为必填 | 盈利次数与亏损次数比。 |
| `winRate` | `string` | 未列为必填 | 胜率。 |
| `lossRate` | `string` | 未列为必填 | 亏损率。 |
| `averageMAE` | `string` | 未列为必填 | 平均最大不利变动 MAE。 |
| `averageMFE` | `string` | 未列为必填 | 平均最大有利变动 MFE；原文描述与 MAE 存在错位。 |
| `largestMAE` | `string` | 未列为必填 | 最大不利变动；原文个别描述与名称错位，须核对引擎定义。 |
| `largestMFE` | `string` | 未列为必填 | 最大有利变动；原文个别描述与名称错位，须核对引擎定义。 |
| `maximumClosedTradeDrawdown` | `string` | 未列为必填 | 已结束交易的最大回撤。 |
| `maximumIntraTradeDrawdown` | `string` | 未列为必填 | 交易内最大回撤。 |
| `profitLossStandardDeviation` | `string` | 未列为必填 | 单笔盈亏标准差。 |
| `profitLossDownsideDeviation` | `string` | 未列为必填 | 单笔盈亏下行偏差。 |
| `profitFactor` | `string` | 未列为必填 | 总盈利与总亏损比。 |
| `sharpeRatio` | `string` | 未列为必填 | 夏普比率，计算口径按该模型。 |
| `sortinoRatio` | `string` | 未列为必填 | 索提诺比率，计算口径按该模型。 |
| `profitToMaxDrawdownRatio` | `string` | 未列为必填 | 总盈亏相对最大已结束交易回撤之比。 |
| `maximumEndTradeDrawdown` | `string` | 未列为必填 | 单笔退出前回吐利润的最大值。 |
| `averageEndTradeDrawdown` | `string` | 未列为必填 | 退出前回吐利润的平均值。 |
| `maximumDrawdownDuration` | `string` | 未列为必填 | 恢复权益高点所需的最长时间。 |
| `totalFees` | `string` | 未列为必填 | 交易费用总额。 |


原文模型说明：A set of statistics calculated from a list of closed trades.

## UpdateBacktestRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `projectId` | `integer` | 是 | 目标项目 ID。 |
| `backtestId` | `string` | 是 | 回测标识。 |
| `name` | `string` | 未列为必填 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |
| `note` | `string` | 未列为必填 | 用户备注。 |


原文模型说明：Request to update a backtest's name or note.

## UpdateOptimizationRequest

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `optimizationId` | `string` | 是 | 优化任务 ID，或所属优化的标识。 |
| `name` | `string` | 是 | 对象名称；具体是项目、文件、分支或参数名，取决于当前模型。 |


原文模型说明：Update the name of an optimization.

## inline_response_200_3

### 请求模式 1

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `progress` | `number` | 未列为必填 | 进度，原文范围 0–1，不是 0–100。 |
| `status` | `string` | 未列为必填 | 任务或订单状态，按当前模型枚举解释。 允许值：`loading`。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |


### 请求模式 2

| 字段 | 类型 | 必填 | 中文含义 |
| --- | --- | --- | --- |
| `chart` | `Chart` | 未列为必填 | 请求的图表对象。 |
| `success` | `boolean` | 未列为必填 | API 业务请求是否成功；不等于仅检查 HTTP 状态码。 |
| `errors` | `array[string]` | 未列为必填 | 业务错误消息列表。 |


## 原始定义

[官方 OpenAPI 源码](https://github.com/QuantConnect/Documentation/blob/697eaf38f1d9b257aabb45e3a3210318276c2212/QuantConnect-Platform-2.0.0.yaml)。本词典不代表实际请求或导出授权。
